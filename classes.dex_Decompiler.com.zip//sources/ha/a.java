package ha;

import a7.c;
import a7.e;
import android.content.Context;
import android.content.Intent;
import java.util.List;
import w6.h;

public abstract class a {
    public static boolean a(Context context) {
        Intent intent = new Intent("android.intent.action.MAIN");
        intent.addCategory("android.intent.category.APP_BROWSER");
        return !context.getPackageManager().queryIntentActivities(intent, 0).isEmpty();
    }

    public static boolean b(Context context) {
        return Boolean.parseBoolean(new r6.a(context).a("dual_auto_scan_support"));
    }

    public static boolean c(Context context) {
        if (!"KR".equalsIgnoreCase(e.f("CountryISO")) || !h.i()) {
            return false;
        }
        List j10 = c.j(context.getPackageManager());
        return (j10 == null ? 0 : j10.size()) > 0;
    }
}
