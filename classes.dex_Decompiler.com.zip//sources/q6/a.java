package q6;

import android.content.Context;
import com.samsung.android.rubin.sdk.common.result.ApiResult;
import com.samsung.android.rubin.sdk.common.result.CommonCode;
import com.samsung.android.rubin.sdk.module.inferenceengine.sleep.RunestoneSleepApi;
import com.samsung.android.rubin.sdk.module.state.RunestoneStateApi;
import com.samsung.android.rubin.sdk.module.state.model.RunestoneState;

public abstract class a {
    public static RunestoneState a(Context context) {
        ApiResult<RunestoneState, CommonCode> runestoneState = new RunestoneStateApi(context).getRunestoneState();
        if (runestoneState instanceof ApiResult.SUCCESS) {
            return runestoneState.toSuccess().getData();
        }
        return null;
    }

    public static boolean b(Context context) {
        return new RunestoneSleepApi(context).isTurnedOn();
    }
}
