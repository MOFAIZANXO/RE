package q6;

import android.content.Context;
import android.util.Log;
import com.samsung.android.rubin.sdk.RunestoneSDK;
import com.samsung.android.rubin.sdk.module.state.model.RunestoneEnableCondition;
import com.samsung.android.rubin.sdk.module.state.model.RunestoneState;
import com.samsung.android.util.SemLog;
import z6.c;

public abstract class b {

    public static /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        public static final /* synthetic */ int[] f9377a;

        /* JADX WARNING: Can't wrap try/catch for region: R(6:0|1|2|3|4|(3:5|6|8)) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        static {
            /*
                com.samsung.android.rubin.sdk.module.state.model.RunestoneEnableCondition[] r0 = com.samsung.android.rubin.sdk.module.state.model.RunestoneEnableCondition.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f9377a = r0
                com.samsung.android.rubin.sdk.module.state.model.RunestoneEnableCondition r1 = com.samsung.android.rubin.sdk.module.state.model.RunestoneEnableCondition.ACCOUNT_NOT_SIGNED_IN     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = f9377a     // Catch:{ NoSuchFieldError -> 0x001d }
                com.samsung.android.rubin.sdk.module.state.model.RunestoneEnableCondition r1 = com.samsung.android.rubin.sdk.module.state.model.RunestoneEnableCondition.USER_NOT_CONSENT_TO_COLLECT_DATA     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                int[] r0 = f9377a     // Catch:{ NoSuchFieldError -> 0x0028 }
                com.samsung.android.rubin.sdk.module.state.model.RunestoneEnableCondition r1 = com.samsung.android.rubin.sdk.module.state.model.RunestoneEnableCondition.OK     // Catch:{ NoSuchFieldError -> 0x0028 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
                r2 = 3
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0028 }
            L_0x0028:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: q6.b.a.<clinit>():void");
        }
    }

    public static int a(Context context) {
        RunestoneState a10 = a.a(context);
        if (a10 != null) {
            RunestoneEnableCondition currentRubinState = a10.getCurrentRubinState();
            Log.i("DC.RunestoneUtils", "runestoneState : " + a10 + ", condition : " + currentRubinState);
            int i10 = a.f9377a[currentRubinState.ordinal()];
            if (i10 == 1 || i10 == 2) {
                return 1;
            }
            if (i10 != 3) {
                return 2;
            }
            return Boolean.TRUE.equals(a10.isEnabledInSupportedApps()) ? 0 : 3;
        }
        Log.w("DC.RunestoneUtils", "RunestoneState is null");
        return -1;
    }

    public static boolean b(Context context) {
        RunestoneState a10 = a.a(context);
        boolean j10 = c.k(context).j();
        Log.i("DC.RunestoneUtils", "runestoneState : " + a10);
        if (j10) {
            Log.w("DC.RunestoneUtils", "Devce runestone Test mode, so return false");
            return false;
        } else if (a10 != null) {
            return Boolean.TRUE.equals(a10.isDeviceRunestoneSupported());
        } else {
            return false;
        }
    }

    public static boolean c(Context context) {
        if (!c.k(context).s()) {
            return a7.b.e("user.owner") && RunestoneSDK.INSTANCE.isRunestonePackageAvailable(context);
        }
        Log.w("DC.RunestoneUtils", "Test mode, so return false");
        return false;
    }

    public static boolean d(Context context) {
        boolean z10 = !a.b(context);
        SemLog.i("DC.RunestoneUtils", "isTurned off result : " + z10);
        return z10;
    }

    public static void e(Context context) {
        RunestoneSDK.INSTANCE.moveToAppsPage(context, "com.android.server.BatteryService", context.getPackageName(), 268435456);
    }

    public static void f(Context context) {
        RunestoneSDK.INSTANCE.moveToMainPage(context, 268435456);
    }

    public static void g(Context context) {
        int a10 = a(context);
        if (a10 == 0 || a10 == 3) {
            e(context);
        } else {
            f(context);
        }
    }
}
