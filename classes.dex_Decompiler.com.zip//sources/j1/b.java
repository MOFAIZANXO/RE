package j1;

import java.lang.reflect.Method;
import kotlin.jvm.internal.l;
import kotlin.jvm.internal.m;

public final class b {

    /* renamed from: a  reason: collision with root package name */
    public final ClassLoader f7423a;

    public static final class a extends m implements ac.a {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ b f7424a;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(b bVar) {
            super(0);
            this.f7424a = bVar;
        }

        /* renamed from: a */
        public final Class invoke() {
            Class<?> loadClass = this.f7424a.f7423a.loadClass("androidx.window.extensions.WindowExtensionsProvider");
            l.d(loadClass, "loader.loadClass(WindowE…XTENSIONS_PROVIDER_CLASS)");
            return loadClass;
        }
    }

    /* renamed from: j1.b$b  reason: collision with other inner class name */
    public static final class C0099b extends m implements ac.a {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ b f7425a;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C0099b(b bVar) {
            super(0);
            this.f7425a = bVar;
        }

        /* renamed from: a */
        public final Boolean invoke() {
            boolean z10 = false;
            Method declaredMethod = this.f7425a.d().getDeclaredMethod("getWindowExtensions", new Class[0]);
            Class c10 = this.f7425a.c();
            m1.a aVar = m1.a.f8117a;
            l.d(declaredMethod, "getWindowExtensionsMethod");
            if (aVar.b(declaredMethod, c10) && aVar.d(declaredMethod)) {
                z10 = true;
            }
            return Boolean.valueOf(z10);
        }
    }

    public b(ClassLoader classLoader) {
        l.e(classLoader, "loader");
        this.f7423a = classLoader;
    }

    public final Class c() {
        Class<?> loadClass = this.f7423a.loadClass("androidx.window.extensions.WindowExtensions");
        l.d(loadClass, "loader.loadClass(WindowE….WINDOW_EXTENSIONS_CLASS)");
        return loadClass;
    }

    public final Class d() {
        Class<?> loadClass = this.f7423a.loadClass("androidx.window.extensions.WindowExtensionsProvider");
        l.d(loadClass, "loader.loadClass(WindowE…XTENSIONS_PROVIDER_CLASS)");
        return loadClass;
    }

    public final boolean e() {
        return m1.a.f8117a.a(new a(this));
    }

    public final boolean f() {
        return e() && m1.a.e("WindowExtensionsProvider#getWindowExtensions is not valid", new C0099b(this));
    }
}
