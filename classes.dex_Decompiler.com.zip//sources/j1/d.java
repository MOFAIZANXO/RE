package j1;

public interface d {
    c a(c cVar);
}
