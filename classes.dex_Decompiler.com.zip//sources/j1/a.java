package j1;

import kotlin.jvm.internal.l;

public final class a implements d {

    /* renamed from: a  reason: collision with root package name */
    public static final a f7422a = new a();

    public c a(c cVar) {
        l.e(cVar, "windowSdkExtensions");
        return cVar;
    }
}
