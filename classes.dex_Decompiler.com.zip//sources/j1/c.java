package j1;

import k1.d;
import kotlin.jvm.internal.g;

public abstract class c {

    /* renamed from: b  reason: collision with root package name */
    public static final a f7426b = new a((g) null);

    /* renamed from: c  reason: collision with root package name */
    public static d f7427c = a.f7422a;

    /* renamed from: a  reason: collision with root package name */
    public final int f7428a = d.f7572a.a();

    public static final class a {

        /* renamed from: j1.c$a$a  reason: collision with other inner class name */
        public static final class C0100a extends c {
        }

        public a() {
        }

        public /* synthetic */ a(g gVar) {
            this();
        }

        public final c a() {
            return c.f7427c.a(new C0100a());
        }
    }

    public int b() {
        return this.f7428a;
    }
}
