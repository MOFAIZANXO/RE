package hb;

import android.content.Context;
import android.text.TextUtils;
import android.util.Log;

public abstract class a {

    /* renamed from: a  reason: collision with root package name */
    public static String f7000a = "";

    /* renamed from: b  reason: collision with root package name */
    public static c f7001b;

    public static int a(String str) {
        c cVar = f7001b;
        return cVar == null ? Log.d("DIAGMON_SDK", str) : cVar.d(f7000a, str);
    }

    public static int b(String str) {
        c cVar = f7001b;
        return cVar == null ? Log.e("DIAGMON_SDK", str) : cVar.c(f7000a, str);
    }

    public static int c(String str) {
        c cVar = f7001b;
        return cVar == null ? Log.i("DIAGMON_SDK", str) : cVar.b(f7000a, str);
    }

    public static void d(Context context, String str) {
        try {
            if (f7001b == null && context != null && !TextUtils.isEmpty(str)) {
                f7000a = str;
                f7001b = new b();
            }
        } catch (Exception e10) {
            Log.e("DIAGMON_SDK", e10.getMessage());
        }
    }

    public static int e(String str) {
        c cVar = f7001b;
        return cVar == null ? Log.w("DIAGMON_SDK", str) : cVar.a(f7000a, str);
    }
}
