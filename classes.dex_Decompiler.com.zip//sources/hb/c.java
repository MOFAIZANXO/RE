package hb;

public interface c {
    int a(String str, String str2);

    int b(String str, String str2);

    int c(String str, String str2);

    int d(String str, String str2);
}
