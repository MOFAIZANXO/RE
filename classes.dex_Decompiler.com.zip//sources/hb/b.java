package hb;

import android.util.Log;

public class b implements c {

    /* renamed from: a  reason: collision with root package name */
    public String f7002a;

    public int a(String str, String str2) {
        try {
            e(str);
            return Log.w("DIAGMON_SDK" + this.f7002a, str2);
        } catch (Exception e10) {
            Log.e("DIAGMON_SDK", e10.getMessage());
            return -1;
        }
    }

    public int b(String str, String str2) {
        try {
            e(str);
            return Log.i("DIAGMON_SDK" + this.f7002a, str2);
        } catch (Exception e10) {
            Log.e("DIAGMON_SDK", e10.getMessage());
            return -1;
        }
    }

    public int c(String str, String str2) {
        try {
            e(str);
            return Log.e("DIAGMON_SDK" + this.f7002a, str2);
        } catch (Exception e10) {
            Log.e("DIAGMON_SDK", e10.getMessage());
            return -1;
        }
    }

    public int d(String str, String str2) {
        try {
            e(str);
            return Log.d("DIAGMON_SDK" + this.f7002a, str2);
        } catch (Exception e10) {
            Log.e("DIAGMON_SDK", e10.getMessage());
            return -1;
        }
    }

    public final void e(String str) {
        this.f7002a = "[" + ra.b.f9595a + "]" + "[" + str + "]" + " ";
    }
}
