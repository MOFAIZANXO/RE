package i;

import java.util.Locale;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReferenceFieldUpdater;
import java.util.concurrent.locks.LockSupport;
import java.util.logging.Level;
import java.util.logging.Logger;

public abstract class a implements u3.a {

    /* renamed from: g  reason: collision with root package name */
    public static final boolean f7111g = Boolean.parseBoolean(System.getProperty("guava.concurrent.generate_cancellation_cause", "false"));

    /* renamed from: h  reason: collision with root package name */
    public static final Logger f7112h;

    /* renamed from: i  reason: collision with root package name */
    public static final b f7113i;

    /* renamed from: j  reason: collision with root package name */
    public static final Object f7114j = new Object();

    /* renamed from: a  reason: collision with root package name */
    public volatile Object f7115a;

    /* renamed from: b  reason: collision with root package name */
    public volatile e f7116b;

    /* renamed from: f  reason: collision with root package name */
    public volatile h f7117f;

    public static abstract class b {
        public b() {
        }

        public abstract boolean a(a aVar, e eVar, e eVar2);

        public abstract boolean b(a aVar, Object obj, Object obj2);

        public abstract boolean c(a aVar, h hVar, h hVar2);

        public abstract void d(h hVar, h hVar2);

        public abstract void e(h hVar, Thread thread);
    }

    public static final class c {

        /* renamed from: c  reason: collision with root package name */
        public static final c f7118c;

        /* renamed from: d  reason: collision with root package name */
        public static final c f7119d;

        /* renamed from: a  reason: collision with root package name */
        public final boolean f7120a;

        /* renamed from: b  reason: collision with root package name */
        public final Throwable f7121b;

        static {
            if (a.f7111g) {
                f7119d = null;
                f7118c = null;
                return;
            }
            f7119d = new c(false, (Throwable) null);
            f7118c = new c(true, (Throwable) null);
        }

        public c(boolean z10, Throwable th) {
            this.f7120a = z10;
            this.f7121b = th;
        }
    }

    public static final class d {

        /* renamed from: a  reason: collision with root package name */
        public final Throwable f7122a;
    }

    public static final class e {

        /* renamed from: d  reason: collision with root package name */
        public static final e f7123d = new e((Runnable) null, (Executor) null);

        /* renamed from: a  reason: collision with root package name */
        public final Runnable f7124a;

        /* renamed from: b  reason: collision with root package name */
        public final Executor f7125b;

        /* renamed from: c  reason: collision with root package name */
        public e f7126c;

        public e(Runnable runnable, Executor executor) {
            this.f7124a = runnable;
            this.f7125b = executor;
        }
    }

    public static final class f extends b {

        /* renamed from: a  reason: collision with root package name */
        public final AtomicReferenceFieldUpdater f7127a;

        /* renamed from: b  reason: collision with root package name */
        public final AtomicReferenceFieldUpdater f7128b;

        /* renamed from: c  reason: collision with root package name */
        public final AtomicReferenceFieldUpdater f7129c;

        /* renamed from: d  reason: collision with root package name */
        public final AtomicReferenceFieldUpdater f7130d;

        /* renamed from: e  reason: collision with root package name */
        public final AtomicReferenceFieldUpdater f7131e;

        public f(AtomicReferenceFieldUpdater atomicReferenceFieldUpdater, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater2, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater3, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater4, AtomicReferenceFieldUpdater atomicReferenceFieldUpdater5) {
            super();
            this.f7127a = atomicReferenceFieldUpdater;
            this.f7128b = atomicReferenceFieldUpdater2;
            this.f7129c = atomicReferenceFieldUpdater3;
            this.f7130d = atomicReferenceFieldUpdater4;
            this.f7131e = atomicReferenceFieldUpdater5;
        }

        public boolean a(a aVar, e eVar, e eVar2) {
            return b.a(this.f7130d, aVar, eVar, eVar2);
        }

        public boolean b(a aVar, Object obj, Object obj2) {
            return b.a(this.f7131e, aVar, obj, obj2);
        }

        public boolean c(a aVar, h hVar, h hVar2) {
            return b.a(this.f7129c, aVar, hVar, hVar2);
        }

        public void d(h hVar, h hVar2) {
            this.f7128b.lazySet(hVar, hVar2);
        }

        public void e(h hVar, Thread thread) {
            this.f7127a.lazySet(hVar, thread);
        }
    }

    public static final class g extends b {
        public g() {
            super();
        }

        public boolean a(a aVar, e eVar, e eVar2) {
            synchronized (aVar) {
                if (aVar.f7116b != eVar) {
                    return false;
                }
                aVar.f7116b = eVar2;
                return true;
            }
        }

        public boolean b(a aVar, Object obj, Object obj2) {
            synchronized (aVar) {
                if (aVar.f7115a != obj) {
                    return false;
                }
                aVar.f7115a = obj2;
                return true;
            }
        }

        public boolean c(a aVar, h hVar, h hVar2) {
            synchronized (aVar) {
                if (aVar.f7117f != hVar) {
                    return false;
                }
                aVar.f7117f = hVar2;
                return true;
            }
        }

        public void d(h hVar, h hVar2) {
            hVar.f7134b = hVar2;
        }

        public void e(h hVar, Thread thread) {
            hVar.f7133a = thread;
        }
    }

    public static final class h {

        /* renamed from: c  reason: collision with root package name */
        public static final h f7132c = new h(false);

        /* renamed from: a  reason: collision with root package name */
        public volatile Thread f7133a;

        /* renamed from: b  reason: collision with root package name */
        public volatile h f7134b;

        public h(boolean z10) {
        }

        public void a(h hVar) {
            a.f7113i.d(this, hVar);
        }

        public void b() {
            Thread thread = this.f7133a;
            if (thread != null) {
                this.f7133a = null;
                LockSupport.unpark(thread);
            }
        }

        public h() {
            a.f7113i.e(this, Thread.currentThread());
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v3, resolved type: i.a$f} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v5, resolved type: i.a$g} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r2v6, resolved type: i.a$f} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v7, resolved type: i.a$f} */
    /* JADX WARNING: Multi-variable type inference failed */
    static {
        /*
            java.lang.Class<i.a$h> r0 = i.a.h.class
            java.lang.String r1 = "guava.concurrent.generate_cancellation_cause"
            java.lang.String r2 = "false"
            java.lang.String r1 = java.lang.System.getProperty(r1, r2)
            boolean r1 = java.lang.Boolean.parseBoolean(r1)
            f7111g = r1
            java.lang.Class<i.a> r1 = i.a.class
            java.lang.String r2 = r1.getName()
            java.util.logging.Logger r2 = java.util.logging.Logger.getLogger(r2)
            f7112h = r2
            i.a$f r2 = new i.a$f     // Catch:{ all -> 0x0048 }
            java.lang.Class<java.lang.Thread> r3 = java.lang.Thread.class
            java.lang.String r4 = "a"
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r4 = java.util.concurrent.atomic.AtomicReferenceFieldUpdater.newUpdater(r0, r3, r4)     // Catch:{ all -> 0x0048 }
            java.lang.String r3 = "b"
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r5 = java.util.concurrent.atomic.AtomicReferenceFieldUpdater.newUpdater(r0, r0, r3)     // Catch:{ all -> 0x0048 }
            java.lang.String r3 = "f"
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r6 = java.util.concurrent.atomic.AtomicReferenceFieldUpdater.newUpdater(r1, r0, r3)     // Catch:{ all -> 0x0048 }
            java.lang.Class<i.a$e> r0 = i.a.e.class
            java.lang.String r3 = "b"
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r7 = java.util.concurrent.atomic.AtomicReferenceFieldUpdater.newUpdater(r1, r0, r3)     // Catch:{ all -> 0x0048 }
            java.lang.Class<java.lang.Object> r0 = java.lang.Object.class
            java.lang.String r3 = "a"
            java.util.concurrent.atomic.AtomicReferenceFieldUpdater r8 = java.util.concurrent.atomic.AtomicReferenceFieldUpdater.newUpdater(r1, r0, r3)     // Catch:{ all -> 0x0048 }
            r3 = r2
            r3.<init>(r4, r5, r6, r7, r8)     // Catch:{ all -> 0x0048 }
            r0 = 0
            goto L_0x004e
        L_0x0048:
            r0 = move-exception
            i.a$g r2 = new i.a$g
            r2.<init>()
        L_0x004e:
            f7113i = r2
            if (r0 == 0) goto L_0x005b
            java.util.logging.Logger r1 = f7112h
            java.util.logging.Level r2 = java.util.logging.Level.SEVERE
            java.lang.String r3 = "SafeAtomicHelper is broken!"
            r1.log(r2, r3, r0)
        L_0x005b:
            java.lang.Object r0 = new java.lang.Object
            r0.<init>()
            f7114j = r0
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: i.a.<clinit>():void");
    }

    public static CancellationException d(String str, Throwable th) {
        CancellationException cancellationException = new CancellationException(str);
        cancellationException.initCause(th);
        return cancellationException;
    }

    public static Object e(Object obj) {
        obj.getClass();
        return obj;
    }

    public static void g(a aVar) {
        aVar.m();
        aVar.c();
        e f10 = aVar.f((e) null);
        while (f10 != null) {
            e eVar = f10.f7126c;
            h(f10.f7124a, f10.f7125b);
            f10 = eVar;
        }
    }

    public static void h(Runnable runnable, Executor executor) {
        try {
            executor.execute(runnable);
        } catch (RuntimeException e10) {
            Logger logger = f7112h;
            Level level = Level.SEVERE;
            logger.log(level, "RuntimeException while executing runnable " + runnable + " with executor " + executor, e10);
        }
    }

    public static Object j(Future future) {
        Object obj;
        boolean z10 = false;
        while (true) {
            try {
                obj = future.get();
                break;
            } catch (InterruptedException unused) {
                z10 = true;
            } catch (Throwable th) {
                if (z10) {
                    Thread.currentThread().interrupt();
                }
                throw th;
            }
        }
        if (z10) {
            Thread.currentThread().interrupt();
        }
        return obj;
    }

    public final void a(Runnable runnable, Executor executor) {
        e(runnable);
        e(executor);
        e eVar = this.f7116b;
        if (eVar != e.f7123d) {
            e eVar2 = new e(runnable, executor);
            do {
                eVar2.f7126c = eVar;
                if (!f7113i.a(this, eVar, eVar2)) {
                    eVar = this.f7116b;
                } else {
                    return;
                }
            } while (eVar != e.f7123d);
        }
        h(runnable, executor);
    }

    public final void b(StringBuilder sb2) {
        try {
            Object j10 = j(this);
            sb2.append("SUCCESS, result=[");
            sb2.append(p(j10));
            sb2.append("]");
        } catch (ExecutionException e10) {
            sb2.append("FAILURE, cause=[");
            sb2.append(e10.getCause());
            sb2.append("]");
        } catch (CancellationException unused) {
            sb2.append("CANCELLED");
        } catch (RuntimeException e11) {
            sb2.append("UNKNOWN, cause=[");
            sb2.append(e11.getClass());
            sb2.append(" thrown from get()]");
        }
    }

    public void c() {
    }

    public final boolean cancel(boolean z10) {
        Object obj = this.f7115a;
        if ((obj == null) || false) {
            if (f7113i.b(this, obj, f7111g ? new c(z10, new CancellationException("Future.cancel() was called.")) : z10 ? c.f7118c : c.f7119d)) {
                if (z10) {
                    k();
                }
                g(this);
                return true;
            }
        }
        return false;
    }

    public final e f(e eVar) {
        e eVar2;
        do {
            eVar2 = this.f7116b;
        } while (!f7113i.a(this, eVar2, e.f7123d));
        while (true) {
            e eVar3 = eVar;
            eVar = eVar2;
            if (eVar == null) {
                return eVar3;
            }
            eVar2 = eVar.f7126c;
            eVar.f7126c = eVar3;
        }
    }

    public final Object get(long j10, TimeUnit timeUnit) {
        long j11 = j10;
        TimeUnit timeUnit2 = timeUnit;
        long nanos = timeUnit2.toNanos(j11);
        if (!Thread.interrupted()) {
            Object obj = this.f7115a;
            if ((obj != null) && true) {
                return i(obj);
            }
            long nanoTime = nanos > 0 ? System.nanoTime() + nanos : 0;
            if (nanos >= 1000) {
                h hVar = this.f7117f;
                if (hVar != h.f7132c) {
                    h hVar2 = new h();
                    do {
                        hVar2.a(hVar);
                        if (f7113i.c(this, hVar, hVar2)) {
                            do {
                                LockSupport.parkNanos(this, nanos);
                                if (!Thread.interrupted()) {
                                    Object obj2 = this.f7115a;
                                    if ((obj2 != null) && true) {
                                        return i(obj2);
                                    }
                                    nanos = nanoTime - System.nanoTime();
                                } else {
                                    n(hVar2);
                                    throw new InterruptedException();
                                }
                            } while (nanos >= 1000);
                            n(hVar2);
                        } else {
                            hVar = this.f7117f;
                        }
                    } while (hVar != h.f7132c);
                }
                return i(this.f7115a);
            }
            while (nanos > 0) {
                Object obj3 = this.f7115a;
                if ((obj3 != null) && true) {
                    return i(obj3);
                }
                if (!Thread.interrupted()) {
                    nanos = nanoTime - System.nanoTime();
                } else {
                    throw new InterruptedException();
                }
            }
            String aVar = toString();
            String obj4 = timeUnit.toString();
            Locale locale = Locale.ROOT;
            String lowerCase = obj4.toLowerCase(locale);
            String str = "Waited " + j11 + " " + timeUnit.toString().toLowerCase(locale);
            if (nanos + 1000 < 0) {
                String str2 = str + " (plus ";
                long j12 = -nanos;
                long convert = timeUnit2.convert(j12, TimeUnit.NANOSECONDS);
                long nanos2 = j12 - timeUnit2.toNanos(convert);
                int i10 = (convert > 0 ? 1 : (convert == 0 ? 0 : -1));
                boolean z10 = i10 == 0 || nanos2 > 1000;
                if (i10 > 0) {
                    String str3 = str2 + convert + " " + lowerCase;
                    if (z10) {
                        str3 = str3 + ",";
                    }
                    str2 = str3 + " ";
                }
                if (z10) {
                    str2 = str2 + nanos2 + " nanoseconds ";
                }
                str = str2 + "delay)";
            }
            if (isDone()) {
                throw new TimeoutException(str + " but future completed as timeout expired");
            }
            throw new TimeoutException(str + " for " + aVar);
        }
        throw new InterruptedException();
    }

    public final Object i(Object obj) {
        if (obj instanceof c) {
            throw d("Task was cancelled.", ((c) obj).f7121b);
        } else if (obj instanceof d) {
            throw new ExecutionException(((d) obj).f7122a);
        } else if (obj == f7114j) {
            return null;
        } else {
            return obj;
        }
    }

    public final boolean isCancelled() {
        return this.f7115a instanceof c;
    }

    public final boolean isDone() {
        return (this.f7115a != null) & true;
    }

    public void k() {
    }

    public String l() {
        if (!(this instanceof ScheduledFuture)) {
            return null;
        }
        return "remaining delay=[" + ((ScheduledFuture) this).getDelay(TimeUnit.MILLISECONDS) + " ms]";
    }

    public final void m() {
        h hVar;
        do {
            hVar = this.f7117f;
        } while (!f7113i.c(this, hVar, h.f7132c));
        while (hVar != null) {
            hVar.b();
            hVar = hVar.f7134b;
        }
    }

    public final void n(h hVar) {
        hVar.f7133a = null;
        while (true) {
            h hVar2 = this.f7117f;
            if (hVar2 != h.f7132c) {
                h hVar3 = null;
                while (hVar2 != null) {
                    h hVar4 = hVar2.f7134b;
                    if (hVar2.f7133a != null) {
                        hVar3 = hVar2;
                    } else if (hVar3 != null) {
                        hVar3.f7134b = hVar4;
                        if (hVar3.f7133a == null) {
                        }
                    } else if (!f7113i.c(this, hVar2, hVar4)) {
                    }
                    hVar2 = hVar4;
                }
                return;
            }
            return;
        }
    }

    public boolean o(Object obj) {
        if (obj == null) {
            obj = f7114j;
        }
        if (!f7113i.b(this, (Object) null, obj)) {
            return false;
        }
        g(this);
        return true;
    }

    public final String p(Object obj) {
        return obj == this ? "this future" : String.valueOf(obj);
    }

    public String toString() {
        String str;
        StringBuilder sb2 = new StringBuilder();
        sb2.append(super.toString());
        sb2.append("[status=");
        if (isCancelled()) {
            sb2.append("CANCELLED");
        } else if (isDone()) {
            b(sb2);
        } else {
            try {
                str = l();
            } catch (RuntimeException e10) {
                str = "Exception thrown from implementation: " + e10.getClass();
            }
            if (str != null && !str.isEmpty()) {
                sb2.append("PENDING, info=[");
                sb2.append(str);
                sb2.append("]");
            } else if (isDone()) {
                b(sb2);
            } else {
                sb2.append("PENDING");
            }
        }
        sb2.append("]");
        return sb2.toString();
    }

    public final Object get() {
        Object obj;
        if (!Thread.interrupted()) {
            Object obj2 = this.f7115a;
            if ((obj2 != null) && true) {
                return i(obj2);
            }
            h hVar = this.f7117f;
            if (hVar != h.f7132c) {
                h hVar2 = new h();
                do {
                    hVar2.a(hVar);
                    if (f7113i.c(this, hVar, hVar2)) {
                        do {
                            LockSupport.park(this);
                            if (!Thread.interrupted()) {
                                obj = this.f7115a;
                            } else {
                                n(hVar2);
                                throw new InterruptedException();
                            }
                        } while (!((obj != null) & true));
                        return i(obj);
                    }
                    hVar = this.f7117f;
                } while (hVar != h.f7132c);
            }
            return i(this.f7115a);
        }
        throw new InterruptedException();
    }
}
