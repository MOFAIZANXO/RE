package i;

public final class c extends a {
    public static c q() {
        return new c();
    }

    public boolean o(Object obj) {
        return super.o(obj);
    }
}
