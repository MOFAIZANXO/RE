package n3;

public abstract class e {

    /* renamed from: a  reason: collision with root package name */
    public static boolean f8455a;

    public static boolean a() {
        return f8455a;
    }
}
