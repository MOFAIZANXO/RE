package n3;

import android.graphics.Typeface;

public final class a extends f {

    /* renamed from: a  reason: collision with root package name */
    public final Typeface f8429a;

    /* renamed from: b  reason: collision with root package name */
    public final C0115a f8430b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f8431c;

    /* renamed from: n3.a$a  reason: collision with other inner class name */
    public interface C0115a {
        void a(Typeface typeface);
    }

    public a(C0115a aVar, Typeface typeface) {
        this.f8429a = typeface;
        this.f8430b = aVar;
    }

    public void a(int i10) {
        d(this.f8429a);
    }

    public void b(Typeface typeface, boolean z10) {
        d(typeface);
    }

    public void c() {
        this.f8431c = true;
    }

    public final void d(Typeface typeface) {
        if (!this.f8431c) {
            this.f8430b.a(typeface);
        }
    }
}
