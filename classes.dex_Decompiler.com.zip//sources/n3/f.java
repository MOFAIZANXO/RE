package n3;

import android.graphics.Typeface;

public abstract class f {
    public abstract void a(int i10);

    public abstract void b(Typeface typeface, boolean z10);
}
