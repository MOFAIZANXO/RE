package n3;

import a3.l;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Typeface;
import android.os.Handler;
import android.text.TextPaint;
import android.util.Log;
import androidx.appcompat.R;
import androidx.core.content.res.ResourcesCompat;
import androidx.core.view.ViewCompat;

public class d {

    /* renamed from: a  reason: collision with root package name */
    public final ColorStateList f8432a;

    /* renamed from: b  reason: collision with root package name */
    public final ColorStateList f8433b;

    /* renamed from: c  reason: collision with root package name */
    public final ColorStateList f8434c;

    /* renamed from: d  reason: collision with root package name */
    public final String f8435d;

    /* renamed from: e  reason: collision with root package name */
    public final int f8436e;

    /* renamed from: f  reason: collision with root package name */
    public final int f8437f;

    /* renamed from: g  reason: collision with root package name */
    public final boolean f8438g;

    /* renamed from: h  reason: collision with root package name */
    public final float f8439h;

    /* renamed from: i  reason: collision with root package name */
    public final float f8440i;

    /* renamed from: j  reason: collision with root package name */
    public final float f8441j;

    /* renamed from: k  reason: collision with root package name */
    public final boolean f8442k;

    /* renamed from: l  reason: collision with root package name */
    public final float f8443l;

    /* renamed from: m  reason: collision with root package name */
    public ColorStateList f8444m;

    /* renamed from: n  reason: collision with root package name */
    public float f8445n;

    /* renamed from: o  reason: collision with root package name */
    public final int f8446o;

    /* renamed from: p  reason: collision with root package name */
    public boolean f8447p = false;

    /* renamed from: q  reason: collision with root package name */
    public Typeface f8448q;

    public class a extends ResourcesCompat.FontCallback {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ f f8449a;

        public a(f fVar) {
            this.f8449a = fVar;
        }

        public void onFontRetrievalFailed(int i10) {
            boolean unused = d.this.f8447p = true;
            this.f8449a.a(i10);
        }

        public void onFontRetrieved(Typeface typeface) {
            d dVar = d.this;
            Typeface unused = dVar.f8448q = Typeface.create(typeface, dVar.f8436e);
            boolean unused2 = d.this.f8447p = true;
            this.f8449a.b(d.this.f8448q, false);
        }
    }

    public class b extends f {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ Context f8451a;

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ TextPaint f8452b;

        /* renamed from: c  reason: collision with root package name */
        public final /* synthetic */ f f8453c;

        public b(Context context, TextPaint textPaint, f fVar) {
            this.f8451a = context;
            this.f8452b = textPaint;
            this.f8453c = fVar;
        }

        public void a(int i10) {
            this.f8453c.a(i10);
        }

        public void b(Typeface typeface, boolean z10) {
            d.this.p(this.f8451a, this.f8452b, typeface);
            this.f8453c.b(typeface, z10);
        }
    }

    public d(Context context, int i10) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(i10, R.styleable.TextAppearance);
        l(obtainStyledAttributes.getDimension(R.styleable.TextAppearance_android_textSize, 0.0f));
        k(c.a(context, obtainStyledAttributes, R.styleable.TextAppearance_android_textColor));
        this.f8432a = c.a(context, obtainStyledAttributes, R.styleable.TextAppearance_android_textColorHint);
        this.f8433b = c.a(context, obtainStyledAttributes, R.styleable.TextAppearance_android_textColorLink);
        this.f8436e = obtainStyledAttributes.getInt(R.styleable.TextAppearance_android_textStyle, 0);
        this.f8437f = obtainStyledAttributes.getInt(R.styleable.TextAppearance_android_typeface, 1);
        int f10 = c.f(obtainStyledAttributes, R.styleable.TextAppearance_fontFamily, R.styleable.TextAppearance_android_fontFamily);
        this.f8446o = obtainStyledAttributes.getResourceId(f10, 0);
        this.f8435d = obtainStyledAttributes.getString(f10);
        this.f8438g = obtainStyledAttributes.getBoolean(R.styleable.TextAppearance_textAllCaps, false);
        this.f8434c = c.a(context, obtainStyledAttributes, R.styleable.TextAppearance_android_shadowColor);
        this.f8439h = obtainStyledAttributes.getFloat(R.styleable.TextAppearance_android_shadowDx, 0.0f);
        this.f8440i = obtainStyledAttributes.getFloat(R.styleable.TextAppearance_android_shadowDy, 0.0f);
        this.f8441j = obtainStyledAttributes.getFloat(R.styleable.TextAppearance_android_shadowRadius, 0.0f);
        obtainStyledAttributes.recycle();
        TypedArray obtainStyledAttributes2 = context.obtainStyledAttributes(i10, l.MaterialTextAppearance);
        int i11 = l.MaterialTextAppearance_android_letterSpacing;
        this.f8442k = obtainStyledAttributes2.hasValue(i11);
        this.f8443l = obtainStyledAttributes2.getFloat(i11, 0.0f);
        obtainStyledAttributes2.recycle();
    }

    public final void d() {
        String str;
        if (this.f8448q == null && (str = this.f8435d) != null) {
            this.f8448q = Typeface.create(str, this.f8436e);
        }
        if (this.f8448q == null) {
            int i10 = this.f8437f;
            if (i10 == 1) {
                this.f8448q = Typeface.SANS_SERIF;
            } else if (i10 == 2) {
                this.f8448q = Typeface.SERIF;
            } else if (i10 != 3) {
                this.f8448q = Typeface.DEFAULT;
            } else {
                this.f8448q = Typeface.MONOSPACE;
            }
            this.f8448q = Typeface.create(this.f8448q, this.f8436e);
        }
    }

    public Typeface e() {
        d();
        return this.f8448q;
    }

    public Typeface f(Context context) {
        if (this.f8447p) {
            return this.f8448q;
        }
        if (!context.isRestricted()) {
            try {
                Typeface font = ResourcesCompat.getFont(context, this.f8446o);
                this.f8448q = font;
                if (font != null) {
                    this.f8448q = Typeface.create(font, this.f8436e);
                }
            } catch (Resources.NotFoundException | UnsupportedOperationException unused) {
            } catch (Exception e10) {
                Log.d("TextAppearance", "Error loading font " + this.f8435d, e10);
            }
        }
        d();
        this.f8447p = true;
        return this.f8448q;
    }

    public void g(Context context, TextPaint textPaint, f fVar) {
        p(context, textPaint, e());
        h(context, new b(context, textPaint, fVar));
    }

    public void h(Context context, f fVar) {
        if (m(context)) {
            f(context);
        } else {
            d();
        }
        int i10 = this.f8446o;
        if (i10 == 0) {
            this.f8447p = true;
        }
        if (this.f8447p) {
            fVar.b(this.f8448q, true);
            return;
        }
        try {
            ResourcesCompat.getFont(context, i10, new a(fVar), (Handler) null);
        } catch (Resources.NotFoundException unused) {
            this.f8447p = true;
            fVar.a(1);
        } catch (Exception e10) {
            Log.d("TextAppearance", "Error loading font " + this.f8435d, e10);
            this.f8447p = true;
            fVar.a(-3);
        }
    }

    public ColorStateList i() {
        return this.f8444m;
    }

    public float j() {
        return this.f8445n;
    }

    public void k(ColorStateList colorStateList) {
        this.f8444m = colorStateList;
    }

    public void l(float f10) {
        this.f8445n = f10;
    }

    public final boolean m(Context context) {
        if (e.a()) {
            return true;
        }
        int i10 = this.f8446o;
        return (i10 != 0 ? ResourcesCompat.getCachedFont(context, i10) : null) != null;
    }

    public void n(Context context, TextPaint textPaint, f fVar) {
        o(context, textPaint, fVar);
        ColorStateList colorStateList = this.f8444m;
        textPaint.setColor(colorStateList != null ? colorStateList.getColorForState(textPaint.drawableState, colorStateList.getDefaultColor()) : ViewCompat.MEASURED_STATE_MASK);
        float f10 = this.f8441j;
        float f11 = this.f8439h;
        float f12 = this.f8440i;
        ColorStateList colorStateList2 = this.f8434c;
        textPaint.setShadowLayer(f10, f11, f12, colorStateList2 != null ? colorStateList2.getColorForState(textPaint.drawableState, colorStateList2.getDefaultColor()) : 0);
    }

    public void o(Context context, TextPaint textPaint, f fVar) {
        if (m(context)) {
            p(context, textPaint, f(context));
        } else {
            g(context, textPaint, fVar);
        }
    }

    public void p(Context context, TextPaint textPaint, Typeface typeface) {
        Typeface a10 = h.a(context, typeface);
        if (a10 != null) {
            typeface = a10;
        }
        textPaint.setTypeface(typeface);
        int i10 = this.f8436e & (~typeface.getStyle());
        textPaint.setFakeBoldText((i10 & 1) != 0);
        textPaint.setTextSkewX((i10 & 2) != 0 ? -0.25f : 0.0f);
        textPaint.setTextSize(this.f8445n);
        if (this.f8442k) {
            textPaint.setLetterSpacing(this.f8443l);
        }
    }
}
