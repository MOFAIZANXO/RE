package n3;

public abstract /* synthetic */ class g {
}
