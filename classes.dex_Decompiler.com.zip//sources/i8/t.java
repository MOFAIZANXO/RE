package i8;

import a7.e;
import a7.f;
import android.content.Context;
import w6.l;

public abstract class t {

    /* renamed from: b  reason: collision with root package name */
    public static String f7277b = "PowerModeDisable";

    /* renamed from: a  reason: collision with root package name */
    public Context f7278a;

    public t(Context context) {
        this.f7278a = context;
    }

    public abstract String a(int i10);

    public abstract int b();

    public abstract int c();

    public boolean d(Context context) {
        return f.h(context, false);
    }

    public boolean e(Context context) {
        return l.b(context);
    }

    public boolean f(int i10) {
        return i10 == c();
    }

    public boolean g(Context context) {
        return e.u(context, false);
    }
}
