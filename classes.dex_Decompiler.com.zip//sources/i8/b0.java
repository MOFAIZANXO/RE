package i8;

import android.content.Context;
import android.net.Uri;
import android.util.Log;
import android.util.SparseIntArray;
import com.samsung.android.feature.SemFloatingFeature;
import com.samsung.android.util.SemLog;
import l8.g;
import o6.a;

public class b0 extends p {

    /* renamed from: e  reason: collision with root package name */
    public final int f7233e;

    /* renamed from: f  reason: collision with root package name */
    public final a f7234f;

    /* renamed from: g  reason: collision with root package name */
    public final Context f7235g;

    public b0(Context context, int i10) {
        super(context);
        this.f7235g = context;
        this.f7233e = i10;
        this.f7234f = new a(context);
        y();
    }

    public final String A(boolean z10, int i10, int i11, boolean z11, boolean z12) {
        return z(z10, i10, i11) + ", isWQHD : " + z11 + ", canSetHighRefreshRateAboveWQHD : " + z12;
    }

    public final void B(int i10, int i11) {
        this.f7234f.n("sem_power_mode_refresh_rate_cover", i10, i11, -1, i10);
    }

    public void C(int i10) {
        SemLog.d("PowerModeRefreshRateCover", "- setSettingValue : " + i10);
        this.f7234f.r("refresh_rate_mode_cover", i10);
    }

    public int f() {
        return 0;
    }

    public int h() {
        int f10 = this.f7234f.f("refresh_rate_mode_cover");
        return f10 == -1 ? f() : f10;
    }

    public Uri i() {
        return null;
    }

    public boolean k() {
        return true;
    }

    public boolean l() {
        return SemFloatingFeature.getInstance().getInt("SEC_FLOATING_FEATURE_LCD_CONFIG_SUB_HFR_MODE") > 0;
    }

    public boolean m() {
        return false;
    }

    public String p() {
        return null;
    }

    public void q() {
        this.f7234f.n("sem_power_mode_refresh_rate_cover", -1, 0, -1, -1);
    }

    public void r(int i10) {
    }

    public void s(boolean z10) {
    }

    public void v() {
        int x10 = x(0);
        boolean c10 = g.c(this.f7235g);
        boolean a10 = g.a(this.f7235g);
        Log.d("PowerModeRefreshRateCover", "turn off, cover refresh rate to be restored : " + x10 + ", canSetRefreshRateAboveWQHD : " + a10 + ", isWideQuadHd : " + c10);
        h7.a aVar = new h7.a(this.f7235g);
        aVar.c("refresh_rate_mode_cover", A(false, h(), x10, c10, a10), System.currentTimeMillis());
        if (a10 || !c10) {
            aVar.c("refresh_rate_mode_cover", "restore refresh rate successfully", System.currentTimeMillis());
            C(x10);
            return;
        }
        aVar.c("refresh_rate_mode_cover", "WQHD and it is not support high refresh rate with WQHD, skip it", System.currentTimeMillis());
    }

    public void w() {
        int h10 = h();
        Log.d("PowerModeRefreshRateCover", "turn on, current cover refresh rate : " + h10);
        new h7.a(this.f7235g).c("refresh_rate_mode_cover", z(true, h10, 0), System.currentTimeMillis());
        B(h10, 0);
        C(0);
    }

    public final int x(int i10) {
        return this.f7234f.a("sem_power_mode_refresh_rate_cover", i10);
    }

    public final void y() {
        if (this.f7234f.a("sem_power_mode_refresh_rate_cover", 0) == -1) {
            SemLog.d("PowerModeRefreshRateCover", "need to init : sem_power_mode_refresh_rate_cover");
            SparseIntArray sparseIntArray = new SparseIntArray();
            sparseIntArray.append(1, 0);
            sparseIntArray.append(2, 0);
            sparseIntArray.append(3, -1);
            sparseIntArray.append(0, h());
            this.f7234f.o("sem_power_mode_refresh_rate_cover", sparseIntArray);
        }
    }

    public final String z(boolean z10, int i10, int i11) {
        return "mode : " + this.f7233e + ", isOn : " + z10 + ", currentRefreshRate : " + i10 + ", newRefreshRate : " + i11;
    }
}
