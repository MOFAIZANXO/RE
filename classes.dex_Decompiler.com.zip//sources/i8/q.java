package i8;

import android.content.Context;
import android.util.SparseArray;
import w6.h;

public class q {
    public SparseArray a(Context context, int i10) {
        SparseArray sparseArray = new SparseArray();
        sparseArray.put(8, new k(context));
        sparseArray.put(1, new s(context, i10));
        sparseArray.put(2, new l(context, i10));
        sparseArray.put(3, new j(context, i10));
        sparseArray.put(5, new z(context, i10));
        sparseArray.put(6, new a0(context, i10));
        sparseArray.put(7, new b0(context, i10));
        sparseArray.put(4, new v(context));
        if (h.h()) {
            sparseArray.put(0, new n(context, i10));
        } else {
            sparseArray.put(0, new m(context, i10));
        }
        return sparseArray;
    }
}
