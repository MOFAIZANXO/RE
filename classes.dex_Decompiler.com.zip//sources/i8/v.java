package i8;

import a7.b;
import a7.e;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.UserHandle;
import android.provider.Settings;
import android.util.Log;
import androidx.core.app.NotificationCompat;
import com.samsung.android.util.SemLog;
import o6.a;

public class v extends p {

    /* renamed from: e  reason: collision with root package name */
    public final a f7280e;

    /* renamed from: f  reason: collision with root package name */
    public final w f7281f;

    /* renamed from: g  reason: collision with root package name */
    public final Context f7282g;

    public v(Context context) {
        super(context);
        this.f7282g = context;
        this.f7280e = new a(context);
        this.f7281f = Build.VERSION.SEM_PLATFORM_INT < 140000 ? new x() : new y();
    }

    public void A(int i10) {
        SemLog.d("PowerModeLimitedApps", "setSettingValue : " + i10);
        this.f7280e.q(e(), i10);
    }

    public String e() {
        return "sem_power_mode_limited_apps_and_home_screen";
    }

    public int f() {
        return 0;
    }

    public int h() {
        int c10 = this.f7280e.c(e());
        if (c10 == -1) {
            return f();
        }
        SemLog.d("PowerModeLimitedApps", "getSettingValue : " + c10);
        return c10;
    }

    public Uri i() {
        return Settings.Global.getUriFor(e());
    }

    public boolean k() {
        boolean z10 = true;
        if (h() != 1) {
            z10 = false;
        }
        SemLog.d("PowerModeLimitedApps", "isChecked : " + z10);
        return z10;
    }

    public boolean l() {
        return b.e("user.owner") && !b.e("dc.secure.phone") && e.w(Boolean.FALSE).booleanValue();
    }

    public boolean m() {
        return true;
    }

    public String p() {
        String b10 = this.f7280e.b(e());
        SemLog.d("PowerModeLimitedApps", "makeSettingsValueForRut : " + b10);
        return b10 == null ? String.valueOf(f()) : b10;
    }

    public void q() {
        boolean z10 = true;
        if (f() != 1) {
            z10 = false;
        }
        s(z10);
    }

    public void r(int i10) {
        if (i10 == 1) {
            d7.b.h(this.f7282g.getString(2131953053), k() ? "1" : "0");
        }
    }

    public void s(boolean z10) {
        SemLog.d("PowerModeLimitedApps", "setChecked : " + z10);
        A(z10 ? 1 : 0);
    }

    public void v() {
        if (x()) {
            Log.i("PowerModeLimitedApps", "mpsm can do it without intent. do nothing");
            return;
        }
        Log.i("PowerModeLimitedApps", "turnOff : " + k());
        z(false);
    }

    public void w() {
        if (x()) {
            Log.i("PowerModeLimitedApps", "mpsm can do it without intent. do nothing");
            return;
        }
        Log.i("PowerModeLimitedApps", "turnOn : " + k());
        z(true);
    }

    public final boolean x() {
        Bundle g10 = g();
        return g10 != null && g10.getBoolean("from_em_intent") && y() >= 110033000;
    }

    public final long y() {
        try {
            return this.f7282g.getPackageManager().getPackageInfo(this.f7281f.a(), 0).getLongVersionCode();
        } catch (Exception e10) {
            SemLog.w("PowerModeLimitedApps", NotificationCompat.CATEGORY_ERROR, e10);
            return 0;
        }
    }

    public final void z(boolean z10) {
        try {
            Intent intent = new Intent();
            intent.putExtra("from_psm", true);
            Intent intent2 = new Intent(this.f7281f.b());
            intent2.setPackage(this.f7281f.a());
            intent2.putExtra("enabled", z10);
            intent2.putExtra("flag", 512);
            intent2.putExtra("from_psm", true);
            intent2.putExtra("skipdialog", true);
            intent2.putExtra("forwardedIntent", intent);
            intent2.setComponent(new ComponentName(this.f7281f.a(), this.f7281f.c()));
            this.f7282g.semStartServiceAsUser(intent2, UserHandle.SEM_CURRENT);
        } catch (Exception e10) {
            Log.w("PowerModeLimitedApps", NotificationCompat.CATEGORY_ERROR, e10);
        }
    }
}
