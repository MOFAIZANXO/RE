package i8;

public class x implements w {
    public String a() {
        return "com.sec.android.emergencymode.service";
    }

    public String b() {
        return "com.samsung.intent.action.EMERGENCY_START_SERVICE_BY_ORDER";
    }

    public String c() {
        return "com.sec.android.emergencymode.service.EmergencyServiceStarter";
    }
}
