package i8;

public class y implements w {
    public String a() {
        return "com.sec.android.emergencylauncher";
    }

    public String b() {
        return "com.samsung.intent.action.MAX_POWER_SAVING_START_SERVICE";
    }

    public String c() {
        return "com.sec.android.emergencylauncher.PowerSavingServiceStarter";
    }
}
