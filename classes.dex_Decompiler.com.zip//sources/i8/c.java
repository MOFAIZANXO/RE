package i8;

import android.content.Context;
import android.os.Bundle;
import androidx.core.view.PointerIconCompat;
import com.samsung.android.util.SemLog;
import h6.a;
import i8.h;

public abstract class c implements a {
    public final void c(Bundle bundle, int i10, String str) {
        bundle.putInt("error_id", i10);
        bundle.putString("error_msg", str);
        bundle.putBoolean("result", false);
    }

    public abstract String d();

    public void e(h hVar, Bundle bundle) {
        h(hVar, false, bundle);
    }

    public void f(h hVar, Bundle bundle) {
        h(hVar, true, bundle);
    }

    public void g(Context context, Bundle bundle) {
        if (bundle == null) {
            SemLog.i(d(), "no configuration");
            return;
        }
        r rVar = new r(context);
        int i10 = bundle.getInt("limit_brightness", -1);
        if (i10 > -1) {
            rVar.a(m.class.getSimpleName(), new m(context, 1), true, i10 > 0, true);
        }
        int i11 = bundle.getInt("limit_cpu_speed", -1);
        if (i11 > -1) {
            rVar.a(s.class.getSimpleName(), new s(context, 1), true, i11 > 0, true);
        }
        int i12 = bundle.getInt("turnoff_aod", -1);
        if (i12 > -1) {
            rVar.a(l.class.getSimpleName(), new l(context, 1), true, i12 > 0, true);
        }
        int i13 = bundle.getInt("turnoff_5g", -1);
        if (i13 > -1) {
            rVar.a(j.class.getSimpleName(), new j(context, 1), true, i13 > 0, true);
        }
        int i14 = bundle.getInt("limit_apps_and_home_screen", -1);
        if (i14 > -1) {
            rVar.a(v.class.getSimpleName(), new v(context), true, i14 > 0, false);
        }
    }

    public final void h(h hVar, boolean z10, Bundle bundle) {
        h7.a aVar = new h7.a(hVar.f7244a);
        if (!hVar.l()) {
            int i10 = hVar.i();
            c(bundle, i10, hVar.h(i10));
            aVar.c("PowerMode", "disabled reason " + i10, System.currentTimeMillis());
        } else if (z10 != hVar.o()) {
            hVar.z(z10);
            bundle.putBoolean("result", true);
            aVar.c("PowerMode", "updated to " + z10, System.currentTimeMillis());
        } else if (z10) {
            c(bundle, PointerIconCompat.TYPE_HELP, "already_on");
        } else {
            c(bundle, PointerIconCompat.TYPE_WAIT, "already_off");
        }
    }

    public void i(Context context, h.a aVar, Bundle bundle) {
        if (bundle == null) {
            SemLog.i(d(), "no configuration");
            return;
        }
        e0 e0Var = new e0(context);
        int i10 = bundle.getInt("limit_brightness", -1);
        boolean z10 = true;
        if (i10 > -1) {
            aVar.d(0, i10 > 0);
            e0Var.d("limit_brightness" + i10);
        }
        int i11 = bundle.getInt("limit_cpu_speed", -1);
        if (i11 > -1) {
            aVar.d(1, i11 > 0);
            e0Var.d("limit_cpu_speed" + i11);
        }
        int i12 = bundle.getInt("turnoff_aod", -1);
        if (i12 > -1) {
            aVar.d(2, i12 > 0);
            e0Var.d("turnoff_aod" + i12);
        }
        int i13 = bundle.getInt("turnoff_5g", -1);
        if (i13 > -1) {
            aVar.d(3, i13 > 0);
            e0Var.d("turnoff_5g" + i13);
        }
        int i14 = bundle.getInt("limit_apps_and_home_screen", -1);
        if (i14 > -1) {
            if (i14 <= 0) {
                z10 = false;
            }
            aVar.d(4, z10);
            e0Var.d("limit_apps_and_home_screen" + i14);
        }
    }
}
