package i8;

import android.content.Context;
import android.net.Uri;
import com.samsung.android.util.SemLog;
import o6.a;

public class z extends p {

    /* renamed from: e  reason: collision with root package name */
    public a f7283e;

    /* renamed from: f  reason: collision with root package name */
    public final int f7284f;

    public z(Context context, int i10) {
        super(context);
        this.f7284f = i10;
        this.f7283e = new a(context);
    }

    public int f() {
        return 1;
    }

    public int h() {
        int f10 = this.f7283e.f("sm_connectivity_disable");
        return f10 == -1 ? f() : f10;
    }

    public Uri i() {
        return null;
    }

    public boolean k() {
        return true;
    }

    public boolean l() {
        return true;
    }

    public boolean m() {
        return false;
    }

    public String p() {
        return String.valueOf(f());
    }

    public void q() {
    }

    public void r(int i10) {
    }

    public void s(boolean z10) {
    }

    public void v() {
        x(0);
    }

    public void w() {
        x(1);
    }

    public void x(int i10) {
        SemLog.d("PowerModeNetwork", "setSettingValue : " + i10);
        this.f7283e.q("low_power_back_data_off", 1);
        this.f7283e.m("psm_network_power_saving", i10, this.f7284f);
        this.f7283e.r("sm_connectivity_disable", i10);
    }
}
