package i8;

import android.content.Context;
import h7.a;

public class e0 extends a {
    public e0(Context context) {
        super(context);
    }

    public void d(String str) {
        c("volatile_config", str, System.currentTimeMillis());
    }
}
