package i8;

import android.content.Context;
import android.net.Uri;
import android.provider.Settings;
import com.samsung.android.util.SemLog;
import o6.a;
import o6.b;

public class s extends p {

    /* renamed from: e  reason: collision with root package name */
    public final Context f7274e;

    /* renamed from: f  reason: collision with root package name */
    public final int f7275f;

    /* renamed from: g  reason: collision with root package name */
    public final a f7276g;

    public s(Context context, int i10) {
        super(context);
        this.f7274e = context;
        this.f7275f = i10;
        this.f7276g = new a(context);
    }

    public String e() {
        return "restricted_device_performance";
    }

    public int f() {
        return b.b() ^ true ? 1 : 0;
    }

    public int h() {
        int a10 = this.f7276g.a(e(), this.f7275f);
        return a10 == -1 ? f() : a10;
    }

    public Uri i() {
        return Settings.Global.getUriFor(e());
    }

    public boolean k() {
        return h() == 1;
    }

    public boolean l() {
        return true;
    }

    public boolean m() {
        return true;
    }

    public String p() {
        String b10 = this.f7276g.b(e());
        SemLog.d("PowerModeCpuLimit", "makeSettingsValueForRut : " + b10);
        return b10 == null ? "0" : b10;
    }

    public void q() {
        boolean z10 = true;
        if (f() != 1) {
            z10 = false;
        }
        s(z10);
    }

    public void r(int i10) {
        int i11 = i10 != 1 ? i10 != 2 ? -1 : 2131953048 : 2131953052;
        if (i11 >= 0) {
            d7.b.h(this.f7274e.getString(i11), k() ? "1" : "0");
        }
    }

    public void s(boolean z10) {
        x(z10 ? 1 : 0);
    }

    public void v() {
    }

    public void w() {
    }

    public void x(int i10) {
        SemLog.d("PowerModeCpuLimit", "setSettingValue : " + i10);
        this.f7276g.m(e(), i10, this.f7275f);
    }
}
