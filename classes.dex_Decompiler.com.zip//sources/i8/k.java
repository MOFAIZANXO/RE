package i8;

import android.content.Context;
import android.net.Uri;
import l8.b;

public class k extends p {

    /* renamed from: e  reason: collision with root package name */
    public final Context f7254e;

    public k(Context context) {
        super(context);
        this.f7254e = context;
    }

    public int f() {
        return 1;
    }

    public int h() {
        return 1;
    }

    public Uri i() {
        return null;
    }

    public boolean k() {
        return true;
    }

    public boolean l() {
        return true;
    }

    public boolean m() {
        return false;
    }

    public String p() {
        return "";
    }

    public void q() {
    }

    public void r(int i10) {
    }

    public void s(boolean z10) {
    }

    public void v() {
        b.i(this.f7254e);
    }

    public void w() {
        b.i(this.f7254e);
    }
}
