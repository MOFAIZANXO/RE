package i8;

import android.content.Context;
import com.samsung.android.util.SemLog;

public class a extends z {
    public a(Context context, int i10) {
        super(context, i10);
    }

    public int f() {
        return 1;
    }

    public int h() {
        int f10 = this.f7283e.f("ultra_power_mode_back_data_off");
        return f10 == -1 ? f() : f10;
    }

    public boolean l() {
        return true;
    }

    public String p() {
        String b10 = this.f7283e.b("ultra_power_mode_back_data_off");
        SemLog.d("MaxModeNetwork", "makeSettingsValueForRut : " + b10);
        return b10 == null ? "0" : b10;
    }

    public void x(int i10) {
        this.f7283e.q("ultra_power_mode_back_data_off", i10);
    }
}
