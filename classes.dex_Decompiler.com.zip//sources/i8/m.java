package i8;

import a7.e;
import android.content.Context;
import android.net.Uri;
import android.provider.Settings;
import android.util.SparseIntArray;
import com.samsung.android.util.SemLog;
import d7.b;
import o6.a;
import w6.h;

public class m extends p {

    /* renamed from: e  reason: collision with root package name */
    public int f7258e;

    /* renamed from: f  reason: collision with root package name */
    public int f7259f;

    /* renamed from: g  reason: collision with root package name */
    public final Context f7260g;

    /* renamed from: h  reason: collision with root package name */
    public final a f7261h;

    /* renamed from: i  reason: collision with root package name */
    public final int f7262i;

    public m(Context context, int i10) {
        super(context);
        this.f7260g = context;
        this.f7262i = i10;
        this.f7261h = new a(context);
        B();
    }

    public final float A(boolean z10) {
        SemLog.d("PowerModeBrightness", "percent : " + 0.9f);
        return z10 ? 0.9f : 1.1111112f;
    }

    public final void B() {
        x();
        H();
    }

    public final boolean C() {
        return Settings.System.getInt(this.f7260g.getContentResolver(), "screen_brightness_mode", 0) == 0;
    }

    public final void D(int i10) {
        SemLog.d("PowerModeBrightness", "- auto brightness limit : " + i10);
        this.f7261h.q("auto_brightness_limit", i10);
    }

    public final void E(int i10) {
        SemLog.d("PowerModeBrightness", "- ManualMode brightness  : " + i10);
        this.f7261h.s("screen_brightness", i10);
    }

    public void F(int i10) {
        SemLog.d("PowerModeBrightness", "setSettingValue : " + i10);
        this.f7261h.n(e(), i10, this.f7262i, -1, this.f7259f);
    }

    public final void G(boolean z10) {
        D(z10 ? this.f7258e : this.f7259f);
    }

    public final void H() {
        if (this.f7261h.a(e(), 0) == -1) {
            SemLog.d("PowerModeBrightness", "need to init : " + e());
            SparseIntArray sparseIntArray = new SparseIntArray();
            sparseIntArray.append(1, this.f7258e);
            sparseIntArray.append(2, this.f7258e);
            sparseIntArray.append(3, -1);
            sparseIntArray.append(0, this.f7259f);
            this.f7261h.o(e(), sparseIntArray);
        }
    }

    public final void I(boolean z10) {
        int g10 = this.f7261h.g("screen_brightness");
        int y10 = y(Math.round(((float) g10) * A(z10)));
        SemLog.d("PowerModeBrightness", "update screen brightness, powerMode on : " + z10 + " (" + g10 + ") to (" + y10 + ")");
        E(y10);
    }

    public String e() {
        return "limit_brightness_state";
    }

    public int f() {
        return this.f7258e;
    }

    public int h() {
        int a10 = this.f7261h.a(e(), this.f7262i);
        return a10 == -1 ? f() : a10;
    }

    public Uri i() {
        return Settings.Global.getUriFor(e());
    }

    public boolean k() {
        return h() == this.f7258e;
    }

    public boolean l() {
        return true;
    }

    public boolean m() {
        return true;
    }

    public String p() {
        String b10 = this.f7261h.b(e());
        SemLog.d("PowerModeBrightness", "makeSettingsValueForRut : " + b10);
        return b10;
    }

    public void q() {
        s(true);
    }

    public void r(int i10) {
        int i11 = i10 != 1 ? i10 != 2 ? -1 : 2131953047 : 2131953051;
        if (i11 >= 0) {
            b.h(this.f7260g.getString(i11), k() ? "1" : "0");
        }
    }

    public void s(boolean z10) {
        F(z10 ? this.f7258e : this.f7259f);
    }

    public void v() {
        z(false);
    }

    public void w() {
        z(true);
    }

    public final void x() {
        int i10 = h.k() ? 90 : 100;
        this.f7259f = i10;
        this.f7258e = i10 - 10;
        SemLog.d("PowerModeBrightness", "default auto brightness limit : " + this.f7259f + ", power mode brightness limit : " + this.f7258e);
    }

    public final int y(int i10) {
        if (i10 > 255) {
            return 255;
        }
        return Math.max(i10, e.m(this.f7260g));
    }

    public final void z(boolean z10) {
        SemLog.d("PowerModeBrightness", "brightness option on, change brightness, default : " + this.f7259f);
        if (C()) {
            I(z10);
        }
        G(z10);
    }
}
