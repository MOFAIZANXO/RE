package i8;

import android.content.Context;
import android.net.Uri;
import android.provider.Settings;
import android.util.SparseIntArray;
import com.samsung.android.util.SemLog;
import d7.b;
import o6.a;
import w6.h;

public class n extends p {

    /* renamed from: e  reason: collision with root package name */
    public int f7263e;

    /* renamed from: f  reason: collision with root package name */
    public int f7264f;

    /* renamed from: g  reason: collision with root package name */
    public final Context f7265g;

    /* renamed from: h  reason: collision with root package name */
    public final a f7266h;

    /* renamed from: i  reason: collision with root package name */
    public final int f7267i;

    public n(Context context, int i10) {
        super(context);
        this.f7265g = context;
        this.f7267i = i10;
        this.f7266h = new a(context);
        z();
    }

    public void A(int i10) {
        SemLog.d("PowerModeBrightnessSolo", "setSettingValue : " + i10);
        this.f7266h.n(e(), i10, this.f7267i, -1, this.f7264f);
    }

    public final void B() {
        if (this.f7266h.a(e(), 0) == -1) {
            SemLog.d("PowerModeBrightnessSolo", "need to init : " + e());
            SparseIntArray sparseIntArray = new SparseIntArray();
            sparseIntArray.append(1, this.f7263e);
            sparseIntArray.append(2, this.f7263e);
            sparseIntArray.append(3, -1);
            sparseIntArray.append(0, this.f7264f);
            this.f7266h.o(e(), sparseIntArray);
        }
    }

    public String e() {
        return "limit_brightness_state";
    }

    public int f() {
        return this.f7263e;
    }

    public int h() {
        int a10 = this.f7266h.a(e(), this.f7267i);
        return a10 == -1 ? f() : a10;
    }

    public Uri i() {
        return Settings.Global.getUriFor(e());
    }

    public boolean k() {
        return h() == this.f7263e;
    }

    public boolean l() {
        return true;
    }

    public boolean m() {
        return true;
    }

    public String p() {
        String b10 = this.f7266h.b(e());
        SemLog.d("PowerModeBrightnessSolo", "makeSettingsValueForRut : " + b10);
        return b10;
    }

    public void q() {
        s(true);
    }

    public void r(int i10) {
        int i11 = i10 != 1 ? i10 != 2 ? -1 : 2131953047 : 2131953051;
        if (i11 >= 0) {
            b.h(this.f7265g.getString(i11), k() ? "1" : "0");
        }
    }

    public void s(boolean z10) {
        A(z10 ? this.f7263e : this.f7264f);
    }

    public void v() {
        y(false);
    }

    public void w() {
        y(true);
    }

    public final void x() {
        int i10 = h.k() ? 90 : 100;
        this.f7264f = i10;
        this.f7263e = i10 - 10;
        SemLog.d("PowerModeBrightnessSolo", "default auto brightness limit : " + this.f7264f + ", power mode brightness limit : " + this.f7263e);
    }

    public final void y(boolean z10) {
        this.f7266h.p("sem_power_saving_adjust_brightness_factor", z10 ? 0.9f : 1.0f);
        this.f7266h.q("sem_power_saving_adjust_brightness_disabled", z10 ? 1 : 0);
        SemLog.d("PowerModeBrightnessSolo", "controlBrightness : " + z10);
    }

    public final void z() {
        x();
        B();
    }
}
