package i8;

import android.content.Context;

public class d extends t {
    public d(Context context) {
        super(context);
    }

    public String a(int i10) {
        return i10 != 1 ? i10 != 2 ? i10 != 3 ? i10 != 4 ? i10 != 5 ? "" : this.f7278a.getResources().getString(2131951914) : this.f7278a.getResources().getString(2131951912) : this.f7278a.getResources().getString(2131951812) : this.f7278a.getResources().getString(2131952824) : this.f7278a.getResources().getString(2131951913);
    }

    /* JADX WARNING: Removed duplicated region for block: B:31:0x008c  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int b() {
        /*
            r7 = this;
            android.content.Context r0 = r7.f7278a
            boolean r0 = r7.e(r0)
            r1 = 2
            r2 = 1
            r3 = 0
            if (r0 == 0) goto L_0x000d
            r0 = r2
            goto L_0x0035
        L_0x000d:
            android.content.Context r0 = r7.f7278a
            boolean r0 = r7.g(r0)
            if (r0 == 0) goto L_0x0034
            android.content.Context r0 = r7.f7278a
            boolean r0 = r7.d(r0)
            if (r0 == 0) goto L_0x001e
            goto L_0x0034
        L_0x001e:
            android.content.Context r0 = r7.f7278a
            boolean r0 = w6.k.o(r0)
            if (r0 == 0) goto L_0x0028
            r0 = 3
            goto L_0x0035
        L_0x0028:
            android.content.Context r0 = r7.f7278a
            boolean r0 = w6.k.m(r0)
            if (r0 == 0) goto L_0x0032
            r0 = 4
            goto L_0x0035
        L_0x0032:
            r0 = r3
            goto L_0x0035
        L_0x0034:
            r0 = r1
        L_0x0035:
            i8.v r4 = new i8.v
            android.content.Context r5 = r7.f7278a
            r4.<init>(r5)
            o6.a r5 = new o6.a
            android.content.Context r6 = r7.f7278a
            r5.<init>(r6)
            java.lang.String r6 = "low_power"
            int r5 = r5.c(r6)
            if (r5 != r2) goto L_0x004c
            goto L_0x004d
        L_0x004c:
            r2 = r3
        L_0x004d:
            boolean r3 = r4.l()
            if (r3 == 0) goto L_0x0073
            boolean r3 = r4.k()
            if (r3 == 0) goto L_0x0073
            m6.a r3 = new m6.a
            android.content.Context r4 = r7.f7278a
            r3.<init>(r4)
            boolean r3 = r3.a()
            if (r3 == 0) goto L_0x0067
            goto L_0x0074
        L_0x0067:
            android.content.Context r1 = r7.f7278a
            boolean r1 = w6.g.a(r1)
            if (r1 == 0) goto L_0x0073
            if (r2 != 0) goto L_0x0073
            r1 = 5
            goto L_0x0074
        L_0x0073:
            r1 = r0
        L_0x0074:
            java.lang.String r0 = i8.t.f7277b
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            java.lang.String r3 = "MidPowerModeDisable reason:"
            r2.append(r3)
            r2.append(r1)
            java.lang.String r2 = r2.toString()
            com.samsung.android.util.SemLog.d(r0, r2)
            if (r1 == 0) goto L_0x00ad
            h7.a r0 = new h7.a
            android.content.Context r7 = r7.f7278a
            r0.<init>(r7)
            java.lang.StringBuilder r7 = new java.lang.StringBuilder
            r7.<init>()
            java.lang.String r2 = "reason:"
            r7.append(r2)
            r7.append(r1)
            java.lang.String r7 = r7.toString()
            long r2 = java.lang.System.currentTimeMillis()
            java.lang.String r4 = "MidPowerModeDisable"
            r0.c(r4, r7, r2)
        L_0x00ad:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: i8.d.b():int");
    }

    public int c() {
        return 0;
    }
}
