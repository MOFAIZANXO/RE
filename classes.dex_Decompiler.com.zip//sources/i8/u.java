package i8;

import android.content.Context;
import android.net.Uri;
import android.util.SparseArray;
import com.samsung.android.util.SemLog;

public class u {

    /* renamed from: a  reason: collision with root package name */
    public final SparseArray f7279a;

    public u(SparseArray sparseArray) {
        this.f7279a = sparseArray;
    }

    public final p a(int i10) {
        if (this.f7279a.indexOfKey(i10) >= 0) {
            return (p) this.f7279a.get(i10);
        }
        return null;
    }

    public Uri b(int i10) {
        p a10 = a(i10);
        if (a10 != null) {
            return a10.i();
        }
        return null;
    }

    public void c(Context context, boolean z10) {
        for (int i10 = 0; i10 < this.f7279a.size(); i10++) {
            SparseArray sparseArray = this.f7279a;
            p pVar = (p) sparseArray.get(sparseArray.keyAt(i10));
            if (pVar == null) {
                SemLog.w("PowerModeFacade", "config is not found at " + i10);
            } else if (pVar.l()) {
                if (z10) {
                    if (pVar.o()) {
                        boolean j10 = pVar.j();
                        if (j10 == pVar.k()) {
                            SemLog.d("PowerModeFacade", "volatile value is same with current value.");
                            new e0(context).d("skip volatile setting");
                        } else {
                            SemLog.d("PowerModeFacade", "apply volatile setting " + j10 + " at " + pVar.h());
                            pVar.b();
                            pVar.s(j10);
                        }
                    }
                } else if (pVar.n()) {
                    boolean d10 = pVar.d();
                    pVar.s(d10);
                    pVar.u(false, false);
                    pVar.a();
                    new e0(context).d("Original value restored " + d10);
                    SemLog.d("PowerModeFacade", "volatile setting roll backed to " + d10 + " at " + pVar.h());
                }
            }
        }
    }

    public boolean d(int i10) {
        p a10 = a(i10);
        if (a10 != null) {
            return a10.k();
        }
        SemLog.d("PowerModeFacade", "configuration is null");
        return false;
    }

    public boolean e(int i10) {
        p a10 = a(i10);
        if (a10 != null) {
            return a10.l();
        }
        return false;
    }

    public void f(int i10, boolean z10) {
        p a10 = a(i10);
        if (a10 != null) {
            SemLog.d("PowerModeFacade", "key : " + i10 + ", isChecked : " + z10);
            a10.s(z10);
            return;
        }
        SemLog.d("PowerModeFacade", "configuration is null");
    }

    public void g(boolean z10) {
        for (int i10 = 0; i10 < this.f7279a.size(); i10++) {
            SparseArray sparseArray = this.f7279a;
            p pVar = (p) sparseArray.get(sparseArray.keyAt(i10));
            if (pVar == null) {
                SemLog.w("PowerModeFacade", "config is not found at " + i10);
            } else if (!pVar.l() || !pVar.k()) {
                SemLog.d("PowerModeFacade", pVar.getClass() + " is supportable : " + pVar.l() + ", isChecked : " + pVar.k());
            } else if (z10) {
                pVar.w();
            } else {
                pVar.v();
            }
        }
    }
}
