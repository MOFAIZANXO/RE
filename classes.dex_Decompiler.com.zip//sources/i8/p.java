package i8;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import androidx.core.app.NotificationManagerCompat;

public abstract class p {

    /* renamed from: a  reason: collision with root package name */
    public final Context f7269a;

    /* renamed from: b  reason: collision with root package name */
    public Bundle f7270b;

    /* renamed from: c  reason: collision with root package name */
    public boolean f7271c = false;

    /* renamed from: d  reason: collision with root package name */
    public boolean f7272d = false;

    public p(Context context) {
        this.f7269a = context;
    }

    public void a() {
        if (m()) {
            Settings.Global.putInt(this.f7269a.getContentResolver(), c(), NotificationManagerCompat.IMPORTANCE_UNSPECIFIED);
        }
    }

    public void b() {
        if (m()) {
            Settings.Global.putInt(this.f7269a.getContentResolver(), c(), h());
        }
    }

    public final String c() {
        return e() + "_volatile";
    }

    public boolean d() {
        return m() ? Settings.Global.getInt(this.f7269a.getContentResolver(), c(), f()) == 1 : f() == 1;
    }

    public String e() {
        return null;
    }

    public abstract int f();

    public Bundle g() {
        return this.f7270b;
    }

    public abstract int h();

    public abstract Uri i();

    public boolean j() {
        return this.f7272d;
    }

    public abstract boolean k();

    public abstract boolean l();

    public abstract boolean m();

    public boolean n() {
        return m() && Settings.Global.getInt(this.f7269a.getContentResolver(), c(), NotificationManagerCompat.IMPORTANCE_UNSPECIFIED) != -1000;
    }

    public boolean o() {
        return this.f7271c;
    }

    public abstract String p();

    public abstract void q();

    public abstract void r(int i10);

    public abstract void s(boolean z10);

    public void t(Bundle bundle) {
        this.f7270b = bundle;
    }

    public void u(boolean z10, boolean z11) {
        this.f7271c = z10;
        this.f7272d = z11;
    }

    public abstract void v();

    public abstract void w();
}
