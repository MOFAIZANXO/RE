package i8;

import android.content.Context;
import android.net.Uri;
import android.provider.Settings;
import android.util.Log;
import android.util.SparseIntArray;
import com.samsung.android.util.SemLog;
import d7.b;
import l8.e;
import o6.a;

public class j extends p {

    /* renamed from: e  reason: collision with root package name */
    public final Context f7251e;

    /* renamed from: f  reason: collision with root package name */
    public final int f7252f;

    /* renamed from: g  reason: collision with root package name */
    public final a f7253g;

    public j(Context context, int i10) {
        super(context);
        this.f7251e = context;
        this.f7252f = i10;
        this.f7253g = new a(context);
        x();
    }

    public String e() {
        return "psm_5G_mode";
    }

    public int f() {
        return e.c(this.f7251e);
    }

    public int h() {
        return e.d(this.f7251e, this.f7252f);
    }

    public Uri i() {
        return Settings.Global.getUriFor(e());
    }

    public boolean k() {
        return h() == 1;
    }

    public boolean l() {
        return e.g(this.f7251e);
    }

    public boolean m() {
        return true;
    }

    public String p() {
        String b10 = this.f7253g.b(e());
        SemLog.d("PowerMode5G", "makeSettingsValueForRut : " + b10);
        return b10;
    }

    public void q() {
        boolean z10 = true;
        if (f() != 1) {
            z10 = false;
        }
        s(z10);
    }

    public void r(int i10) {
        int i11 = i10 != 1 ? i10 != 2 ? -1 : 2131953045 : 2131953049;
        if (i11 >= 0) {
            b.h(this.f7251e.getString(i11), k() ? "1" : "0");
        }
    }

    public void s(boolean z10) {
        y(z10 ? 1 : 0);
    }

    public void v() {
        e.k(this.f7251e, false);
    }

    public void w() {
        e.k(this.f7251e, true);
    }

    public final void x() {
        if (this.f7253g.a(e(), this.f7252f) == -1) {
            Log.i("PowerMode5G", "need to init : " + e());
            h7.a aVar = new h7.a(this.f7251e);
            aVar.c("PowerMode5G", "PSM_5G_MODE : " + this.f7253g.b(e()) + ", need to init", System.currentTimeMillis());
            SparseIntArray sparseIntArray = new SparseIntArray();
            sparseIntArray.append(1, f());
            sparseIntArray.append(2, 1);
            this.f7253g.o(e(), sparseIntArray);
        }
    }

    public void y(int i10) {
        Context context = this.f7251e;
        boolean z10 = true;
        if (i10 != 1) {
            z10 = false;
        }
        e.l(context, z10, this.f7252f);
    }
}
