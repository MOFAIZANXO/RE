package i8;

import android.content.Context;
import android.util.Log;
import android.util.SparseArray;
import android.util.SparseIntArray;
import com.samsung.android.util.SemLog;
import i6.b;
import l8.g;
import o6.a;

public class d0 {

    /* renamed from: a  reason: collision with root package name */
    public final SparseArray f7238a;

    /* renamed from: b  reason: collision with root package name */
    public final Context f7239b;

    /* renamed from: c  reason: collision with root package name */
    public final int f7240c;

    public d0(Context context, int i10, SparseArray sparseArray) {
        this.f7238a = sparseArray;
        this.f7239b = context;
        this.f7240c = i10;
    }

    public final String a() {
        return new a(this.f7239b, this.f7240c).p();
    }

    public final String b() {
        int b10 = g.b(this.f7239b);
        SparseIntArray sparseIntArray = new SparseIntArray();
        sparseIntArray.append(1, b10);
        sparseIntArray.append(2, b10);
        sparseIntArray.append(3, -1);
        sparseIntArray.append(0, b10);
        String h10 = new a(this.f7239b).h(sparseIntArray);
        SemLog.d("RutCalculator", "getResolutionSettings : " + h10);
        return h10;
    }

    public long c() {
        String d10 = d(0);
        String d11 = d(1);
        String d12 = d(2);
        String d13 = d(3);
        String d14 = d(5);
        String d15 = d(4);
        String str = "limit_brightness_state:" + d10 + ";screen_resolution_state:" + b() + ";restricted_device_performance:" + d11 + ";low_power_back_data_off:" + d14 + ";ultra_power_mode_back_data_off:" + a() + ";psm_always_on_display_mode:" + d12 + ";psm_5G_mode:" + d13 + ";sem_power_mode_limited_apps_and_home_screen:" + d15;
        long b10 = (long) b.b(this.f7239b, this.f7240c, str);
        Log.i("RutCalculator", "calculateNewRut : " + b10);
        Log.d("RutCalculator", "rutParameterString : " + str);
        return b10;
    }

    public final String d(int i10) {
        p pVar = this.f7238a.contains(i10) ? (p) this.f7238a.get(i10) : null;
        return pVar != null ? pVar.p() : "";
    }
}
