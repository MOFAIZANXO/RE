package i8;

import android.content.Context;
import android.util.Log;
import i8.h;

public class r {

    /* renamed from: a  reason: collision with root package name */
    public h f7273a;

    public r(Context context) {
        this.f7273a = new h.a(context).a();
    }

    public void a(String str, p pVar, boolean z10, boolean z11, boolean z12) {
        Log.i("PowerModeConfigSettings", str + ", mode:" + this.f7273a.o() + ", current:" + pVar.l() + "/" + pVar.k() + ", after:" + z10 + "/" + z11 + "/" + z12);
        if (pVar.l() && z10 && pVar.k() != z11) {
            pVar.s(z11);
            if (this.f7273a.o() && z12) {
                if (pVar.k()) {
                    pVar.w();
                } else {
                    pVar.v();
                }
            }
        }
    }
}
