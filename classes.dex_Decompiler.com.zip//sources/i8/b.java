package i8;

import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import androidx.core.view.PointerIconCompat;
import com.samsung.android.util.SemLog;
import i8.h;
import java.util.Arrays;
import java.util.List;

public class b extends c {

    /* renamed from: b  reason: collision with root package name */
    public static final List f7231b = Arrays.asList(new String[]{"psm_turn_on", "psm_turn_off", "psm_get_info", "psm_get_state", "psm_set_option"});

    /* renamed from: a  reason: collision with root package name */
    public final Context f7232a;

    public b(Context context) {
        this.f7232a = context;
    }

    public Bundle a(Context context, String str, String str2, Bundle bundle) {
        Bundle bundle2 = new Bundle();
        SemLog.d("MidPowerModeDcApi", "API " + str);
        String j10 = j(bundle);
        if ("psm_turn_on".equals(str)) {
            h.a c10 = new h.a(context).e(j10).c(bundle);
            i(context, c10, bundle);
            f(c10.a(), bundle2);
        } else if ("psm_turn_off".equals(str)) {
            e(new h.a(context).e(j10).c(bundle).a(), bundle2);
        } else if ("psm_get_info".equals(str)) {
            k(bundle2);
        } else if ("psm_get_state".equals(str)) {
            l(context, bundle2);
        } else if ("psm_set_option".equals(str)) {
            m(context, bundle);
        } else {
            bundle2.putInt("error_id", PointerIconCompat.TYPE_CONTEXT_MENU);
            bundle2.putBoolean("result", false);
        }
        bundle2.putInt("version", 1000);
        return bundle2;
    }

    public List b() {
        return f7231b;
    }

    public String d() {
        return "MidPowerModeDcApi";
    }

    public final String j(Bundle bundle) {
        if (bundle != null) {
            if (bundle.getBoolean("from_em_intent")) {
                return "8";
            }
            if (!TextUtils.isEmpty(bundle.getString("request_id"))) {
                return "7_" + bundle.getString("request_id");
            }
        }
        Log.w("MidPowerModeDcApi", "from data is empty");
        return "7";
    }

    public final void k(Bundle bundle) {
        bundle.putString("title", this.f7232a.getString(2131952540));
        bundle.putString("summary", "waiting new DID");
        bundle.putInt("icon_id", 0);
        bundle.putBoolean("result", true);
    }

    public final void l(Context context, Bundle bundle) {
        h a10 = new h.a(context).a();
        bundle.putBoolean("state", a10.o());
        boolean l10 = a10.l();
        if (!l10) {
            int i10 = a10.i();
            bundle.putInt("error_id", PointerIconCompat.TYPE_HAND);
            bundle.putString("error_msg", a10.h(i10));
        }
        bundle.putBoolean("changeable", l10);
        bundle.putBoolean("result", true);
    }

    public final void m(Context context, Bundle bundle) {
        h a10 = new h.a(context).a();
        boolean o10 = a10.o();
        boolean l10 = a10.l();
        if (o10 || !l10) {
            SemLog.d("MidPowerModeDcApi", "cannot set configuration when powerMode " + o10 + " isChangeable " + l10);
            return;
        }
        g(context, bundle);
    }
}
