package i8;

public interface w {
    String a();

    String b();

    String c();
}
