package i8;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.provider.Settings;
import android.util.SparseIntArray;
import com.samsung.android.feature.SemFloatingFeature;
import com.samsung.android.util.SemLog;
import d7.b;
import o6.a;

public class l extends p {

    /* renamed from: e  reason: collision with root package name */
    public final Context f7255e;

    /* renamed from: f  reason: collision with root package name */
    public final int f7256f;

    /* renamed from: g  reason: collision with root package name */
    public final a f7257g;

    public l(Context context, int i10) {
        super(context);
        this.f7255e = context;
        this.f7256f = i10;
        this.f7257g = new a(context);
    }

    public String e() {
        return "psm_always_on_display_mode";
    }

    public int f() {
        return 1;
    }

    public int h() {
        int a10 = this.f7257g.a(e(), this.f7256f);
        return a10 == -1 ? f() : a10;
    }

    public Uri i() {
        return Settings.Global.getUriFor(e());
    }

    public boolean k() {
        return h() == 1;
    }

    public boolean l() {
        return SemFloatingFeature.getInstance().getString("SEC_FLOATING_FEATURE_FRAMEWORK_CONFIG_AOD_ITEM").contains("aodversion");
    }

    public boolean m() {
        return true;
    }

    public String p() {
        String b10 = this.f7257g.b(e());
        SemLog.d("PowerModeAod", "makeSettingsValueForRut : " + b10);
        if (b10 != null) {
            return b10;
        }
        SparseIntArray sparseIntArray = new SparseIntArray();
        sparseIntArray.append(1, l() ? f() : 0);
        sparseIntArray.append(2, f());
        return new a(this.f7255e).h(sparseIntArray);
    }

    public void q() {
        boolean z10 = true;
        if (f() != 1) {
            z10 = false;
        }
        s(z10);
    }

    public void r(int i10) {
        int i11 = i10 != 1 ? i10 != 2 ? -1 : 2131953046 : 2131953050;
        if (i11 >= 0) {
            b.h(this.f7255e.getString(i11), k() ? "1" : "0");
        }
    }

    public void s(boolean z10) {
        y(z10 ? 1 : 0);
    }

    public void v() {
        x(0, 0);
    }

    public void w() {
        x(this.f7256f, 1);
    }

    public final void x(int i10, int i11) {
        SemLog.d("PowerModeAod", "broadcastIntent AOD targetMode : " + i10 + ", isAodEnabledExtra : " + i11);
        Intent intent = new Intent("com.samsung.android.app.aodservice.PSM_APPLY");
        intent.putExtra("isPSM", i10);
        intent.putExtra("isAODEnable", i11);
        intent.setPackage("com.samsung.android.app.aodservice");
        this.f7255e.sendBroadcast(intent, "com.samsung.android.app.aodservice.permission.BROADCAST_RECEIVER");
    }

    public void y(int i10) {
        SemLog.d("PowerModeAod", "setSettingValue : " + i10);
        this.f7257g.m(e(), i10, this.f7256f);
    }
}
