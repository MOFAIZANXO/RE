package i8;

import android.util.Log;

public abstract class o {

    /* renamed from: a  reason: collision with root package name */
    public static long f7268a;

    public static synchronized boolean a() {
        synchronized (o.class) {
            long currentTimeMillis = System.currentTimeMillis();
            if (Math.abs(currentTimeMillis - f7268a) < 1000) {
                Log.w("PowerMode.buffer", "repeated request in short time. ignored");
                return true;
            }
            f7268a = currentTimeMillis;
            return false;
        }
    }
}
