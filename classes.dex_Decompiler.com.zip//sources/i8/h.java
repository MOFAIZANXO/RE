package i8;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.util.SparseArray;
import com.samsung.android.sdk.routines.v3.RoutineSdkProvider;
import com.samsung.android.util.SemLog;
import d7.b;
import t6.g;

public class h {

    /* renamed from: a  reason: collision with root package name */
    public Context f7244a;

    /* renamed from: b  reason: collision with root package name */
    public SparseArray f7245b;

    /* renamed from: c  reason: collision with root package name */
    public u f7246c;

    /* renamed from: d  reason: collision with root package name */
    public t f7247d;

    /* renamed from: e  reason: collision with root package name */
    public d0 f7248e;

    /* renamed from: f  reason: collision with root package name */
    public String f7249f;

    public static class a {

        /* renamed from: a  reason: collision with root package name */
        public h f7250a;

        public a(Context context) {
            h hVar = new h(context);
            this.f7250a = hVar;
            hVar.f();
            this.f7250a.y(new d(context));
        }

        public h a() {
            this.f7250a.s();
            return this.f7250a;
        }

        public a b(t tVar) {
            this.f7250a.y(tVar);
            return this;
        }

        public a c(Bundle bundle) {
            SparseArray b10 = this.f7250a.g();
            int size = b10.size();
            for (int i10 = 0; i10 < size; i10++) {
                p pVar = (p) b10.get(b10.keyAt(i10));
                if (pVar == null) {
                    SemLog.w("PowerMode", "config is not found at " + i10);
                } else {
                    pVar.t(bundle);
                }
            }
            return this;
        }

        public void d(int i10, boolean z10) {
            p pVar = (p) this.f7250a.g().get(i10);
            if (pVar == null) {
                SemLog.w("PowerMode", "config not found " + i10);
                return;
            }
            SemLog.d("PowerMode", "set volatile config " + i10 + " to  " + z10);
            pVar.u(true, z10);
        }

        public a e(String str) {
            this.f7250a.A(str);
            return this;
        }

        public a f(int i10) {
            this.f7250a.g().remove(i10);
            return this;
        }
    }

    public static void w(Context context) {
        new a(context).a().v();
    }

    public final void A(String str) {
        this.f7249f = str;
    }

    public void B(boolean z10) {
        SemLog.d("PowerMode", "2) apply for mode (1) to (" + z10 + ")");
        this.f7246c.g(z10);
    }

    public final void f() {
        this.f7245b = new q().a(this.f7244a, 1);
    }

    public final SparseArray g() {
        return this.f7245b;
    }

    public String h(int i10) {
        return this.f7247d.a(i10);
    }

    public int i() {
        return this.f7247d.b();
    }

    public long j() {
        return this.f7248e.c();
    }

    public Uri k(int i10) {
        return this.f7246c.b(i10);
    }

    public boolean l() {
        return n(i());
    }

    public boolean m(int i10) {
        return this.f7246c.d(i10);
    }

    public boolean n(int i10) {
        return this.f7247d.f(i10);
    }

    public boolean o() {
        return Settings.Global.getInt(this.f7244a.getContentResolver(), "low_power", 0) == 1;
    }

    public boolean p(int i10) {
        return this.f7246c.e(i10);
    }

    public final void q(boolean z10) {
        SemLog.d("PowerMode", "3) onPostExecute mode (1) to (" + z10 + ")");
        Settings.Global.putInt(this.f7244a.getContentResolver(), "low_power", z10 ? 1 : 0);
        Log.d("PowerMode", "set PowerMode end : " + z10 + ", from : " + this.f7249f);
        h7.a aVar = new h7.a(this.f7244a);
        aVar.c("PowerMode", "set PowerMode end : " + z10 + ", from : " + this.f7249f, System.currentTimeMillis());
        if (!z10) {
            this.f7246c.c(this.f7244a, false);
        }
        g.c(this.f7244a, "power_mode");
        RoutineSdkProvider.getInstance().getConditionStatusManager().notifyConditionChanged(this.f7244a, "dc_power_mode_condition");
    }

    public final void r(boolean z10) {
        SemLog.d("PowerMode", "1) onPreExecute for (1)");
        if (z10) {
            this.f7246c.c(this.f7244a, true);
        }
    }

    public final void s() {
        this.f7246c = new u(this.f7245b);
        this.f7248e = new d0(this.f7244a, 1, this.f7245b);
    }

    public void t() {
        int size = this.f7245b.size();
        for (int i10 = 0; i10 < size; i10++) {
            SparseArray sparseArray = this.f7245b;
            p pVar = (p) sparseArray.get(sparseArray.keyAt(i10));
            if (pVar == null) {
                SemLog.w("PowerMode", "config is not found at " + i10);
            } else if (pVar.l()) {
                pVar.q();
            }
        }
    }

    public final void u(boolean z10) {
        String str;
        boolean m10 = m(4);
        if (z10) {
            str = this.f7244a.getString(m10 ? 2131952175 : 2131952177);
        } else {
            str = this.f7244a.getString(m10 ? 2131952174 : 2131952176);
        }
        b.f(this.f7244a.getString(2131952759), str, this.f7249f);
    }

    public final void v() {
        int a10 = o6.b.a(this.f7244a);
        String str = "1";
        b.h(this.f7244a.getString(2131953027), a10 == 1 ? str : "0");
        if (a10 != 0) {
            str = a10 == 1 ? "2" : a10 == 2 ? "3" : "4";
        }
        b.h(this.f7244a.getString(2131953026), str);
        int size = this.f7245b.size();
        for (int i10 = 0; i10 < size; i10++) {
            SparseArray sparseArray = this.f7245b;
            p pVar = (p) sparseArray.get(sparseArray.keyAt(i10));
            if (pVar == null) {
                SemLog.w("PowerMode", "config is not found at " + i10);
            } else if (pVar.l()) {
                pVar.r(a10);
            }
        }
    }

    public void x(int i10, boolean z10) {
        this.f7246c.f(i10, z10);
    }

    public final void y(t tVar) {
        this.f7247d = tVar;
    }

    public void z(boolean z10) {
        Log.d("PowerMode", "set PowerMode start : " + z10 + ", from : " + this.f7249f);
        h7.a aVar = new h7.a(this.f7244a);
        aVar.c("PowerMode", "set PowerMode start : " + z10 + ", from : " + this.f7249f, System.currentTimeMillis());
        StringBuilder sb2 = new StringBuilder();
        sb2.append("- apply (1) to (");
        sb2.append(z10);
        sb2.append(")");
        SemLog.d("PowerMode", sb2.toString(), new Exception("Just print call stack"));
        if (o() == z10) {
            Log.e("PowerMode", "Power saving mode1 is already : " + z10);
        } else if (!l()) {
            Log.e("PowerMode", "Power mode is not changeable!");
        } else {
            r(z10);
            B(z10);
            q(z10);
            u(z10);
        }
    }

    public h(Context context) {
        this.f7245b = null;
        this.f7249f = "1";
        this.f7244a = context;
    }
}
