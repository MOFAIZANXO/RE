package i8;

import android.content.Context;
import android.os.Bundle;
import androidx.core.view.PointerIconCompat;
import com.samsung.android.util.SemLog;
import h6.a;
import i6.b;
import i8.h;
import java.util.Arrays;
import java.util.List;

public class c0 implements a {

    /* renamed from: b  reason: collision with root package name */
    public static final List f7236b = Arrays.asList(new String[]{"rut_get_current_time", "rut_get_psm_time"});

    /* renamed from: a  reason: collision with root package name */
    public final Context f7237a;

    public c0(Context context) {
        this.f7237a = context;
    }

    public Bundle a(Context context, String str, String str2, Bundle bundle) {
        Bundle bundle2 = new Bundle();
        SemLog.d("RutApi", "API " + str);
        if ("rut_get_psm_time".equals(str)) {
            d(bundle2);
        } else if ("rut_get_current_time".equals(str)) {
            c(bundle2);
        } else {
            bundle2.putInt("error_id", PointerIconCompat.TYPE_CONTEXT_MENU);
            bundle2.putBoolean("result", false);
        }
        return bundle2;
    }

    public List b() {
        return f7236b;
    }

    public final void c(Bundle bundle) {
        bundle.putLong("time", (long) b.f(this.f7237a));
        bundle.putBoolean("result", true);
    }

    public final void d(Bundle bundle) {
        bundle.putLong("time", new h.a(this.f7237a).a().j());
        bundle.putBoolean("result", true);
    }
}
