package i8;

import android.content.Context;
import android.os.Bundle;
import androidx.core.view.PointerIconCompat;
import com.samsung.android.util.SemLog;
import i8.h;
import java.util.Arrays;
import java.util.List;

public class g extends c {

    /* renamed from: a  reason: collision with root package name */
    public static final List f7243a = Arrays.asList(new String[]{"from_routine_turn_on_psm", "from_routine_turn_off_psm"});

    public Bundle a(Context context, String str, String str2, Bundle bundle) {
        Bundle bundle2 = new Bundle();
        SemLog.d("api.psm.routine", "API " + str);
        if ("from_routine_turn_on_psm".equals(str)) {
            h.a e10 = new h.a(context).e("5");
            i(context, e10, bundle);
            f(e10.a(), bundle2);
        } else if ("from_routine_turn_off_psm".equals(str)) {
            e(new h.a(context).e("5").a(), bundle2);
        } else {
            bundle2.putInt("error_id", PointerIconCompat.TYPE_CONTEXT_MENU);
            bundle2.putBoolean("result", false);
        }
        return bundle2;
    }

    public List b() {
        return f7243a;
    }

    public String d() {
        return "api.psm.routine";
    }
}
