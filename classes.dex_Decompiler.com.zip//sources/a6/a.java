package a6;

import androidx.core.location.LocationRequestCompat;
import java.util.ArrayList;

public class a {

    /* renamed from: a  reason: collision with root package name */
    public boolean f133a = false;

    /* renamed from: b  reason: collision with root package name */
    public long f134b = 0;

    /* renamed from: c  reason: collision with root package name */
    public boolean f135c = false;

    /* renamed from: d  reason: collision with root package name */
    public int f136d = 3;

    /* renamed from: e  reason: collision with root package name */
    public int f137e = 300;

    /* renamed from: f  reason: collision with root package name */
    public double f138f = 0.5d;

    /* renamed from: g  reason: collision with root package name */
    public long f139g = LocationRequestCompat.PASSIVE_INTERVAL;

    /* renamed from: h  reason: collision with root package name */
    public boolean f140h = true;

    /* renamed from: i  reason: collision with root package name */
    public int f141i = 3;

    /* renamed from: j  reason: collision with root package name */
    public int f142j = 7;

    /* renamed from: k  reason: collision with root package name */
    public ArrayList f143k = new ArrayList();

    /* renamed from: l  reason: collision with root package name */
    public ArrayList f144l = new ArrayList();

    /* renamed from: m  reason: collision with root package name */
    public ArrayList f145m = new ArrayList();

    public void A(int i10) {
        this.f142j = i10;
    }

    public void a(String str) {
        this.f145m.add(str);
    }

    public void b(String str) {
        this.f144l.add(str);
    }

    public void c(String str) {
        this.f143k.add(str);
    }

    public int d() {
        return this.f137e;
    }

    public double e() {
        return this.f138f;
    }

    public ArrayList f() {
        return this.f145m;
    }

    public int g() {
        return this.f141i;
    }

    public long h() {
        return this.f139g;
    }

    public boolean i() {
        return this.f133a;
    }

    public boolean j() {
        return this.f135c;
    }

    public int k() {
        return this.f136d;
    }

    public long l() {
        return this.f134b;
    }

    public int m() {
        return this.f142j;
    }

    public String n() {
        return "master_switch " + this.f135c + "\nisScpmV2 " + this.f133a + "\npolicyVersion  " + this.f134b + "\nmin_num_of_suspicous_apps " + this.f136d + "\nadj_not_exceeding " + this.f137e + "\nbattery_usage_threshold " + this.f138f + "\nforeground_usage_time_threshold " + this.f139g + "\ncheck_app_alarm_setting " + this.f140h + "\nfirst_alert_period " + this.f141i + "\nsecond_alert_period " + this.f142j + "\ntargetModels " + this.f143k.size() + "\nsuspiciousAppList " + this.f144l.size() + "\ndeepSleepList " + this.f145m.size();
    }

    public ArrayList o() {
        return this.f144l;
    }

    public ArrayList p() {
        return this.f143k;
    }

    public boolean q() {
        return this.f140h;
    }

    public void r(int i10) {
        this.f137e = i10;
    }

    public void s(double d10) {
        this.f138f = d10;
    }

    public void t(boolean z10) {
        this.f140h = z10;
    }

    public void u(int i10) {
        this.f141i = i10;
    }

    public void v(long j10) {
        this.f139g = j10;
    }

    public void w(boolean z10) {
        this.f133a = z10;
    }

    public void x(boolean z10) {
        this.f135c = z10;
    }

    public void y(int i10) {
        this.f136d = i10;
    }

    public void z(long j10) {
        this.f134b = j10;
    }
}
