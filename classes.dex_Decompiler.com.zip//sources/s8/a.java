package s8;

import android.content.Context;
import h7.c;
import java.util.ArrayList;

public class a implements c {
    public ArrayList a(Context context) {
        ArrayList arrayList = new ArrayList(1);
        if (a9.a.f(context)) {
            arrayList.add(h7.a.a("RAM PLUS", "true"));
            arrayList.add(h7.a.a("RAM PLUS", "size : " + a9.a.d(context)));
        } else {
            arrayList.add(h7.a.a("RAM PLUS", "false"));
        }
        return arrayList;
    }
}
