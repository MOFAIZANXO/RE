package pa;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.os.Bundle;
import ma.b;
import w6.h;

public class a {
    public final int a(int i10, float f10) {
        return (int) (((float) i10) * f10);
    }

    public float b(Context context) {
        return context.getResources().getDisplayMetrics().density;
    }

    public b c(Context context, Bundle bundle, boolean z10) {
        float b10 = b(context);
        return new b(a(bundle.getInt(z10 ? "appWidgetMaxWidth" : "appWidgetMinWidth"), b10), a(bundle.getInt(z10 ? "appWidgetMinHeight" : "appWidgetMaxHeight"), b10));
    }

    public boolean d(Context context, int i10) {
        return h.i() && AppWidgetManager.getInstance(context).getAppWidgetOptions(i10).getInt("hsIconSize", 0) > 0;
    }
}
