package h8;

import a7.c;
import android.app.StatusBarManager;
import android.content.Context;
import android.net.Uri;
import android.provider.Settings;
import android.util.Log;
import com.samsung.android.feature.SemFloatingFeature;
import t6.g;

public class b {

    /* renamed from: a  reason: collision with root package name */
    public final Context f6993a;

    public b(Context context) {
        this.f6993a = context;
    }

    public static boolean f() {
        return SemFloatingFeature.getInstance().getBoolean("SEC_FLOATING_FEATURE_SYSTEM_SUPPORT_LOW_HEAT_MODE");
    }

    public static void g(Context context) {
        if (f()) {
            d7.b.h(context.getString(2131953019), String.valueOf(new b(context).a()));
        }
    }

    public int a() {
        return Settings.Global.getInt(this.f6993a.getContentResolver(), "sem_low_heat_mode", 0);
    }

    public String b() {
        return a() == 1 ? this.f6993a.getString(2131952522) : this.f6993a.getString(2131952524);
    }

    public Uri c() {
        return Settings.Global.getUriFor("sem_low_heat_mode");
    }

    public void d(boolean z10) {
        StatusBarManager statusBarManager = (StatusBarManager) this.f6993a.getSystemService("statusbar");
        if (z10) {
            c.q(statusBarManager, "performance_profile");
            c.r(statusBarManager, "performance_profile", 2131230905, 0, this.f6993a.getString(2131952521));
            return;
        }
        c.q(statusBarManager, "performance_profile");
    }

    public boolean e() {
        return a() == 1;
    }

    public void h(int i10) {
        Log.d("LowHeatManager", "Update Mode: " + i10);
        Settings.Global.putInt(this.f6993a.getContentResolver(), "sem_low_heat_mode", i10);
        d(e());
        g.c(this.f6993a, "performance_optimization");
    }
}
