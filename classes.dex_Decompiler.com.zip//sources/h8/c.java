package h8;

import android.app.ActivityManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.provider.Settings;
import android.widget.RemoteViews;
import androidx.core.view.ViewCompat;
import com.samsung.android.util.SemLog;
import java.util.HashMap;
import java.util.Map;
import kotlin.jvm.internal.g;
import kotlin.jvm.internal.l;
import kotlin.jvm.internal.m;
import qb.d;
import qb.e;

public final class c implements t6.b {

    /* renamed from: c  reason: collision with root package name */
    public static final a f6994c = new a((g) null);

    /* renamed from: a  reason: collision with root package name */
    public final Context f6995a;

    /* renamed from: b  reason: collision with root package name */
    public final d f6996b = e.a(new b(this));

    public static final class a {
        public a() {
        }

        public /* synthetic */ a(g gVar) {
            this();
        }
    }

    public static final class b extends m implements ac.a {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ c f6997a;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public b(c cVar) {
            super(0);
            this.f6997a = cVar;
        }

        /* renamed from: a */
        public final b invoke() {
            return new b(this.f6997a.f6995a);
        }
    }

    public c(Context context) {
        l.e(context, "context");
        this.f6995a = context;
    }

    public String a() {
        return "";
    }

    public boolean b() {
        return true;
    }

    public int c() {
        return 2131230883;
    }

    public void d() {
        SemLog.d("DC.PerfOptTileBridge", "onStartListening");
    }

    public Map e() {
        HashMap hashMap = new HashMap();
        hashMap.put("DC.PerfOptTileBridge", new IntentFilter("com.samsung.android.sm.ACTION_PERFORMANCE_OPTIMIZATION_TILE"));
        return hashMap;
    }

    public Intent f() {
        Intent intent = new Intent();
        intent.setPackage(this.f6995a.getPackageName());
        intent.setAction("com.samsung.android.sm.ACTION_PERFORMANCE_OPTIMIZATION");
        return intent;
    }

    public boolean g() {
        return false;
    }

    public void h() {
        SemLog.d("DC.PerfOptTileBridge", "onStopListening");
    }

    public Map i() {
        HashMap hashMap = new HashMap();
        Uri uriFor = Settings.Global.getUriFor("sem_low_heat_mode");
        l.d(uriFor, "getUriFor(PerfOptManager.SETTINGS_KEY)");
        hashMap.put(uriFor, (Object) null);
        return hashMap;
    }

    public boolean isTurnedOn() {
        return r().e();
    }

    public void j(Intent intent) {
        super.j(intent);
        if (intent != null) {
            int intExtra = intent.getIntExtra("key_mode", -1);
            SemLog.i("DC.PerfOptTileBridge", "Tile BroadcastReceiver get state value: " + intExtra);
            if (intExtra != -1) {
                r().h(intExtra);
            }
        }
    }

    public void k() {
        int a10 = r().a() ^ 1;
        SemLog.d("DC.PerfOptTileBridge", "Toggled State: " + a10);
        r().h(a10);
    }

    public RemoteViews m() {
        SemLog.d("DC.PerfOptTileBridge", "getRemoteView");
        RemoteViews remoteViews = new RemoteViews(this.f6995a.getPackageName(), 2131558587);
        y(remoteViews);
        u(remoteViews);
        w(remoteViews);
        return remoteViews;
    }

    public String n() {
        return "performance_optimization";
    }

    public int o() {
        return 2131952526;
    }

    public int p() {
        return 2131952526;
    }

    public final b r() {
        return (b) this.f6996b.getValue();
    }

    public final int s(String str) {
        return Settings.System.semGetIntForUser(this.f6995a.getContentResolver(), str, ViewCompat.MEASURED_STATE_MASK, ActivityManager.semGetCurrentUser());
    }

    public final PendingIntent t(int i10) {
        Intent intent = new Intent();
        intent.setPackage(this.f6995a.getPackageName());
        intent.setAction("com.samsung.android.sm.ACTION_PERFORMANCE_OPTIMIZATION_TILE");
        intent.putExtra("key_mode", i10);
        return PendingIntent.getBroadcast(this.f6995a, i10, intent, 201326592);
    }

    public final void u(RemoteViews remoteViews) {
        remoteViews.setOnClickPendingIntent(2131362956, t(0));
        remoteViews.setOnClickPendingIntent(2131362944, t(1));
    }

    public final void v(RemoteViews remoteViews, int i10) {
        remoteViews.setTextColor(i10, s("qs_detail_content_primary_text_color"));
    }

    public final void w(RemoteViews remoteViews) {
        int a10 = r().a();
        int i10 = a10 != 0 ? a10 != 1 ? -1 : 2131362945 : 2131362957;
        if (i10 != -1) {
            remoteViews.setBoolean(i10, "setChecked", true);
        }
    }

    public final void x(RemoteViews remoteViews, int i10) {
        remoteViews.setTextColor(i10, s("qs_detail_content_secondary_text_color"));
    }

    public final void y(RemoteViews remoteViews) {
        v(remoteViews, 2131362958);
        v(remoteViews, 2131362946);
        x(remoteViews, 2131362719);
        x(remoteViews, 2131362718);
    }
}
