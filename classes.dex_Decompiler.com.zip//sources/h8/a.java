package h8;

import android.content.Context;
import h7.c;
import java.util.ArrayList;

public class a implements c {
    public ArrayList a(Context context) {
        ArrayList arrayList = new ArrayList(1);
        arrayList.add(h7.a.a("PerformanceOptimization", "Performance Optimization avail : " + b.f()));
        return arrayList;
    }
}
