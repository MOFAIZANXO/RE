package u1;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import n1.l;

public abstract class c extends d {

    /* renamed from: h  reason: collision with root package name */
    public static final String f10050h = l.f("BrdcstRcvrCnstrntTrckr");

    /* renamed from: g  reason: collision with root package name */
    public final BroadcastReceiver f10051g = new a();

    public class a extends BroadcastReceiver {
        public a() {
        }

        public void onReceive(Context context, Intent intent) {
            if (intent != null) {
                c.this.h(context, intent);
            }
        }
    }

    public c(Context context, z1.a aVar) {
        super(context, aVar);
    }

    public void e() {
        l.c().a(f10050h, String.format("%s: registering receiver", new Object[]{getClass().getSimpleName()}), new Throwable[0]);
        this.f10055b.registerReceiver(this.f10051g, g());
    }

    public void f() {
        l.c().a(f10050h, String.format("%s: unregistering receiver", new Object[]{getClass().getSimpleName()}), new Throwable[0]);
        this.f10055b.unregisterReceiver(this.f10051g);
    }

    public abstract IntentFilter g();

    public abstract void h(Context context, Intent intent);
}
