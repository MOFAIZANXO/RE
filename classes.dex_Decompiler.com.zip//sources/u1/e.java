package u1;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import androidx.core.net.ConnectivityManagerCompat;
import n1.l;

public class e extends d {

    /* renamed from: j  reason: collision with root package name */
    public static final String f10061j = l.f("NetworkStateTracker");

    /* renamed from: g  reason: collision with root package name */
    public final ConnectivityManager f10062g = ((ConnectivityManager) this.f10055b.getSystemService("connectivity"));

    /* renamed from: h  reason: collision with root package name */
    public b f10063h;

    /* renamed from: i  reason: collision with root package name */
    public a f10064i;

    public class a extends BroadcastReceiver {
        public a() {
        }

        public void onReceive(Context context, Intent intent) {
            if (intent != null && intent.getAction() != null && intent.getAction().equals("android.net.conn.CONNECTIVITY_CHANGE")) {
                l.c().a(e.f10061j, "Network broadcast received", new Throwable[0]);
                e eVar = e.this;
                eVar.d(eVar.g());
            }
        }
    }

    public class b extends ConnectivityManager.NetworkCallback {
        public b() {
        }

        public void onCapabilitiesChanged(Network network, NetworkCapabilities networkCapabilities) {
            l.c().a(e.f10061j, String.format("Network capabilities changed: %s", new Object[]{networkCapabilities}), new Throwable[0]);
            e eVar = e.this;
            eVar.d(eVar.g());
        }

        public void onLost(Network network) {
            l.c().a(e.f10061j, "Network connection lost", new Throwable[0]);
            e eVar = e.this;
            eVar.d(eVar.g());
        }
    }

    public e(Context context, z1.a aVar) {
        super(context, aVar);
        if (j()) {
            this.f10063h = new b();
        } else {
            this.f10064i = new a();
        }
    }

    public static boolean j() {
        return true;
    }

    public void e() {
        if (j()) {
            try {
                l.c().a(f10061j, "Registering network callback", new Throwable[0]);
                this.f10062g.registerDefaultNetworkCallback(this.f10063h);
            } catch (IllegalArgumentException | SecurityException e10) {
                l.c().b(f10061j, "Received exception while registering network callback", e10);
            }
        } else {
            l.c().a(f10061j, "Registering broadcast receiver", new Throwable[0]);
            this.f10055b.registerReceiver(this.f10064i, new IntentFilter("android.net.conn.CONNECTIVITY_CHANGE"));
        }
    }

    public void f() {
        if (j()) {
            try {
                l.c().a(f10061j, "Unregistering network callback", new Throwable[0]);
                this.f10062g.unregisterNetworkCallback(this.f10063h);
            } catch (IllegalArgumentException | SecurityException e10) {
                l.c().b(f10061j, "Received exception while unregistering network callback", e10);
            }
        } else {
            l.c().a(f10061j, "Unregistering broadcast receiver", new Throwable[0]);
            this.f10055b.unregisterReceiver(this.f10064i);
        }
    }

    public s1.b g() {
        NetworkInfo activeNetworkInfo = this.f10062g.getActiveNetworkInfo();
        boolean z10 = true;
        boolean z11 = activeNetworkInfo != null && activeNetworkInfo.isConnected();
        boolean i10 = i();
        boolean isActiveNetworkMetered = ConnectivityManagerCompat.isActiveNetworkMetered(this.f10062g);
        if (activeNetworkInfo == null || activeNetworkInfo.isRoaming()) {
            z10 = false;
        }
        return new s1.b(z11, i10, isActiveNetworkMetered, z10);
    }

    /* renamed from: h */
    public s1.b b() {
        return g();
    }

    public boolean i() {
        try {
            NetworkCapabilities networkCapabilities = this.f10062g.getNetworkCapabilities(this.f10062g.getActiveNetwork());
            return networkCapabilities != null && networkCapabilities.hasCapability(16);
        } catch (SecurityException e10) {
            l.c().b(f10061j, "Unable to validate active network", e10);
            return false;
        }
    }
}
