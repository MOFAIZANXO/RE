package u1;

import android.content.Context;
import z1.a;

public class g {

    /* renamed from: e  reason: collision with root package name */
    public static g f10068e;

    /* renamed from: a  reason: collision with root package name */
    public a f10069a;

    /* renamed from: b  reason: collision with root package name */
    public b f10070b;

    /* renamed from: c  reason: collision with root package name */
    public e f10071c;

    /* renamed from: d  reason: collision with root package name */
    public f f10072d;

    public g(Context context, a aVar) {
        Context applicationContext = context.getApplicationContext();
        this.f10069a = new a(applicationContext, aVar);
        this.f10070b = new b(applicationContext, aVar);
        this.f10071c = new e(applicationContext, aVar);
        this.f10072d = new f(applicationContext, aVar);
    }

    public static synchronized g c(Context context, a aVar) {
        g gVar;
        synchronized (g.class) {
            if (f10068e == null) {
                f10068e = new g(context, aVar);
            }
            gVar = f10068e;
        }
        return gVar;
    }

    public a a() {
        return this.f10069a;
    }

    public b b() {
        return this.f10070b;
    }

    public e d() {
        return this.f10071c;
    }

    public f e() {
        return this.f10072d;
    }
}
