package u1;

import android.content.Context;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import n1.l;

public abstract class d {

    /* renamed from: f  reason: collision with root package name */
    public static final String f10053f = l.f("ConstraintTracker");

    /* renamed from: a  reason: collision with root package name */
    public final z1.a f10054a;

    /* renamed from: b  reason: collision with root package name */
    public final Context f10055b;

    /* renamed from: c  reason: collision with root package name */
    public final Object f10056c = new Object();

    /* renamed from: d  reason: collision with root package name */
    public final Set f10057d = new LinkedHashSet();

    /* renamed from: e  reason: collision with root package name */
    public Object f10058e;

    public class a implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ List f10059a;

        public a(List list) {
            this.f10059a = list;
        }

        public void run() {
            for (s1.a a10 : this.f10059a) {
                a10.a(d.this.f10058e);
            }
        }
    }

    public d(Context context, z1.a aVar) {
        this.f10055b = context.getApplicationContext();
        this.f10054a = aVar;
    }

    public void a(s1.a aVar) {
        synchronized (this.f10056c) {
            if (this.f10057d.add(aVar)) {
                if (this.f10057d.size() == 1) {
                    this.f10058e = b();
                    l.c().a(f10053f, String.format("%s: initial state = %s", new Object[]{getClass().getSimpleName(), this.f10058e}), new Throwable[0]);
                    e();
                }
                aVar.a(this.f10058e);
            }
        }
    }

    public abstract Object b();

    public void c(s1.a aVar) {
        synchronized (this.f10056c) {
            if (this.f10057d.remove(aVar) && this.f10057d.isEmpty()) {
                f();
            }
        }
    }

    /* JADX WARNING: Code restructure failed: missing block: B:13:0x002a, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void d(java.lang.Object r4) {
        /*
            r3 = this;
            java.lang.Object r0 = r3.f10056c
            monitor-enter(r0)
            java.lang.Object r1 = r3.f10058e     // Catch:{ all -> 0x002b }
            if (r1 == r4) goto L_0x0029
            if (r1 == 0) goto L_0x0010
            boolean r1 = r1.equals(r4)     // Catch:{ all -> 0x002b }
            if (r1 == 0) goto L_0x0010
            goto L_0x0029
        L_0x0010:
            r3.f10058e = r4     // Catch:{ all -> 0x002b }
            java.util.ArrayList r4 = new java.util.ArrayList     // Catch:{ all -> 0x002b }
            java.util.Set r1 = r3.f10057d     // Catch:{ all -> 0x002b }
            r4.<init>(r1)     // Catch:{ all -> 0x002b }
            z1.a r1 = r3.f10054a     // Catch:{ all -> 0x002b }
            java.util.concurrent.Executor r1 = r1.a()     // Catch:{ all -> 0x002b }
            u1.d$a r2 = new u1.d$a     // Catch:{ all -> 0x002b }
            r2.<init>(r4)     // Catch:{ all -> 0x002b }
            r1.execute(r2)     // Catch:{ all -> 0x002b }
            monitor-exit(r0)     // Catch:{ all -> 0x002b }
            return
        L_0x0029:
            monitor-exit(r0)     // Catch:{ all -> 0x002b }
            return
        L_0x002b:
            r3 = move-exception
            monitor-exit(r0)     // Catch:{ all -> 0x002b }
            throw r3
        */
        throw new UnsupportedOperationException("Method not decompiled: u1.d.d(java.lang.Object):void");
    }

    public abstract void e();

    public abstract void f();
}
