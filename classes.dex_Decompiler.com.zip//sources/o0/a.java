package o0;

import dalvik.system.PathClassLoader;
import h0.b;
import java.lang.reflect.Method;

public abstract class a {
    public static Object a(PathClassLoader pathClassLoader) {
        Method c10 = b.c(pathClassLoader, "com.android.calendar.Feature", "getSolarLunarConverter", new Class[0]);
        if (c10 != null) {
            return h0.a.k((Object) null, c10, new Object[0]);
        }
        return null;
    }
}
