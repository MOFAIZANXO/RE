package o0;

import dalvik.system.PathClassLoader;
import h0.a;
import h0.b;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public abstract class d {
    public static int a(PathClassLoader pathClassLoader, Object obj, int i10, int i11, boolean z10) {
        Class cls = Integer.TYPE;
        Method c10 = b.c(pathClassLoader, "com.samsung.android.calendar.secfeature.lunarcalendar.SolarLunarTables", "getDayLengthOf", cls, cls, Boolean.TYPE);
        if (c10 == null) {
            return 29;
        }
        Object k10 = a.k(obj, c10, Integer.valueOf(i10), Integer.valueOf(i11), Boolean.valueOf(z10));
        if (k10 instanceof Integer) {
            return ((Integer) k10).intValue();
        }
        return 29;
    }

    public static int b(PathClassLoader pathClassLoader, Object obj) {
        Field b10 = b.b(pathClassLoader, "com.samsung.android.calendar.secfeature.lunarcalendar.SolarLunarTables", "INDEX_OF_LEAP_MONTH");
        if (b10 == null) {
            return 13;
        }
        Object a10 = a.a(obj, b10);
        if (a10 instanceof Integer) {
            return ((Integer) a10).intValue();
        }
        return 13;
    }

    public static int c(PathClassLoader pathClassLoader, Object obj) {
        Field b10 = b.b(pathClassLoader, "com.samsung.android.calendar.secfeature.lunarcalendar.SolarLunarTables", "START_OF_LUNAR_YEAR");
        if (b10 == null) {
            return 1881;
        }
        Object a10 = a.a(obj, b10);
        if (a10 instanceof Integer) {
            return ((Integer) a10).intValue();
        }
        return 1881;
    }

    public static int d(PathClassLoader pathClassLoader, Object obj) {
        Field b10 = b.b(pathClassLoader, "com.samsung.android.calendar.secfeature.lunarcalendar.SolarLunarTables", "WIDTH_PER_YEAR");
        if (b10 == null) {
            return 14;
        }
        Object a10 = a.a(obj, b10);
        if (a10 instanceof Integer) {
            return ((Integer) a10).intValue();
        }
        return 14;
    }

    public static byte e(PathClassLoader pathClassLoader, Object obj, int i10) {
        Method c10 = b.c(pathClassLoader, "com.samsung.android.calendar.secfeature.lunarcalendar.SolarLunarTables", "getLunar", Integer.TYPE);
        if (c10 == null) {
            return Byte.MAX_VALUE;
        }
        Object k10 = a.k(obj, c10, Integer.valueOf(i10));
        if (k10 instanceof Byte) {
            return ((Byte) k10).byteValue();
        }
        return Byte.MAX_VALUE;
    }

    public static boolean f(PathClassLoader pathClassLoader, Object obj, int i10, int i11) {
        Class cls = Integer.TYPE;
        Method c10 = b.c(pathClassLoader, "com.samsung.android.calendar.secfeature.lunarcalendar.SolarLunarTables", "isLeapMonth", cls, cls);
        if (c10 != null) {
            Object k10 = a.k(obj, c10, Integer.valueOf(i10), Integer.valueOf(i11));
            if (k10 instanceof Boolean) {
                return ((Boolean) k10).booleanValue();
            }
        }
        return false;
    }
}
