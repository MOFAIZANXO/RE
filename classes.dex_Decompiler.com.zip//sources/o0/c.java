package o0;

import dalvik.system.PathClassLoader;
import h0.a;
import h0.b;
import java.lang.reflect.Method;

public abstract class c {
    public static void a(PathClassLoader pathClassLoader, Object obj, int i10, int i11, int i12, boolean z10) {
        Class cls = Integer.TYPE;
        Method c10 = b.c(pathClassLoader, "com.samsung.android.calendar.secfeature.lunarcalendar.SolarLunarConverter", "convertLunarToSolar", cls, cls, cls, Boolean.TYPE);
        if (c10 != null) {
            a.k(obj, c10, Integer.valueOf(i10), Integer.valueOf(i11), Integer.valueOf(i12), Boolean.valueOf(z10));
        }
    }

    public static void b(PathClassLoader pathClassLoader, Object obj, int i10, int i11, int i12) {
        Class cls = Integer.TYPE;
        Method c10 = b.c(pathClassLoader, "com.samsung.android.calendar.secfeature.lunarcalendar.SolarLunarConverter", "convertSolarToLunar", cls, cls, cls);
        if (c10 != null) {
            a.k(obj, c10, Integer.valueOf(i10), Integer.valueOf(i11), Integer.valueOf(i12));
        }
    }

    public static int c(PathClassLoader pathClassLoader, Object obj) {
        Method c10 = b.c(pathClassLoader, "com.samsung.android.calendar.secfeature.lunarcalendar.SolarLunarConverter", "getDay", new Class[0]);
        if (c10 == null) {
            return 19;
        }
        Object k10 = a.k(obj, c10, new Object[0]);
        if (k10 instanceof Integer) {
            return ((Integer) k10).intValue();
        }
        return 19;
    }

    public static int d(PathClassLoader pathClassLoader, Object obj, int i10, int i11, boolean z10) {
        Class cls = Integer.TYPE;
        Method c10 = b.c(pathClassLoader, "com.samsung.android.calendar.secfeature.lunarcalendar.SolarLunarConverter", "getDayLengthOf", cls, cls, Boolean.TYPE);
        if (c10 == null) {
            return 30;
        }
        Object k10 = a.k(obj, c10, Integer.valueOf(i10), Integer.valueOf(i11), Boolean.valueOf(z10));
        if (k10 instanceof Integer) {
            return ((Integer) k10).intValue();
        }
        return 30;
    }

    public static int e(PathClassLoader pathClassLoader, Object obj) {
        Method c10 = b.c(pathClassLoader, "com.samsung.android.calendar.secfeature.lunarcalendar.SolarLunarConverter", "getMonth", new Class[0]);
        if (c10 == null) {
            return 10;
        }
        Object k10 = a.k(obj, c10, new Object[0]);
        if (k10 instanceof Integer) {
            return ((Integer) k10).intValue();
        }
        return 10;
    }

    public static int f(PathClassLoader pathClassLoader, Object obj, int i10, int i11, int i12) {
        Class cls = Integer.TYPE;
        Method c10 = b.c(pathClassLoader, "com.samsung.android.calendar.secfeature.lunarcalendar.SolarLunarConverter", "getWeekday", cls, cls, cls);
        if (c10 != null) {
            Object k10 = a.k(obj, c10, Integer.valueOf(i10), Integer.valueOf(i11), Integer.valueOf(i12));
            if (k10 instanceof Integer) {
                return ((Integer) k10).intValue();
            }
        }
        return 0;
    }

    public static int g(PathClassLoader pathClassLoader, Object obj) {
        Method c10 = b.c(pathClassLoader, "com.samsung.android.calendar.secfeature.lunarcalendar.SolarLunarConverter", "getYear", new Class[0]);
        if (c10 == null) {
            return 2019;
        }
        Object k10 = a.k(obj, c10, new Object[0]);
        if (k10 instanceof Integer) {
            return ((Integer) k10).intValue();
        }
        return 2019;
    }

    public static boolean h(PathClassLoader pathClassLoader, Object obj) {
        Method c10 = b.c(pathClassLoader, "com.samsung.android.calendar.secfeature.lunarcalendar.SolarLunarConverter", "isLeapMonth", new Class[0]);
        if (c10 != null) {
            Object k10 = a.k(obj, c10, new Object[0]);
            if (k10 instanceof Boolean) {
                return ((Boolean) k10).booleanValue();
            }
        }
        return false;
    }
}
