package o0;

import android.content.Context;
import dalvik.system.PathClassLoader;
import h0.a;
import java.lang.reflect.Method;
import java.util.Calendar;

public abstract class b {
    public static String a(PathClassLoader pathClassLoader, Calendar calendar, Context context) {
        Method c10 = h0.b.c(pathClassLoader, "com.android.calendar.event.widget.datetimepicker.LunarDateUtils", "buildLunarDateString", Calendar.class, Context.class);
        if (c10 != null) {
            Object k10 = a.k((Object) null, c10, calendar, context);
            if (k10 instanceof String) {
                return (String) k10;
            }
        }
        return null;
    }
}
