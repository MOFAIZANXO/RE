package u9;

public interface a {
    void h(int i10);

    void i(int i10);
}
