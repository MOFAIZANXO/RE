package u9;

import com.samsung.android.sm.score.data.OptData;

public interface b {
    void g(OptData optData);

    void k(OptData optData);

    void l(OptData optData);
}
