package u9;

import java.util.ArrayList;

public interface c {
    void a(ArrayList arrayList);
}
