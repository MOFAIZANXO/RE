package j9;

import android.animation.ValueAnimator;
import com.samsung.android.sm.scheduled.reboot.autorestart.AlarmRepeatButton;

public final /* synthetic */ class b implements ValueAnimator.AnimatorUpdateListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ AlarmRepeatButton f7472a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ int f7473b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ boolean f7474c;

    public /* synthetic */ b(AlarmRepeatButton alarmRepeatButton, int i10, boolean z10) {
        this.f7472a = alarmRepeatButton;
        this.f7473b = i10;
        this.f7474c = z10;
    }

    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        this.f7472a.k(this.f7473b, this.f7474c, valueAnimator);
    }
}
