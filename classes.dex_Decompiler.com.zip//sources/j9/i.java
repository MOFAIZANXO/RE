package j9;

import a7.b;
import android.content.Context;
import android.net.Uri;
import com.samsung.android.util.SemLog;
import n9.h;
import w6.d;
import w6.e;

public class i {
    public static boolean b() {
        return b.e("user.owner") && !b.e("dc.secure.phone") && (!d.a() || d.d());
    }

    public static boolean c(Context context) {
        return e.b(context);
    }

    public Uri a() {
        return e.a();
    }

    public boolean d(Context context) {
        return new h().c(context);
    }

    public void e(Context context, boolean z10) {
        SemLog.i("AutoRebootConfig", "set to " + z10);
        if (z10 != c(context)) {
            e.e(context, Boolean.valueOf(z10));
        }
    }
}
