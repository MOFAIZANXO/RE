package j9;

import android.content.Context;
import android.os.Bundle;
import com.samsung.android.util.SemLog;
import h6.a;
import java.util.Collections;
import java.util.List;
import m9.d;

public class k implements a {

    /* renamed from: a  reason: collision with root package name */
    public static final List f7492a = Collections.singletonList("autorestart_last_time");

    public Bundle a(Context context, String str, String str2, Bundle bundle) {
        Bundle bundle2 = new Bundle();
        SemLog.d("AutoRestartLastTimeDcApi", "API " + str);
        if ("autorestart_last_time".equals(str)) {
            d(context, bundle2);
        } else {
            bundle2.putBoolean("result", false);
        }
        return bundle2;
    }

    public List b() {
        return f7492a;
    }

    public final long c(Context context) {
        return new d(context).d();
    }

    public final void d(Context context, Bundle bundle) {
        bundle.putLong("value", c(context));
        bundle.putBoolean("result", true);
    }
}
