package j9;

import android.view.View;
import com.samsung.android.sm.scheduled.reboot.autorestart.AlarmRepeatButton;

public final /* synthetic */ class a implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ AlarmRepeatButton f7470a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ int f7471b;

    public /* synthetic */ a(AlarmRepeatButton alarmRepeatButton, int i10) {
        this.f7470a = alarmRepeatButton;
        this.f7471b = i10;
    }

    public final void onClick(View view) {
        this.f7470a.j(this.f7471b, view);
    }
}
