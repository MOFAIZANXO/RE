package j9;

import android.content.Context;
import com.samsung.android.util.SemLog;
import n9.a;
import n9.o;

public class e {
    public boolean a(Context context, i iVar, d dVar) {
        a aVar = new a(context);
        if (!i.c(context)) {
            SemLog.d("AutoRebootCondition", "sec_silent_auto_reset is off, Should drop reset event");
            aVar.d("auto reboot setting off");
            return false;
        } else if (!dVar.g()) {
            SemLog.d("AutoRebootCondition", "It's not the day to AutoReset, Should drop reset event");
            aVar.d("wrong day of week");
            return false;
        } else if (!w6.e.c(context)) {
            return new o(context).e();
        } else {
            SemLog.d("AutoRebootCondition", "FlashLight is on, Should drop reset event");
            aVar.d("FlashLight is on");
            return false;
        }
    }
}
