package j9;

import android.content.Context;
import h7.a;
import h7.c;
import java.util.ArrayList;

public class l implements c {
    public ArrayList a(Context context) {
        ArrayList arrayList = new ArrayList(1);
        h hVar = new h(context);
        arrayList.add(a.a("AutoReboot", "support : " + hVar.l()));
        arrayList.add(a.a("AutoReboot", "status : " + hVar.m()));
        arrayList.add(a.a("AutoReboot", "changeable : " + hVar.n()));
        arrayList.add(a.a("AutoReboot", "multi days : " + hVar.e()));
        arrayList.add(a.a("AutoReboot", "displayed time : " + hVar.j()));
        arrayList.add(a.a("AutoReboot", "distributed time : " + hVar.g()));
        return arrayList;
    }
}
