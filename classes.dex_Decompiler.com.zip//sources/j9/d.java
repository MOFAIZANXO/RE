package j9;

import android.content.Context;
import android.widget.ToggleButton;
import com.samsung.android.util.SemLog;
import h9.b;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;

public class d {

    /* renamed from: c  reason: collision with root package name */
    public static final int[] f7478c = {16777216, 1048576, 65536, 4096, 256, 16, 1};

    /* renamed from: a  reason: collision with root package name */
    public j f7479a;

    /* renamed from: b  reason: collision with root package name */
    public b f7480b;

    public d(Context context) {
        this.f7479a = new j(context);
        this.f7480b = new b(context, new f(context));
    }

    public final int a(int i10) {
        switch (i10) {
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
                return f7478c[i10 - 1];
            default:
                return 0;
        }
    }

    public String b(Context context) {
        StringBuilder sb2 = new StringBuilder();
        int d10 = new j(context).d();
        int i10 = 1;
        for (int i11 : f7478c) {
            if ((i11 & d10) > 0) {
                sb2.append(i10);
                sb2.append(", ");
            }
            i10++;
        }
        return sb2.toString();
    }

    public String c() {
        return new SimpleDateFormat("HH:mm", Locale.ENGLISH).format(this.f7480b.c().getTime());
    }

    public Calendar d() {
        return this.f7480b.b();
    }

    public int e(ToggleButton[] toggleButtonArr) {
        int firstDayOfWeek = Calendar.getInstance().getFirstDayOfWeek() - 1;
        int i10 = 0;
        for (int i11 = 0; i11 < 7; i11++) {
            if (toggleButtonArr[i11].isChecked()) {
                i10 |= f7478c[(firstDayOfWeek + i11) % 7];
            }
        }
        SemLog.d("AutoRebootAlarm", "getCheckDay : " + i10);
        return i10;
    }

    public void f(int i10) {
        this.f7479a.k(a(i10));
    }

    public boolean g() {
        return (a(Calendar.getInstance().get(7)) & this.f7479a.d()) > 0;
    }

    public void h() {
        this.f7480b.d();
    }

    public void i() {
        this.f7480b.e();
    }

    public void j() {
        if (this.f7479a.d() <= 0) {
            f(Calendar.getInstance().get(7));
        }
    }

    public void k(boolean[] zArr, int i10) {
        int firstDayOfWeek = Calendar.getInstance().getFirstDayOfWeek() - 1;
        for (int i11 = 0; i11 < 7; i11++) {
            int i12 = f7478c[(firstDayOfWeek + i11) % 7];
            zArr[i11] = (i10 & i12) == i12;
        }
    }

    public void l(int i10, int i11) {
        this.f7480b.f(i10, i11);
    }
}
