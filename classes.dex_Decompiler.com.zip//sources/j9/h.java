package j9;

import android.content.Context;
import android.net.Uri;
import android.widget.ToggleButton;
import com.samsung.android.util.SemLog;
import d7.b;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;
import m9.d;
import n9.a;
import n9.o;
import z6.c;

public class h {

    /* renamed from: a  reason: collision with root package name */
    public final Context f7485a;

    /* renamed from: b  reason: collision with root package name */
    public final j f7486b;

    /* renamed from: c  reason: collision with root package name */
    public final i f7487c = new i();

    /* renamed from: d  reason: collision with root package name */
    public final d f7488d;

    public h(Context context) {
        this.f7485a = context;
        this.f7486b = new j(context);
        this.f7488d = new d(context);
    }

    public boolean a() {
        return new e().a(this.f7485a, this.f7487c, this.f7488d);
    }

    public void b() {
        boolean z10;
        boolean b10 = i.b();
        boolean c10 = i.c(this.f7485a);
        boolean z11 = false;
        if (!b10 || !c10) {
            z10 = false;
        } else {
            o oVar = new o(this.f7485a);
            boolean f10 = oVar.f();
            if (f10) {
                z11 = oVar.j();
            }
            u(true);
            z10 = z11;
            z11 = f10;
        }
        String str = "AutoReboot isSupported :" + b10 + ", isTurnedOn :" + c10 + ", isSilentReboot :" + z11 + ", postProcessResult :" + z10;
        SemLog.i("AutoRebootRepo", str);
        new a(this.f7485a).d(str);
    }

    public void c() {
        o oVar = new o(this.f7485a);
        if (oVar.k()) {
            new a(this.f7485a).d("AutoReboot");
            new d(this.f7485a).i(Long.toString(System.currentTimeMillis()));
            c.k(this.f7485a).y(Boolean.TRUE);
            oVar.i();
            return;
        }
        u(m());
    }

    public Calendar d() {
        return this.f7488d.d();
    }

    public String e() {
        return this.f7488d.b(this.f7485a);
    }

    public int f() {
        return this.f7486b.d();
    }

    public String g() {
        return this.f7488d.c();
    }

    public int h(ToggleButton[] toggleButtonArr) {
        return this.f7488d.e(toggleButtonArr);
    }

    public String i() {
        return this.f7486b.c(this.f7485a);
    }

    public String j() {
        return this.f7486b.b();
    }

    public Uri k() {
        return this.f7487c.a();
    }

    public boolean l() {
        return i.b();
    }

    public boolean m() {
        return i.c(this.f7485a);
    }

    public boolean n() {
        return this.f7487c.d(this.f7485a);
    }

    public void o() {
        this.f7486b.i();
    }

    public final void p(boolean z10) {
        String str = "updateRebootSetting :" + z10 + " AutoRebootDays : " + f() + " AutoRebootTime : " + g();
        SemLog.i("AutoRebootRepo", str);
        new a(this.f7485a).d(str);
    }

    public final void q() {
        long c10 = new d(this.f7485a).c();
        b.h(this.f7485a.getString(2131953010), c10 > 0 ? Long.toString(TimeUnit.MILLISECONDS.toDays(c10)) : !w6.d.b(this.f7485a) ? "Off" : "Never");
    }

    public void r() {
        if (l()) {
            boolean m10 = m();
            SemLog.i("AutoRebootRepo", "context ReSTart option : " + m10);
            b.h(this.f7485a.getString(2131953002), m10 ? "1" : "0");
            if (m10) {
                b.h(this.f7485a.getString(2131953000), e());
                b.h(this.f7485a.getString(2131953001), g());
            }
        }
        q();
    }

    public void s(boolean[] zArr, int i10) {
        this.f7488d.k(zArr, i10);
    }

    public int t() {
        Calendar instance = Calendar.getInstance();
        int i10 = instance.get(7);
        int firstDayOfWeek = ((i10 + 7) - instance.getFirstDayOfWeek()) % 7;
        this.f7488d.f(i10);
        return firstDayOfWeek;
    }

    public void u(boolean z10) {
        if (z10) {
            this.f7488d.j();
            this.f7488d.h();
        } else {
            this.f7488d.i();
        }
        p(z10);
    }

    public void v(int i10) {
        this.f7486b.k(i10);
    }

    public void w(boolean z10) {
        this.f7487c.e(this.f7485a, z10);
        u(z10);
    }

    public void x(int i10, int i11) {
        this.f7488d.l(i10, i11);
        u(i.c(this.f7485a));
    }
}
