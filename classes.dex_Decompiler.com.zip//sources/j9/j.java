package j9;

import android.content.ContentResolver;
import android.content.Context;
import android.content.SharedPreferences;
import android.text.format.DateFormat;
import android.util.Log;
import com.samsung.android.util.SemLog;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Random;
import p6.a;

public class j {

    /* renamed from: a  reason: collision with root package name */
    public final SharedPreferences.Editor f7489a;

    /* renamed from: b  reason: collision with root package name */
    public final ContentResolver f7490b;

    /* renamed from: c  reason: collision with root package name */
    public final Random f7491c = new Random();

    public j(Context context) {
        this.f7489a = context.getSharedPreferences("pref_sm_security", 0).edit();
        this.f7490b = context.getContentResolver();
    }

    public final Calendar a() {
        Calendar instance = Calendar.getInstance();
        instance.setTimeInMillis(System.currentTimeMillis());
        instance.set(11, g());
        instance.set(12, h());
        return instance;
    }

    public String b() {
        return new SimpleDateFormat("HH:mm", Locale.ENGLISH).format(a().getTime());
    }

    public String c(Context context) {
        return DateFormat.getTimeFormat(context).format(a().getTime());
    }

    public int d() {
        return a.b(this.f7490b, "key_auto_reset_multi_day", 0);
    }

    public int e() {
        return a.b(this.f7490b, "key_auto_reset_random_time_hour", -1);
    }

    public int f() {
        return a.b(this.f7490b, "key_auto_reset_random_time_min", -1);
    }

    public int g() {
        return a.b(this.f7490b, "key_auto_reset_time_hour", 3);
    }

    public int h() {
        return a.b(this.f7490b, "key_auto_reset_time_min", 0);
    }

    public void i() {
        this.f7489a.remove("key_auto_reset_enabled");
        this.f7489a.remove("key_auto_reset_time_hour");
        this.f7489a.remove("key_auto_reset_time_min");
        this.f7489a.remove("key_auto_reset_multi_day");
        this.f7489a.remove("key_auto_reset_time_set");
        this.f7489a.remove("key_auto_reset_random_time_hour");
        this.f7489a.remove("key_auto_reset_random_time_min");
        this.f7489a.commit();
    }

    public void j(int i10, int i11) {
        SemLog.d("AutoReset", "setAutoResetTime - " + i10 + ":" + i11);
        o("key_auto_reset_time_set", Boolean.TRUE);
        o("key_auto_reset_time_hour", Integer.valueOf(i10));
        o("key_auto_reset_time_min", Integer.valueOf(i11));
        n(i10, i11);
    }

    public void k(int i10) {
        o("key_auto_reset_multi_day", Integer.valueOf(i10));
    }

    public void l(int i10) {
        o("key_auto_reset_random_time_hour", Integer.valueOf(i10));
    }

    public void m(int i10) {
        o("key_auto_reset_random_time_min", Integer.valueOf(i10));
    }

    public final void n(int i10, int i11) {
        int nextInt = this.f7491c.nextInt(60);
        if (i10 == 23) {
            nextInt = this.f7491c.nextInt(60 - i11);
        }
        int i12 = i11 + nextInt;
        if (i12 >= 60) {
            int i13 = i10 + 1;
            o("key_auto_reset_random_time_hour", Integer.valueOf(i13));
            int i14 = i12 - 60;
            o("key_auto_reset_random_time_min", Integer.valueOf(i14));
            Log.d("AutoReset", "setTimeRandom - " + i13 + ":" + i14 + ":" + 10);
            return;
        }
        o("key_auto_reset_random_time_hour", Integer.valueOf(i10));
        o("key_auto_reset_random_time_min", Integer.valueOf(i12));
        Log.d("AutoReset", "setTimeRandom - " + i10 + ":" + i12 + ":" + 10);
    }

    public final void o(String str, Object obj) {
        a.f(this.f7490b, str, obj);
    }
}
