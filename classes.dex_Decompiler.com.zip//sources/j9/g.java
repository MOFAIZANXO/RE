package j9;

import com.samsung.android.sm.scheduled.reboot.autorestart.AlarmRepeatButton;
import com.samsung.android.sm.scheduled.reboot.autorestart.a;

public final /* synthetic */ class g implements AlarmRepeatButton.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ a f7484a;

    public /* synthetic */ g(a aVar) {
        this.f7484a = aVar;
    }

    public final void a(int i10) {
        this.f7484a.G(i10);
    }
}
