package j9;

import android.animation.ValueAnimator;
import com.samsung.android.sm.scheduled.reboot.autorestart.AlarmRepeatButton;

public final /* synthetic */ class c implements ValueAnimator.AnimatorUpdateListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ AlarmRepeatButton f7475a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ int f7476b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ boolean f7477c;

    public /* synthetic */ c(AlarmRepeatButton alarmRepeatButton, int i10, boolean z10) {
        this.f7475a = alarmRepeatButton;
        this.f7476b = i10;
        this.f7477c = z10;
    }

    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        this.f7475a.l(this.f7476b, this.f7477c, valueAnimator);
    }
}
