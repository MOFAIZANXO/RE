package j9;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import h9.a;
import java.util.Random;

public class f implements a {

    /* renamed from: a  reason: collision with root package name */
    public Context f7481a;

    /* renamed from: b  reason: collision with root package name */
    public j f7482b;

    /* renamed from: c  reason: collision with root package name */
    public final Random f7483c = new Random();

    public f(Context context) {
        this.f7481a = context;
        this.f7482b = new j(context);
    }

    public void a(int i10) {
        this.f7482b.l(i10);
    }

    public void b() {
        c(3, 0);
        d(3, 0);
    }

    public void c(int i10, int i11) {
        this.f7482b.j(i10, i11);
    }

    public void d(int i10, int i11) {
        int nextInt = this.f7483c.nextInt(60);
        if (i10 == 23) {
            nextInt = this.f7483c.nextInt(60 - i11);
        }
        int i12 = i11 + nextInt;
        if (i12 >= 60) {
            a(i10 + 1);
            g(i12 - 60);
        } else {
            a(i10);
            g(i12);
        }
        Log.d("AutoRebootDailyAlarm", "Randomized time " + j() + ":" + h());
    }

    public PendingIntent e() {
        Intent intent = new Intent("com.samsung.android.sm.ACTION_AUTO_REBOOT");
        intent.setPackage(this.f7481a.getPackageName());
        return PendingIntent.getService(this.f7481a, 2345, intent, 335544320);
    }

    public int f() {
        return this.f7482b.g();
    }

    public void g(int i10) {
        this.f7482b.m(i10);
    }

    public int h() {
        return this.f7482b.f();
    }

    public int i() {
        return 10;
    }

    public boolean isEmpty() {
        return f() < 0 || k() < 0 || j() < 0 || h() < 0;
    }

    public int j() {
        return this.f7482b.e();
    }

    public int k() {
        return this.f7482b.h();
    }
}
