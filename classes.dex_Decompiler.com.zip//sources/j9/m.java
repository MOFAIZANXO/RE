package j9;

import android.content.Context;
import androidx.core.internal.view.SupportMenu;
import androidx.core.view.ViewCompat;
import com.samsung.android.feature.SemCscFeature;
import com.samsung.android.util.SemLog;
import w6.k;

public abstract class m {
    public static int a(char c10, int[] iArr) {
        return c10 == 'R' ? iArr[2] : c10 == 'B' ? iArr[1] : iArr[0];
    }

    public static int[] b(Context context, int[] iArr, int i10) {
        String str;
        try {
            str = c("CscFeature_Calendar_SetColorOfDays");
        } catch (NullPointerException unused) {
            SemLog.d("WeekdayColorParser", "NullPointerException - Feature.getCscString");
            str = null;
        }
        if (k.w(context)) {
            SemLog.d("WeekdayColorParser", "isUAEModel");
            str = "XXXXXBR";
        }
        if (str == null || "".equals(str) || str.isEmpty() || str.length() != 7) {
            str = "XXXXXXR";
        }
        if (iArr == null || iArr.length != 3) {
            iArr = new int[]{ViewCompat.MEASURED_STATE_MASK, -16776961, SupportMenu.CATEGORY_MASK};
        }
        int[] iArr2 = new int[7];
        for (int i11 = 0; i11 < 7; i11++) {
            iArr2[i11] = a(str.charAt(i11), iArr);
        }
        return e(iArr2, d(i10));
    }

    public static String c(String str) {
        return SemCscFeature.getInstance().getString(str);
    }

    public static int d(int i10) {
        if (i10 == 0) {
            return 1;
        }
        if (i10 == 2) {
            return 6;
        }
        if (i10 == 3) {
            return 5;
        }
        if (i10 == 4) {
            return 4;
        }
        if (i10 != 5) {
            return i10 != 6 ? 0 : 2;
        }
        return 3;
    }

    public static int[] e(int[] iArr, int i10) {
        int length = iArr.length;
        int[] iArr2 = new int[length];
        for (int i11 = 0; i11 < length; i11++) {
            iArr2[(i11 + i10) % length] = iArr[i11];
        }
        return iArr2;
    }
}
