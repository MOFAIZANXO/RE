package t9;

public final /* synthetic */ class d implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ e f9995a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ int f9996b;

    public /* synthetic */ d(e eVar, int i10) {
        this.f9995a = eVar;
        this.f9996b = i10;
    }

    public final void run() {
        this.f9995a.y(this.f9996b);
    }
}
