package t9;

public final /* synthetic */ class a implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ e f9988a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ int f9989b;

    public /* synthetic */ a(e eVar, int i10) {
        this.f9988a = eVar;
        this.f9989b = i10;
    }

    public final void run() {
        this.f9988a.A(this.f9989b);
    }
}
