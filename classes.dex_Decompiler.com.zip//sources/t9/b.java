package t9;

import java.util.ArrayList;

public final /* synthetic */ class b implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ e f9990a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ int f9991b;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ ArrayList f9992f;

    public /* synthetic */ b(e eVar, int i10, ArrayList arrayList) {
        this.f9990a = eVar;
        this.f9991b = i10;
        this.f9992f = arrayList;
    }

    public final void run() {
        this.f9990a.z(this.f9991b, this.f9992f);
    }
}
