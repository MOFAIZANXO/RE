package t9;

import v9.g;

public final /* synthetic */ class c implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ g f9993a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ int f9994b;

    public /* synthetic */ c(g gVar, int i10) {
        this.f9993a = gVar;
        this.f9994b = i10;
    }

    public final void run() {
        e.B(this.f9993a, this.f9994b);
    }
}
