package t9;

import android.content.Context;
import android.os.Message;
import android.util.Log;
import android.util.SparseArray;
import androidx.core.view.PointerIconCompat;
import c7.f;
import com.samsung.android.sm.score.data.OptData;
import f6.c;
import f6.d;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import u9.b;
import v9.g;
import v9.h;

public class e implements c {

    /* renamed from: r  reason: collision with root package name */
    public static volatile e f9997r;

    /* renamed from: s  reason: collision with root package name */
    public static SparseArray f9998s = new SparseArray();

    /* renamed from: a  reason: collision with root package name */
    public final Object f9999a = new Object();

    /* renamed from: b  reason: collision with root package name */
    public final Object f10000b = new Object();

    /* renamed from: f  reason: collision with root package name */
    public final d f10001f = new d(this);

    /* renamed from: g  reason: collision with root package name */
    public final ConcurrentHashMap f10002g = new ConcurrentHashMap();

    /* renamed from: h  reason: collision with root package name */
    public ArrayList f10003h = new ArrayList();

    /* renamed from: i  reason: collision with root package name */
    public ArrayList f10004i = new ArrayList();

    /* renamed from: j  reason: collision with root package name */
    public f f10005j = new f();

    /* renamed from: k  reason: collision with root package name */
    public int f10006k = 4000;

    /* renamed from: l  reason: collision with root package name */
    public ExecutorService f10007l;

    /* renamed from: m  reason: collision with root package name */
    public CountDownLatch f10008m;

    /* renamed from: n  reason: collision with root package name */
    public CountDownLatch f10009n;

    /* renamed from: o  reason: collision with root package name */
    public int f10010o;

    /* renamed from: p  reason: collision with root package name */
    public int f10011p;

    /* renamed from: q  reason: collision with root package name */
    public final b f10012q = new a();

    public class a implements b {
        public a() {
        }

        public void g(OptData optData) {
            synchronized (e.this.f10000b) {
                int j10 = optData.j();
                e.this.f10002g.put(Integer.valueOf(j10), optData);
                Iterator it = new ArrayList(e.this.f10003h).iterator();
                while (it.hasNext()) {
                    ((b) it.next()).g(optData);
                }
                ArrayList arrayList = o9.c.f8660a;
                int indexOf = arrayList.indexOf(Integer.valueOf(j10));
                if (indexOf != -1) {
                    e eVar = e.this;
                    eVar.f10011p = (1 << indexOf) | eVar.f10011p;
                }
                Log.d("DashBoard.OptManager", j10 + " make clean flag to " + e.this.f10011p);
                if (((double) e.this.f10011p) >= Math.pow(2.0d, (double) arrayList.size()) - 1.0d) {
                    e.this.f10011p = 0;
                    if (e.this.f10009n != null) {
                        e.this.f10009n.countDown();
                    }
                }
            }
        }

        public void k(OptData optData) {
            synchronized (e.this.f10000b) {
                int j10 = optData.j();
                e.this.f10002g.put(Integer.valueOf(j10), optData);
                Iterator it = new ArrayList(e.this.f10003h).iterator();
                while (it.hasNext()) {
                    ((b) it.next()).k(optData);
                }
                ArrayList arrayList = o9.c.f8660a;
                int indexOf = arrayList.indexOf(Integer.valueOf(j10));
                if (indexOf != -1) {
                    e eVar = e.this;
                    eVar.f10010o = (1 << indexOf) | eVar.f10010o;
                }
                Log.d("DashBoard.OptManager", j10 + " make scan flag to " + e.this.f10010o);
                if (((double) e.this.f10010o) >= Math.pow(2.0d, (double) arrayList.size()) - 1.0d) {
                    e.this.f10010o = 0;
                    if (e.this.f10008m != null) {
                        e.this.f10008m.countDown();
                    }
                }
            }
        }

        public void l(OptData optData) {
            synchronized (e.this.f10000b) {
                e.this.f10002g.put(Integer.valueOf(optData.j()), optData);
                Iterator it = new ArrayList(e.this.f10003h).iterator();
                while (it.hasNext()) {
                    ((b) it.next()).l(optData);
                }
                e eVar = e.this;
                eVar.f10006k = 4000;
                eVar.f10001f.sendEmptyMessage(PointerIconCompat.TYPE_CONTEXT_MENU);
            }
        }
    }

    public e(Context context) {
        w(context);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void A(int i10) {
        synchronized (this.f9999a) {
            Log.i("DashBoard.OptManager", "do scan with type " + i10);
            v(i10);
        }
    }

    public static /* synthetic */ void B(g gVar, int i10) {
        Log.v("DashBoard.OptManager", gVar + " start scan");
        gVar.h(i10);
    }

    public static e x(Context context) {
        synchronized (e.class) {
            if (f9997r == null) {
                f9997r = new e(context.getApplicationContext());
            }
        }
        return f9997r;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void y(int i10) {
        synchronized (this.f9999a) {
            Log.i("DashBoard.OptManager", "do clean with type : " + i10);
            r(i10);
        }
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void z(int i10, ArrayList arrayList) {
        synchronized (this.f9999a) {
            Log.i("DashBoard.OptManager", "do manual fix : " + i10);
            t(i10, arrayList);
        }
    }

    public void C(b bVar, u9.a aVar) {
        Log.i("DashBoard.OptManager", "remove Listener. " + bVar + ", " + aVar);
        if (bVar != null) {
            this.f10003h.remove(bVar);
        }
        if (aVar != null) {
            this.f10004i.remove(aVar);
        }
    }

    public final void D(c7.e eVar) {
        this.f10006k = eVar.a();
        Thread thread = new Thread(eVar.b());
        thread.setPriority(1);
        thread.start();
    }

    public final void E() {
        ExecutorService executorService = this.f10007l;
        if (executorService != null && !executorService.isShutdown()) {
            try {
                this.f10007l.shutdown();
                this.f10007l.awaitTermination(3, TimeUnit.SECONDS);
            } catch (InterruptedException e10) {
                Log.w("DashBoard.OptManager", "error : " + e10.getMessage());
            }
        }
        this.f10007l = Executors.newFixedThreadPool(2);
    }

    public final void F() {
        ExecutorService executorService = this.f10007l;
        if (executorService != null) {
            executorService.shutdownNow();
        }
    }

    public void handleMessage(Message message) {
        c7.e eVar;
        if (message.what == 1001 && (eVar = (c7.e) this.f10005j.a()) != null) {
            D(eVar);
        }
    }

    public void o(b bVar, u9.a aVar) {
        Log.i("DashBoard.OptManager", "addListener. " + bVar + ", " + aVar);
        if (bVar != null) {
            if (!this.f10003h.contains(bVar)) {
                this.f10003h.add(bVar);
            } else {
                Log.w("DashBoard.OptManager", bVar + " is already in item cb list");
            }
        }
        if (aVar == null) {
            return;
        }
        if (!this.f10004i.contains(aVar)) {
            this.f10004i.add(aVar);
            return;
        }
        Log.w("DashBoard.OptManager", aVar + " is already in complete cb list");
    }

    public final boolean p(c7.e eVar) {
        if (this.f10006k != 4003 && (eVar.a() == this.f10006k || this.f10005j.c(eVar))) {
            Log.w("DashBoard.OptManager", "doScoreJob, already same req exists : " + eVar + " / now working of " + this.f10006k);
            return false;
        } else if (this.f10006k == 4000) {
            return true;
        } else {
            Log.w("DashBoard.OptManager", this.f10006k + " is working. " + eVar + " put in waiting queue");
            this.f10005j.b(eVar);
            return false;
        }
    }

    public void q(int i10) {
        if (this.f10006k == 4002) {
            Log.i("DashBoard.OptManager", "on cleaning. Fill the current data");
            for (Map.Entry value : this.f10002g.entrySet()) {
                OptData optData = (OptData) value.getValue();
                if (!optData.m()) {
                    Iterator it = this.f10003h.iterator();
                    while (it.hasNext()) {
                        ((b) it.next()).g(optData);
                    }
                }
            }
        }
        c7.e eVar = new c7.e(4002, new d(this, i10));
        if (p(eVar)) {
            D(eVar);
        }
    }

    public void r(int i10) {
        this.f10006k = 4002;
        this.f10002g.clear();
        this.f10011p = 0;
        this.f10009n = new CountDownLatch(1);
        Iterator it = o9.c.f8660a.iterator();
        while (it.hasNext()) {
            g gVar = (g) f9998s.get(((Integer) it.next()).intValue());
            if (gVar != null) {
                Log.v("DashBoard.OptManager", gVar + " start clean");
                gVar.f(i10);
            }
        }
        try {
            if (!this.f10009n.await(60, TimeUnit.SECONDS)) {
                Log.w("DashBoard.OptManager", "timeout during fix now");
            }
        } catch (InterruptedException e10) {
            Log.e("DashBoard.OptManager", "Latch interrupted : " + e10.getMessage());
        }
        Log.d("DashBoard.OptManager", "notify onAutoFixCompleted");
        Iterator it2 = new ArrayList(this.f10004i).iterator();
        while (it2.hasNext()) {
            ((u9.a) it2.next()).h(i10);
        }
        this.f10006k = 4000;
        this.f10001f.sendEmptyMessage(PointerIconCompat.TYPE_CONTEXT_MENU);
    }

    public void s(int i10, ArrayList arrayList) {
        c7.e eVar = new c7.e(4003, new b(this, i10, arrayList));
        if (p(eVar)) {
            D(eVar);
        }
    }

    public void t(int i10, ArrayList arrayList) {
        g gVar = (g) f9998s.get(i10);
        if (gVar != null) {
            gVar.g(arrayList);
        }
    }

    public void u(int i10) {
        if (this.f10006k == 4001) {
            Log.i("DashBoard.OptManager", "on scanning. Fill the current data");
            for (Map.Entry entry : this.f10002g.entrySet()) {
                Iterator it = this.f10003h.iterator();
                while (it.hasNext()) {
                    ((b) it.next()).k((OptData) entry.getValue());
                }
            }
        }
        c7.e eVar = new c7.e(4001, new a(this, i10));
        if (p(eVar)) {
            D(eVar);
        }
    }

    public void v(int i10) {
        this.f10006k = 4001;
        this.f10002g.clear();
        this.f10010o = 0;
        this.f10008m = new CountDownLatch(1);
        E();
        Iterator it = o9.c.f8660a.iterator();
        while (it.hasNext()) {
            g gVar = (g) f9998s.get(((Integer) it.next()).intValue());
            if (gVar != null) {
                this.f10007l.execute(new c(gVar, i10));
            }
        }
        try {
            if (!this.f10008m.await(60, TimeUnit.SECONDS)) {
                Log.w("DashBoard.OptManager", "timeout during scan");
            }
        } catch (InterruptedException e10) {
            Log.e("DashBoard.OptManager", "Latch interrupted : " + e10.getMessage());
        }
        F();
        Log.d("DashBoard.OptManager", "notify onScanCompleted");
        Iterator it2 = new ArrayList(this.f10004i).iterator();
        while (it2.hasNext()) {
            ((u9.a) it2.next()).i(i10);
        }
        this.f10006k = 4000;
        this.f10001f.sendEmptyMessage(PointerIconCompat.TYPE_CONTEXT_MENU);
    }

    public final void w(Context context) {
        Iterator it = o9.c.f8660a.iterator();
        while (it.hasNext()) {
            int intValue = ((Integer) it.next()).intValue();
            g a10 = h.a(intValue, context, this.f10012q);
            if (a10 != null) {
                f9998s.put(intValue, a10);
            }
        }
    }
}
