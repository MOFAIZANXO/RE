package q8;

import android.content.Context;
import android.content.Intent;
import r8.l;

public class a extends z6.a {
    public a(String str) {
        e(str);
    }

    public Intent a(Context context) {
        Intent intent = new Intent();
        intent.setPackage(context.getPackageName());
        intent.setAction("com.samsung.android.sm.ACTION_POWER_SHARE_START_DETAIL_ACTIVITY");
        return intent;
    }

    public boolean c(Context context) {
        return l.q();
    }
}
