package rb;

import java.util.Collections;
import java.util.Set;
import kotlin.jvm.internal.l;

public abstract class e0 {
    public static final Set a(Object obj) {
        Set singleton = Collections.singleton(obj);
        l.d(singleton, "singleton(element)");
        return singleton;
    }
}
