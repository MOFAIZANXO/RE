package rb;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.NoSuchElementException;
import kotlin.jvm.internal.l;

public abstract class i extends h {
    public static final boolean f(Object[] objArr, Object obj) {
        l.e(objArr, "<this>");
        return l(objArr, obj) >= 0;
    }

    public static final List g(Object[] objArr, int i10) {
        l.e(objArr, "<this>");
        if (i10 >= 0) {
            return o(objArr, dc.i.b(objArr.length - i10, 0));
        }
        throw new IllegalArgumentException(("Requested element count " + i10 + " is less than zero.").toString());
    }

    public static final List h(Object[] objArr) {
        l.e(objArr, "<this>");
        return (List) i(objArr, new ArrayList());
    }

    public static final Collection i(Object[] objArr, Collection collection) {
        l.e(objArr, "<this>");
        l.e(collection, "destination");
        for (Object obj : objArr) {
            if (obj != null) {
                collection.add(obj);
            }
        }
        return collection;
    }

    public static final Object j(Object[] objArr) {
        l.e(objArr, "<this>");
        if (!(objArr.length == 0)) {
            return objArr[0];
        }
        throw new NoSuchElementException("Array is empty.");
    }

    public static final int k(Object[] objArr) {
        l.e(objArr, "<this>");
        return objArr.length - 1;
    }

    public static final int l(Object[] objArr, Object obj) {
        l.e(objArr, "<this>");
        int i10 = 0;
        if (obj == null) {
            int length = objArr.length;
            while (i10 < length) {
                if (objArr[i10] == null) {
                    return i10;
                }
                i10++;
            }
            return -1;
        }
        int length2 = objArr.length;
        while (i10 < length2) {
            if (l.a(obj, objArr[i10])) {
                return i10;
            }
            i10++;
        }
        return -1;
    }

    public static final char m(char[] cArr) {
        l.e(cArr, "<this>");
        int length = cArr.length;
        if (length == 0) {
            throw new NoSuchElementException("Array is empty.");
        } else if (length == 1) {
            return cArr[0];
        } else {
            throw new IllegalArgumentException("Array has more than one element.");
        }
    }

    public static final Object n(Object[] objArr) {
        l.e(objArr, "<this>");
        if (objArr.length == 1) {
            return objArr[0];
        }
        return null;
    }

    public static final List o(Object[] objArr, int i10) {
        l.e(objArr, "<this>");
        if (!(i10 >= 0)) {
            throw new IllegalArgumentException(("Requested element count " + i10 + " is less than zero.").toString());
        } else if (i10 == 0) {
            return m.d();
        } else {
            int length = objArr.length;
            if (i10 >= length) {
                return p(objArr);
            }
            if (i10 == 1) {
                return l.b(objArr[length - 1]);
            }
            ArrayList arrayList = new ArrayList(i10);
            for (int i11 = length - i10; i11 < length; i11++) {
                arrayList.add(objArr[i11]);
            }
            return arrayList;
        }
    }

    public static final List p(Object[] objArr) {
        l.e(objArr, "<this>");
        int length = objArr.length;
        return length != 0 ? length != 1 ? q(objArr) : l.b(objArr[0]) : m.d();
    }

    public static final List q(Object[] objArr) {
        l.e(objArr, "<this>");
        return new ArrayList(m.c(objArr));
    }
}
