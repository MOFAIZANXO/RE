package rb;

public abstract class p extends o {
}
