package rb;

import java.lang.reflect.Array;
import kotlin.jvm.internal.l;

public abstract class f {
    public static final Object[] a(Object[] objArr, int i10) {
        l.e(objArr, "reference");
        Object newInstance = Array.newInstance(objArr.getClass().getComponentType(), i10);
        l.c(newInstance, "null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.arrayOfNulls>");
        return (Object[]) newInstance;
    }
}
