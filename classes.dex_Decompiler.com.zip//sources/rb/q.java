package rb;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import kotlin.jvm.internal.l;

public abstract class q extends p {
    public static final void k(List list, Comparator comparator) {
        l.e(list, "<this>");
        l.e(comparator, "comparator");
        if (list.size() > 1) {
            Collections.sort(list, comparator);
        }
    }
}
