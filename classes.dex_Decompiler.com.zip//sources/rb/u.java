package rb;

import fc.d;
import gc.k;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Set;
import kotlin.jvm.internal.l;
import qb.o;

public abstract class u extends t {

    public static final class a implements d {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ Iterable f9629a;

        public a(Iterable iterable) {
            this.f9629a = iterable;
        }

        public Iterator iterator() {
            return this.f9629a.iterator();
        }
    }

    public static final Set A(Iterable iterable) {
        l.e(iterable, "<this>");
        return iterable instanceof Collection ? new LinkedHashSet((Collection) iterable) : (Set) w(iterable, new LinkedHashSet());
    }

    public static final Set B(Iterable iterable) {
        l.e(iterable, "<this>");
        if (!(iterable instanceof Collection)) {
            return f0.c((Set) w(iterable, new LinkedHashSet()));
        }
        Collection collection = (Collection) iterable;
        int size = collection.size();
        if (size == 0) {
            return f0.b();
        }
        if (size != 1) {
            return (Set) w(iterable, new LinkedHashSet(c0.a(collection.size())));
        }
        return e0.a(iterable instanceof List ? ((List) iterable).get(0) : iterable.iterator().next());
    }

    public static final List C(Iterable iterable, Iterable iterable2) {
        l.e(iterable, "<this>");
        l.e(iterable2, "other");
        Iterator it = iterable.iterator();
        Iterator it2 = iterable2.iterator();
        ArrayList arrayList = new ArrayList(Math.min(n.j(iterable, 10), n.j(iterable2, 10)));
        while (it.hasNext() && it2.hasNext()) {
            arrayList.add(o.a(it.next(), it2.next()));
        }
        return arrayList;
    }

    public static final d m(Iterable iterable) {
        l.e(iterable, "<this>");
        return new a(iterable);
    }

    public static final boolean n(Iterable iterable, Object obj) {
        l.e(iterable, "<this>");
        return iterable instanceof Collection ? ((Collection) iterable).contains(obj) : p(iterable, obj) >= 0;
    }

    public static final List o(Iterable iterable) {
        l.e(iterable, "<this>");
        return x(A(iterable));
    }

    public static final int p(Iterable iterable, Object obj) {
        l.e(iterable, "<this>");
        if (iterable instanceof List) {
            return ((List) iterable).indexOf(obj);
        }
        int i10 = 0;
        for (Object next : iterable) {
            if (i10 < 0) {
                m.i();
            }
            if (l.a(obj, next)) {
                return i10;
            }
            i10++;
        }
        return -1;
    }

    public static final Appendable q(Iterable iterable, Appendable appendable, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, int i10, CharSequence charSequence4, ac.l lVar) {
        l.e(iterable, "<this>");
        l.e(appendable, "buffer");
        l.e(charSequence, "separator");
        l.e(charSequence2, "prefix");
        l.e(charSequence3, "postfix");
        l.e(charSequence4, "truncated");
        appendable.append(charSequence2);
        int i11 = 0;
        for (Object next : iterable) {
            i11++;
            if (i11 > 1) {
                appendable.append(charSequence);
            }
            if (i10 >= 0 && i11 > i10) {
                break;
            }
            k.a(appendable, next, lVar);
        }
        if (i10 >= 0 && i11 > i10) {
            appendable.append(charSequence4);
        }
        appendable.append(charSequence3);
        return appendable;
    }

    public static final String r(Iterable iterable, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, int i10, CharSequence charSequence4, ac.l lVar) {
        l.e(iterable, "<this>");
        l.e(charSequence, "separator");
        l.e(charSequence2, "prefix");
        l.e(charSequence3, "postfix");
        l.e(charSequence4, "truncated");
        String sb2 = ((StringBuilder) q(iterable, new StringBuilder(), charSequence, charSequence2, charSequence3, i10, charSequence4, lVar)).toString();
        l.d(sb2, "joinTo(StringBuilder(), …ed, transform).toString()");
        return sb2;
    }

    public static /* synthetic */ String s(Iterable iterable, CharSequence charSequence, CharSequence charSequence2, CharSequence charSequence3, int i10, CharSequence charSequence4, ac.l lVar, int i11, Object obj) {
        if ((i11 & 1) != 0) {
            charSequence = ", ";
        }
        CharSequence charSequence5 = "";
        CharSequence charSequence6 = (i11 & 2) != 0 ? charSequence5 : charSequence2;
        if ((i11 & 4) == 0) {
            charSequence5 = charSequence3;
        }
        if ((i11 & 8) != 0) {
            i10 = -1;
        }
        int i12 = i10;
        if ((i11 & 16) != 0) {
            charSequence4 = "...";
        }
        CharSequence charSequence7 = charSequence4;
        if ((i11 & 32) != 0) {
            lVar = null;
        }
        return r(iterable, charSequence, charSequence6, charSequence5, i12, charSequence7, lVar);
    }

    public static final List t(Collection collection, Iterable iterable) {
        l.e(collection, "<this>");
        l.e(iterable, "elements");
        if (iterable instanceof Collection) {
            Collection collection2 = (Collection) iterable;
            ArrayList arrayList = new ArrayList(collection.size() + collection2.size());
            arrayList.addAll(collection);
            arrayList.addAll(collection2);
            return arrayList;
        }
        ArrayList arrayList2 = new ArrayList(collection);
        r.l(arrayList2, iterable);
        return arrayList2;
    }

    public static final Object u(Iterable iterable) {
        l.e(iterable, "<this>");
        if (iterable instanceof List) {
            return v((List) iterable);
        }
        Iterator it = iterable.iterator();
        if (it.hasNext()) {
            Object next = it.next();
            if (!it.hasNext()) {
                return next;
            }
            throw new IllegalArgumentException("Collection has more than one element.");
        }
        throw new NoSuchElementException("Collection is empty.");
    }

    public static final Object v(List list) {
        l.e(list, "<this>");
        int size = list.size();
        if (size == 0) {
            throw new NoSuchElementException("List is empty.");
        } else if (size == 1) {
            return list.get(0);
        } else {
            throw new IllegalArgumentException("List has more than one element.");
        }
    }

    public static final Collection w(Iterable iterable, Collection collection) {
        l.e(iterable, "<this>");
        l.e(collection, "destination");
        for (Object add : iterable) {
            collection.add(add);
        }
        return collection;
    }

    public static final List x(Iterable iterable) {
        l.e(iterable, "<this>");
        if (!(iterable instanceof Collection)) {
            return m.h(y(iterable));
        }
        Collection collection = (Collection) iterable;
        int size = collection.size();
        if (size == 0) {
            return m.d();
        }
        if (size != 1) {
            return z(collection);
        }
        return l.b(iterable instanceof List ? ((List) iterable).get(0) : iterable.iterator().next());
    }

    public static final List y(Iterable iterable) {
        l.e(iterable, "<this>");
        return iterable instanceof Collection ? z((Collection) iterable) : (List) w(iterable, new ArrayList());
    }

    public static final List z(Collection collection) {
        l.e(collection, "<this>");
        return new ArrayList(collection);
    }
}
