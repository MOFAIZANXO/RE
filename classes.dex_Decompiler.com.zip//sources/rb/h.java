package rb;

import java.util.Arrays;
import java.util.List;
import kotlin.jvm.internal.l;

public abstract class h extends g {
    public static final List b(Object[] objArr) {
        l.e(objArr, "<this>");
        List a10 = j.a(objArr);
        l.d(a10, "asList(this)");
        return a10;
    }

    public static final Object[] c(Object[] objArr, Object[] objArr2, int i10, int i11, int i12) {
        l.e(objArr, "<this>");
        l.e(objArr2, "destination");
        System.arraycopy(objArr, i11, objArr2, i10, i12 - i11);
        return objArr2;
    }

    public static /* synthetic */ Object[] d(Object[] objArr, Object[] objArr2, int i10, int i11, int i12, int i13, Object obj) {
        if ((i13 & 2) != 0) {
            i10 = 0;
        }
        if ((i13 & 4) != 0) {
            i11 = 0;
        }
        if ((i13 & 8) != 0) {
            i12 = objArr.length;
        }
        return c(objArr, objArr2, i10, i11, i12);
    }

    public static final void e(Object[] objArr, Object obj, int i10, int i11) {
        l.e(objArr, "<this>");
        Arrays.fill(objArr, i10, i11, obj);
    }
}
