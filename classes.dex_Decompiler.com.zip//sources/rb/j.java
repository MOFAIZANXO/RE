package rb;

import java.util.Arrays;
import java.util.List;

public abstract class j {
    public static List a(Object[] objArr) {
        return Arrays.asList(objArr);
    }
}
