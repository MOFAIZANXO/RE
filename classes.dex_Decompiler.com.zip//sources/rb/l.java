package rb;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public abstract class l {
    public static final Object[] a(Object[] objArr, boolean z10) {
        kotlin.jvm.internal.l.e(objArr, "<this>");
        Class<Object[]> cls = Object[].class;
        if (z10 && kotlin.jvm.internal.l.a(objArr.getClass(), cls)) {
            return objArr;
        }
        Object[] copyOf = Arrays.copyOf(objArr, objArr.length, cls);
        kotlin.jvm.internal.l.d(copyOf, "copyOf(this, this.size, Array<Any?>::class.java)");
        return copyOf;
    }

    public static final List b(Object obj) {
        List singletonList = Collections.singletonList(obj);
        kotlin.jvm.internal.l.d(singletonList, "singletonList(element)");
        return singletonList;
    }
}
