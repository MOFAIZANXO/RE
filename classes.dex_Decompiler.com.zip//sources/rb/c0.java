package rb;

import androidx.appcompat.widget.ActivityChooserView;
import java.util.Collections;
import java.util.Map;
import kotlin.jvm.internal.l;
import qb.i;

public abstract class c0 extends b0 {
    public static final int a(int i10) {
        return i10 < 0 ? i10 : i10 < 3 ? i10 + 1 : i10 < 1073741824 ? (int) ((((float) i10) / 0.75f) + 1.0f) : ActivityChooserView.ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED;
    }

    public static final Map b(i iVar) {
        l.e(iVar, "pair");
        Map singletonMap = Collections.singletonMap(iVar.c(), iVar.d());
        l.d(singletonMap, "singletonMap(pair.first, pair.second)");
        return singletonMap;
    }

    public static final Map c(Map map) {
        l.e(map, "<this>");
        Map.Entry entry = (Map.Entry) map.entrySet().iterator().next();
        Map singletonMap = Collections.singletonMap(entry.getKey(), entry.getValue());
        l.d(singletonMap, "with(entries.iterator().…ingletonMap(key, value) }");
        return singletonMap;
    }
}
