package rb;

import java.util.AbstractList;
import java.util.List;

public abstract class c extends AbstractList implements List {
    public abstract int a();

    public abstract Object b(int i10);

    public final /* bridge */ Object remove(int i10) {
        return b(i10);
    }

    public final /* bridge */ int size() {
        return a();
    }
}
