package rb;

import ac.l;
import java.util.Collection;
import kotlin.jvm.internal.f;
import kotlin.jvm.internal.m;

public abstract class a implements Collection {

    /* renamed from: rb.a$a  reason: collision with other inner class name */
    public static final class C0126a extends m implements l {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ a f9614a;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C0126a(a aVar) {
            super(1);
            this.f9614a = aVar;
        }

        /* renamed from: a */
        public final CharSequence invoke(Object obj) {
            return obj == this.f9614a ? "(this Collection)" : String.valueOf(obj);
        }
    }

    public abstract int a();

    public boolean add(Object obj) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public boolean addAll(Collection collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public void clear() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public boolean contains(Object obj) {
        if (isEmpty()) {
            return false;
        }
        for (Object a10 : this) {
            if (kotlin.jvm.internal.l.a(a10, obj)) {
                return true;
            }
        }
        return false;
    }

    public boolean containsAll(Collection collection) {
        kotlin.jvm.internal.l.e(collection, "elements");
        if (collection.isEmpty()) {
            return true;
        }
        for (Object contains : collection) {
            if (!contains(contains)) {
                return false;
            }
        }
        return true;
    }

    public boolean isEmpty() {
        return size() == 0;
    }

    public boolean remove(Object obj) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public boolean removeAll(Collection collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public boolean retainAll(Collection collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public final /* bridge */ int size() {
        return a();
    }

    public Object[] toArray() {
        return f.a(this);
    }

    public String toString() {
        return u.s(this, ", ", "[", "]", 0, (CharSequence) null, new C0126a(this), 24, (Object) null);
    }

    public Object[] toArray(Object[] objArr) {
        kotlin.jvm.internal.l.e(objArr, "array");
        return f.b(this, objArr);
    }
}
