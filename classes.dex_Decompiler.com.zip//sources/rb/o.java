package rb;

public abstract class o extends n {
}
