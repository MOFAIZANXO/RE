package rb;

public abstract class s extends r {
}
