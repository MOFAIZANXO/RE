package rb;

import dc.d;
import java.util.Collection;
import java.util.List;
import kotlin.jvm.internal.l;

public abstract class m extends l {
    public static final Collection c(Object[] objArr) {
        l.e(objArr, "<this>");
        return new d(objArr, false);
    }

    public static final List d() {
        return w.f9631a;
    }

    public static final d e(Collection collection) {
        l.e(collection, "<this>");
        return new d(0, collection.size() - 1);
    }

    public static final int f(List list) {
        l.e(list, "<this>");
        return list.size() - 1;
    }

    public static final List g(Object... objArr) {
        l.e(objArr, "elements");
        return objArr.length > 0 ? h.b(objArr) : d();
    }

    public static final List h(List list) {
        l.e(list, "<this>");
        int size = list.size();
        return size != 0 ? size != 1 ? list : l.b(list.get(0)) : d();
    }

    public static final void i() {
        throw new ArithmeticException("Index overflow has happened.");
    }
}
