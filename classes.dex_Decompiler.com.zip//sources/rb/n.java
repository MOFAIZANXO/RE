package rb;

import java.util.Collection;
import kotlin.jvm.internal.l;

public abstract class n extends m {
    public static final int j(Iterable iterable, int i10) {
        l.e(iterable, "<this>");
        return iterable instanceof Collection ? ((Collection) iterable).size() : i10;
    }
}
