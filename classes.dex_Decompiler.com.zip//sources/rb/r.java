package rb;

import java.util.Collection;
import kotlin.jvm.internal.l;

public abstract class r extends q {
    public static final boolean l(Collection collection, Iterable iterable) {
        l.e(collection, "<this>");
        l.e(iterable, "elements");
        if (iterable instanceof Collection) {
            return collection.addAll((Collection) iterable);
        }
        boolean z10 = false;
        for (Object add : iterable) {
            if (collection.add(add)) {
                z10 = true;
            }
        }
        return z10;
    }
}
