package rb;

public abstract class b0 {
}
