package rb;

public abstract class t extends s {
}
