package rb;

import java.util.Set;
import kotlin.jvm.internal.l;

public abstract class f0 extends e0 {
    public static final Set b() {
        return y.f9633a;
    }

    public static final Set c(Set set) {
        l.e(set, "<this>");
        int size = set.size();
        return size != 0 ? size != 1 ? set : e0.a(set.iterator().next()) : b();
    }
}
