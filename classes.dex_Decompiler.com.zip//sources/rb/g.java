package rb;

public abstract class g extends f {
}
