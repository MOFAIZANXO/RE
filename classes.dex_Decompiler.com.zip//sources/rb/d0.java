package rb;

import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import kotlin.jvm.internal.l;
import qb.i;

public abstract class d0 extends c0 {
    public static final Map d() {
        x xVar = x.f9632a;
        l.c(xVar, "null cannot be cast to non-null type kotlin.collections.Map<K of kotlin.collections.MapsKt__MapsKt.emptyMap, V of kotlin.collections.MapsKt__MapsKt.emptyMap>");
        return xVar;
    }

    public static final Map e(Map map) {
        l.e(map, "<this>");
        int size = map.size();
        return size != 0 ? size != 1 ? map : c0.c(map) : d();
    }

    public static final void f(Map map, Iterable iterable) {
        l.e(map, "<this>");
        l.e(iterable, "pairs");
        Iterator it = iterable.iterator();
        while (it.hasNext()) {
            i iVar = (i) it.next();
            map.put(iVar.a(), iVar.b());
        }
    }

    public static final Map g(Iterable iterable) {
        l.e(iterable, "<this>");
        if (!(iterable instanceof Collection)) {
            return e(h(iterable, new LinkedHashMap()));
        }
        Collection collection = (Collection) iterable;
        int size = collection.size();
        if (size == 0) {
            return d();
        }
        if (size != 1) {
            return h(iterable, new LinkedHashMap(c0.a(collection.size())));
        }
        return c0.b((i) (iterable instanceof List ? ((List) iterable).get(0) : iterable.iterator().next()));
    }

    public static final Map h(Iterable iterable, Map map) {
        l.e(iterable, "<this>");
        l.e(map, "destination");
        f(map, iterable);
        return map;
    }

    public static final Map i(Map map) {
        l.e(map, "<this>");
        int size = map.size();
        return size != 0 ? size != 1 ? j(map) : c0.c(map) : d();
    }

    public static final Map j(Map map) {
        l.e(map, "<this>");
        return new LinkedHashMap(map);
    }
}
