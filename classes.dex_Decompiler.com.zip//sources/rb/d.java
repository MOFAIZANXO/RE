package rb;

import java.util.Collection;
import java.util.Iterator;
import kotlin.jvm.internal.b;
import kotlin.jvm.internal.f;
import kotlin.jvm.internal.l;

public final class d implements Collection {

    /* renamed from: a  reason: collision with root package name */
    public final Object[] f9622a;

    /* renamed from: b  reason: collision with root package name */
    public final boolean f9623b;

    public d(Object[] objArr, boolean z10) {
        l.e(objArr, "values");
        this.f9622a = objArr;
        this.f9623b = z10;
    }

    public int a() {
        return this.f9622a.length;
    }

    public boolean add(Object obj) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public boolean addAll(Collection collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public void clear() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public boolean contains(Object obj) {
        return i.f(this.f9622a, obj);
    }

    public boolean containsAll(Collection collection) {
        l.e(collection, "elements");
        if (collection.isEmpty()) {
            return true;
        }
        for (Object contains : collection) {
            if (!contains(contains)) {
                return false;
            }
        }
        return true;
    }

    public boolean isEmpty() {
        return this.f9622a.length == 0;
    }

    public Iterator iterator() {
        return b.a(this.f9622a);
    }

    public boolean remove(Object obj) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public boolean removeAll(Collection collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public boolean retainAll(Collection collection) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public final /* bridge */ int size() {
        return a();
    }

    public Object[] toArray(Object[] objArr) {
        l.e(objArr, "array");
        return f.b(this, objArr);
    }

    public final Object[] toArray() {
        return l.a(this.f9622a, this.f9623b);
    }
}
