package oc;

public final class i {

    /* renamed from: a  reason: collision with root package name */
    public final byte[] f8742a;

    /* renamed from: b  reason: collision with root package name */
    public int f8743b;

    /* renamed from: c  reason: collision with root package name */
    public int f8744c;

    /* renamed from: d  reason: collision with root package name */
    public boolean f8745d;

    /* renamed from: e  reason: collision with root package name */
    public boolean f8746e;

    /* renamed from: f  reason: collision with root package name */
    public i f8747f;

    /* renamed from: g  reason: collision with root package name */
    public i f8748g;

    public i() {
        this.f8742a = new byte[8192];
        this.f8746e = true;
        this.f8745d = false;
    }

    public final void a() {
        i iVar = this.f8748g;
        if (iVar == this) {
            throw new IllegalStateException();
        } else if (iVar.f8746e) {
            int i10 = this.f8744c - this.f8743b;
            if (i10 <= (8192 - iVar.f8744c) + (iVar.f8745d ? 0 : iVar.f8743b)) {
                f(iVar, i10);
                b();
                j.a(this);
            }
        }
    }

    public final i b() {
        i iVar = this.f8747f;
        i iVar2 = iVar != this ? iVar : null;
        i iVar3 = this.f8748g;
        iVar3.f8747f = iVar;
        this.f8747f.f8748g = iVar3;
        this.f8747f = null;
        this.f8748g = null;
        return iVar2;
    }

    public final i c(i iVar) {
        iVar.f8748g = this;
        iVar.f8747f = this.f8747f;
        this.f8747f.f8748g = iVar;
        this.f8747f = iVar;
        return iVar;
    }

    public final i d() {
        this.f8745d = true;
        return new i(this.f8742a, this.f8743b, this.f8744c, true, false);
    }

    public final i e(int i10) {
        i iVar;
        if (i10 <= 0 || i10 > this.f8744c - this.f8743b) {
            throw new IllegalArgumentException();
        }
        if (i10 >= 1024) {
            iVar = d();
        } else {
            iVar = j.b();
            System.arraycopy(this.f8742a, this.f8743b, iVar.f8742a, 0, i10);
        }
        iVar.f8744c = iVar.f8743b + i10;
        this.f8743b += i10;
        this.f8748g.c(iVar);
        return iVar;
    }

    public final void f(i iVar, int i10) {
        if (iVar.f8746e) {
            int i11 = iVar.f8744c;
            if (i11 + i10 > 8192) {
                if (!iVar.f8745d) {
                    int i12 = iVar.f8743b;
                    if ((i11 + i10) - i12 <= 8192) {
                        byte[] bArr = iVar.f8742a;
                        System.arraycopy(bArr, i12, bArr, 0, i11 - i12);
                        iVar.f8744c -= iVar.f8743b;
                        iVar.f8743b = 0;
                    } else {
                        throw new IllegalArgumentException();
                    }
                } else {
                    throw new IllegalArgumentException();
                }
            }
            System.arraycopy(this.f8742a, this.f8743b, iVar.f8742a, iVar.f8744c, i10);
            iVar.f8744c += i10;
            this.f8743b += i10;
            return;
        }
        throw new IllegalArgumentException();
    }

    public i(byte[] bArr, int i10, int i11, boolean z10, boolean z11) {
        this.f8742a = bArr;
        this.f8743b = i10;
        this.f8744c = i11;
        this.f8745d = z10;
        this.f8746e = z11;
    }
}
