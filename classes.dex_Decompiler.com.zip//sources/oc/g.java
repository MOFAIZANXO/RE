package oc;

public final class g implements l {

    /* renamed from: a  reason: collision with root package name */
    public final c f8732a;

    /* renamed from: b  reason: collision with root package name */
    public final a f8733b;

    /* renamed from: f  reason: collision with root package name */
    public i f8734f;

    /* renamed from: g  reason: collision with root package name */
    public int f8735g;

    /* renamed from: h  reason: collision with root package name */
    public boolean f8736h;

    /* renamed from: i  reason: collision with root package name */
    public long f8737i;

    public g(c cVar) {
        this.f8732a = cVar;
        a p10 = cVar.p();
        this.f8733b = p10;
        i iVar = p10.f8719a;
        this.f8734f = iVar;
        this.f8735g = iVar != null ? iVar.f8743b : -1;
    }

    public long O(a aVar, long j10) {
        i iVar;
        i iVar2;
        int i10 = (j10 > 0 ? 1 : (j10 == 0 ? 0 : -1));
        if (i10 < 0) {
            throw new IllegalArgumentException("byteCount < 0: " + j10);
        } else if (!this.f8736h) {
            i iVar3 = this.f8734f;
            if (iVar3 != null && (iVar3 != (iVar2 = this.f8733b.f8719a) || this.f8735g != iVar2.f8743b)) {
                throw new IllegalStateException("Peek source is invalid because upstream source was used");
            } else if (i10 == 0) {
                return 0;
            } else {
                if (!this.f8732a.v(this.f8737i + 1)) {
                    return -1;
                }
                if (this.f8734f == null && (iVar = this.f8733b.f8719a) != null) {
                    this.f8734f = iVar;
                    this.f8735g = iVar.f8743b;
                }
                long min = Math.min(j10, this.f8733b.f8720b - this.f8737i);
                this.f8733b.d(aVar, this.f8737i, min);
                this.f8737i += min;
                return min;
            }
        } else {
            throw new IllegalStateException("closed");
        }
    }

    public void close() {
        this.f8736h = true;
    }
}
