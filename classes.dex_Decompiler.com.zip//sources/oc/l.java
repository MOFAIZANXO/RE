package oc;

import java.io.Closeable;

public interface l extends Closeable {
    long O(a aVar, long j10);

    void close();
}
