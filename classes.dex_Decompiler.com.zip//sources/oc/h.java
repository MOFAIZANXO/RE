package oc;

import java.io.EOFException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;

public final class h implements c {

    /* renamed from: a  reason: collision with root package name */
    public final a f8738a = new a();

    /* renamed from: b  reason: collision with root package name */
    public final l f8739b;

    /* renamed from: f  reason: collision with root package name */
    public boolean f8740f;

    public h(l lVar) {
        if (lVar != null) {
            this.f8739b = lVar;
            return;
        }
        throw new NullPointerException("source == null");
    }

    public long N(d dVar) {
        return c(dVar, 0);
    }

    public long O(a aVar, long j10) {
        if (aVar == null) {
            throw new IllegalArgumentException("sink == null");
        } else if (j10 < 0) {
            throw new IllegalArgumentException("byteCount < 0: " + j10);
        } else if (!this.f8740f) {
            a aVar2 = this.f8738a;
            if (aVar2.f8720b == 0 && this.f8739b.O(aVar2, 8192) == -1) {
                return -1;
            }
            return this.f8738a.O(aVar, Math.min(j10, this.f8738a.f8720b));
        } else {
            throw new IllegalStateException("closed");
        }
    }

    public c R() {
        return e.a(new g(this));
    }

    public int Z(f fVar) {
        if (!this.f8740f) {
            do {
                int Q = this.f8738a.Q(fVar, true);
                if (Q == -1) {
                    return -1;
                }
                if (Q != -2) {
                    this.f8738a.c0((long) fVar.f8730a[Q].j());
                    return Q;
                }
            } while (this.f8739b.O(this.f8738a, 8192) != -1);
            return -1;
        }
        throw new IllegalStateException("closed");
    }

    public long a(d dVar, long j10) {
        if (!this.f8740f) {
            while (true) {
                long k10 = this.f8738a.k(dVar, j10);
                if (k10 != -1) {
                    return k10;
                }
                a aVar = this.f8738a;
                long j11 = aVar.f8720b;
                if (this.f8739b.O(aVar, 8192) == -1) {
                    return -1;
                }
                j10 = Math.max(j10, (j11 - ((long) dVar.j())) + 1);
            }
        } else {
            throw new IllegalStateException("closed");
        }
    }

    public InputStream a0() {
        return new a();
    }

    public byte b0() {
        d(1);
        return this.f8738a.b0();
    }

    public long c(d dVar, long j10) {
        if (!this.f8740f) {
            while (true) {
                long m10 = this.f8738a.m(dVar, j10);
                if (m10 != -1) {
                    return m10;
                }
                a aVar = this.f8738a;
                long j11 = aVar.f8720b;
                if (this.f8739b.O(aVar, 8192) == -1) {
                    return -1;
                }
                j10 = Math.max(j10, j11);
            }
        } else {
            throw new IllegalStateException("closed");
        }
    }

    public void close() {
        if (!this.f8740f) {
            this.f8740f = true;
            this.f8739b.close();
            this.f8738a.a();
        }
    }

    public void d(long j10) {
        if (!v(j10)) {
            throw new EOFException();
        }
    }

    public long i(d dVar) {
        return a(dVar, 0);
    }

    public boolean isOpen() {
        return !this.f8740f;
    }

    public a p() {
        return this.f8738a;
    }

    public int read(ByteBuffer byteBuffer) {
        a aVar = this.f8738a;
        if (aVar.f8720b == 0 && this.f8739b.O(aVar, 8192) == -1) {
            return -1;
        }
        return this.f8738a.read(byteBuffer);
    }

    public String toString() {
        return "buffer(" + this.f8739b + ")";
    }

    public boolean v(long j10) {
        a aVar;
        if (j10 < 0) {
            throw new IllegalArgumentException("byteCount < 0: " + j10);
        } else if (!this.f8740f) {
            do {
                aVar = this.f8738a;
                if (aVar.f8720b >= j10) {
                    return true;
                }
            } while (this.f8739b.O(aVar, 8192) != -1);
            return false;
        } else {
            throw new IllegalStateException("closed");
        }
    }

    public class a extends InputStream {
        public a() {
        }

        public int available() {
            h hVar = h.this;
            if (!hVar.f8740f) {
                return (int) Math.min(hVar.f8738a.f8720b, 2147483647L);
            }
            throw new IOException("closed");
        }

        public void close() {
            h.this.close();
        }

        public int read() {
            h hVar = h.this;
            if (!hVar.f8740f) {
                a aVar = hVar.f8738a;
                if (aVar.f8720b == 0 && hVar.f8739b.O(aVar, 8192) == -1) {
                    return -1;
                }
                return h.this.f8738a.b0() & 255;
            }
            throw new IOException("closed");
        }

        public String toString() {
            return h.this + ".inputStream()";
        }

        public int read(byte[] bArr, int i10, int i11) {
            if (!h.this.f8740f) {
                n.b((long) bArr.length, (long) i10, (long) i11);
                h hVar = h.this;
                a aVar = hVar.f8738a;
                if (aVar.f8720b == 0 && hVar.f8739b.O(aVar, 8192) == -1) {
                    return -1;
                }
                return h.this.f8738a.q(bArr, i10, i11);
            }
            throw new IOException("closed");
        }
    }
}
