package oc;

import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Logger;

public abstract class e {

    /* renamed from: a  reason: collision with root package name */
    public static final Logger f8727a = Logger.getLogger(e.class.getName());

    public class a implements l {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ m f8728a;

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ InputStream f8729b;

        public a(m mVar, InputStream inputStream) {
            this.f8728a = mVar;
            this.f8729b = inputStream;
        }

        public long O(a aVar, long j10) {
            int i10 = (j10 > 0 ? 1 : (j10 == 0 ? 0 : -1));
            if (i10 < 0) {
                throw new IllegalArgumentException("byteCount < 0: " + j10);
            } else if (i10 == 0) {
                return 0;
            } else {
                try {
                    this.f8728a.a();
                    i f02 = aVar.f0(1);
                    int read = this.f8729b.read(f02.f8742a, f02.f8744c, (int) Math.min(j10, (long) (8192 - f02.f8744c)));
                    if (read == -1) {
                        return -1;
                    }
                    f02.f8744c += read;
                    long j11 = (long) read;
                    aVar.f8720b += j11;
                    return j11;
                } catch (AssertionError e10) {
                    if (e.b(e10)) {
                        throw new IOException(e10);
                    }
                    throw e10;
                }
            }
        }

        public void close() {
            this.f8729b.close();
        }

        public String toString() {
            return "source(" + this.f8729b + ")";
        }
    }

    public static c a(l lVar) {
        return new h(lVar);
    }

    public static boolean b(AssertionError assertionError) {
        return (assertionError.getCause() == null || assertionError.getMessage() == null || !assertionError.getMessage().contains("getsockname failed")) ? false : true;
    }

    public static l c(InputStream inputStream) {
        return d(inputStream, new m());
    }

    public static l d(InputStream inputStream, m mVar) {
        if (inputStream == null) {
            throw new IllegalArgumentException("in == null");
        } else if (mVar != null) {
            return new a(mVar, inputStream);
        } else {
            throw new IllegalArgumentException("timeout == null");
        }
    }
}
