package oc;

import java.io.InputStream;
import java.nio.channels.ReadableByteChannel;

public interface c extends l, ReadableByteChannel {
    long N(d dVar);

    c R();

    int Z(f fVar);

    InputStream a0();

    byte b0();

    long i(d dVar);

    a p();

    boolean v(long j10);
}
