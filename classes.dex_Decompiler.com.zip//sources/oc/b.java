package oc;

import java.io.Closeable;
import java.io.Flushable;
import java.nio.channels.WritableByteChannel;

public interface b extends Closeable, Flushable, WritableByteChannel {
    b B(int i10);

    b V(String str);

    b l(String str, int i10, int i11);
}
