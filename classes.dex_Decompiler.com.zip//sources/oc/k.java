package oc;

import java.util.Arrays;

public final class k extends d {

    /* renamed from: i  reason: collision with root package name */
    public final transient byte[][] f8751i;

    /* renamed from: j  reason: collision with root package name */
    public final transient int[] f8752j;

    public k(a aVar, int i10) {
        super((byte[]) null);
        n.b(aVar.f8720b, 0, (long) i10);
        i iVar = aVar.f8719a;
        int i11 = 0;
        int i12 = 0;
        int i13 = 0;
        while (i12 < i10) {
            int i14 = iVar.f8744c;
            int i15 = iVar.f8743b;
            if (i14 != i15) {
                i12 += i14 - i15;
                i13++;
                iVar = iVar.f8747f;
            } else {
                throw new AssertionError("s.limit == s.pos");
            }
        }
        this.f8751i = new byte[i13][];
        this.f8752j = new int[(i13 * 2)];
        i iVar2 = aVar.f8719a;
        int i16 = 0;
        while (i11 < i10) {
            byte[][] bArr = this.f8751i;
            bArr[i16] = iVar2.f8742a;
            int i17 = iVar2.f8744c;
            int i18 = iVar2.f8743b;
            i11 += i17 - i18;
            if (i11 > i10) {
                i11 = i10;
            }
            int[] iArr = this.f8752j;
            iArr[i16] = i11;
            iArr[bArr.length + i16] = i18;
            iVar2.f8745d = true;
            i16++;
            iVar2 = iVar2.f8747f;
        }
    }

    public byte d(int i10) {
        n.b((long) this.f8752j[this.f8751i.length - 1], (long) i10, 1);
        int n10 = n(i10);
        int i11 = n10 == 0 ? 0 : this.f8752j[n10 - 1];
        int[] iArr = this.f8752j;
        byte[][] bArr = this.f8751i;
        return bArr[n10][(i10 - i11) + iArr[bArr.length + n10]];
    }

    public String e() {
        return p().e();
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof d) {
            d dVar = (d) obj;
            if (dVar.j() == j() && h(0, dVar, 0, j())) {
                return true;
            }
        }
        return false;
    }

    public byte[] f() {
        return o();
    }

    public boolean h(int i10, d dVar, int i11, int i12) {
        if (i10 < 0 || i10 > j() - i12) {
            return false;
        }
        int n10 = n(i10);
        while (i12 > 0) {
            int i13 = n10 == 0 ? 0 : this.f8752j[n10 - 1];
            int min = Math.min(i12, ((this.f8752j[n10] - i13) + i13) - i10);
            int[] iArr = this.f8752j;
            byte[][] bArr = this.f8751i;
            if (!dVar.i(i11, bArr[n10], (i10 - i13) + iArr[bArr.length + n10], min)) {
                return false;
            }
            i10 += min;
            i11 += min;
            i12 -= min;
            n10++;
        }
        return true;
    }

    public int hashCode() {
        int i10 = this.f8725b;
        if (i10 != 0) {
            return i10;
        }
        int length = this.f8751i.length;
        int i11 = 0;
        int i12 = 1;
        int i13 = 0;
        while (i11 < length) {
            byte[] bArr = this.f8751i[i11];
            int[] iArr = this.f8752j;
            int i14 = iArr[length + i11];
            int i15 = iArr[i11];
            int i16 = (i15 - i13) + i14;
            while (i14 < i16) {
                i12 = (i12 * 31) + bArr[i14];
                i14++;
            }
            i11++;
            i13 = i15;
        }
        this.f8725b = i12;
        return i12;
    }

    public boolean i(int i10, byte[] bArr, int i11, int i12) {
        if (i10 < 0 || i10 > j() - i12 || i11 < 0 || i11 > bArr.length - i12) {
            return false;
        }
        int n10 = n(i10);
        while (i12 > 0) {
            int i13 = n10 == 0 ? 0 : this.f8752j[n10 - 1];
            int min = Math.min(i12, ((this.f8752j[n10] - i13) + i13) - i10);
            int[] iArr = this.f8752j;
            byte[][] bArr2 = this.f8751i;
            if (!n.a(bArr2[n10], (i10 - i13) + iArr[bArr2.length + n10], bArr, i11, min)) {
                return false;
            }
            i10 += min;
            i11 += min;
            i12 -= min;
            n10++;
        }
        return true;
    }

    public int j() {
        return this.f8752j[this.f8751i.length - 1];
    }

    public d l(int i10, int i11) {
        return p().l(i10, i11);
    }

    public String m() {
        return p().m();
    }

    public final int n(int i10) {
        int binarySearch = Arrays.binarySearch(this.f8752j, 0, this.f8751i.length, i10 + 1);
        return binarySearch >= 0 ? binarySearch : ~binarySearch;
    }

    public byte[] o() {
        int[] iArr = this.f8752j;
        byte[][] bArr = this.f8751i;
        byte[] bArr2 = new byte[iArr[bArr.length - 1]];
        int length = bArr.length;
        int i10 = 0;
        int i11 = 0;
        while (i10 < length) {
            int[] iArr2 = this.f8752j;
            int i12 = iArr2[length + i10];
            int i13 = iArr2[i10];
            System.arraycopy(this.f8751i[i10], i12, bArr2, i11, i13 - i11);
            i10++;
            i11 = i13;
        }
        return bArr2;
    }

    public final d p() {
        return new d(o());
    }

    public String toString() {
        return p().toString();
    }
}
