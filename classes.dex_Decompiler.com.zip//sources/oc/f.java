package oc;

import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.RandomAccess;

public final class f extends AbstractList implements RandomAccess {

    /* renamed from: a  reason: collision with root package name */
    public final d[] f8730a;

    /* renamed from: b  reason: collision with root package name */
    public final int[] f8731b;

    public f(d[] dVarArr, int[] iArr) {
        this.f8730a = dVarArr;
        this.f8731b = iArr;
    }

    public static void a(long j10, a aVar, int i10, List list, int i11, int i12, List list2) {
        int i13;
        int i14;
        int i15;
        int i16;
        a aVar2;
        int i17;
        a aVar3 = aVar;
        int i18 = i10;
        List list3 = list;
        int i19 = i11;
        int i20 = i12;
        List list4 = list2;
        if (i19 < i20) {
            int i21 = i19;
            while (i21 < i20) {
                if (((d) list3.get(i21)).j() >= i18) {
                    i21++;
                } else {
                    throw new AssertionError();
                }
            }
            d dVar = (d) list.get(i11);
            d dVar2 = (d) list3.get(i20 - 1);
            if (i18 == dVar.j()) {
                int intValue = ((Integer) list4.get(i19)).intValue();
                int i22 = i19 + 1;
                i13 = i22;
                i14 = intValue;
                dVar = (d) list3.get(i22);
            } else {
                i14 = -1;
                i13 = i19;
            }
            if (dVar.d(i18) != dVar2.d(i18)) {
                int i23 = 1;
                for (int i24 = i13 + 1; i24 < i20; i24++) {
                    if (((d) list3.get(i24 - 1)).d(i18) != ((d) list3.get(i24)).d(i18)) {
                        i23++;
                    }
                }
                long c10 = j10 + ((long) c(aVar)) + 2 + ((long) (i23 * 2));
                aVar3.i0(i23);
                aVar3.i0(i14);
                for (int i25 = i13; i25 < i20; i25++) {
                    byte d10 = ((d) list3.get(i25)).d(i18);
                    if (i25 == i13 || d10 != ((d) list3.get(i25 - 1)).d(i18)) {
                        aVar3.i0(d10 & 255);
                    }
                }
                a aVar4 = new a();
                int i26 = i13;
                while (i26 < i20) {
                    byte d11 = ((d) list3.get(i26)).d(i18);
                    int i27 = i26 + 1;
                    int i28 = i27;
                    while (true) {
                        if (i28 >= i20) {
                            i16 = i20;
                            break;
                        } else if (d11 != ((d) list3.get(i28)).d(i18)) {
                            i16 = i28;
                            break;
                        } else {
                            i28++;
                        }
                    }
                    if (i27 == i16 && i18 + 1 == ((d) list3.get(i26)).j()) {
                        aVar3.i0(((Integer) list4.get(i26)).intValue());
                        i17 = i16;
                        aVar2 = aVar4;
                    } else {
                        aVar3.i0((int) ((((long) c(aVar4)) + c10) * -1));
                        i17 = i16;
                        aVar2 = aVar4;
                        a(c10, aVar4, i18 + 1, list, i26, i16, list2);
                    }
                    aVar4 = aVar2;
                    i26 = i17;
                }
                a aVar5 = aVar4;
                aVar3.g0(aVar5, aVar5.T());
                return;
            }
            int min = Math.min(dVar.j(), dVar2.j());
            int i29 = 0;
            int i30 = i18;
            while (i30 < min && dVar.d(i30) == dVar2.d(i30)) {
                i29++;
                i30++;
            }
            long c11 = 1 + j10 + ((long) c(aVar)) + 2 + ((long) i29);
            aVar3.i0(-i29);
            aVar3.i0(i14);
            int i31 = i18;
            while (true) {
                i15 = i18 + i29;
                if (i31 >= i15) {
                    break;
                }
                aVar3.i0(dVar.d(i31) & 255);
                i31++;
            }
            if (i13 + 1 != i20) {
                a aVar6 = new a();
                aVar3.i0((int) ((((long) c(aVar6)) + c11) * -1));
                a(c11, aVar6, i15, list, i13, i12, list2);
                aVar3.g0(aVar6, aVar6.T());
            } else if (i15 == ((d) list3.get(i13)).j()) {
                aVar3.i0(((Integer) list4.get(i13)).intValue());
            } else {
                throw new AssertionError();
            }
        } else {
            throw new AssertionError();
        }
    }

    public static int c(a aVar) {
        return (int) (aVar.T() / 4);
    }

    public static f d(d... dVarArr) {
        if (dVarArr.length == 0) {
            return new f(new d[0], new int[]{0, -1});
        }
        ArrayList arrayList = new ArrayList(Arrays.asList(dVarArr));
        Collections.sort(arrayList);
        ArrayList arrayList2 = new ArrayList();
        for (int i10 = 0; i10 < arrayList.size(); i10++) {
            arrayList2.add(-1);
        }
        for (int i11 = 0; i11 < arrayList.size(); i11++) {
            arrayList2.set(Collections.binarySearch(arrayList, dVarArr[i11]), Integer.valueOf(i11));
        }
        if (((d) arrayList.get(0)).j() != 0) {
            int i12 = 0;
            while (i12 < arrayList.size()) {
                d dVar = (d) arrayList.get(i12);
                int i13 = i12 + 1;
                int i14 = i13;
                while (i14 < arrayList.size()) {
                    d dVar2 = (d) arrayList.get(i14);
                    if (!dVar2.k(dVar)) {
                        continue;
                        break;
                    } else if (dVar2.j() == dVar.j()) {
                        throw new IllegalArgumentException("duplicate option: " + dVar2);
                    } else if (((Integer) arrayList2.get(i14)).intValue() > ((Integer) arrayList2.get(i12)).intValue()) {
                        arrayList.remove(i14);
                        arrayList2.remove(i14);
                    } else {
                        i14++;
                    }
                }
                i12 = i13;
            }
            a aVar = new a();
            a(0, aVar, 0, arrayList, 0, arrayList.size(), arrayList2);
            int c10 = c(aVar);
            int[] iArr = new int[c10];
            for (int i15 = 0; i15 < c10; i15++) {
                iArr[i15] = aVar.H();
            }
            if (aVar.e()) {
                return new f((d[]) dVarArr.clone(), iArr);
            }
            throw new AssertionError();
        }
        throw new IllegalArgumentException("the empty byte string is not a supported option");
    }

    /* renamed from: b */
    public d get(int i10) {
        return this.f8730a[i10];
    }

    public final int size() {
        return this.f8730a.length;
    }
}
