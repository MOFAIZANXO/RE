package oc;

public abstract class j {

    /* renamed from: a  reason: collision with root package name */
    public static i f8749a;

    /* renamed from: b  reason: collision with root package name */
    public static long f8750b;

    public static void a(i iVar) {
        if (iVar.f8747f != null || iVar.f8748g != null) {
            throw new IllegalArgumentException();
        } else if (!iVar.f8745d) {
            synchronized (j.class) {
                long j10 = f8750b;
                if (j10 + 8192 <= 65536) {
                    f8750b = j10 + 8192;
                    iVar.f8747f = f8749a;
                    iVar.f8744c = 0;
                    iVar.f8743b = 0;
                    f8749a = iVar;
                }
            }
        }
    }

    public static i b() {
        synchronized (j.class) {
            i iVar = f8749a;
            if (iVar == null) {
                return new i();
            }
            f8749a = iVar.f8747f;
            iVar.f8747f = null;
            f8750b -= 8192;
            return iVar;
        }
    }
}
