package oc;

import java.io.InterruptedIOException;

public class m {

    /* renamed from: c  reason: collision with root package name */
    public static final m f8753c = new a();

    /* renamed from: a  reason: collision with root package name */
    public boolean f8754a;

    /* renamed from: b  reason: collision with root package name */
    public long f8755b;

    public class a extends m {
        public void a() {
        }
    }

    public void a() {
        if (Thread.interrupted()) {
            Thread.currentThread().interrupt();
            throw new InterruptedIOException("interrupted");
        } else if (this.f8754a && this.f8755b - System.nanoTime() <= 0) {
            throw new InterruptedIOException("deadline reached");
        }
    }
}
