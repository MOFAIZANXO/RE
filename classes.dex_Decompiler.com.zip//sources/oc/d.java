package oc;

import java.io.Serializable;
import java.util.Arrays;

public class d implements Serializable, Comparable {

    /* renamed from: g  reason: collision with root package name */
    public static final char[] f8722g = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f'};

    /* renamed from: h  reason: collision with root package name */
    public static final d f8723h = g(new byte[0]);

    /* renamed from: a  reason: collision with root package name */
    public final byte[] f8724a;

    /* renamed from: b  reason: collision with root package name */
    public transient int f8725b;

    /* renamed from: f  reason: collision with root package name */
    public transient String f8726f;

    public d(byte[] bArr) {
        this.f8724a = bArr;
    }

    public static int a(String str, int i10) {
        int length = str.length();
        int i11 = 0;
        int i12 = 0;
        while (i11 < length) {
            if (i12 == i10) {
                return i11;
            }
            int codePointAt = str.codePointAt(i11);
            if ((Character.isISOControl(codePointAt) && codePointAt != 10 && codePointAt != 13) || codePointAt == 65533) {
                return -1;
            }
            i12++;
            i11 += Character.charCount(codePointAt);
        }
        return str.length();
    }

    public static d c(String str) {
        if (str != null) {
            d dVar = new d(str.getBytes(n.f8756a));
            dVar.f8726f = str;
            return dVar;
        }
        throw new IllegalArgumentException("s == null");
    }

    public static d g(byte... bArr) {
        if (bArr != null) {
            return new d((byte[]) bArr.clone());
        }
        throw new IllegalArgumentException("data == null");
    }

    /* renamed from: b */
    public int compareTo(d dVar) {
        int j10 = j();
        int j11 = dVar.j();
        int min = Math.min(j10, j11);
        for (int i10 = 0; i10 < min; i10++) {
            byte d10 = d(i10) & 255;
            byte d11 = dVar.d(i10) & 255;
            if (d10 != d11) {
                return d10 < d11 ? -1 : 1;
            }
        }
        if (j10 == j11) {
            return 0;
        }
        return j10 < j11 ? -1 : 1;
    }

    public byte d(int i10) {
        return this.f8724a[i10];
    }

    public String e() {
        byte[] bArr = this.f8724a;
        char[] cArr = new char[(bArr.length * 2)];
        int i10 = 0;
        for (byte b10 : bArr) {
            int i11 = i10 + 1;
            char[] cArr2 = f8722g;
            cArr[i10] = cArr2[(b10 >> 4) & 15];
            i10 = i11 + 1;
            cArr[i11] = cArr2[b10 & 15];
        }
        return new String(cArr);
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj instanceof d) {
            d dVar = (d) obj;
            int j10 = dVar.j();
            byte[] bArr = this.f8724a;
            if (j10 == bArr.length && dVar.i(0, bArr, 0, bArr.length)) {
                return true;
            }
        }
        return false;
    }

    public byte[] f() {
        return this.f8724a;
    }

    public boolean h(int i10, d dVar, int i11, int i12) {
        return dVar.i(i11, this.f8724a, i10, i12);
    }

    public int hashCode() {
        int i10 = this.f8725b;
        if (i10 != 0) {
            return i10;
        }
        int hashCode = Arrays.hashCode(this.f8724a);
        this.f8725b = hashCode;
        return hashCode;
    }

    public boolean i(int i10, byte[] bArr, int i11, int i12) {
        if (i10 >= 0) {
            byte[] bArr2 = this.f8724a;
            return i10 <= bArr2.length - i12 && i11 >= 0 && i11 <= bArr.length - i12 && n.a(bArr2, i10, bArr, i11, i12);
        }
    }

    public int j() {
        return this.f8724a.length;
    }

    public final boolean k(d dVar) {
        return h(0, dVar, 0, dVar.j());
    }

    public d l(int i10, int i11) {
        if (i10 >= 0) {
            byte[] bArr = this.f8724a;
            if (i11 <= bArr.length) {
                int i12 = i11 - i10;
                if (i12 < 0) {
                    throw new IllegalArgumentException("endIndex < beginIndex");
                } else if (i10 == 0 && i11 == bArr.length) {
                    return this;
                } else {
                    byte[] bArr2 = new byte[i12];
                    System.arraycopy(bArr, i10, bArr2, 0, i12);
                    return new d(bArr2);
                }
            } else {
                throw new IllegalArgumentException("endIndex > length(" + this.f8724a.length + ")");
            }
        } else {
            throw new IllegalArgumentException("beginIndex < 0");
        }
    }

    public String m() {
        String str = this.f8726f;
        if (str != null) {
            return str;
        }
        String str2 = new String(this.f8724a, n.f8756a);
        this.f8726f = str2;
        return str2;
    }

    public String toString() {
        if (this.f8724a.length == 0) {
            return "[size=0]";
        }
        String m10 = m();
        int a10 = a(m10, 64);
        if (a10 != -1) {
            String replace = m10.substring(0, a10).replace("\\", "\\\\").replace("\n", "\\n").replace("\r", "\\r");
            if (a10 < m10.length()) {
                return "[size=" + this.f8724a.length + " text=" + replace + "…]";
            }
            return "[text=" + replace + "]";
        } else if (this.f8724a.length <= 64) {
            return "[hex=" + e() + "]";
        } else {
            return "[size=" + this.f8724a.length + " hex=" + l(0, 64).e() + "…]";
        }
    }
}
