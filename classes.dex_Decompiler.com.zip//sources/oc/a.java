package oc;

import java.io.EOFException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.channels.ByteChannel;
import java.nio.charset.Charset;

public final class a implements c, b, Cloneable, ByteChannel {

    /* renamed from: f  reason: collision with root package name */
    public static final byte[] f8718f = {48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 97, 98, 99, 100, 101, 102};

    /* renamed from: a  reason: collision with root package name */
    public i f8719a;

    /* renamed from: b  reason: collision with root package name */
    public long f8720b;

    /* renamed from: oc.a$a  reason: collision with other inner class name */
    public class C0121a extends InputStream {
        public C0121a() {
        }

        public int available() {
            return (int) Math.min(a.this.f8720b, 2147483647L);
        }

        public void close() {
        }

        public int read() {
            a aVar = a.this;
            if (aVar.f8720b > 0) {
                return aVar.b0() & 255;
            }
            return -1;
        }

        public String toString() {
            return a.this + ".inputStream()";
        }

        public int read(byte[] bArr, int i10, int i11) {
            return a.this.q(bArr, i10, i11);
        }
    }

    public d C() {
        return new d(r());
    }

    public void F(byte[] bArr) {
        int i10 = 0;
        while (i10 < bArr.length) {
            int q10 = q(bArr, i10, bArr.length - i10);
            if (q10 != -1) {
                i10 += q10;
            } else {
                throw new EOFException();
            }
        }
    }

    public int H() {
        long j10 = this.f8720b;
        if (j10 >= 4) {
            i iVar = this.f8719a;
            int i10 = iVar.f8743b;
            int i11 = iVar.f8744c;
            if (i11 - i10 < 4) {
                return (b0() & 255) | ((b0() & 255) << 24) | ((b0() & 255) << 16) | ((b0() & 255) << 8);
            }
            byte[] bArr = iVar.f8742a;
            int i12 = i10 + 1;
            int i13 = i12 + 1;
            byte b10 = ((bArr[i10] & 255) << 24) | ((bArr[i12] & 255) << 16);
            int i14 = i13 + 1;
            byte b11 = b10 | ((bArr[i13] & 255) << 8);
            int i15 = i14 + 1;
            byte b12 = b11 | (bArr[i14] & 255);
            this.f8720b = j10 - 4;
            if (i15 == i11) {
                this.f8719a = iVar.b();
                j.a(iVar);
            } else {
                iVar.f8743b = i15;
            }
            return b12;
        }
        throw new IllegalStateException("size < 4: " + this.f8720b);
    }

    public String I(long j10, Charset charset) {
        n.b(this.f8720b, 0, j10);
        if (charset == null) {
            throw new IllegalArgumentException("charset == null");
        } else if (j10 > 2147483647L) {
            throw new IllegalArgumentException("byteCount > Integer.MAX_VALUE: " + j10);
        } else if (j10 == 0) {
            return "";
        } else {
            i iVar = this.f8719a;
            int i10 = iVar.f8743b;
            if (((long) i10) + j10 > ((long) iVar.f8744c)) {
                return new String(y(j10), charset);
            }
            String str = new String(iVar.f8742a, i10, (int) j10, charset);
            int i11 = (int) (((long) iVar.f8743b) + j10);
            iVar.f8743b = i11;
            this.f8720b -= j10;
            if (i11 == iVar.f8744c) {
                this.f8719a = iVar.b();
                j.a(iVar);
            }
            return str;
        }
    }

    public String K() {
        try {
            return I(this.f8720b, n.f8756a);
        } catch (EOFException e10) {
            throw new AssertionError(e10);
        }
    }

    public long N(d dVar) {
        return m(dVar, 0);
    }

    public long O(a aVar, long j10) {
        if (aVar == null) {
            throw new IllegalArgumentException("sink == null");
        } else if (j10 >= 0) {
            long j11 = this.f8720b;
            if (j11 == 0) {
                return -1;
            }
            if (j10 > j11) {
                j10 = j11;
            }
            aVar.g0(this, j10);
            return j10;
        } else {
            throw new IllegalArgumentException("byteCount < 0: " + j10);
        }
    }

    public String P(long j10) {
        return I(j10, n.f8756a);
    }

    public int Q(f fVar, boolean z10) {
        int i10;
        int i11;
        int i12;
        i iVar;
        int i13;
        f fVar2 = fVar;
        i iVar2 = this.f8719a;
        if (iVar2 != null) {
            byte[] bArr = iVar2.f8742a;
            int i14 = iVar2.f8743b;
            int i15 = iVar2.f8744c;
            int[] iArr = fVar2.f8731b;
            i iVar3 = iVar2;
            int i16 = 0;
            int i17 = -1;
            loop0:
            while (true) {
                int i18 = i16 + 1;
                int i19 = iArr[i16];
                int i20 = i18 + 1;
                int i21 = iArr[i18];
                if (i21 != -1) {
                    i17 = i21;
                }
                if (iVar3 == null) {
                    break;
                }
                if (i19 < 0) {
                    int i22 = i20 + (i19 * -1);
                    while (true) {
                        int i23 = i14 + 1;
                        int i24 = i20 + 1;
                        if ((bArr[i14] & 255) != iArr[i20]) {
                            return i17;
                        }
                        boolean z11 = i24 == i22;
                        if (i23 == i15) {
                            i iVar4 = iVar3.f8747f;
                            i13 = iVar4.f8743b;
                            byte[] bArr2 = iVar4.f8742a;
                            i12 = iVar4.f8744c;
                            if (iVar4 != iVar2) {
                                byte[] bArr3 = bArr2;
                                iVar = iVar4;
                                bArr = bArr3;
                            } else if (!z11) {
                                break loop0;
                            } else {
                                bArr = bArr2;
                                iVar = null;
                            }
                        } else {
                            i iVar5 = iVar3;
                            i12 = i15;
                            i13 = i23;
                            iVar = iVar5;
                        }
                        if (z11) {
                            i11 = iArr[i24];
                            i10 = i13;
                            i15 = i12;
                            iVar3 = iVar;
                            break;
                        }
                        i14 = i13;
                        i15 = i12;
                        i20 = i24;
                        iVar3 = iVar;
                    }
                } else {
                    i10 = i14 + 1;
                    byte b10 = bArr[i14] & 255;
                    int i25 = i20 + i19;
                    while (i20 != i25) {
                        if (b10 == iArr[i20]) {
                            i11 = iArr[i20 + i19];
                            if (i10 == i15) {
                                iVar3 = iVar3.f8747f;
                                i10 = iVar3.f8743b;
                                bArr = iVar3.f8742a;
                                i15 = iVar3.f8744c;
                                if (iVar3 == iVar2) {
                                    iVar3 = null;
                                }
                            }
                        } else {
                            i20++;
                        }
                    }
                    return i17;
                }
                if (i11 >= 0) {
                    return i11;
                }
                i16 = -i11;
                i14 = i10;
            }
            if (z10) {
                return -2;
            }
            return i17;
        } else if (z10) {
            return -2;
        } else {
            return fVar2.indexOf(d.f8723h);
        }
    }

    public c R() {
        return e.a(new g(this));
    }

    public final long T() {
        return this.f8720b;
    }

    public int Z(f fVar) {
        int Q = Q(fVar, false);
        if (Q == -1) {
            return -1;
        }
        try {
            c0((long) fVar.f8730a[Q].j());
            return Q;
        } catch (EOFException unused) {
            throw new AssertionError();
        }
    }

    public final void a() {
        try {
            c0(this.f8720b);
        } catch (EOFException e10) {
            throw new AssertionError(e10);
        }
    }

    public InputStream a0() {
        return new C0121a();
    }

    public byte b0() {
        long j10 = this.f8720b;
        if (j10 != 0) {
            i iVar = this.f8719a;
            int i10 = iVar.f8743b;
            int i11 = iVar.f8744c;
            int i12 = i10 + 1;
            byte b10 = iVar.f8742a[i10];
            this.f8720b = j10 - 1;
            if (i12 == i11) {
                this.f8719a = iVar.b();
                j.a(iVar);
            } else {
                iVar.f8743b = i12;
            }
            return b10;
        }
        throw new IllegalStateException("size == 0");
    }

    /* renamed from: c */
    public a clone() {
        a aVar = new a();
        if (this.f8720b == 0) {
            return aVar;
        }
        i d10 = this.f8719a.d();
        aVar.f8719a = d10;
        d10.f8748g = d10;
        d10.f8747f = d10;
        i iVar = this.f8719a;
        while (true) {
            iVar = iVar.f8747f;
            if (iVar != this.f8719a) {
                aVar.f8719a.f8748g.c(iVar.d());
            } else {
                aVar.f8720b = this.f8720b;
                return aVar;
            }
        }
    }

    public void c0(long j10) {
        while (j10 > 0) {
            i iVar = this.f8719a;
            if (iVar != null) {
                int min = (int) Math.min(j10, (long) (iVar.f8744c - iVar.f8743b));
                long j11 = (long) min;
                this.f8720b -= j11;
                j10 -= j11;
                i iVar2 = this.f8719a;
                int i10 = iVar2.f8743b + min;
                iVar2.f8743b = i10;
                if (i10 == iVar2.f8744c) {
                    this.f8719a = iVar2.b();
                    j.a(iVar2);
                }
            } else {
                throw new EOFException();
            }
        }
    }

    public void close() {
    }

    public final a d(a aVar, long j10, long j11) {
        if (aVar != null) {
            n.b(this.f8720b, j10, j11);
            if (j11 == 0) {
                return this;
            }
            aVar.f8720b += j11;
            i iVar = this.f8719a;
            while (true) {
                int i10 = iVar.f8744c;
                int i11 = iVar.f8743b;
                if (j10 < ((long) (i10 - i11))) {
                    break;
                }
                j10 -= (long) (i10 - i11);
                iVar = iVar.f8747f;
            }
            while (j11 > 0) {
                i d10 = iVar.d();
                int i12 = (int) (((long) d10.f8743b) + j10);
                d10.f8743b = i12;
                d10.f8744c = Math.min(i12 + ((int) j11), d10.f8744c);
                i iVar2 = aVar.f8719a;
                if (iVar2 == null) {
                    d10.f8748g = d10;
                    d10.f8747f = d10;
                    aVar.f8719a = d10;
                } else {
                    iVar2.f8748g.c(d10);
                }
                j11 -= (long) (d10.f8744c - d10.f8743b);
                iVar = iVar.f8747f;
                j10 = 0;
            }
            return this;
        }
        throw new IllegalArgumentException("out == null");
    }

    public final d d0() {
        long j10 = this.f8720b;
        if (j10 <= 2147483647L) {
            return e0((int) j10);
        }
        throw new IllegalArgumentException("size > Integer.MAX_VALUE: " + this.f8720b);
    }

    public boolean e() {
        return this.f8720b == 0;
    }

    public final d e0(int i10) {
        return i10 == 0 ? d.f8723h : new k(this, i10);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        long j10 = this.f8720b;
        if (j10 != aVar.f8720b) {
            return false;
        }
        long j11 = 0;
        if (j10 == 0) {
            return true;
        }
        i iVar = this.f8719a;
        i iVar2 = aVar.f8719a;
        int i10 = iVar.f8743b;
        int i11 = iVar2.f8743b;
        while (j11 < this.f8720b) {
            long min = (long) Math.min(iVar.f8744c - i10, iVar2.f8744c - i11);
            int i12 = 0;
            while (((long) i12) < min) {
                int i13 = i10 + 1;
                int i14 = i11 + 1;
                if (iVar.f8742a[i10] != iVar2.f8742a[i11]) {
                    return false;
                }
                i12++;
                i10 = i13;
                i11 = i14;
            }
            if (i10 == iVar.f8744c) {
                iVar = iVar.f8747f;
                i10 = iVar.f8743b;
            }
            if (i11 == iVar2.f8744c) {
                iVar2 = iVar2.f8747f;
                i11 = iVar2.f8743b;
            }
            j11 += min;
        }
        return true;
    }

    public final byte f(long j10) {
        int i10;
        n.b(this.f8720b, j10, 1);
        long j11 = this.f8720b;
        if (j11 - j10 > j10) {
            i iVar = this.f8719a;
            while (true) {
                int i11 = iVar.f8744c;
                int i12 = iVar.f8743b;
                long j12 = (long) (i11 - i12);
                if (j10 < j12) {
                    return iVar.f8742a[i12 + ((int) j10)];
                }
                j10 -= j12;
                iVar = iVar.f8747f;
            }
        } else {
            long j13 = j10 - j11;
            i iVar2 = this.f8719a;
            do {
                iVar2 = iVar2.f8748g;
                int i13 = iVar2.f8744c;
                i10 = iVar2.f8743b;
                j13 += (long) (i13 - i10);
            } while (j13 < 0);
            return iVar2.f8742a[i10 + ((int) j13)];
        }
    }

    public i f0(int i10) {
        if (i10 < 1 || i10 > 8192) {
            throw new IllegalArgumentException();
        }
        i iVar = this.f8719a;
        if (iVar == null) {
            i b10 = j.b();
            this.f8719a = b10;
            b10.f8748g = b10;
            b10.f8747f = b10;
            return b10;
        }
        i iVar2 = iVar.f8748g;
        return (iVar2.f8744c + i10 > 8192 || !iVar2.f8746e) ? iVar2.c(j.b()) : iVar2;
    }

    public void flush() {
    }

    public void g0(a aVar, long j10) {
        if (aVar == null) {
            throw new IllegalArgumentException("source == null");
        } else if (aVar != this) {
            n.b(aVar.f8720b, 0, j10);
            while (j10 > 0) {
                i iVar = aVar.f8719a;
                if (j10 < ((long) (iVar.f8744c - iVar.f8743b))) {
                    i iVar2 = this.f8719a;
                    i iVar3 = iVar2 != null ? iVar2.f8748g : null;
                    if (iVar3 != null && iVar3.f8746e) {
                        if ((((long) iVar3.f8744c) + j10) - ((long) (iVar3.f8745d ? 0 : iVar3.f8743b)) <= 8192) {
                            iVar.f(iVar3, (int) j10);
                            aVar.f8720b -= j10;
                            this.f8720b += j10;
                            return;
                        }
                    }
                    aVar.f8719a = iVar.e((int) j10);
                }
                i iVar4 = aVar.f8719a;
                long j11 = (long) (iVar4.f8744c - iVar4.f8743b);
                aVar.f8719a = iVar4.b();
                i iVar5 = this.f8719a;
                if (iVar5 == null) {
                    this.f8719a = iVar4;
                    iVar4.f8748g = iVar4;
                    iVar4.f8747f = iVar4;
                } else {
                    iVar5.f8748g.c(iVar4).a();
                }
                aVar.f8720b -= j11;
                this.f8720b += j11;
                j10 -= j11;
            }
        } else {
            throw new IllegalArgumentException("source == this");
        }
    }

    /* renamed from: h0 */
    public a B(int i10) {
        i f02 = f0(1);
        byte[] bArr = f02.f8742a;
        int i11 = f02.f8744c;
        f02.f8744c = i11 + 1;
        bArr[i11] = (byte) i10;
        this.f8720b++;
        return this;
    }

    public int hashCode() {
        i iVar = this.f8719a;
        if (iVar == null) {
            return 0;
        }
        int i10 = 1;
        do {
            int i11 = iVar.f8744c;
            for (int i12 = iVar.f8743b; i12 < i11; i12++) {
                i10 = (i10 * 31) + iVar.f8742a[i12];
            }
            iVar = iVar.f8747f;
        } while (iVar != this.f8719a);
        return i10;
    }

    public long i(d dVar) {
        return k(dVar, 0);
    }

    public a i0(int i10) {
        i f02 = f0(4);
        byte[] bArr = f02.f8742a;
        int i11 = f02.f8744c;
        int i12 = i11 + 1;
        bArr[i11] = (byte) ((i10 >>> 24) & 255);
        int i13 = i12 + 1;
        bArr[i12] = (byte) ((i10 >>> 16) & 255);
        int i14 = i13 + 1;
        bArr[i13] = (byte) ((i10 >>> 8) & 255);
        bArr[i14] = (byte) (i10 & 255);
        f02.f8744c = i14 + 1;
        this.f8720b += 4;
        return this;
    }

    public boolean isOpen() {
        return true;
    }

    /* renamed from: j0 */
    public a V(String str) {
        return l(str, 0, str.length());
    }

    public long k(d dVar, long j10) {
        byte[] bArr;
        if (dVar.j() != 0) {
            long j11 = 0;
            if (j10 >= 0) {
                i iVar = this.f8719a;
                long j12 = -1;
                if (iVar == null) {
                    return -1;
                }
                long j13 = this.f8720b;
                if (j13 - j10 < j10) {
                    while (j13 > j10) {
                        iVar = iVar.f8748g;
                        j13 -= (long) (iVar.f8744c - iVar.f8743b);
                    }
                } else {
                    while (true) {
                        long j14 = ((long) (iVar.f8744c - iVar.f8743b)) + j11;
                        if (j14 >= j10) {
                            break;
                        }
                        iVar = iVar.f8747f;
                        j11 = j14;
                    }
                    j13 = j11;
                }
                byte d10 = dVar.d(0);
                int j15 = dVar.j();
                long j16 = 1 + (this.f8720b - ((long) j15));
                long j17 = j10;
                i iVar2 = iVar;
                long j18 = j13;
                while (j18 < j16) {
                    byte[] bArr2 = iVar2.f8742a;
                    int min = (int) Math.min((long) iVar2.f8744c, (((long) iVar2.f8743b) + j16) - j18);
                    int i10 = (int) ((((long) iVar2.f8743b) + j17) - j18);
                    while (i10 < min) {
                        if (bArr2[i10] == d10) {
                            bArr = bArr2;
                            if (o(iVar2, i10 + 1, dVar, 1, j15)) {
                                return ((long) (i10 - iVar2.f8743b)) + j18;
                            }
                        } else {
                            bArr = bArr2;
                        }
                        i10++;
                        bArr2 = bArr;
                    }
                    j18 += (long) (iVar2.f8744c - iVar2.f8743b);
                    iVar2 = iVar2.f8747f;
                    j17 = j18;
                    j12 = -1;
                }
                return j12;
            }
            throw new IllegalArgumentException("fromIndex < 0");
        }
        throw new IllegalArgumentException("bytes is empty");
    }

    /* renamed from: k0 */
    public a l(String str, int i10, int i11) {
        if (str == null) {
            throw new IllegalArgumentException("string == null");
        } else if (i10 < 0) {
            throw new IllegalArgumentException("beginIndex < 0: " + i10);
        } else if (i11 < i10) {
            throw new IllegalArgumentException("endIndex < beginIndex: " + i11 + " < " + i10);
        } else if (i11 <= str.length()) {
            while (i10 < i11) {
                char charAt = str.charAt(i10);
                if (charAt < 128) {
                    i f02 = f0(1);
                    byte[] bArr = f02.f8742a;
                    int i12 = f02.f8744c - i10;
                    int min = Math.min(i11, 8192 - i12);
                    int i13 = i10 + 1;
                    bArr[i10 + i12] = (byte) charAt;
                    while (i13 < min) {
                        char charAt2 = str.charAt(i13);
                        if (charAt2 >= 128) {
                            break;
                        }
                        bArr[i13 + i12] = (byte) charAt2;
                        i13++;
                    }
                    int i14 = f02.f8744c;
                    int i15 = (i12 + i13) - i14;
                    f02.f8744c = i14 + i15;
                    this.f8720b += (long) i15;
                    i10 = i13;
                } else {
                    if (charAt < 2048) {
                        B((charAt >> 6) | 192);
                        B((charAt & '?') | 128);
                    } else if (charAt < 55296 || charAt > 57343) {
                        B((charAt >> 12) | 224);
                        B(((charAt >> 6) & 63) | 128);
                        B((charAt & '?') | 128);
                    } else {
                        int i16 = i10 + 1;
                        char charAt3 = i16 < i11 ? str.charAt(i16) : 0;
                        if (charAt > 56319 || charAt3 < 56320 || charAt3 > 57343) {
                            B(63);
                            i10 = i16;
                        } else {
                            int i17 = (((charAt & 10239) << 10) | (9215 & charAt3)) + 0;
                            B((i17 >> 18) | 240);
                            B(((i17 >> 12) & 63) | 128);
                            B(((i17 >> 6) & 63) | 128);
                            B((i17 & 63) | 128);
                            i10 += 2;
                        }
                    }
                    i10++;
                }
            }
            return this;
        } else {
            throw new IllegalArgumentException("endIndex > string.length: " + i11 + " > " + str.length());
        }
    }

    public long m(d dVar, long j10) {
        int i10;
        int i11;
        long j11 = 0;
        if (j10 >= 0) {
            i iVar = this.f8719a;
            if (iVar == null) {
                return -1;
            }
            long j12 = this.f8720b;
            if (j12 - j10 < j10) {
                while (j12 > j10) {
                    iVar = iVar.f8748g;
                    j12 -= (long) (iVar.f8744c - iVar.f8743b);
                }
            } else {
                while (true) {
                    long j13 = ((long) (iVar.f8744c - iVar.f8743b)) + j11;
                    if (j13 >= j10) {
                        break;
                    }
                    iVar = iVar.f8747f;
                    j11 = j13;
                }
                j12 = j11;
            }
            if (dVar.j() == 2) {
                byte d10 = dVar.d(0);
                byte d11 = dVar.d(1);
                while (j12 < this.f8720b) {
                    byte[] bArr = iVar.f8742a;
                    i10 = (int) ((((long) iVar.f8743b) + j10) - j12);
                    int i12 = iVar.f8744c;
                    while (i10 < i12) {
                        byte b10 = bArr[i10];
                        if (b10 == d10 || b10 == d11) {
                            i11 = iVar.f8743b;
                        } else {
                            i10++;
                        }
                    }
                    j12 += (long) (iVar.f8744c - iVar.f8743b);
                    iVar = iVar.f8747f;
                    j10 = j12;
                }
                return -1;
            }
            byte[] f10 = dVar.f();
            while (j12 < this.f8720b) {
                byte[] bArr2 = iVar.f8742a;
                int i13 = (int) ((((long) iVar.f8743b) + j10) - j12);
                int i14 = iVar.f8744c;
                while (i10 < i14) {
                    byte b11 = bArr2[i10];
                    int length = f10.length;
                    int i15 = 0;
                    while (i15 < length) {
                        if (b11 == f10[i15]) {
                            i11 = iVar.f8743b;
                        } else {
                            i15++;
                        }
                    }
                    i13 = i10 + 1;
                }
                j12 += (long) (iVar.f8744c - iVar.f8743b);
                iVar = iVar.f8747f;
                j10 = j12;
            }
            return -1;
            return ((long) (i10 - i11)) + j12;
        }
        throw new IllegalArgumentException("fromIndex < 0");
    }

    public final boolean o(i iVar, int i10, d dVar, int i11, int i12) {
        int i13 = iVar.f8744c;
        byte[] bArr = iVar.f8742a;
        while (i11 < i12) {
            if (i10 == i13) {
                i iVar2 = iVar.f8747f;
                byte[] bArr2 = iVar2.f8742a;
                i10 = iVar2.f8743b;
                byte[] bArr3 = bArr2;
                iVar = iVar2;
                i13 = iVar2.f8744c;
                bArr = bArr3;
            }
            if (bArr[i10] != dVar.d(i11)) {
                return false;
            }
            i10++;
            i11++;
        }
        return true;
    }

    public a p() {
        return this;
    }

    public int q(byte[] bArr, int i10, int i11) {
        n.b((long) bArr.length, (long) i10, (long) i11);
        i iVar = this.f8719a;
        if (iVar == null) {
            return -1;
        }
        int min = Math.min(i11, iVar.f8744c - iVar.f8743b);
        System.arraycopy(iVar.f8742a, iVar.f8743b, bArr, i10, min);
        int i12 = iVar.f8743b + min;
        iVar.f8743b = i12;
        this.f8720b -= (long) min;
        if (i12 == iVar.f8744c) {
            this.f8719a = iVar.b();
            j.a(iVar);
        }
        return min;
    }

    public byte[] r() {
        try {
            return y(this.f8720b);
        } catch (EOFException e10) {
            throw new AssertionError(e10);
        }
    }

    public int read(ByteBuffer byteBuffer) {
        i iVar = this.f8719a;
        if (iVar == null) {
            return -1;
        }
        int min = Math.min(byteBuffer.remaining(), iVar.f8744c - iVar.f8743b);
        byteBuffer.put(iVar.f8742a, iVar.f8743b, min);
        int i10 = iVar.f8743b + min;
        iVar.f8743b = i10;
        this.f8720b -= (long) min;
        if (i10 == iVar.f8744c) {
            this.f8719a = iVar.b();
            j.a(iVar);
        }
        return min;
    }

    public String toString() {
        return d0().toString();
    }

    public boolean v(long j10) {
        return this.f8720b >= j10;
    }

    public int write(ByteBuffer byteBuffer) {
        if (byteBuffer != null) {
            int remaining = byteBuffer.remaining();
            int i10 = remaining;
            while (i10 > 0) {
                i f02 = f0(1);
                int min = Math.min(i10, 8192 - f02.f8744c);
                byteBuffer.get(f02.f8742a, f02.f8744c, min);
                i10 -= min;
                f02.f8744c += min;
            }
            this.f8720b += (long) remaining;
            return remaining;
        }
        throw new IllegalArgumentException("source == null");
    }

    public byte[] y(long j10) {
        n.b(this.f8720b, 0, j10);
        if (j10 <= 2147483647L) {
            byte[] bArr = new byte[((int) j10)];
            F(bArr);
            return bArr;
        }
        throw new IllegalArgumentException("byteCount > Integer.MAX_VALUE: " + j10);
    }
}
