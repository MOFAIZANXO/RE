package n2;

public interface e {
    Object a(b bVar);
}
