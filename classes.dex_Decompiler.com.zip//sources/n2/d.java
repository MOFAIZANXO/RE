package n2;

public class d {

    /* renamed from: a  reason: collision with root package name */
    public float f8427a;

    /* renamed from: b  reason: collision with root package name */
    public float f8428b;

    public d(float f10, float f11) {
        this.f8427a = f10;
        this.f8428b = f11;
    }

    public boolean a(float f10, float f11) {
        return this.f8427a == f10 && this.f8428b == f11;
    }

    public float b() {
        return this.f8427a;
    }

    public float c() {
        return this.f8428b;
    }

    public void d(float f10, float f11) {
        this.f8427a = f10;
        this.f8428b = f11;
    }

    public String toString() {
        return b() + "x" + c();
    }

    public d() {
        this(1.0f, 1.0f);
    }
}
