package n2;

public class b {

    /* renamed from: a  reason: collision with root package name */
    public float f8417a;

    /* renamed from: b  reason: collision with root package name */
    public float f8418b;

    /* renamed from: c  reason: collision with root package name */
    public Object f8419c;

    /* renamed from: d  reason: collision with root package name */
    public Object f8420d;

    /* renamed from: e  reason: collision with root package name */
    public float f8421e;

    /* renamed from: f  reason: collision with root package name */
    public float f8422f;

    /* renamed from: g  reason: collision with root package name */
    public float f8423g;

    public float a() {
        return this.f8418b;
    }

    public Object b() {
        return this.f8420d;
    }

    public float c() {
        return this.f8422f;
    }

    public float d() {
        return this.f8421e;
    }

    public float e() {
        return this.f8423g;
    }

    public float f() {
        return this.f8417a;
    }

    public Object g() {
        return this.f8419c;
    }

    public b h(float f10, float f11, Object obj, Object obj2, float f12, float f13, float f14) {
        this.f8417a = f10;
        this.f8418b = f11;
        this.f8419c = obj;
        this.f8420d = obj2;
        this.f8421e = f12;
        this.f8422f = f13;
        this.f8423g = f14;
        return this;
    }
}
