package n2;

import android.graphics.PointF;
import android.view.animation.Interpolator;
import com.airbnb.lottie.h;

public class a {

    /* renamed from: a  reason: collision with root package name */
    public final h f8401a;

    /* renamed from: b  reason: collision with root package name */
    public final Object f8402b;

    /* renamed from: c  reason: collision with root package name */
    public Object f8403c;

    /* renamed from: d  reason: collision with root package name */
    public final Interpolator f8404d;

    /* renamed from: e  reason: collision with root package name */
    public final Interpolator f8405e;

    /* renamed from: f  reason: collision with root package name */
    public final Interpolator f8406f;

    /* renamed from: g  reason: collision with root package name */
    public final float f8407g;

    /* renamed from: h  reason: collision with root package name */
    public Float f8408h;

    /* renamed from: i  reason: collision with root package name */
    public float f8409i;

    /* renamed from: j  reason: collision with root package name */
    public float f8410j;

    /* renamed from: k  reason: collision with root package name */
    public int f8411k;

    /* renamed from: l  reason: collision with root package name */
    public int f8412l;

    /* renamed from: m  reason: collision with root package name */
    public float f8413m;

    /* renamed from: n  reason: collision with root package name */
    public float f8414n;

    /* renamed from: o  reason: collision with root package name */
    public PointF f8415o;

    /* renamed from: p  reason: collision with root package name */
    public PointF f8416p;

    public a(h hVar, Object obj, Object obj2, Interpolator interpolator, float f10, Float f11) {
        this.f8409i = -3987645.8f;
        this.f8410j = -3987645.8f;
        this.f8411k = 784923401;
        this.f8412l = 784923401;
        this.f8413m = Float.MIN_VALUE;
        this.f8414n = Float.MIN_VALUE;
        this.f8415o = null;
        this.f8416p = null;
        this.f8401a = hVar;
        this.f8402b = obj;
        this.f8403c = obj2;
        this.f8404d = interpolator;
        this.f8405e = null;
        this.f8406f = null;
        this.f8407g = f10;
        this.f8408h = f11;
    }

    public boolean a(float f10) {
        return f10 >= e() && f10 < b();
    }

    public float b() {
        if (this.f8401a == null) {
            return 1.0f;
        }
        if (this.f8414n == Float.MIN_VALUE) {
            if (this.f8408h == null) {
                this.f8414n = 1.0f;
            } else {
                this.f8414n = e() + ((this.f8408h.floatValue() - this.f8407g) / this.f8401a.e());
            }
        }
        return this.f8414n;
    }

    public float c() {
        if (this.f8410j == -3987645.8f) {
            this.f8410j = ((Float) this.f8403c).floatValue();
        }
        return this.f8410j;
    }

    public int d() {
        if (this.f8412l == 784923401) {
            this.f8412l = ((Integer) this.f8403c).intValue();
        }
        return this.f8412l;
    }

    public float e() {
        h hVar = this.f8401a;
        if (hVar == null) {
            return 0.0f;
        }
        if (this.f8413m == Float.MIN_VALUE) {
            this.f8413m = (this.f8407g - hVar.p()) / this.f8401a.e();
        }
        return this.f8413m;
    }

    public float f() {
        if (this.f8409i == -3987645.8f) {
            this.f8409i = ((Float) this.f8402b).floatValue();
        }
        return this.f8409i;
    }

    public int g() {
        if (this.f8411k == 784923401) {
            this.f8411k = ((Integer) this.f8402b).intValue();
        }
        return this.f8411k;
    }

    public boolean h() {
        return this.f8404d == null && this.f8405e == null && this.f8406f == null;
    }

    public String toString() {
        return "Keyframe{startValue=" + this.f8402b + ", endValue=" + this.f8403c + ", startFrame=" + this.f8407g + ", endFrame=" + this.f8408h + ", interpolator=" + this.f8404d + '}';
    }

    public a(h hVar, Object obj, Object obj2, Interpolator interpolator, Interpolator interpolator2, float f10, Float f11) {
        this.f8409i = -3987645.8f;
        this.f8410j = -3987645.8f;
        this.f8411k = 784923401;
        this.f8412l = 784923401;
        this.f8413m = Float.MIN_VALUE;
        this.f8414n = Float.MIN_VALUE;
        this.f8415o = null;
        this.f8416p = null;
        this.f8401a = hVar;
        this.f8402b = obj;
        this.f8403c = obj2;
        this.f8404d = null;
        this.f8405e = interpolator;
        this.f8406f = interpolator2;
        this.f8407g = f10;
        this.f8408h = f11;
    }

    public a(h hVar, Object obj, Object obj2, Interpolator interpolator, Interpolator interpolator2, Interpolator interpolator3, float f10, Float f11) {
        this.f8409i = -3987645.8f;
        this.f8410j = -3987645.8f;
        this.f8411k = 784923401;
        this.f8412l = 784923401;
        this.f8413m = Float.MIN_VALUE;
        this.f8414n = Float.MIN_VALUE;
        this.f8415o = null;
        this.f8416p = null;
        this.f8401a = hVar;
        this.f8402b = obj;
        this.f8403c = obj2;
        this.f8404d = interpolator;
        this.f8405e = interpolator2;
        this.f8406f = interpolator3;
        this.f8407g = f10;
        this.f8408h = f11;
    }

    public a(Object obj) {
        this.f8409i = -3987645.8f;
        this.f8410j = -3987645.8f;
        this.f8411k = 784923401;
        this.f8412l = 784923401;
        this.f8413m = Float.MIN_VALUE;
        this.f8414n = Float.MIN_VALUE;
        this.f8415o = null;
        this.f8416p = null;
        this.f8401a = null;
        this.f8402b = obj;
        this.f8403c = obj;
        this.f8404d = null;
        this.f8405e = null;
        this.f8406f = null;
        this.f8407g = Float.MIN_VALUE;
        this.f8408h = Float.valueOf(Float.MAX_VALUE);
    }
}
