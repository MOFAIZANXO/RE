package n2;

import d2.a;

public class c {

    /* renamed from: a  reason: collision with root package name */
    public final b f8424a;

    /* renamed from: b  reason: collision with root package name */
    public a f8425b;

    /* renamed from: c  reason: collision with root package name */
    public Object f8426c;

    public c() {
        this.f8424a = new b();
        this.f8426c = null;
    }

    public Object a(b bVar) {
        return this.f8426c;
    }

    public final Object b(float f10, float f11, Object obj, Object obj2, float f12, float f13, float f14) {
        return a(this.f8424a.h(f10, f11, obj, obj2, f12, f13, f14));
    }

    public final void c(a aVar) {
        this.f8425b = aVar;
    }

    public c(Object obj) {
        this.f8424a = new b();
        this.f8426c = obj;
    }
}
