package o5;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.appcompat.widget.SeslSwitchBar;
import androidx.appcompat.widget.SeslToggleSwitch;
import androidx.appcompat.widget.SwitchCompat;
import androidx.fragment.app.Fragment;
import com.airbnb.lottie.LottieAnimationView;
import com.samsung.android.sm.core.data.PkgUid;
import com.samsung.android.util.SemLog;
import v5.k;
import w6.b0;
import w6.h;
import w6.i0;

public class b extends Fragment implements SeslSwitchBar.OnSwitchChangeListener, SeslToggleSwitch.OnBeforeCheckedChangeListener {

    /* renamed from: a  reason: collision with root package name */
    public Context f8625a;

    /* renamed from: b  reason: collision with root package name */
    public SeslSwitchBar f8626b;

    /* renamed from: f  reason: collision with root package name */
    public TextView f8627f;

    /* renamed from: g  reason: collision with root package name */
    public boolean f8628g;

    /* renamed from: h  reason: collision with root package name */
    public String f8629h;

    /* renamed from: i  reason: collision with root package name */
    public LottieAnimationView f8630i;

    /* access modifiers changed from: private */
    public /* synthetic */ void B(View view) {
        try {
            Intent intent = new Intent("com.samsung.android.app.routines.action.SETTINGS");
            intent.setPackage("com.samsung.android.app.routines");
            intent.setFlags(268435456);
            startActivity(intent);
            d7.b.c(this.f8629h, getString(2131952110));
        } catch (ActivityNotFoundException e10) {
            Log.e("FastWirelessFragment", "Unable to start activity : " + e10.getMessage());
        }
    }

    public final void A(View view) {
        SemLog.d("FastWirelessFragment", "initSwitchBar");
        SeslSwitchBar seslSwitchBar = (SeslSwitchBar) view.findViewById(2131362249);
        this.f8626b = seslSwitchBar;
        seslSwitchBar.setEnabled(true);
        this.f8626b.setChecked(k.o(this.f8625a));
        this.f8626b.show();
        this.f8626b.addOnSwitchChangeListener(this);
        this.f8626b.getSwitch().setOnBeforeCheckedChangeListener(this);
    }

    public final void C() {
        b0.c(this.f8627f);
        this.f8627f.setText(h.i() ? 2131952305 : 2131952306);
        this.f8627f.setOnClickListener(new a(this));
        this.f8627f.setMovementMethod(LinkMovementMethod.getInstance());
    }

    public void onAttach(Context context) {
        super.onAttach(context);
        this.f8625a = context;
    }

    public boolean onBeforeCheckedChanged(SeslToggleSwitch seslToggleSwitch, boolean z10) {
        return !k.a("wireless_fast_charging");
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f8629h = getString(2131952748);
        if (bundle != null) {
            this.f8628g = bundle.getBoolean("IsToastShown", false);
        }
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        View inflate = layoutInflater.inflate(2131558509, viewGroup, false);
        z(inflate);
        A(inflate);
        return inflate;
    }

    public void onResume() {
        super.onResume();
        d7.b.g(this.f8625a.getString(2131952748));
    }

    public void onSaveInstanceState(Bundle bundle) {
        bundle.putBoolean("IsToastShown", this.f8628g);
        super.onSaveInstanceState(bundle);
    }

    public void onSwitchChanged(SwitchCompat switchCompat, boolean z10) {
        Log.i("FastWirelessFragment", "onSwitchChanged : " + z10);
        if (switchCompat.getId() == 2131362786) {
            this.f8626b.setTextViewLabel(z10);
            k.B(this.f8625a, z10);
            d7.b.d(this.f8629h, getString(2131952111), z10 ? 1 : 0);
            return;
        }
        throw new UnsupportedOperationException("undefined id : " + switchCompat.getId());
    }

    public void onViewStateRestored(Bundle bundle) {
        super.onViewStateRestored(bundle);
        this.f8630i.setAnimation(c.b(this.f8625a));
    }

    public final void z(View view) {
        SemLog.d("FastWirelessFragment", "initAllViews");
        TextView textView = (TextView) view.findViewById(2131362243);
        if (a7.b.e("screen.res.tablet")) {
            textView.setText(getString(2131952308));
        } else {
            textView.setText(getString(2131952307));
        }
        this.f8627f = (TextView) view.findViewById(2131362245);
        TextView textView2 = (TextView) view.findViewById(2131362247);
        if (!a7.b.e("user.owner") || !i0.h(this.f8625a, new PkgUid("com.samsung.android.app.routines"))) {
            this.f8627f.setVisibility(8);
            textView2.setVisibility(8);
        } else {
            C();
            this.f8627f.setVisibility(0);
            textView2.setVisibility(0);
        }
        this.f8630i = (LottieAnimationView) view.findViewById(2131362404);
    }
}
