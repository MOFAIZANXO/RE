package o5;

import android.view.View;

public final /* synthetic */ class a implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ b f8624a;

    public /* synthetic */ a(b bVar) {
        this.f8624a = bVar;
    }

    public final void onClick(View view) {
        this.f8624a.B(view);
    }
}
