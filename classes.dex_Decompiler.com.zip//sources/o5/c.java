package o5;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import w6.k;
import w6.v;

public class c {

    /* renamed from: a  reason: collision with root package name */
    public final Context f8631a;

    public c(Context context) {
        this.f8631a = context;
    }

    public static String a() {
        return k.k() ? "Wireless_charging_setting_help_fold_dark.json" : k.x() ? k.h() ? "Wireless_charging_setting_help_B5_dark.json" : "Wireless_charging_setting_help_flip_dark.json" : "Wireless_charging_setting_help_default_dark.json";
    }

    public static String b(Context context) {
        return v.c(context) ? a() : c();
    }

    public static String c() {
        return k.k() ? "Wireless_charging_setting_help_fold_light.json" : k.x() ? k.h() ? "Wireless_charging_setting_help_B5_light.json" : "Wireless_charging_setting_help_flip_light.json" : "Wireless_charging_setting_help_default_light.json";
    }

    public void d(boolean z10) {
        Intent intent = new Intent();
        intent.setAction("com.samsung.android.sm.ACTION_FAST_WIRELESS_CHARGING_CONTROL");
        intent.putExtra("write", z10);
        this.f8631a.sendBroadcast(intent);
        Log.d("FastWirelessAlarmUtils", "sendBroadcastFastWirelessChargingControl:" + z10);
    }
}
