package d5;

import android.content.Context;
import android.util.Log;
import com.samsung.android.sm.anomaly.data.AnomalyAppData;
import com.samsung.android.sm.battery.entity.BatteryIssueEntity;
import com.samsung.android.sm.core.data.AppData;
import com.samsung.android.sm.core.data.PkgUid;
import g6.b;
import g6.h;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import v5.p;
import w5.o;

public class a implements b {

    /* renamed from: d  reason: collision with root package name */
    public final Context f5598d;

    public a(Context context) {
        this.f5598d = context;
    }

    public List a(String str) {
        return d(new t4.b().c(this.f5598d, str));
    }

    public void b(List list) {
        n6.b.b(this.f5598d, 2000);
        List e10 = e(list);
        ArrayList arrayList = new ArrayList();
        arrayList.addAll(e10);
        o.b().e(this.f5598d, arrayList, 0, true, h.f6517a[4]);
    }

    public int c(String str) {
        return a(str).size();
    }

    public List d(List list) {
        ArrayList arrayList = new ArrayList();
        if (list != null) {
            Iterator it = list.iterator();
            while (it.hasNext()) {
                AnomalyAppData anomalyAppData = (AnomalyAppData) it.next();
                AppData appData = new AppData(anomalyAppData.z());
                appData.O(anomalyAppData.u());
                appData.V(p.d(anomalyAppData.H()));
                appData.J(anomalyAppData.X());
                arrayList.add(appData);
            }
        }
        return arrayList;
    }

    public final List e(List list) {
        ArrayList arrayList = new ArrayList();
        Iterator it = list.iterator();
        while (it.hasNext()) {
            PkgUid pkgUid = (PkgUid) it.next();
            BatteryIssueEntity batteryIssueEntity = new BatteryIssueEntity();
            int c10 = p.b().c(this.f5598d, pkgUid.b(), pkgUid.e());
            Log.i("BridgeInBatteryImpl", "userId=" + pkgUid.e() + " uid=" + c10 + " p:" + pkgUid.b());
            if (c10 >= 0) {
                batteryIssueEntity.e(pkgUid.b());
                batteryIssueEntity.s(c10);
                arrayList.add(batteryIssueEntity);
            }
        }
        return arrayList;
    }
}
