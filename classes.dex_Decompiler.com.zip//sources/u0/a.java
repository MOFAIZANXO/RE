package u0;

import android.view.accessibility.AccessibilityManager;
import java.lang.reflect.Method;

public abstract class a {

    /* renamed from: a  reason: collision with root package name */
    public static String f10047a = "android.view.accessibility.AccessibilityManager";

    public static boolean a(AccessibilityManager accessibilityManager, boolean z10) {
        Method f10 = h0.a.f(f10047a, "semIsScreenReaderEnabled", new Class[0]);
        return (f10 == null || accessibilityManager == null) ? z10 : ((Boolean) h0.a.k(accessibilityManager, f10, new Object[0])).booleanValue();
    }
}
