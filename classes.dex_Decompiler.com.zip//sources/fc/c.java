package fc;

import ac.l;
import java.util.Iterator;
import java.util.NoSuchElementException;

public final class c implements d {

    /* renamed from: a  reason: collision with root package name */
    public final ac.a f6407a;

    /* renamed from: b  reason: collision with root package name */
    public final l f6408b;

    public static final class a implements Iterator {

        /* renamed from: a  reason: collision with root package name */
        public Object f6409a;

        /* renamed from: b  reason: collision with root package name */
        public int f6410b = -2;

        /* renamed from: f  reason: collision with root package name */
        public final /* synthetic */ c f6411f;

        public a(c cVar) {
            this.f6411f = cVar;
        }

        public final void a() {
            Object obj;
            if (this.f6410b == -2) {
                obj = this.f6411f.f6407a.invoke();
            } else {
                l b10 = this.f6411f.f6408b;
                Object obj2 = this.f6409a;
                kotlin.jvm.internal.l.b(obj2);
                obj = b10.invoke(obj2);
            }
            this.f6409a = obj;
            this.f6410b = obj == null ? 0 : 1;
        }

        public boolean hasNext() {
            if (this.f6410b < 0) {
                a();
            }
            return this.f6410b == 1;
        }

        public Object next() {
            if (this.f6410b < 0) {
                a();
            }
            if (this.f6410b != 0) {
                Object obj = this.f6409a;
                kotlin.jvm.internal.l.c(obj, "null cannot be cast to non-null type T of kotlin.sequences.GeneratorSequence");
                this.f6410b = -1;
                return obj;
            }
            throw new NoSuchElementException();
        }

        public void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }
    }

    public c(ac.a aVar, l lVar) {
        kotlin.jvm.internal.l.e(aVar, "getInitialValue");
        kotlin.jvm.internal.l.e(lVar, "getNextValue");
        this.f6407a = aVar;
        this.f6408b = lVar;
    }

    public Iterator iterator() {
        return new a(this);
    }
}
