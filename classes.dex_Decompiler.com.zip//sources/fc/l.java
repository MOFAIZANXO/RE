package fc;

import java.util.Iterator;

public final class l implements d {

    /* renamed from: a  reason: collision with root package name */
    public final d f6420a;

    /* renamed from: b  reason: collision with root package name */
    public final ac.l f6421b;

    public static final class a implements Iterator {

        /* renamed from: a  reason: collision with root package name */
        public final Iterator f6422a;

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ l f6423b;

        public a(l lVar) {
            this.f6423b = lVar;
            this.f6422a = lVar.f6420a.iterator();
        }

        public boolean hasNext() {
            return this.f6422a.hasNext();
        }

        public Object next() {
            return this.f6423b.f6421b.invoke(this.f6422a.next());
        }

        public void remove() {
            throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }
    }

    public l(d dVar, ac.l lVar) {
        kotlin.jvm.internal.l.e(dVar, "sequence");
        kotlin.jvm.internal.l.e(lVar, "transformer");
        this.f6420a = dVar;
        this.f6421b = lVar;
    }

    public Iterator iterator() {
        return new a(this);
    }
}
