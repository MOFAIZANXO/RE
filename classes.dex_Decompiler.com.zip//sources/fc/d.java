package fc;

import java.util.Iterator;

public interface d {
    Iterator iterator();
}
