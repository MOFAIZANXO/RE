package fc;

import ac.p;
import java.util.Iterator;
import kotlin.jvm.internal.l;
import tb.b;

public abstract class g {

    public static final class a implements d {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ p f6416a;

        public a(p pVar) {
            this.f6416a = pVar;
        }

        public Iterator iterator() {
            return g.a(this.f6416a);
        }
    }

    public static final Iterator a(p pVar) {
        l.e(pVar, "block");
        e eVar = new e();
        eVar.h(b.a(pVar, eVar, eVar));
        return eVar;
    }

    public static final d b(p pVar) {
        l.e(pVar, "block");
        return new a(pVar);
    }
}
