package fc;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import kotlin.jvm.internal.l;
import rb.m;

public abstract class k extends j {

    public static final class a implements Iterable {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ d f6419a;

        public a(d dVar) {
            this.f6419a = dVar;
        }

        public Iterator iterator() {
            return this.f6419a.iterator();
        }
    }

    public static final Iterable f(d dVar) {
        l.e(dVar, "<this>");
        return new a(dVar);
    }

    public static final d g(d dVar, ac.l lVar) {
        l.e(dVar, "<this>");
        l.e(lVar, "transform");
        return new l(dVar, lVar);
    }

    public static final Collection h(d dVar, Collection collection) {
        l.e(dVar, "<this>");
        l.e(collection, "destination");
        for (Object add : dVar) {
            collection.add(add);
        }
        return collection;
    }

    public static final List i(d dVar) {
        l.e(dVar, "<this>");
        return m.h(j(dVar));
    }

    public static final List j(d dVar) {
        l.e(dVar, "<this>");
        return (List) h(dVar, new ArrayList());
    }
}
