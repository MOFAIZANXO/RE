package fc;

public abstract class j extends i {
}
