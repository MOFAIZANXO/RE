package fc;

public abstract class h extends g {
}
