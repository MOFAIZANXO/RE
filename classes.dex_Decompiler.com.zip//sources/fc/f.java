package fc;

import java.util.Iterator;
import qb.r;
import sb.d;
import tb.c;

public abstract class f {
    public abstract Object a(Object obj, d dVar);

    public final Object c(d dVar, d dVar2) {
        Object d10 = d(dVar.iterator(), dVar2);
        return d10 == c.c() ? d10 : r.f9409a;
    }

    public abstract Object d(Iterator it, d dVar);
}
