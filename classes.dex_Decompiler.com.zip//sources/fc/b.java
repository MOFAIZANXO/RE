package fc;

import java.util.Iterator;
import rb.v;

public final class b implements d {

    /* renamed from: a  reason: collision with root package name */
    public static final b f6406a = new b();

    public Iterator iterator() {
        return v.f9630a;
    }
}
