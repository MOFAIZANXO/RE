package fc;

import java.util.Iterator;
import java.util.NoSuchElementException;
import kotlin.jvm.internal.l;
import qb.j;
import qb.k;
import qb.r;
import sb.d;
import sb.g;
import tb.c;
import ub.h;

public final class e extends f implements Iterator, d {

    /* renamed from: a  reason: collision with root package name */
    public int f6412a;

    /* renamed from: b  reason: collision with root package name */
    public Object f6413b;

    /* renamed from: f  reason: collision with root package name */
    public Iterator f6414f;

    /* renamed from: g  reason: collision with root package name */
    public d f6415g;

    public Object a(Object obj, d dVar) {
        this.f6413b = obj;
        this.f6412a = 3;
        this.f6415g = dVar;
        Object c10 = c.c();
        if (c10 == c.c()) {
            h.c(dVar);
        }
        return c10 == c.c() ? c10 : r.f9409a;
    }

    public Object d(Iterator it, d dVar) {
        if (!it.hasNext()) {
            return r.f9409a;
        }
        this.f6414f = it;
        this.f6412a = 2;
        this.f6415g = dVar;
        Object c10 = c.c();
        if (c10 == c.c()) {
            h.c(dVar);
        }
        return c10 == c.c() ? c10 : r.f9409a;
    }

    public final Throwable e() {
        int i10 = this.f6412a;
        if (i10 == 4) {
            return new NoSuchElementException();
        }
        if (i10 == 5) {
            return new IllegalStateException("Iterator has failed.");
        }
        return new IllegalStateException("Unexpected state of the iterator: " + this.f6412a);
    }

    public final Object f() {
        if (hasNext()) {
            return next();
        }
        throw new NoSuchElementException();
    }

    public g getContext() {
        return sb.h.f9792a;
    }

    public final void h(d dVar) {
        this.f6415g = dVar;
    }

    public boolean hasNext() {
        while (true) {
            int i10 = this.f6412a;
            if (i10 != 0) {
                if (i10 == 1) {
                    Iterator it = this.f6414f;
                    l.b(it);
                    if (it.hasNext()) {
                        this.f6412a = 2;
                        return true;
                    }
                    this.f6414f = null;
                } else if (i10 == 2 || i10 == 3) {
                    return true;
                } else {
                    if (i10 == 4) {
                        return false;
                    }
                    throw e();
                }
            }
            this.f6412a = 5;
            d dVar = this.f6415g;
            l.b(dVar);
            this.f6415g = null;
            j.a aVar = j.f9395a;
            dVar.resumeWith(j.a(r.f9409a));
        }
    }

    public Object next() {
        int i10 = this.f6412a;
        if (i10 == 0 || i10 == 1) {
            return f();
        }
        if (i10 == 2) {
            this.f6412a = 1;
            Iterator it = this.f6414f;
            l.b(it);
            return it.next();
        } else if (i10 == 3) {
            this.f6412a = 0;
            Object obj = this.f6413b;
            this.f6413b = null;
            return obj;
        } else {
            throw e();
        }
    }

    public void remove() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    public void resumeWith(Object obj) {
        k.b(obj);
        this.f6412a = 4;
    }
}
