package fc;

import java.util.Iterator;
import kotlin.jvm.internal.l;
import kotlin.jvm.internal.m;

public abstract class i extends h {

    public static final class a implements d {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ Iterator f6417a;

        public a(Iterator it) {
            this.f6417a = it;
        }

        public Iterator iterator() {
            return this.f6417a;
        }
    }

    public static final class b extends m implements ac.a {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ Object f6418a;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public b(Object obj) {
            super(0);
            this.f6418a = obj;
        }

        public final Object invoke() {
            return this.f6418a;
        }
    }

    public static final d c(Iterator it) {
        l.e(it, "<this>");
        return d(new a(it));
    }

    public static final d d(d dVar) {
        l.e(dVar, "<this>");
        return dVar instanceof a ? dVar : new a(dVar);
    }

    public static final d e(Object obj, ac.l lVar) {
        l.e(lVar, "nextFunction");
        return obj == null ? b.f6406a : new c(new b(obj), lVar);
    }
}
