package fc;

import java.util.Iterator;
import java.util.concurrent.atomic.AtomicReference;
import kotlin.jvm.internal.l;

public final class a implements d {

    /* renamed from: a  reason: collision with root package name */
    public final AtomicReference f6405a;

    public a(d dVar) {
        l.e(dVar, "sequence");
        this.f6405a = new AtomicReference(dVar);
    }

    public Iterator iterator() {
        d dVar = (d) this.f6405a.getAndSet((Object) null);
        if (dVar != null) {
            return dVar.iterator();
        }
        throw new IllegalStateException("This sequence can be consumed only once.");
    }
}
