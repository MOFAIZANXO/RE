package za;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Queue;
import java.util.TimeZone;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import ya.c;
import ya.f;

public class b extends ya.a {

    /* renamed from: e  reason: collision with root package name */
    public final ua.a f11530e;

    public class a extends jb.a {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ int f11531a;

        public a(int i10) {
            this.f11531a = i10;
        }

        public void a(int i10, String str, String str2, String str3) {
            bb.a f10 = b.this.f11305c;
            long parseLong = Long.parseLong(str);
            c cVar = c.DEVICE;
            if (!str3.equals(cVar.a())) {
                cVar = c.UIX;
            }
            f10.g(parseLong, str2, cVar);
            va.b.n(b.this.f11303a, this.f11531a, str2.getBytes().length * -1);
        }

        public void b(int i10, String str, String str2, String str3) {
        }
    }

    public b(Context context, ra.c cVar) {
        super(context, cVar);
        this.f11530e = ua.a.b(context);
    }

    /* JADX WARNING: Removed duplicated region for block: B:12:0x0066 A[LOOP:0: B:12:0x0066->B:15:0x0076, LOOP_START, PHI: r7 
      PHI: (r7v4 int) = (r7v2 int), (r7v7 int) binds: [B:10:0x0059, B:15:0x0076] A[DONT_GENERATE, DONT_INLINE]] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public int a(java.util.Map r7) {
        /*
            r6 = this;
            int r0 = r6.j()
            int r1 = r6.h(r0)
            if (r1 == 0) goto L_0x0021
            r6.c(r7)
            r7 = -6
            if (r1 != r7) goto L_0x0020
            android.content.Context r7 = r6.f11303a
            ra.c r0 = r6.f11304b
            jb.c r2 = r6.f11306d
            ua.a r3 = r6.f11530e
            va.b.l(r7, r0, r2, r3)
            bb.a r6 = r6.f11305c
            r6.a()
        L_0x0020:
            return r1
        L_0x0021:
            za.b$a r1 = new za.b$a
            r1.<init>(r0)
            ya.f r2 = new ya.f
            java.lang.String r3 = "ts"
            java.lang.Object r3 = r7.get(r3)
            java.lang.String r3 = (java.lang.String) r3
            long r3 = java.lang.Long.parseLong(r3)
            java.util.Map r5 = r6.e(r7)
            java.lang.String r5 = r6.d(r5)
            ya.c r7 = r6.b(r7)
            r2.<init>(r3, r5, r7)
            int r7 = r6.k(r0, r2, r1)
            r2 = -1
            if (r7 != r2) goto L_0x004b
            return r7
        L_0x004b:
            bb.a r3 = r6.f11305c
            r4 = 200(0xc8, float:2.8E-43)
            java.util.Queue r3 = r3.e(r4)
            bb.a r4 = r6.f11305c
            boolean r4 = r4.i()
            if (r4 == 0) goto L_0x0066
            ya.c r2 = ya.c.UIX
            r6.i(r0, r2, r3, r1)
            ya.c r2 = ya.c.DEVICE
            r6.i(r0, r2, r3, r1)
            goto L_0x0078
        L_0x0066:
            boolean r4 = r3.isEmpty()
            if (r4 != 0) goto L_0x0078
            java.lang.Object r7 = r3.poll()
            ya.f r7 = (ya.f) r7
            int r7 = r6.k(r0, r7, r1)
            if (r7 != r2) goto L_0x0066
        L_0x0078:
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: za.b.a(java.util.Map):int");
    }

    public Map e(Map map) {
        map.put("la", this.f11530e.e());
        if (!TextUtils.isEmpty(this.f11530e.f())) {
            map.put("mcc", this.f11530e.f());
        }
        if (!TextUtils.isEmpty(this.f11530e.g())) {
            map.put("mnc", this.f11530e.g());
        }
        map.put("dm", this.f11530e.c());
        map.put("auid", this.f11304b.d());
        map.put("do", this.f11530e.a());
        map.put("av", ib.a.b(this.f11303a));
        map.put("uv", this.f11304b.h());
        map.put("v", ra.b.f9596b);
        map.put("at", String.valueOf(this.f11304b.b()));
        map.put("fv", this.f11530e.d());
        map.put("tid", this.f11304b.f());
        map.put("tz", String.valueOf(TimeUnit.MILLISECONDS.toMinutes((long) TimeZone.getDefault().getRawOffset())));
        return map;
    }

    public final int h(int i10) {
        if (i10 == -4) {
            gb.c.b("DLS Sender", "Network unavailable.");
            return -4;
        } else if (!va.b.h(this.f11303a)) {
            return 0;
        } else {
            gb.c.b("DLS Sender", "policy expired. request policy");
            return -6;
        }
    }

    public final void i(int i10, c cVar, Queue queue, jb.a aVar) {
        ArrayList arrayList = new ArrayList();
        Iterator it = queue.iterator();
        while (it.hasNext()) {
            LinkedBlockingQueue linkedBlockingQueue = new LinkedBlockingQueue();
            int min = Math.min(51200, va.b.d(this.f11303a, i10));
            int i11 = 0;
            while (it.hasNext()) {
                f fVar = (f) it.next();
                if (fVar.d() == cVar) {
                    if (fVar.a().getBytes().length + i11 > min) {
                        break;
                    }
                    i11 += fVar.a().getBytes().length;
                    linkedBlockingQueue.add(fVar);
                    it.remove();
                    arrayList.add(fVar.b());
                    if (queue.isEmpty()) {
                        this.f11305c.k(arrayList);
                        queue = this.f11305c.e(200);
                        it = queue.iterator();
                    }
                }
            }
            if (!linkedBlockingQueue.isEmpty()) {
                this.f11305c.k(arrayList);
                l(i10, cVar, linkedBlockingQueue, i11, aVar);
                gb.c.b("DLSLogSender", "send packet : num(" + linkedBlockingQueue.size() + ") size(" + i11 + ")");
            } else {
                return;
            }
        }
    }

    public final int j() {
        NetworkInfo activeNetworkInfo = ((ConnectivityManager) this.f11303a.getSystemService("connectivity")).getActiveNetworkInfo();
        if (activeNetworkInfo == null || !activeNetworkInfo.isConnected()) {
            return -4;
        }
        return activeNetworkInfo.getType();
    }

    public final int k(int i10, f fVar, jb.a aVar) {
        if (fVar == null) {
            return -100;
        }
        int length = fVar.a().getBytes().length;
        int g10 = va.b.g(this.f11303a, i10, length);
        if (g10 != 0) {
            return g10;
        }
        va.b.n(this.f11303a, i10, length);
        this.f11306d.a(new a(fVar, this.f11304b.f(), aVar));
        return 0;
    }

    public final void l(int i10, c cVar, Queue queue, int i11, jb.a aVar) {
        va.b.n(this.f11303a, i10, i11);
        this.f11306d.a(new a(cVar, queue, this.f11304b.f(), aVar));
    }
}
