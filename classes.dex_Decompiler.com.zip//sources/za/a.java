package za;

import android.net.Uri;
import android.text.TextUtils;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Iterator;
import java.util.Queue;
import java.util.zip.GZIPOutputStream;
import javax.net.ssl.HttpsURLConnection;
import jb.b;
import org.json.JSONObject;
import ya.c;
import ya.f;

public class a implements b {

    /* renamed from: h  reason: collision with root package name */
    public static final ta.a f11521h = ta.a.SEND_LOG;

    /* renamed from: i  reason: collision with root package name */
    public static final ta.a f11522i = ta.a.SEND_BUFFERED_LOG;

    /* renamed from: a  reason: collision with root package name */
    public final String f11523a;

    /* renamed from: b  reason: collision with root package name */
    public final c f11524b;

    /* renamed from: c  reason: collision with root package name */
    public final jb.a f11525c;

    /* renamed from: d  reason: collision with root package name */
    public Queue f11526d;

    /* renamed from: e  reason: collision with root package name */
    public f f11527e;

    /* renamed from: f  reason: collision with root package name */
    public HttpsURLConnection f11528f;

    /* renamed from: g  reason: collision with root package name */
    public Boolean f11529g;

    public a(f fVar, String str, jb.a aVar) {
        this.f11528f = null;
        this.f11529g = Boolean.FALSE;
        this.f11527e = fVar;
        this.f11523a = str;
        this.f11525c = aVar;
        this.f11524b = fVar.d();
    }

    public int a() {
        BufferedReader bufferedReader;
        Exception e10;
        int i10;
        try {
            int responseCode = this.f11528f.getResponseCode();
            bufferedReader = new BufferedReader(new InputStreamReader(this.f11528f.getInputStream()));
            try {
                String string = new JSONObject(bufferedReader.readLine()).getString("rc");
                if (responseCode == 200) {
                    if (string.equalsIgnoreCase("1000")) {
                        gb.c.a("[DLS Sender] send result success : " + responseCode + " " + string);
                        i10 = 1;
                        b(responseCode, string);
                        c(bufferedReader);
                        return i10;
                    }
                }
                gb.c.a("[DLS Sender] send result fail : " + responseCode + " " + string);
                i10 = -7;
                b(responseCode, string);
                c(bufferedReader);
                return i10;
            } catch (Exception e11) {
                e10 = e11;
                try {
                    gb.c.c("[DLS Client] Send fail.");
                    gb.c.d("[DLS Client] " + e10.getMessage());
                    b(0, "");
                    c(bufferedReader);
                    return -41;
                } catch (Throwable th) {
                    th = th;
                    c(bufferedReader);
                    throw th;
                }
            }
        } catch (Exception e12) {
            bufferedReader = null;
            e10 = e12;
            gb.c.c("[DLS Client] Send fail.");
            gb.c.d("[DLS Client] " + e10.getMessage());
            b(0, "");
            c(bufferedReader);
            return -41;
        } catch (Throwable th2) {
            bufferedReader = null;
            th = th2;
            c(bufferedReader);
            throw th;
        }
    }

    public final void b(int i10, String str) {
        if (this.f11525c != null) {
            if (i10 == 200 && str.equalsIgnoreCase("1000")) {
                return;
            }
            if (this.f11529g.booleanValue()) {
                while (!this.f11526d.isEmpty()) {
                    f fVar = (f) this.f11526d.poll();
                    jb.a aVar = this.f11525c;
                    aVar.a(i10, fVar.c() + "", fVar.a(), fVar.d().a());
                }
                return;
            }
            jb.a aVar2 = this.f11525c;
            aVar2.a(i10, this.f11527e.c() + "", this.f11527e.a(), this.f11527e.d().a());
        }
    }

    public final void c(BufferedReader bufferedReader) {
        if (bufferedReader != null) {
            try {
                bufferedReader.close();
            } catch (IOException e10) {
                gb.c.d("[DLS Client] " + e10.getMessage());
                return;
            }
        }
        HttpsURLConnection httpsURLConnection = this.f11528f;
        if (httpsURLConnection != null) {
            httpsURLConnection.disconnect();
        }
    }

    public final String d() {
        if (!this.f11529g.booleanValue()) {
            return this.f11527e.a();
        }
        Iterator it = this.f11526d.iterator();
        StringBuilder sb2 = new StringBuilder(((f) it.next()).a());
        while (it.hasNext()) {
            sb2.append("\u000e");
            sb2.append(((f) it.next()).a());
        }
        return sb2.toString();
    }

    public void e(URL url, String str, String str2) {
        HttpsURLConnection httpsURLConnection = (HttpsURLConnection) url.openConnection();
        this.f11528f = httpsURLConnection;
        httpsURLConnection.setSSLSocketFactory(xa.a.a().b().getSocketFactory());
        this.f11528f.setRequestMethod(str2);
        this.f11528f.addRequestProperty("Content-Encoding", this.f11529g.booleanValue() ? "gzip" : "text");
        this.f11528f.setConnectTimeout(3000);
        this.f11528f.setDoOutput(true);
        BufferedOutputStream bufferedOutputStream = this.f11529g.booleanValue() ? new BufferedOutputStream(new GZIPOutputStream(this.f11528f.getOutputStream())) : new BufferedOutputStream(this.f11528f.getOutputStream());
        bufferedOutputStream.write(str.getBytes());
        bufferedOutputStream.flush();
        bufferedOutputStream.close();
    }

    public void run() {
        try {
            ta.a aVar = this.f11529g.booleanValue() ? f11522i : f11521h;
            Uri.Builder buildUpon = Uri.parse(aVar.b()).buildUpon();
            String valueOf = String.valueOf(System.currentTimeMillis());
            Uri.Builder appendQueryParameter = buildUpon.appendQueryParameter("ts", valueOf).appendQueryParameter("type", this.f11524b.a()).appendQueryParameter("tid", this.f11523a);
            appendQueryParameter.appendQueryParameter("hc", gb.a.a(this.f11523a + valueOf + gb.b.f6756a));
            URL url = new URL(buildUpon.build().toString());
            String d10 = d();
            if (TextUtils.isEmpty(d10)) {
                gb.c.g("[DLS Client] body is empty");
                return;
            }
            e(url, d10, aVar.a());
            gb.c.d("[DLS Client] Send to DLS : " + d10);
        } catch (Exception e10) {
            gb.c.c("[DLS Client] Send fail.");
            gb.c.d("[DLS Client] " + e10.getMessage());
        }
    }

    public a(c cVar, Queue queue, String str, jb.a aVar) {
        this.f11528f = null;
        this.f11526d = queue;
        this.f11523a = str;
        this.f11525c = aVar;
        this.f11529g = Boolean.TRUE;
        this.f11524b = cVar;
    }
}
