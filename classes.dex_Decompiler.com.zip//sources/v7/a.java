package v7;

import java.util.ArrayList;

public class a {

    /* renamed from: a  reason: collision with root package name */
    public int f10247a = 0;

    /* renamed from: b  reason: collision with root package name */
    public String f10248b = "";

    /* renamed from: c  reason: collision with root package name */
    public long f10249c = 0;

    /* renamed from: d  reason: collision with root package name */
    public ArrayList f10250d;

    public String a() {
        if (this.f10248b == null) {
            this.f10248b = "";
        }
        return this.f10248b;
    }

    public long b() {
        return this.f10249c;
    }

    public int c() {
        return this.f10247a;
    }

    public ArrayList d() {
        if (this.f10250d == null) {
            this.f10250d = new ArrayList();
        }
        return this.f10250d;
    }

    public void e(String str) {
        this.f10248b = str;
    }

    public void f(long j10) {
        this.f10249c = j10;
    }

    public void g(int i10) {
        this.f10247a = i10;
    }

    public void h(ArrayList arrayList) {
        this.f10250d = arrayList;
    }
}
