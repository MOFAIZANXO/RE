package v7;

import java.util.ArrayList;

public class b {

    /* renamed from: a  reason: collision with root package name */
    public boolean f10251a = false;

    /* renamed from: b  reason: collision with root package name */
    public ArrayList f10252b;

    public ArrayList a() {
        if (this.f10252b == null) {
            this.f10252b = new ArrayList();
        }
        return this.f10252b;
    }

    public boolean b() {
        return this.f10251a;
    }

    public void c(boolean z10) {
        this.f10251a = z10;
    }

    public void d(ArrayList arrayList) {
        this.f10252b = arrayList;
    }
}
