package j4;

import android.content.Context;
import android.os.Bundle;

public abstract class a {
    public abstract void a(Context context, String str, Bundle bundle, b bVar);
}
