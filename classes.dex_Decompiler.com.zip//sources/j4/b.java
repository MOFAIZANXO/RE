package j4;

public interface b {
    void a(String str);
}
