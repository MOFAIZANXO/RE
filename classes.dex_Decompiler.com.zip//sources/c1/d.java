package c1;

import android.database.sqlite.SQLiteProgram;

public class d implements b1.d {

    /* renamed from: a  reason: collision with root package name */
    public final SQLiteProgram f2983a;

    public d(SQLiteProgram sQLiteProgram) {
        this.f2983a = sQLiteProgram;
    }

    public void A(int i10, double d10) {
        this.f2983a.bindDouble(i10, d10);
    }

    public void J(int i10, long j10) {
        this.f2983a.bindLong(i10, j10);
    }

    public void S(int i10, byte[] bArr) {
        this.f2983a.bindBlob(i10, bArr);
    }

    public void close() {
        this.f2983a.close();
    }

    public void t(int i10, String str) {
        this.f2983a.bindString(i10, str);
    }

    public void z(int i10) {
        this.f2983a.bindNull(i10);
    }
}
