package c1;

import b1.c;

public final class c implements c.C0048c {
    public b1.c a(c.b bVar) {
        return new b(bVar.f2770a, bVar.f2771b, bVar.f2772c, bVar.f2773d);
    }
}
