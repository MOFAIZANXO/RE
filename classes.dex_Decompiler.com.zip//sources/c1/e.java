package c1;

import android.database.sqlite.SQLiteStatement;
import b1.f;

public class e extends d implements f {

    /* renamed from: b  reason: collision with root package name */
    public final SQLiteStatement f2984b;

    public e(SQLiteStatement sQLiteStatement) {
        super(sQLiteStatement);
        this.f2984b = sQLiteStatement;
    }

    public long X() {
        return this.f2984b.executeInsert();
    }

    public int w() {
        return this.f2984b.executeUpdateDelete();
    }
}
