package c1;

import android.content.Context;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import b1.c;
import java.io.File;

public class b implements c {

    /* renamed from: a  reason: collision with root package name */
    public final Context f2971a;

    /* renamed from: b  reason: collision with root package name */
    public final String f2972b;

    /* renamed from: f  reason: collision with root package name */
    public final c.a f2973f;

    /* renamed from: g  reason: collision with root package name */
    public final boolean f2974g;

    /* renamed from: h  reason: collision with root package name */
    public final Object f2975h = new Object();

    /* renamed from: i  reason: collision with root package name */
    public a f2976i;

    /* renamed from: j  reason: collision with root package name */
    public boolean f2977j;

    public static class a extends SQLiteOpenHelper {

        /* renamed from: a  reason: collision with root package name */
        public final a[] f2978a;

        /* renamed from: b  reason: collision with root package name */
        public final c.a f2979b;

        /* renamed from: f  reason: collision with root package name */
        public boolean f2980f;

        /* renamed from: c1.b$a$a  reason: collision with other inner class name */
        public class C0054a implements DatabaseErrorHandler {

            /* renamed from: a  reason: collision with root package name */
            public final /* synthetic */ c.a f2981a;

            /* renamed from: b  reason: collision with root package name */
            public final /* synthetic */ a[] f2982b;

            public C0054a(c.a aVar, a[] aVarArr) {
                this.f2981a = aVar;
                this.f2982b = aVarArr;
            }

            public void onCorruption(SQLiteDatabase sQLiteDatabase) {
                this.f2981a.c(a.c(this.f2982b, sQLiteDatabase));
            }
        }

        public a(Context context, String str, a[] aVarArr, c.a aVar) {
            super(context, str, (SQLiteDatabase.CursorFactory) null, aVar.f2769a, new C0054a(aVar, aVarArr));
            this.f2979b = aVar;
            this.f2978a = aVarArr;
        }

        public static a c(a[] aVarArr, SQLiteDatabase sQLiteDatabase) {
            a aVar = aVarArr[0];
            if (aVar == null || !aVar.a(sQLiteDatabase)) {
                aVarArr[0] = new a(sQLiteDatabase);
            }
            return aVarArr[0];
        }

        public a a(SQLiteDatabase sQLiteDatabase) {
            return c(this.f2978a, sQLiteDatabase);
        }

        public synchronized void close() {
            super.close();
            this.f2978a[0] = null;
        }

        public synchronized b1.b d() {
            this.f2980f = false;
            SQLiteDatabase writableDatabase = super.getWritableDatabase();
            if (this.f2980f) {
                close();
                return d();
            }
            return a(writableDatabase);
        }

        public void onConfigure(SQLiteDatabase sQLiteDatabase) {
            this.f2979b.b(a(sQLiteDatabase));
        }

        public void onCreate(SQLiteDatabase sQLiteDatabase) {
            this.f2979b.d(a(sQLiteDatabase));
        }

        public void onDowngrade(SQLiteDatabase sQLiteDatabase, int i10, int i11) {
            this.f2980f = true;
            this.f2979b.e(a(sQLiteDatabase), i10, i11);
        }

        public void onOpen(SQLiteDatabase sQLiteDatabase) {
            if (!this.f2980f) {
                this.f2979b.f(a(sQLiteDatabase));
            }
        }

        public void onUpgrade(SQLiteDatabase sQLiteDatabase, int i10, int i11) {
            this.f2980f = true;
            this.f2979b.g(a(sQLiteDatabase), i10, i11);
        }
    }

    public b(Context context, String str, c.a aVar, boolean z10) {
        this.f2971a = context;
        this.f2972b = str;
        this.f2973f = aVar;
        this.f2974g = z10;
    }

    public final a a() {
        a aVar;
        synchronized (this.f2975h) {
            if (this.f2976i == null) {
                a[] aVarArr = new a[1];
                if (this.f2972b == null || !this.f2974g) {
                    this.f2976i = new a(this.f2971a, this.f2972b, aVarArr, this.f2973f);
                } else {
                    this.f2976i = new a(this.f2971a, new File(this.f2971a.getNoBackupFilesDir(), this.f2972b).getAbsolutePath(), aVarArr, this.f2973f);
                }
                this.f2976i.setWriteAheadLoggingEnabled(this.f2977j);
            }
            aVar = this.f2976i;
        }
        return aVar;
    }

    public void close() {
        a().close();
    }

    public String getDatabaseName() {
        return this.f2972b;
    }

    public b1.b getWritableDatabase() {
        return a().d();
    }

    public void setWriteAheadLoggingEnabled(boolean z10) {
        synchronized (this.f2975h) {
            a aVar = this.f2976i;
            if (aVar != null) {
                aVar.setWriteAheadLoggingEnabled(z10);
            }
            this.f2977j = z10;
        }
    }
}
