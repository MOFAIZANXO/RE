package c1;

import android.database.Cursor;
import android.database.sqlite.SQLiteCursor;
import android.database.sqlite.SQLiteCursorDriver;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQuery;
import android.os.CancellationSignal;
import b1.e;
import b1.f;
import java.util.List;

public class a implements b1.b {

    /* renamed from: b  reason: collision with root package name */
    public static final String[] f2964b = {"", " OR ROLLBACK ", " OR ABORT ", " OR FAIL ", " OR IGNORE ", " OR REPLACE "};

    /* renamed from: f  reason: collision with root package name */
    public static final String[] f2965f = new String[0];

    /* renamed from: a  reason: collision with root package name */
    public final SQLiteDatabase f2966a;

    /* renamed from: c1.a$a  reason: collision with other inner class name */
    public class C0053a implements SQLiteDatabase.CursorFactory {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ e f2967a;

        public C0053a(e eVar) {
            this.f2967a = eVar;
        }

        public Cursor newCursor(SQLiteDatabase sQLiteDatabase, SQLiteCursorDriver sQLiteCursorDriver, String str, SQLiteQuery sQLiteQuery) {
            this.f2967a.c(new d(sQLiteQuery));
            return new SQLiteCursor(sQLiteCursorDriver, str, sQLiteQuery);
        }
    }

    public class b implements SQLiteDatabase.CursorFactory {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ e f2969a;

        public b(e eVar) {
            this.f2969a = eVar;
        }

        public Cursor newCursor(SQLiteDatabase sQLiteDatabase, SQLiteCursorDriver sQLiteCursorDriver, String str, SQLiteQuery sQLiteQuery) {
            this.f2969a.c(new d(sQLiteQuery));
            return new SQLiteCursor(sQLiteCursorDriver, str, sQLiteQuery);
        }
    }

    public a(SQLiteDatabase sQLiteDatabase) {
        this.f2966a = sQLiteDatabase;
    }

    public boolean E() {
        return this.f2966a.inTransaction();
    }

    public Cursor G(e eVar) {
        return this.f2966a.rawQueryWithFactory(new C0053a(eVar), eVar.a(), f2965f, (String) null);
    }

    public void L() {
        this.f2966a.setTransactionSuccessful();
    }

    public void M(String str, Object[] objArr) {
        this.f2966a.execSQL(str, objArr);
    }

    public Cursor Y(String str) {
        return G(new b1.a(str));
    }

    public boolean a(SQLiteDatabase sQLiteDatabase) {
        return this.f2966a == sQLiteDatabase;
    }

    public String b() {
        return this.f2966a.getPath();
    }

    public void close() {
        this.f2966a.close();
    }

    public void g() {
        this.f2966a.endTransaction();
    }

    public void h() {
        this.f2966a.beginTransaction();
    }

    public boolean isOpen() {
        return this.f2966a.isOpen();
    }

    public List n() {
        return this.f2966a.getAttachedDbs();
    }

    public void s(String str) {
        this.f2966a.execSQL(str);
    }

    public Cursor u(e eVar, CancellationSignal cancellationSignal) {
        return this.f2966a.rawQueryWithFactory(new b(eVar), eVar.a(), f2965f, (String) null, cancellationSignal);
    }

    public f x(String str) {
        return new e(this.f2966a.compileStatement(str));
    }
}
