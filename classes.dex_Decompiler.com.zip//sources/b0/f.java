package b0;

import ac.l;

public final class f {

    /* renamed from: a  reason: collision with root package name */
    public final Class f2765a;

    /* renamed from: b  reason: collision with root package name */
    public final l f2766b;

    public f(Class cls, l lVar) {
        kotlin.jvm.internal.l.e(cls, "clazz");
        kotlin.jvm.internal.l.e(lVar, "initializer");
        this.f2765a = cls;
        this.f2766b = lVar;
    }

    public final Class a() {
        return this.f2765a;
    }

    public final l b() {
        return this.f2766b;
    }
}
