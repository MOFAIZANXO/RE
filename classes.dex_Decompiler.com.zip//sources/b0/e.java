package b0;

public abstract class e {
    public static final int view_tree_view_model_store_owner = 2131363049;
}
