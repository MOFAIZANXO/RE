package b0;

import androidx.lifecycle.e0;
import androidx.lifecycle.g0;
import kotlin.jvm.internal.l;

public final class b implements g0.b {

    /* renamed from: b  reason: collision with root package name */
    public final f[] f2763b;

    public b(f... fVarArr) {
        l.e(fVarArr, "initializers");
        this.f2763b = fVarArr;
    }

    public e0 b(Class cls, a aVar) {
        l.e(cls, "modelClass");
        l.e(aVar, "extras");
        e0 e0Var = null;
        for (f fVar : this.f2763b) {
            if (l.a(fVar.a(), cls)) {
                Object invoke = fVar.b().invoke(aVar);
                e0Var = invoke instanceof e0 ? (e0) invoke : null;
            }
        }
        if (e0Var != null) {
            return e0Var;
        }
        throw new IllegalArgumentException("No initializer set for given class " + cls.getName());
    }
}
