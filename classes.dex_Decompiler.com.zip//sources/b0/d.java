package b0;

import b0.a;
import kotlin.jvm.internal.g;
import kotlin.jvm.internal.l;

public final class d extends a {
    public d() {
        this((a) null, 1, (g) null);
    }

    public Object a(a.b bVar) {
        l.e(bVar, "key");
        return b().get(bVar);
    }

    public final void c(a.b bVar, Object obj) {
        l.e(bVar, "key");
        b().put(bVar, obj);
    }

    public d(a aVar) {
        l.e(aVar, "initialExtras");
        b().putAll(aVar.b());
    }

    /* JADX INFO: this call moved to the top of the method (can break code semantics) */
    public /* synthetic */ d(a aVar, int i10, g gVar) {
        this((i10 & 1) != 0 ? a.C0047a.f2762b : aVar);
    }
}
