package b0;

import ac.l;
import androidx.lifecycle.g0;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import zb.a;

public final class c {

    /* renamed from: a  reason: collision with root package name */
    public final List f2764a = new ArrayList();

    public final void a(ec.c cVar, l lVar) {
        kotlin.jvm.internal.l.e(cVar, "clazz");
        kotlin.jvm.internal.l.e(lVar, "initializer");
        this.f2764a.add(new f(a.a(cVar), lVar));
    }

    public final g0.b b() {
        Object[] array = this.f2764a.toArray(new f[0]);
        if (array != null) {
            f[] fVarArr = (f[]) array;
            return new b((f[]) Arrays.copyOf(fVarArr, fVarArr.length));
        }
        throw new NullPointerException("null cannot be cast to non-null type kotlin.Array<T of kotlin.collections.ArraysKt__ArraysJVMKt.toTypedArray>");
    }
}
