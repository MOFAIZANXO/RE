package b0;

import java.util.LinkedHashMap;
import java.util.Map;
import kotlin.jvm.internal.l;

public abstract class a {

    /* renamed from: a  reason: collision with root package name */
    public final Map f2761a = new LinkedHashMap();

    /* renamed from: b0.a$a  reason: collision with other inner class name */
    public static final class C0047a extends a {

        /* renamed from: b  reason: collision with root package name */
        public static final C0047a f2762b = new C0047a();

        public Object a(b bVar) {
            l.e(bVar, "key");
            return null;
        }
    }

    public interface b {
    }

    public abstract Object a(b bVar);

    public final Map b() {
        return this.f2761a;
    }
}
