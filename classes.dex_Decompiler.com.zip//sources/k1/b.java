package k1;

public final class b {

    /* renamed from: a  reason: collision with root package name */
    public static final b f7567a = new b();

    /* renamed from: b  reason: collision with root package name */
    public static final j f7568b = j.QUIET;

    public final j a() {
        return f7568b;
    }
}
