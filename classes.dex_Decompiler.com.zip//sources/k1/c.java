package k1;

import ac.l;
import ec.d;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import qb.r;

public final class c {

    /* renamed from: a  reason: collision with root package name */
    public final ClassLoader f7569a;

    public static final class a implements InvocationHandler {

        /* renamed from: a  reason: collision with root package name */
        public final ec.c f7570a;

        /* renamed from: b  reason: collision with root package name */
        public final l f7571b;

        public a(ec.c cVar, l lVar) {
            kotlin.jvm.internal.l.e(cVar, "clazz");
            kotlin.jvm.internal.l.e(lVar, "consumer");
            this.f7570a = cVar;
            this.f7571b = lVar;
        }

        public final void a(Object obj) {
            kotlin.jvm.internal.l.e(obj, "parameter");
            this.f7571b.invoke(obj);
        }

        public final boolean b(Method method, Object[] objArr) {
            if (!kotlin.jvm.internal.l.a(method.getName(), "accept")) {
                return false;
            }
            return objArr != null && objArr.length == 1;
        }

        public final boolean c(Method method, Object[] objArr) {
            if (!kotlin.jvm.internal.l.a(method.getName(), "equals") || !method.getReturnType().equals(Boolean.TYPE)) {
                return false;
            }
            return objArr != null && objArr.length == 1;
        }

        public final boolean d(Method method, Object[] objArr) {
            return kotlin.jvm.internal.l.a(method.getName(), "hashCode") && method.getReturnType().equals(Integer.TYPE) && objArr == null;
        }

        public final boolean e(Method method, Object[] objArr) {
            return kotlin.jvm.internal.l.a(method.getName(), "toString") && method.getReturnType().equals(String.class) && objArr == null;
        }

        public Object invoke(Object obj, Method method, Object[] objArr) {
            kotlin.jvm.internal.l.e(obj, "obj");
            kotlin.jvm.internal.l.e(method, "method");
            Object obj2 = null;
            boolean z10 = false;
            if (b(method, objArr)) {
                ec.c cVar = this.f7570a;
                if (objArr != null) {
                    obj2 = objArr[0];
                }
                a(d.a(cVar, obj2));
                return r.f9409a;
            } else if (c(method, objArr)) {
                if (objArr != null) {
                    obj2 = objArr[0];
                }
                if (obj == obj2) {
                    z10 = true;
                }
                return Boolean.valueOf(z10);
            } else if (d(method, objArr)) {
                return Integer.valueOf(this.f7571b.hashCode());
            } else {
                if (e(method, objArr)) {
                    return this.f7571b.toString();
                }
                throw new UnsupportedOperationException("Unexpected method call object:" + obj + ", method: " + method + ", args: " + objArr);
            }
        }
    }

    public c(ClassLoader classLoader) {
        kotlin.jvm.internal.l.e(classLoader, "loader");
        this.f7569a = classLoader;
    }

    public final void a(Object obj, ec.c cVar, String str, l lVar) {
        kotlin.jvm.internal.l.e(obj, "obj");
        kotlin.jvm.internal.l.e(cVar, "clazz");
        kotlin.jvm.internal.l.e(str, "methodName");
        kotlin.jvm.internal.l.e(lVar, "consumer");
        obj.getClass().getMethod(str, new Class[]{d()}).invoke(obj, new Object[]{b(cVar, lVar)});
    }

    public final Object b(ec.c cVar, l lVar) {
        a aVar = new a(cVar, lVar);
        Object newProxyInstance = Proxy.newProxyInstance(this.f7569a, new Class[]{d()}, aVar);
        kotlin.jvm.internal.l.d(newProxyInstance, "newProxyInstance(loader,…onsumerClass()), handler)");
        return newProxyInstance;
    }

    public final Class c() {
        try {
            return d();
        } catch (ClassNotFoundException unused) {
            return null;
        }
    }

    public final Class d() {
        Class<?> loadClass = this.f7569a.loadClass("java.util.function.Consumer");
        kotlin.jvm.internal.l.d(loadClass, "loader.loadClass(\"java.util.function.Consumer\")");
        return loadClass;
    }
}
