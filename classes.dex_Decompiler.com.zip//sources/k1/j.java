package k1;

public enum j {
    STRICT,
    LOG,
    QUIET
}
