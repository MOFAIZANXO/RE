package k1;

import kotlin.jvm.internal.g;
import kotlin.jvm.internal.l;

public abstract class h {

    /* renamed from: a  reason: collision with root package name */
    public static final a f7582a = new a((g) null);

    public static final class a {
        public a() {
        }

        public /* synthetic */ a(g gVar) {
            this();
        }

        public static /* synthetic */ h b(a aVar, Object obj, String str, j jVar, f fVar, int i10, Object obj2) {
            if ((i10 & 2) != 0) {
                jVar = b.f7567a.a();
            }
            if ((i10 & 4) != 0) {
                fVar = a.f7566a;
            }
            return aVar.a(obj, str, jVar, fVar);
        }

        public final h a(Object obj, String str, j jVar, f fVar) {
            l.e(obj, "<this>");
            l.e(str, "tag");
            l.e(jVar, "verificationMode");
            l.e(fVar, "logger");
            return new i(obj, str, jVar, fVar);
        }
    }

    public abstract Object a();

    public final String b(Object obj, String str) {
        l.e(obj, "value");
        l.e(str, "message");
        return str + " value: " + obj;
    }

    public abstract h c(String str, ac.l lVar);
}
