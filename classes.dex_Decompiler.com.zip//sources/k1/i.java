package k1;

import kotlin.jvm.internal.l;

public final class i extends h {

    /* renamed from: b  reason: collision with root package name */
    public final Object f7583b;

    /* renamed from: c  reason: collision with root package name */
    public final String f7584c;

    /* renamed from: d  reason: collision with root package name */
    public final j f7585d;

    /* renamed from: e  reason: collision with root package name */
    public final f f7586e;

    public i(Object obj, String str, j jVar, f fVar) {
        l.e(obj, "value");
        l.e(str, "tag");
        l.e(jVar, "verificationMode");
        l.e(fVar, "logger");
        this.f7583b = obj;
        this.f7584c = str;
        this.f7585d = jVar;
        this.f7586e = fVar;
    }

    public Object a() {
        return this.f7583b;
    }

    public h c(String str, ac.l lVar) {
        l.e(str, "message");
        l.e(lVar, "condition");
        if (((Boolean) lVar.invoke(this.f7583b)).booleanValue()) {
            return this;
        }
        return new e(this.f7583b, this.f7584c, str, this.f7586e, this.f7585d);
    }
}
