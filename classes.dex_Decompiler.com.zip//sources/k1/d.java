package k1;

import android.util.Log;
import androidx.window.extensions.WindowExtensionsProvider;
import kotlin.jvm.internal.v;

public final class d {

    /* renamed from: a  reason: collision with root package name */
    public static final d f7572a = new d();

    /* renamed from: b  reason: collision with root package name */
    public static final String f7573b = v.b(d.class).c();

    public final int a() {
        try {
            return WindowExtensionsProvider.getWindowExtensions().getVendorApiLevel();
        } catch (NoClassDefFoundError unused) {
            if (b.f7567a.a() != j.LOG) {
                return 0;
            }
            Log.d(f7573b, "Embedding extension version not found");
            return 0;
        } catch (UnsupportedOperationException unused2) {
            if (b.f7567a.a() != j.LOG) {
                return 0;
            }
            Log.d(f7573b, "Stub Extension");
            return 0;
        }
    }
}
