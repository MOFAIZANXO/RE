package k1;

import kotlin.jvm.internal.l;

public final class g {

    /* renamed from: a  reason: collision with root package name */
    public final ClassLoader f7581a;

    public g(ClassLoader classLoader) {
        l.e(classLoader, "loader");
        this.f7581a = classLoader;
    }
}
