package k1;

import android.util.Log;
import kotlin.jvm.internal.l;

public final class a implements f {

    /* renamed from: a  reason: collision with root package name */
    public static final a f7566a = new a();

    public void a(String str, String str2) {
        l.e(str, "tag");
        l.e(str2, "message");
        Log.d(str, str2);
    }
}
