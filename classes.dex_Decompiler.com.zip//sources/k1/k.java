package k1;

import kotlin.jvm.internal.l;

public final class k extends Exception {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public k(String str) {
        super(str);
        l.e(str, "message");
    }
}
