package k1;

public interface f {
    void a(String str, String str2);
}
