package k1;

import kotlin.jvm.internal.l;
import qb.g;
import rb.i;

public final class e extends h {

    /* renamed from: b  reason: collision with root package name */
    public final Object f7574b;

    /* renamed from: c  reason: collision with root package name */
    public final String f7575c;

    /* renamed from: d  reason: collision with root package name */
    public final String f7576d;

    /* renamed from: e  reason: collision with root package name */
    public final f f7577e;

    /* renamed from: f  reason: collision with root package name */
    public final j f7578f;

    /* renamed from: g  reason: collision with root package name */
    public final k f7579g;

    public /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        public static final /* synthetic */ int[] f7580a;

        /* JADX WARNING: Can't wrap try/catch for region: R(9:0|1|2|3|4|5|6|7|9) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0010 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x0019 */
        static {
            /*
                k1.j[] r0 = k1.j.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                k1.j r1 = k1.j.STRICT     // Catch:{ NoSuchFieldError -> 0x0010 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0010 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0010 }
            L_0x0010:
                k1.j r1 = k1.j.LOG     // Catch:{ NoSuchFieldError -> 0x0019 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0019 }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0019 }
            L_0x0019:
                k1.j r1 = k1.j.QUIET     // Catch:{ NoSuchFieldError -> 0x0022 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0022 }
                r2 = 3
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0022 }
            L_0x0022:
                f7580a = r0
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: k1.e.a.<clinit>():void");
        }
    }

    public e(Object obj, String str, String str2, f fVar, j jVar) {
        l.e(obj, "value");
        l.e(str, "tag");
        l.e(str2, "message");
        l.e(fVar, "logger");
        l.e(jVar, "verificationMode");
        this.f7574b = obj;
        this.f7575c = str;
        this.f7576d = str2;
        this.f7577e = fVar;
        this.f7578f = jVar;
        k kVar = new k(b(obj, str2));
        StackTraceElement[] stackTrace = kVar.getStackTrace();
        l.d(stackTrace, "stackTrace");
        kVar.setStackTrace((StackTraceElement[]) i.g(stackTrace, 2).toArray(new StackTraceElement[0]));
        this.f7579g = kVar;
    }

    public Object a() {
        int i10 = a.f7580a[this.f7578f.ordinal()];
        if (i10 == 1) {
            throw this.f7579g;
        } else if (i10 == 2) {
            this.f7577e.a(this.f7575c, b(this.f7574b, this.f7576d));
            return null;
        } else if (i10 == 3) {
            return null;
        } else {
            throw new g();
        }
    }

    public h c(String str, ac.l lVar) {
        l.e(str, "message");
        l.e(lVar, "condition");
        return this;
    }
}
