package la;

public final /* synthetic */ class e implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ g f7923a;

    public /* synthetic */ e(g gVar) {
        this.f7923a = gVar;
    }

    public final void run() {
        this.f7923a.o();
    }
}
