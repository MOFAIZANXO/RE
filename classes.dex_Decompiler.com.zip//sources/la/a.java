package la;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import com.samsung.android.util.SemLog;
import y6.b;

public abstract class a extends AppWidgetProvider {

    /* renamed from: a  reason: collision with root package name */
    public Context f7920a;

    public void onAppWidgetOptionsChanged(Context context, AppWidgetManager appWidgetManager, int i10, Bundle bundle) {
        Log.i("SmWidget.Provider", "onAppWidgetOptionsChanged, id : " + i10);
        int i11 = bundle.getInt("appWidgetMinWidth");
        int i12 = bundle.getInt("appWidgetMaxWidth");
        int i13 = bundle.getInt("appWidgetMinHeight");
        int i14 = bundle.getInt("appWidgetMaxHeight");
        SemLog.i("SmWidget.Provider", "Widget minWidth = " + i11 + " / maxWidth = " + i12 + " / minHeight = " + i13 + " / maxHeight = " + i14);
        StringBuilder sb2 = new StringBuilder();
        sb2.append("- option changed orientation : ");
        sb2.append(context.getResources().getConfiguration().orientation);
        Log.i("SmWidget.Provider", sb2.toString());
        int[] iArr = {i10};
        if (i10 > 0) {
            onUpdate(context, appWidgetManager, iArr);
        }
    }

    public void onDeleted(Context context, int[] iArr) {
        if (iArr != null && iArr.length > 0) {
            b bVar = new b();
            for (int i10 : iArr) {
                if (i10 > 0) {
                    Log.i("SmWidget.Provider", "delete " + i10 + " pref - " + bVar.a(context, i10));
                }
            }
        }
    }

    public void onDisabled(Context context) {
        y6.a.m(context);
        SemLog.i("SmWidget.Provider", "----onDisabled----");
    }

    public void onEnabled(Context context) {
        super.onEnabled(context);
        this.f7920a = context;
        y6.a.l(context, "com.samsung.android.sm.widget.UPDATE_DATA_WIDGET");
        SemLog.i("SmWidget.Provider", "----onEnabled----");
    }

    public void onReceive(Context context, Intent intent) {
        if (intent != null) {
            this.f7920a = context;
            String action = intent.getAction();
            SemLog.i("SmWidget.Provider", "onReceive : " + action);
            super.onReceive(context, intent);
            if ("android.intent.action.TIME_SET".equalsIgnoreCase(action)) {
                if (y6.a.f(this.f7920a)) {
                    SemLog.i("SmWidget.Provider", "action time set");
                    y6.a.l(this.f7920a, "com.samsung.android.sm.widget.UPDATE_DATA_WIDGET");
                }
            } else if (("com.samsung.android.theme.themecenter.THEME_APPLY".equalsIgnoreCase(action) || "com.sec.android.intent.action.WALLPAPER_CHANGED".equalsIgnoreCase(action)) && y6.a.g(this.f7920a)) {
                SemLog.i("SmWidget.Provider", "action theme apply/widget update");
                y6.a.l(this.f7920a, "com.samsung.android.sm.widget.UPDATE_DATA_WIDGET");
            }
        }
    }

    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] iArr) {
        SemLog.i("SmWidget.Provider", "onUpdate");
        if (iArr != null && iArr.length > 0) {
            y6.a.l(context, "com.samsung.android.sm.widget.UPDATE_DATA_WIDGET");
        }
    }
}
