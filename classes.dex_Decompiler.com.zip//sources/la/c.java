package la;

import androidx.lifecycle.t;
import z9.f;

public final /* synthetic */ class c implements t {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ g f7922a;

    public /* synthetic */ c(g gVar) {
        this.f7922a = gVar;
    }

    public final void a(Object obj) {
        this.f7922a.m((f) obj);
    }
}
