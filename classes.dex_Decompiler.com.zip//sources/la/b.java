package la;

import com.samsung.android.sm.widgetapp.SMWidgetService;

public final /* synthetic */ class b implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ SMWidgetService f7921a;

    public /* synthetic */ b(SMWidgetService sMWidgetService) {
        this.f7921a = sMWidgetService;
    }

    public final void run() {
        this.f7921a.r();
    }
}
