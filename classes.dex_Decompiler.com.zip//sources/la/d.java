package la;

import androidx.lifecycle.t;
import com.samsung.android.sm.score.data.OptData;

public final /* synthetic */ class d implements t {
    public final void a(Object obj) {
        g.n((OptData) obj);
    }
}
