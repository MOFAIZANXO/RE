package la;

public final /* synthetic */ class f implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ g f7924a;

    public /* synthetic */ f(g gVar) {
        this.f7924a = gVar;
    }

    public final void run() {
        this.f7924a.l();
    }
}
