package la;

import android.appwidget.AppWidgetManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.RemoteViews;
import android.widget.Toast;
import androidx.lifecycle.t;
import com.samsung.android.sm.score.data.OptData;
import com.samsung.android.sm.widgetapp.data.WidgetConfig;
import com.samsung.android.util.SemLog;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import qa.d;
import qa.e;
import qa.f;
import w6.z;
import y6.b;
import z9.f;

public class g {

    /* renamed from: e  reason: collision with root package name */
    public static int f7925e = 1;

    /* renamed from: f  reason: collision with root package name */
    public static long f7926f;

    /* renamed from: a  reason: collision with root package name */
    public final Context f7927a;

    /* renamed from: b  reason: collision with root package name */
    public final ArrayList f7928b;

    /* renamed from: c  reason: collision with root package name */
    public final t f7929c = new c(this);

    /* renamed from: d  reason: collision with root package name */
    public final t f7930d = new d();

    public static /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        public static final /* synthetic */ int[] f7931a;

        /* JADX WARNING: Can't wrap try/catch for region: R(6:0|1|2|3|4|6) */
        /* JADX WARNING: Code restructure failed: missing block: B:7:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        static {
            /*
                z9.f$a[] r0 = z9.f.a.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f7931a = r0
                z9.f$a r1 = z9.f.a.FIXED     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = f7931a     // Catch:{ NoSuchFieldError -> 0x001d }
                z9.f$a r1 = z9.f.a.SCANNING     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: la.g.a.<clinit>():void");
        }
    }

    public g(Context context) {
        ArrayList arrayList = new ArrayList();
        this.f7928b = arrayList;
        Context applicationContext = context.getApplicationContext();
        this.f7927a = applicationContext;
        arrayList.add(new f(applicationContext, new d()));
        arrayList.add(new e(applicationContext, new d()));
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void l() {
        if (f7925e == 2) {
            r();
        }
        f7925e = 1;
        t();
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void m(z9.f fVar) {
        if (fVar != null) {
            f.a d10 = fVar.d();
            Log.i("SmWidget.UpdateMgr", "result stat : " + d10);
            int i10 = a.f7931a[d10.ordinal()];
            if (i10 == 1) {
                new Handler(Looper.getMainLooper()).postDelayed(new f(this), 1900);
            } else if (i10 == 2) {
                f7925e = 2;
                t();
            }
        }
    }

    public static /* synthetic */ void n(OptData optData) {
        if (optData != null && optData.j() == 910 && optData.e() != 0) {
            int size = optData.d().size();
            SemLog.d("SmWidget.UpdateMgr", "current ram stat : " + f7926f + ", received stat : " + optData.e() + " : " + size);
            if (f7926f == optData.e()) {
                return;
            }
            if (size > 0) {
                f7926f = optData.e();
            } else {
                f7926f = 0;
            }
        }
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void o() {
        f7925e = 1;
        t();
    }

    public final void e(AppWidgetManager appWidgetManager, int[] iArr, qa.g gVar) {
        for (int appWidgetOptions : iArr) {
            Bundle appWidgetOptions2 = appWidgetManager.getAppWidgetOptions(appWidgetOptions);
            int i10 = appWidgetOptions2.getInt("Old_WidgetId");
            int i11 = appWidgetOptions2.getInt("New_WidgetId");
            SemLog.i("SmWidget.UpdateMgr", "old widget : " + i10 + ", new widget : " + i11);
            if (k(i10)) {
                na.a aVar = new na.a();
                if (j(i10)) {
                    aVar.a(this.f7927a, i10);
                    aVar.m(this.f7927a, i11);
                    new h7.a(this.f7927a).c("Widget", "delete(oldWidgetId) " + i10 + " restored data. remove(newWidgetId) " + i11 + " from restoredList", System.currentTimeMillis());
                } else if (aVar.j(this.f7927a, i11)) {
                    Log.w("SmWidget.UpdateMgr", "(" + i10 + "-> " + i11 + ") already restored.");
                } else {
                    aVar.k(this.f7927a, i10, i11);
                    u(gVar, i10, i11);
                    new h7.a(this.f7927a).c("Widget", "restored from (old) : " + i10 + "to (new) " + i11, System.currentTimeMillis());
                }
            }
        }
    }

    public t f() {
        return this.f7930d;
    }

    public t g() {
        return this.f7929c;
    }

    public final RemoteViews h(int i10, qa.g gVar) {
        WidgetConfig widgetConfig = new WidgetConfig();
        widgetConfig.f5489a = i10;
        SharedPreferences d10 = new b().d(this.f7927a, i10);
        if (d10.getAll().isEmpty()) {
            gVar.j(i10, widgetConfig);
        }
        WidgetConfig h10 = gVar.h(d10, widgetConfig);
        Log.i("SmWidget.UpdateMgr", "getUpdateViews() config loaded id " + i10 + " as " + h10);
        gVar.p(h10);
        return new RemoteViews((RemoteViews) gVar.f(2, f7925e, (ViewGroup) null), (RemoteViews) gVar.f(1, f7925e, (ViewGroup) null));
    }

    public void i() {
        f7925e = 1;
        f7926f = 0;
    }

    public final boolean j(int i10) {
        long i11 = new na.a().i(this.f7927a, i10);
        long currentTimeMillis = System.currentTimeMillis();
        SemLog.i("SmWidget.UpdateMgr", "current time : " + currentTimeMillis + ", restoredTime : " + i11);
        return (((currentTimeMillis - i11) / 1000) % 3600) / 60 >= 5;
    }

    public final boolean k(int i10) {
        return new na.a().i(this.f7927a, i10) > 0;
    }

    public void p() {
        if (f7925e != 1) {
            Log.i("SmWidget.UpdateMgr", "try to update info but icon status is " + f7925e + ". so skip.");
            return;
        }
        q();
        new Handler(Looper.getMainLooper()).postDelayed(new e(this), 1900);
    }

    public final void q() {
        f7925e = 4;
        AppWidgetManager instance = AppWidgetManager.getInstance(this.f7927a);
        try {
            Iterator it = this.f7928b.iterator();
            while (it.hasNext()) {
                qa.g gVar = (qa.g) it.next();
                int[] appWidgetIds = instance.getAppWidgetIds(gVar.d());
                Log.i("SmWidget.UpdateMgr", "runProgressIcon of " + Arrays.toString(appWidgetIds) + " config : " + this.f7927a.getResources().getConfiguration());
                for (int i10 : appWidgetIds) {
                    instance.updateAppWidget(i10, h(i10, gVar));
                }
            }
        } catch (IllegalStateException e10) {
            Log.w("SmWidget.UpdateMgr", "error", e10);
        }
    }

    public final void r() {
        SemLog.i("SmWidget.UpdateMgr", "show toast:: cleanable ram size : " + f7926f);
        Context context = this.f7927a;
        String string = context.getString(2131953160, new Object[]{z.c(context, f7926f * 1024)});
        this.f7927a.setTheme(2132017164);
        if (f7926f == 0) {
            int i10 = a7.b.e("screen.res.tablet") ? 2131952714 : 2131952713;
            Context context2 = this.f7927a;
            Toast.makeText(context2, context2.getString(i10), 0).show();
        } else {
            Toast.makeText(this.f7927a, string, 0).show();
        }
        f7926f = 0;
    }

    public void s() {
        if (f7925e != 1) {
            Log.v("SmWidget.UpdateMgr", "try to update info but icon status is " + f7925e + ". so skip.");
            return;
        }
        t();
    }

    public final void t() {
        Log.i("SmWidget.UpdateMgr", "updateAllWidgetsInternal(), status : " + f7925e + ", Configuration : " + this.f7927a.getResources().getConfiguration());
        AppWidgetManager instance = AppWidgetManager.getInstance(this.f7927a);
        try {
            Iterator it = this.f7928b.iterator();
            while (it.hasNext()) {
                qa.g gVar = (qa.g) it.next();
                int[] appWidgetIds = instance.getAppWidgetIds(gVar.d());
                e(instance, appWidgetIds, gVar);
                for (int i10 : appWidgetIds) {
                    SemLog.i("SmWidget.UpdateMgr", "request updateAppWidget() of id : [" + i10 + "], Configuration : " + this.f7927a.getResources().getConfiguration());
                    instance.updateAppWidget(i10, h(i10, gVar));
                }
            }
        } catch (IllegalStateException e10) {
            Log.w("SmWidget.UpdateMgr", "error", e10);
        }
    }

    public final void u(qa.g gVar, int i10, int i11) {
        WidgetConfig h10 = gVar.h(new na.a().d(this.f7927a, i10), new WidgetConfig());
        Log.i("SmWidget.UpdateMgr", "start restore old widget : " + i10 + " to new widget : " + i11 + " with " + h10);
        gVar.j(i11, h10);
    }
}
