package h1;

import android.database.DataSetObservable;
import android.database.DataSetObserver;
import android.os.Parcelable;
import android.view.View;
import android.view.ViewGroup;

public abstract class a {

    /* renamed from: a  reason: collision with root package name */
    public final DataSetObservable f6845a = new DataSetObservable();

    /* renamed from: b  reason: collision with root package name */
    public DataSetObserver f6846b;

    public abstract void a(View view, int i10, Object obj);

    public void b(ViewGroup viewGroup, int i10, Object obj) {
        a(viewGroup, i10, obj);
    }

    public abstract void c(View view);

    public void d(ViewGroup viewGroup) {
        c(viewGroup);
    }

    public abstract int e();

    public abstract int f(Object obj);

    public float g(int i10) {
        return 1.0f;
    }

    public abstract Object h(View view, int i10);

    public Object i(ViewGroup viewGroup, int i10) {
        return h(viewGroup, i10);
    }

    public abstract boolean j(View view, Object obj);

    public void k() {
        synchronized (this) {
            DataSetObserver dataSetObserver = this.f6846b;
            if (dataSetObserver != null) {
                dataSetObserver.onChanged();
            }
        }
        this.f6845a.notifyChanged();
    }

    public void l(Parcelable parcelable, ClassLoader classLoader) {
    }

    public abstract Parcelable m();

    public void n(View view, int i10, Object obj) {
    }

    public void o(ViewGroup viewGroup, int i10, Object obj) {
        n(viewGroup, i10, obj);
    }

    public void p(DataSetObserver dataSetObserver) {
        synchronized (this) {
            this.f6846b = dataSetObserver;
        }
    }

    public abstract void q(View view);

    public void r(ViewGroup viewGroup) {
        q(viewGroup);
    }
}
