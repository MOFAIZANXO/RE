package ia;

import aa.b;
import aa.c;
import aa.d;
import android.app.Application;
import androidx.lifecycle.s;
import ba.w;
import ba.y;

public class a extends androidx.lifecycle.a {

    /* renamed from: h  reason: collision with root package name */
    public w f7305h;

    /* renamed from: i  reason: collision with root package name */
    public s f7306i = new s();

    /* renamed from: ia.a$a  reason: collision with other inner class name */
    public class C0098a implements y {
        public C0098a() {
        }

        public void a(d dVar) {
            a.this.f7306i.u(b.b(dVar, (c) a.this.f7305h.b().f158b));
        }
    }

    public a(Application application) {
        super(application);
        w wVar = new w(application.getApplicationContext());
        this.f7305h = wVar;
        wVar.a();
        this.f7305h.c(new C0098a());
    }

    public void p() {
        this.f7305h.d();
        super.p();
    }

    public s u() {
        return this.f7306i;
    }

    public void v() {
        this.f7306i.u(this.f7305h.b());
    }
}
