package ia;

import android.app.Application;
import android.os.HandlerThread;
import android.os.Message;
import android.util.Log;
import androidx.lifecycle.a;
import androidx.lifecycle.s;
import com.samsung.android.sm.core.data.PkgUid;
import f6.c;
import f6.d;

public class b extends a implements c {

    /* renamed from: h  reason: collision with root package name */
    public ea.b f7308h;

    /* renamed from: i  reason: collision with root package name */
    public HandlerThread f7309i;

    /* renamed from: j  reason: collision with root package name */
    public d f7310j;

    public b(Application application) {
        super(application);
        this.f7308h = ea.b.m(application);
        t();
    }

    public void handleMessage(Message message) {
        int i10 = message.what;
        if (i10 == 1) {
            this.f7308h.B();
        } else if (i10 == 2) {
            Object obj = message.obj;
            if (obj instanceof PkgUid) {
                try {
                    this.f7308h.w((PkgUid) obj);
                } catch (UnsupportedOperationException e10) {
                    Log.e("SSVM", e10.toString());
                }
            }
        } else if (i10 != 3) {
            Log.w("SSVM", "Wrong message" + message.what);
        } else {
            this.f7309i.quit();
        }
    }

    public void p() {
        Log.d("SSVM", "onCleared");
        this.f7308h.C();
        this.f7310j.sendEmptyMessage(3);
        super.p();
    }

    public s s() {
        return this.f7308h.k();
    }

    public final void t() {
        HandlerThread handlerThread = new HandlerThread("SSVM");
        this.f7309i = handlerThread;
        handlerThread.start();
        this.f7310j = new d(this.f7309i.getLooper(), this);
    }

    public void u(PkgUid pkgUid) {
        Message obtainMessage = this.f7310j.obtainMessage(2);
        obtainMessage.obj = pkgUid;
        this.f7310j.sendMessage(obtainMessage);
    }

    public void v() {
        this.f7310j.sendEmptyMessage(1);
    }
}
