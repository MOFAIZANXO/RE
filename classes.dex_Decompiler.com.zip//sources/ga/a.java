package ga;

import a7.b;
import android.content.Context;
import android.content.Intent;

public class a extends z6.a {
    public a(String str) {
        e(str);
    }

    public Intent a(Context context) {
        Intent intent = new Intent();
        intent.setPackage(context.getPackageName());
        intent.setAction("com.samsung.android.sm.USE_DEVICE_PROTECTION");
        return intent;
    }

    public boolean c(Context context) {
        return !b.e("security.remove") && ha.a.b(context);
    }
}
