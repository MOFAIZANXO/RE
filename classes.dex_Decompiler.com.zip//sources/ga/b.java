package ga;

import android.content.Context;
import android.content.Intent;
import w6.i0;
import z6.a;

public class b extends a {
    public b(String str) {
        e(str);
    }

    public Intent a(Context context) {
        Intent intent = new Intent();
        intent.setPackage(context.getPackageName());
        intent.setAction(i0.d());
        return intent;
    }

    public boolean c(Context context) {
        return !a7.b.e("security.remove");
    }
}
