package q9;

import java.util.HashMap;
import java.util.function.Supplier;

public final /* synthetic */ class f implements Supplier {
    public final Object get() {
        return new HashMap();
    }
}
