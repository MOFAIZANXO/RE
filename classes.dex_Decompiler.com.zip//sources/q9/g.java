package q9;

import com.samsung.android.sm.score.data.DetailItem;
import java.util.function.Function;

public final /* synthetic */ class g implements Function {
    public final Object apply(Object obj) {
        return ((DetailItem) obj).f5332i;
    }
}
