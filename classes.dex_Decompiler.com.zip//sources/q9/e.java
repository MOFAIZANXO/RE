package q9;

import com.samsung.android.sm.score.data.DetailItem;
import java.util.function.Function;

public final /* synthetic */ class e implements Function {
    public final Object apply(Object obj) {
        return Integer.valueOf(((DetailItem) obj).f5328b);
    }
}
