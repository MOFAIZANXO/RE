package q9;

import android.content.Context;
import android.content.Intent;
import d8.c;

public class b implements d {
    public int a() {
        return c.sb_bottom_button_manage_storage;
    }

    public int b() {
        return 2131952698;
    }

    public Intent c(Context context) {
        Intent intent = new Intent("com.samsung.android.sm.ACTION_STORAGE");
        intent.setPackage(context.getPackageName());
        return intent;
    }

    public int d() {
        return 2131952207;
    }

    public int e() {
        return 2131952199;
    }
}
