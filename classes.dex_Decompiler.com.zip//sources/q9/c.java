package q9;

public class c implements h {
    public int b() {
        return 225;
    }

    public int e() {
        return 2131952213;
    }

    public int g() {
        return 2131953137;
    }

    public int i() {
        return d8.c.uninstall;
    }
}
