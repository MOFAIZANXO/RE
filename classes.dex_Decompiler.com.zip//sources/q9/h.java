package q9;

import android.content.Intent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.stream.Collectors;
import p5.x;

public interface h {
    int b();

    HashMap c(ArrayList arrayList) {
        return (HashMap) arrayList.stream().collect(Collectors.groupingBy(new e(), new f(), Collectors.mapping(new g(), Collectors.toCollection(new x()))));
    }

    int e();

    int g();

    int i();

    Intent j(ArrayList arrayList) {
        Intent intent = new Intent("com.samsung.android.sm.ACTION_MANUAL_FIX_ANIM");
        intent.setPackage(c7.h.f3267a);
        intent.putExtra("manualFixItemMap", c(arrayList));
        intent.putExtra("actionType", b());
        return intent;
    }
}
