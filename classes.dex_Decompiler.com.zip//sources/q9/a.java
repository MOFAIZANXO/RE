package q9;

public class a implements h {
    public int b() {
        return 255;
    }

    public int e() {
        return 2131952210;
    }

    public int g() {
        return 2131951866;
    }

    public int i() {
        return 2131952696;
    }
}
