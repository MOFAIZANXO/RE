package q9;

import android.content.Context;
import android.content.Intent;

public interface d {
    int a();

    int b();

    Intent c(Context context);

    int d();

    int e();
}
