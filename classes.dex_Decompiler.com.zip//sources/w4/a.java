package w4;

import com.samsung.android.sm.anomaly.data.AnomalyAppData;
import java.util.function.Function;

public final /* synthetic */ class a implements Function {
    public final Object apply(Object obj) {
        return ((AnomalyAppData) obj).z();
    }
}
