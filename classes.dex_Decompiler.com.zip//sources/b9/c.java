package b9;

import ac.p;
import android.app.Application;
import android.database.ContentObserver;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.f0;
import b7.e;
import hc.d0;
import hc.i1;
import java.util.List;
import kotlin.jvm.internal.g;
import qb.k;
import qb.r;
import u8.s;
import ub.l;

public final class c extends androidx.lifecycle.a {

    /* renamed from: k  reason: collision with root package name */
    public static final a f2866k = new a((g) null);

    /* renamed from: h  reason: collision with root package name */
    public int f2867h = 1000;

    /* renamed from: i  reason: collision with root package name */
    public s f2868i;

    /* renamed from: j  reason: collision with root package name */
    public final ContentObserver f2869j = new e(this, new Handler(Looper.getMainLooper()));

    public static final class a {
        public a() {
        }

        public /* synthetic */ a(g gVar) {
            this();
        }
    }

    public static final class b extends l implements p {

        /* renamed from: a  reason: collision with root package name */
        public int f2870a;

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ c f2871b;

        /* renamed from: f  reason: collision with root package name */
        public final /* synthetic */ List f2872f;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public b(c cVar, List list, sb.d dVar) {
            super(2, dVar);
            this.f2871b = cVar;
            this.f2872f = list;
        }

        public final sb.d create(Object obj, sb.d dVar) {
            return new b(this.f2871b, this.f2872f, dVar);
        }

        public final Object invoke(d0 d0Var, sb.d dVar) {
            return ((b) create(d0Var, dVar)).invokeSuspend(r.f9409a);
        }

        public final Object invokeSuspend(Object obj) {
            Object c10 = tb.c.c();
            int i10 = this.f2870a;
            if (i10 == 0) {
                k.b(obj);
                s t10 = this.f2871b.f2868i;
                List list = this.f2872f;
                this.f2870a = 1;
                if (t10.m(list, this) == c10) {
                    return c10;
                }
            } else if (i10 == 1) {
                k.b(obj);
            } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return r.f9409a;
        }
    }

    /* renamed from: b9.c$c  reason: collision with other inner class name */
    public static final class C0051c extends l implements p {

        /* renamed from: a  reason: collision with root package name */
        public int f2873a;

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ c f2874b;

        /* renamed from: f  reason: collision with root package name */
        public final /* synthetic */ List f2875f;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public C0051c(c cVar, List list, sb.d dVar) {
            super(2, dVar);
            this.f2874b = cVar;
            this.f2875f = list;
        }

        public final sb.d create(Object obj, sb.d dVar) {
            return new C0051c(this.f2874b, this.f2875f, dVar);
        }

        public final Object invoke(d0 d0Var, sb.d dVar) {
            return ((C0051c) create(d0Var, dVar)).invokeSuspend(r.f9409a);
        }

        public final Object invokeSuspend(Object obj) {
            Object c10 = tb.c.c();
            int i10 = this.f2873a;
            if (i10 == 0) {
                k.b(obj);
                s t10 = this.f2874b.f2868i;
                List list = this.f2875f;
                this.f2873a = 1;
                if (t10.f(list, this) == c10) {
                    return c10;
                }
            } else if (i10 == 1) {
                k.b(obj);
            } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return r.f9409a;
        }
    }

    public static final class d extends l implements p {

        /* renamed from: a  reason: collision with root package name */
        public int f2876a;

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ c f2877b;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public d(c cVar, sb.d dVar) {
            super(2, dVar);
            this.f2877b = cVar;
        }

        public final sb.d create(Object obj, sb.d dVar) {
            return new d(this.f2877b, dVar);
        }

        public final Object invoke(d0 d0Var, sb.d dVar) {
            return ((d) create(d0Var, dVar)).invokeSuspend(r.f9409a);
        }

        public final Object invokeSuspend(Object obj) {
            Object c10 = tb.c.c();
            int i10 = this.f2876a;
            if (i10 == 0) {
                k.b(obj);
                if (this.f2877b.f2867h != 1001) {
                    s t10 = this.f2877b.f2868i;
                    this.f2876a = 1;
                    if (t10.p(this) == c10) {
                        return c10;
                    }
                } else {
                    s t11 = this.f2877b.f2868i;
                    this.f2876a = 2;
                    if (t11.q(this) == c10) {
                        return c10;
                    }
                }
            } else if (i10 == 1 || i10 == 2) {
                k.b(obj);
            } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return r.f9409a;
        }
    }

    public static final class e extends ContentObserver {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ c f2878a;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public e(c cVar, Handler handler) {
            super(handler);
            this.f2878a = cVar;
        }

        public void onChange(boolean z10) {
            super.onChange(z10);
            int s10 = this.f2878a.f2867h;
            Log.i("ExceptedAppsListViewModel", "onChange reloadData --mode--: " + s10);
            this.f2878a.z();
        }
    }

    public static final class f extends l implements p {

        /* renamed from: a  reason: collision with root package name */
        public int f2879a;

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ c f2880b;

        /* renamed from: f  reason: collision with root package name */
        public final /* synthetic */ String f2881f;

        /* renamed from: g  reason: collision with root package name */
        public final /* synthetic */ String f2882g;

        /* renamed from: h  reason: collision with root package name */
        public final /* synthetic */ List f2883h;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public f(c cVar, String str, String str2, List list, sb.d dVar) {
            super(2, dVar);
            this.f2880b = cVar;
            this.f2881f = str;
            this.f2882g = str2;
            this.f2883h = list;
        }

        public final sb.d create(Object obj, sb.d dVar) {
            return new f(this.f2880b, this.f2881f, this.f2882g, this.f2883h, dVar);
        }

        public final Object invoke(d0 d0Var, sb.d dVar) {
            return ((f) create(d0Var, dVar)).invokeSuspend(r.f9409a);
        }

        public final Object invokeSuspend(Object obj) {
            Object c10 = tb.c.c();
            int i10 = this.f2879a;
            if (i10 == 0) {
                k.b(obj);
                s t10 = this.f2880b.f2868i;
                String str = this.f2881f;
                String str2 = this.f2882g;
                List list = this.f2883h;
                this.f2879a = 1;
                if (t10.s(str, str2, list, this) == c10) {
                    return c10;
                }
            } else if (i10 == 1) {
                k.b(obj);
            } else {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            return r.f9409a;
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public c(Application application) {
        super(application);
        kotlin.jvm.internal.l.e(application, "application");
        this.f2868i = new s(application);
        A();
    }

    public final void A() {
        r();
        r().getContentResolver().registerContentObserver(e.g.f2844a, true, this.f2869j);
    }

    public final void B(String str, String str2, List list) {
        kotlin.jvm.internal.l.e(list, "exceptedAppsList");
        i1 unused = hc.g.b(f0.a(this), (sb.g) null, (hc.f0) null, new f(this, str, str2, list, (sb.d) null), 3, (Object) null);
    }

    public final void C(int i10) {
        this.f2867h = i10;
    }

    public final void D() {
        if (r().getContentResolver() != null) {
            Log.i("ExceptedAppsListViewModel", "unregister ContentObserver");
            r().getContentResolver().unregisterContentObserver(this.f2869j);
        }
    }

    public void p() {
        Log.d("ExceptedAppsListViewModel", "onCleared");
        D();
        super.p();
    }

    public final void u(List list) {
        kotlin.jvm.internal.l.e(list, "appData");
        i1 unused = hc.g.b(f0.a(this), (sb.g) null, (hc.f0) null, new b(this, list, (sb.d) null), 3, (Object) null);
    }

    public final void v(List list) {
        kotlin.jvm.internal.l.e(list, "appData");
        i1 unused = hc.g.b(f0.a(this), (sb.g) null, (hc.f0) null, new C0051c(this, list, (sb.d) null), 3, (Object) null);
    }

    public final LiveData w() {
        return this.f2868i.g();
    }

    public final int x() {
        return this.f2867h;
    }

    public final LiveData y() {
        return this.f2868i.k();
    }

    public final void z() {
        Log.i("ExceptedAppsListViewModel", "loadData: ");
        i1 unused = hc.g.b(f0.a(this), (sb.g) null, (hc.f0) null, new d(this, (sb.d) null), 3, (Object) null);
    }
}
