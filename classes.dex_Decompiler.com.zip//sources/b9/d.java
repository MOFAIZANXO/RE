package b9;

import androidx.lifecycle.q;
import androidx.lifecycle.t;
import w8.g;

public final /* synthetic */ class d implements t {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ q f2884a;

    public /* synthetic */ d(q qVar) {
        this.f2884a = qVar;
    }

    public final void a(Object obj) {
        this.f2884a.u((g) obj);
    }
}
