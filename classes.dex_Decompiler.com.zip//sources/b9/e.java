package b9;

import android.app.Application;
import android.database.ContentObserver;
import android.os.Handler;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.q;
import b7.e;
import com.samsung.android.sm.core.data.PkgUid;
import java.util.Objects;
import u8.w;

public class e extends androidx.lifecycle.a {

    /* renamed from: h  reason: collision with root package name */
    public final q f2885h;

    /* renamed from: i  reason: collision with root package name */
    public w f2886i;

    /* renamed from: j  reason: collision with root package name */
    public ContentObserver f2887j = new a(new Handler());

    public class a extends ContentObserver {
        public a(Handler handler) {
            super(handler);
        }

        public void onChange(boolean z10) {
            super.onChange(z10);
            e.this.f2886i.g();
        }
    }

    public e(Application application) {
        super(application);
        q qVar = new q();
        this.f2885h = qVar;
        qVar.u((Object) null);
        w wVar = new w(application.getApplicationContext());
        this.f2886i = wVar;
        wVar.g();
        LiveData e10 = this.f2886i.e();
        Objects.requireNonNull(qVar);
        qVar.v(e10, new d(qVar));
        r().getContentResolver().registerContentObserver(e.b.f2839a, true, this.f2887j);
    }

    public void p() {
        if (r().getContentResolver() != null) {
            r().getContentResolver().unregisterContentObserver(this.f2887j);
        }
        super.p();
    }

    public LiveData t() {
        return this.f2885h;
    }

    public void u(PkgUid pkgUid) {
        this.f2886i.h(pkgUid);
    }

    public void v() {
        this.f2886i.g();
    }
}
