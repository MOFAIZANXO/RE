package b9;

import android.app.Application;
import androidx.lifecycle.a;
import androidx.lifecycle.s;
import u8.q;

public class b extends a {

    /* renamed from: h  reason: collision with root package name */
    public q f2865h;

    public b(Application application) {
        super(application);
        this.f2865h = new q(application);
    }

    public s s() {
        return this.f2865h.a();
    }

    public void t() {
        this.f2865h.b();
    }
}
