package b9;

import android.app.Application;
import androidx.lifecycle.s;
import com.samsung.android.sm.core.data.PkgUid;
import u8.p;

public class a extends androidx.lifecycle.a {

    /* renamed from: h  reason: collision with root package name */
    public p f2864h;

    public a(Application application, boolean z10) {
        super(application);
        this.f2864h = new p(application, z10);
    }

    public void p() {
        this.f2864h.t();
        super.p();
    }

    public s s(int i10) {
        return this.f2864h.d(i10);
    }

    public void t(int i10) {
        this.f2864h.o(i10);
    }

    public void u() {
        this.f2864h.e();
    }

    public void v(PkgUid pkgUid) {
        this.f2864h.p(pkgUid);
    }

    public void w(String str, String str2, long j10) {
        this.f2864h.q(str, str2, j10);
    }

    public void x(String str) {
        this.f2864h.r(str);
    }

    public void y(boolean z10) {
        this.f2864h.s(z10);
    }
}
