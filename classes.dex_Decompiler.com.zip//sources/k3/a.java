package k3;

public interface a {
}
