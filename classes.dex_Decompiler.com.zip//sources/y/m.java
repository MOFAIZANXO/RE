package y;

import androidx.fragment.app.Fragment;
import kotlin.jvm.internal.l;

public abstract class m extends RuntimeException {

    /* renamed from: a  reason: collision with root package name */
    public final Fragment f11163a;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public m(Fragment fragment, String str) {
        super(str);
        l.e(fragment, "fragment");
        this.f11163a = fragment;
    }

    public final Fragment a() {
        return this.f11163a;
    }
}
