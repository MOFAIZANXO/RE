package y;

import androidx.fragment.app.Fragment;
import kotlin.jvm.internal.l;

public final class e extends h {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public e(Fragment fragment) {
        super(fragment, "Attempting to get retain instance for fragment " + fragment);
        l.e(fragment, "fragment");
    }
}
