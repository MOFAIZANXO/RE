package y;

public final /* synthetic */ class b implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ String f11142a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ m f11143b;

    public /* synthetic */ b(String str, m mVar) {
        this.f11142a = str;
        this.f11143b = mVar;
    }

    public final void run() {
        c.d(this.f11142a, this.f11143b);
    }
}
