package y;

import androidx.fragment.app.Fragment;

public abstract class l extends m {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public l(Fragment fragment, String str) {
        super(fragment, str);
        kotlin.jvm.internal.l.e(fragment, "fragment");
    }
}
