package y;

import androidx.fragment.app.Fragment;
import kotlin.jvm.internal.l;

public final class k extends m {

    /* renamed from: b  reason: collision with root package name */
    public final boolean f11162b;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public k(Fragment fragment, boolean z10) {
        super(fragment, "Attempting to set user visible hint to " + z10 + " for fragment " + fragment);
        l.e(fragment, "fragment");
        this.f11162b = z10;
    }
}
