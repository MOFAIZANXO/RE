package y;

import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import kotlin.jvm.internal.g;
import kotlin.jvm.internal.l;
import rb.d0;
import rb.f0;
import rb.u;

public final class c {

    /* renamed from: a  reason: collision with root package name */
    public static final c f11144a = new c();

    /* renamed from: b  reason: collision with root package name */
    public static C0150c f11145b = C0150c.f11156d;

    public enum a {
        PENALTY_LOG,
        PENALTY_DEATH,
        DETECT_FRAGMENT_REUSE,
        DETECT_FRAGMENT_TAG_USAGE,
        DETECT_RETAIN_INSTANCE_USAGE,
        DETECT_SET_USER_VISIBLE_HINT,
        DETECT_TARGET_FRAGMENT_USAGE,
        DETECT_WRONG_FRAGMENT_CONTAINER
    }

    public interface b {
    }

    /* renamed from: y.c$c  reason: collision with other inner class name */
    public static final class C0150c {

        /* renamed from: c  reason: collision with root package name */
        public static final a f11155c = new a((g) null);

        /* renamed from: d  reason: collision with root package name */
        public static final C0150c f11156d = new C0150c(f0.b(), (b) null, d0.d());

        /* renamed from: a  reason: collision with root package name */
        public final Set f11157a;

        /* renamed from: b  reason: collision with root package name */
        public final Map f11158b;

        /* renamed from: y.c$c$a */
        public static final class a {
            public a() {
            }

            public /* synthetic */ a(g gVar) {
                this();
            }
        }

        public C0150c(Set set, b bVar, Map map) {
            l.e(set, "flags");
            l.e(map, "allowedViolations");
            this.f11157a = set;
            LinkedHashMap linkedHashMap = new LinkedHashMap();
            for (Map.Entry entry : map.entrySet()) {
                linkedHashMap.put((String) entry.getKey(), (Set) entry.getValue());
            }
            this.f11158b = linkedHashMap;
        }

        public final Set a() {
            return this.f11157a;
        }

        public final b b() {
            return null;
        }

        public final Map c() {
            return this.f11158b;
        }
    }

    public static final void d(String str, m mVar) {
        l.e(mVar, "$violation");
        Log.e("FragmentStrictMode", "Policy violation with PENALTY_DEATH in " + str, mVar);
        throw mVar;
    }

    public static final void f(Fragment fragment, String str) {
        l.e(fragment, "fragment");
        l.e(str, "previousFragmentId");
        a aVar = new a(fragment, str);
        c cVar = f11144a;
        cVar.e(aVar);
        C0150c b10 = cVar.b(fragment);
        if (b10.a().contains(a.DETECT_FRAGMENT_REUSE) && cVar.p(b10, fragment.getClass(), aVar.getClass())) {
            cVar.c(b10, aVar);
        }
    }

    public static final void g(Fragment fragment, ViewGroup viewGroup) {
        l.e(fragment, "fragment");
        d dVar = new d(fragment, viewGroup);
        c cVar = f11144a;
        cVar.e(dVar);
        C0150c b10 = cVar.b(fragment);
        if (b10.a().contains(a.DETECT_FRAGMENT_TAG_USAGE) && cVar.p(b10, fragment.getClass(), dVar.getClass())) {
            cVar.c(b10, dVar);
        }
    }

    public static final void h(Fragment fragment) {
        l.e(fragment, "fragment");
        e eVar = new e(fragment);
        c cVar = f11144a;
        cVar.e(eVar);
        C0150c b10 = cVar.b(fragment);
        if (b10.a().contains(a.DETECT_RETAIN_INSTANCE_USAGE) && cVar.p(b10, fragment.getClass(), eVar.getClass())) {
            cVar.c(b10, eVar);
        }
    }

    public static final void i(Fragment fragment) {
        l.e(fragment, "fragment");
        f fVar = new f(fragment);
        c cVar = f11144a;
        cVar.e(fVar);
        C0150c b10 = cVar.b(fragment);
        if (b10.a().contains(a.DETECT_TARGET_FRAGMENT_USAGE) && cVar.p(b10, fragment.getClass(), fVar.getClass())) {
            cVar.c(b10, fVar);
        }
    }

    public static final void j(Fragment fragment) {
        l.e(fragment, "fragment");
        g gVar = new g(fragment);
        c cVar = f11144a;
        cVar.e(gVar);
        C0150c b10 = cVar.b(fragment);
        if (b10.a().contains(a.DETECT_TARGET_FRAGMENT_USAGE) && cVar.p(b10, fragment.getClass(), gVar.getClass())) {
            cVar.c(b10, gVar);
        }
    }

    public static final void k(Fragment fragment) {
        l.e(fragment, "fragment");
        i iVar = new i(fragment);
        c cVar = f11144a;
        cVar.e(iVar);
        C0150c b10 = cVar.b(fragment);
        if (b10.a().contains(a.DETECT_RETAIN_INSTANCE_USAGE) && cVar.p(b10, fragment.getClass(), iVar.getClass())) {
            cVar.c(b10, iVar);
        }
    }

    public static final void l(Fragment fragment, Fragment fragment2, int i10) {
        l.e(fragment, "violatingFragment");
        l.e(fragment2, "targetFragment");
        j jVar = new j(fragment, fragment2, i10);
        c cVar = f11144a;
        cVar.e(jVar);
        C0150c b10 = cVar.b(fragment);
        if (b10.a().contains(a.DETECT_TARGET_FRAGMENT_USAGE) && cVar.p(b10, fragment.getClass(), jVar.getClass())) {
            cVar.c(b10, jVar);
        }
    }

    public static final void m(Fragment fragment, boolean z10) {
        l.e(fragment, "fragment");
        k kVar = new k(fragment, z10);
        c cVar = f11144a;
        cVar.e(kVar);
        C0150c b10 = cVar.b(fragment);
        if (b10.a().contains(a.DETECT_SET_USER_VISIBLE_HINT) && cVar.p(b10, fragment.getClass(), kVar.getClass())) {
            cVar.c(b10, kVar);
        }
    }

    public static final void n(Fragment fragment, ViewGroup viewGroup) {
        l.e(fragment, "fragment");
        l.e(viewGroup, "container");
        n nVar = new n(fragment, viewGroup);
        c cVar = f11144a;
        cVar.e(nVar);
        C0150c b10 = cVar.b(fragment);
        if (b10.a().contains(a.DETECT_WRONG_FRAGMENT_CONTAINER) && cVar.p(b10, fragment.getClass(), nVar.getClass())) {
            cVar.c(b10, nVar);
        }
    }

    public final C0150c b(Fragment fragment) {
        while (fragment != null) {
            if (fragment.isAdded()) {
                FragmentManager parentFragmentManager = fragment.getParentFragmentManager();
                l.d(parentFragmentManager, "declaringFragment.parentFragmentManager");
                if (parentFragmentManager.A0() != null) {
                    C0150c A0 = parentFragmentManager.A0();
                    l.b(A0);
                    return A0;
                }
            }
            fragment = fragment.getParentFragment();
        }
        return f11145b;
    }

    public final void c(C0150c cVar, m mVar) {
        Fragment a10 = mVar.a();
        String name = a10.getClass().getName();
        if (cVar.a().contains(a.PENALTY_LOG)) {
            Log.d("FragmentStrictMode", "Policy violation in " + name, mVar);
        }
        cVar.b();
        if (cVar.a().contains(a.PENALTY_DEATH)) {
            o(a10, new b(name, mVar));
        }
    }

    public final void e(m mVar) {
        if (FragmentManager.H0(3)) {
            Log.d("FragmentManager", "StrictMode violation in " + mVar.a().getClass().getName(), mVar);
        }
    }

    public final void o(Fragment fragment, Runnable runnable) {
        if (fragment.isAdded()) {
            Handler g10 = fragment.getParentFragmentManager().u0().g();
            l.d(g10, "fragment.parentFragmentManager.host.handler");
            if (l.a(g10.getLooper(), Looper.myLooper())) {
                runnable.run();
            } else {
                g10.post(runnable);
            }
        } else {
            runnable.run();
        }
    }

    public final boolean p(C0150c cVar, Class cls, Class cls2) {
        Set set = (Set) cVar.c().get(cls.getName());
        if (set == null) {
            return true;
        }
        if (l.a(cls2.getSuperclass(), m.class) || !u.n(set, cls2.getSuperclass())) {
            return !set.contains(cls2);
        }
        return false;
    }
}
