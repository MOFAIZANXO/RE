package y;

import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import kotlin.jvm.internal.l;

public final class n extends m {

    /* renamed from: b  reason: collision with root package name */
    public final ViewGroup f11164b;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public n(Fragment fragment, ViewGroup viewGroup) {
        super(fragment, "Attempting to add fragment " + fragment + " to container " + viewGroup + " which is not a FragmentContainerView");
        l.e(fragment, "fragment");
        l.e(viewGroup, "container");
        this.f11164b = viewGroup;
    }
}
