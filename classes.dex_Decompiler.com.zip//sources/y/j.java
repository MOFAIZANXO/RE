package y;

import androidx.fragment.app.Fragment;
import kotlin.jvm.internal.l;

public final class j extends l {

    /* renamed from: b  reason: collision with root package name */
    public final Fragment f11160b;

    /* renamed from: f  reason: collision with root package name */
    public final int f11161f;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public j(Fragment fragment, Fragment fragment2, int i10) {
        super(fragment, "Attempting to set target fragment " + fragment2 + " with request code " + i10 + " for fragment " + fragment);
        l.e(fragment, "fragment");
        l.e(fragment2, "targetFragment");
        this.f11160b = fragment2;
        this.f11161f = i10;
    }
}
