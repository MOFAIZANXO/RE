package y;

import androidx.fragment.app.Fragment;
import kotlin.jvm.internal.l;

public abstract class h extends m {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public h(Fragment fragment, String str) {
        super(fragment, str);
        l.e(fragment, "fragment");
    }
}
