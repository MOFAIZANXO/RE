package y;

import androidx.fragment.app.Fragment;
import kotlin.jvm.internal.l;

public final class a extends m {

    /* renamed from: b  reason: collision with root package name */
    public final String f11141b;

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public a(Fragment fragment, String str) {
        super(fragment, "Attempting to reuse fragment " + fragment + " with previous ID " + str);
        l.e(fragment, "fragment");
        l.e(str, "previousFragmentId");
        this.f11141b = str;
    }
}
