package y;

import androidx.fragment.app.Fragment;
import kotlin.jvm.internal.l;

public final class i extends h {
    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public i(Fragment fragment) {
        super(fragment, "Attempting to set retain instance for fragment " + fragment);
        l.e(fragment, "fragment");
    }
}
