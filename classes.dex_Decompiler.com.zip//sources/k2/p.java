package k2;

import android.graphics.Path;
import com.airbnb.lottie.h;
import g2.b;
import g2.d;
import g2.f;
import h2.e;
import java.util.Collections;
import l2.c;
import n2.a;
import q3.g;

public abstract class p {

    /* renamed from: a  reason: collision with root package name */
    public static final c.a f7635a = c.a.a("nm", g.A, "o", "t", "s", "e", "r", "hd");

    /* renamed from: b  reason: collision with root package name */
    public static final c.a f7636b = c.a.a("p", "k");

    public static e a(c cVar, h hVar) {
        d dVar = null;
        Path.FillType fillType = Path.FillType.WINDING;
        String str = null;
        h2.g gVar = null;
        g2.c cVar2 = null;
        f fVar = null;
        f fVar2 = null;
        boolean z10 = false;
        while (cVar.k()) {
            switch (cVar.I(f7635a)) {
                case 0:
                    str = cVar.y();
                    break;
                case 1:
                    cVar.d();
                    int i10 = -1;
                    while (cVar.k()) {
                        int I = cVar.I(f7636b);
                        if (I == 0) {
                            i10 = cVar.q();
                        } else if (I != 1) {
                            cVar.K();
                            cVar.P();
                        } else {
                            cVar2 = d.g(cVar, hVar, i10);
                        }
                    }
                    cVar.f();
                    break;
                case 2:
                    dVar = d.h(cVar, hVar);
                    break;
                case 3:
                    gVar = cVar.q() == 1 ? h2.g.LINEAR : h2.g.RADIAL;
                    break;
                case 4:
                    fVar = d.i(cVar, hVar);
                    break;
                case 5:
                    fVar2 = d.i(cVar, hVar);
                    break;
                case 6:
                    fillType = cVar.q() == 1 ? Path.FillType.WINDING : Path.FillType.EVEN_ODD;
                    break;
                case 7:
                    z10 = cVar.m();
                    break;
                default:
                    cVar.K();
                    cVar.P();
                    break;
            }
        }
        return new e(str, gVar, fillType, cVar2, dVar == null ? new d(Collections.singletonList(new a(100))) : dVar, fVar, fVar2, (b) null, (b) null, z10);
    }
}
