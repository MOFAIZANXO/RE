package k2;

import android.graphics.Path;
import com.airbnb.lottie.h;
import g2.a;
import g2.d;
import h2.o;
import java.util.Collections;
import l2.c;

public abstract class i0 {

    /* renamed from: a  reason: collision with root package name */
    public static final c.a f7612a = c.a.a("nm", com.google.android.material.navigation.c.W, "o", "fillEnabled", "r", "hd");

    public static o a(c cVar, h hVar) {
        d dVar = null;
        String str = null;
        a aVar = null;
        boolean z10 = false;
        boolean z11 = false;
        int i10 = 1;
        while (cVar.k()) {
            int I = cVar.I(f7612a);
            if (I == 0) {
                str = cVar.y();
            } else if (I == 1) {
                aVar = d.c(cVar, hVar);
            } else if (I == 2) {
                dVar = d.h(cVar, hVar);
            } else if (I == 3) {
                z10 = cVar.m();
            } else if (I == 4) {
                i10 = cVar.q();
            } else if (I != 5) {
                cVar.K();
                cVar.P();
            } else {
                z11 = cVar.m();
            }
        }
        if (dVar == null) {
            dVar = new d(Collections.singletonList(new n2.a(100)));
        }
        return new o(str, z10, i10 == 1 ? Path.FillType.WINDING : Path.FillType.EVEN_ODD, aVar, dVar, z11);
    }
}
