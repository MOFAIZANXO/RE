package k2;

import android.graphics.Color;
import l2.c;

public class g implements n0 {

    /* renamed from: a  reason: collision with root package name */
    public static final g f7605a = new g();

    /* renamed from: b */
    public Integer a(c cVar, float f10) {
        boolean z10 = cVar.F() == c.b.BEGIN_ARRAY;
        if (z10) {
            cVar.c();
        }
        double o10 = cVar.o();
        double o11 = cVar.o();
        double o12 = cVar.o();
        double o13 = cVar.F() == c.b.NUMBER ? cVar.o() : 1.0d;
        if (z10) {
            cVar.e();
        }
        if (o10 <= 1.0d && o11 <= 1.0d && o12 <= 1.0d) {
            o10 *= 255.0d;
            o11 *= 255.0d;
            o12 *= 255.0d;
            if (o13 <= 1.0d) {
                o13 *= 255.0d;
            }
        }
        return Integer.valueOf(Color.argb((int) o13, (int) o10, (int) o11, (int) o12));
    }
}
