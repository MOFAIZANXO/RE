package k2;

import com.airbnb.lottie.h;
import d2.i;
import java.util.ArrayList;
import java.util.List;
import l2.c;
import n2.a;

public abstract class u {

    /* renamed from: a  reason: collision with root package name */
    public static c.a f7647a = c.a.a("k");

    public static List a(c cVar, h hVar, float f10, n0 n0Var, boolean z10) {
        ArrayList arrayList = new ArrayList();
        if (cVar.F() == c.b.STRING) {
            hVar.a("Lottie doesn't support expressions.");
            return arrayList;
        }
        cVar.d();
        while (cVar.k()) {
            if (cVar.I(f7647a) != 0) {
                cVar.P();
            } else if (cVar.F() == c.b.BEGIN_ARRAY) {
                cVar.c();
                if (cVar.F() == c.b.NUMBER) {
                    arrayList.add(t.c(cVar, hVar, f10, n0Var, false, z10));
                } else {
                    while (cVar.k()) {
                        arrayList.add(t.c(cVar, hVar, f10, n0Var, true, z10));
                    }
                }
                cVar.e();
            } else {
                arrayList.add(t.c(cVar, hVar, f10, n0Var, false, z10));
            }
        }
        cVar.f();
        b(arrayList);
        return arrayList;
    }

    public static void b(List list) {
        int i10;
        Object obj;
        int size = list.size();
        int i11 = 0;
        while (true) {
            i10 = size - 1;
            if (i11 >= i10) {
                break;
            }
            a aVar = (a) list.get(i11);
            i11++;
            a aVar2 = (a) list.get(i11);
            aVar.f8408h = Float.valueOf(aVar2.f8407g);
            if (aVar.f8403c == null && (obj = aVar2.f8402b) != null) {
                aVar.f8403c = obj;
                if (aVar instanceof i) {
                    ((i) aVar).i();
                }
            }
        }
        a aVar3 = (a) list.get(i10);
        if ((aVar3.f8402b == null || aVar3.f8403c == null) && list.size() > 1) {
            list.remove(aVar3);
        }
    }
}
