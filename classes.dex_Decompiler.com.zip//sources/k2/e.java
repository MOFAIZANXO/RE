package k2;

import com.airbnb.lottie.h;
import h2.a;
import l2.c;

public abstract class e {

    /* renamed from: a  reason: collision with root package name */
    public static final c.a f7600a = c.a.a("ef");

    /* renamed from: b  reason: collision with root package name */
    public static final c.a f7601b = c.a.a("ty", "v");

    public static a a(c cVar, h hVar) {
        cVar.d();
        a aVar = null;
        while (true) {
            boolean z10 = false;
            while (true) {
                if (cVar.k()) {
                    int I = cVar.I(f7601b);
                    if (I != 0) {
                        if (I != 1) {
                            cVar.K();
                            cVar.P();
                        } else if (z10) {
                            aVar = new a(d.e(cVar, hVar));
                        } else {
                            cVar.P();
                        }
                    } else if (cVar.q() == 0) {
                        z10 = true;
                    }
                } else {
                    cVar.f();
                    return aVar;
                }
            }
        }
    }

    public static a b(c cVar, h hVar) {
        a aVar = null;
        while (cVar.k()) {
            if (cVar.I(f7600a) != 0) {
                cVar.K();
                cVar.P();
            } else {
                cVar.c();
                while (cVar.k()) {
                    a a10 = a(cVar, hVar);
                    if (a10 != null) {
                        aVar = a10;
                    }
                }
                cVar.e();
            }
        }
        return aVar;
    }
}
