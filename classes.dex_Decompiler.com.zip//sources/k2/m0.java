package k2;

import com.airbnb.lottie.h;
import g2.b;
import h2.s;
import l2.c;

public abstract class m0 {

    /* renamed from: a  reason: collision with root package name */
    public static final c.a f7632a = c.a.a("s", "e", "o", "nm", "m", "hd");

    public static s a(c cVar, h hVar) {
        String str = null;
        s.a aVar = null;
        b bVar = null;
        b bVar2 = null;
        b bVar3 = null;
        boolean z10 = false;
        while (cVar.k()) {
            int I = cVar.I(f7632a);
            if (I == 0) {
                bVar = d.f(cVar, hVar, false);
            } else if (I == 1) {
                bVar2 = d.f(cVar, hVar, false);
            } else if (I == 2) {
                bVar3 = d.f(cVar, hVar, false);
            } else if (I == 3) {
                str = cVar.y();
            } else if (I == 4) {
                aVar = s.a.a(cVar.q());
            } else if (I != 5) {
                cVar.P();
            } else {
                z10 = cVar.m();
            }
        }
        return new s(str, aVar, bVar, bVar2, bVar3, z10);
    }
}
