package k2;

import com.airbnb.lottie.h;
import h2.q;
import l2.c;

public abstract class k0 {

    /* renamed from: a  reason: collision with root package name */
    public static c.a f7626a = c.a.a("nm", "ind", "ks", "hd");

    public static q a(c cVar, h hVar) {
        String str = null;
        int i10 = 0;
        boolean z10 = false;
        g2.h hVar2 = null;
        while (cVar.k()) {
            int I = cVar.I(f7626a);
            if (I == 0) {
                str = cVar.y();
            } else if (I == 1) {
                i10 = cVar.q();
            } else if (I == 2) {
                hVar2 = d.k(cVar, hVar);
            } else if (I != 3) {
                cVar.P();
            } else {
                z10 = cVar.m();
            }
        }
        return new q(str, i10, hVar2, z10);
    }
}
