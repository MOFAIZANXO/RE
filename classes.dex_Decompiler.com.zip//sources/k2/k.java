package k2;

import com.airbnb.lottie.h;
import g2.a;
import g2.b;
import l2.c;

public class k {

    /* renamed from: f  reason: collision with root package name */
    public static final c.a f7619f = c.a.a("ef");

    /* renamed from: g  reason: collision with root package name */
    public static final c.a f7620g = c.a.a("nm", "v");

    /* renamed from: a  reason: collision with root package name */
    public a f7621a;

    /* renamed from: b  reason: collision with root package name */
    public b f7622b;

    /* renamed from: c  reason: collision with root package name */
    public b f7623c;

    /* renamed from: d  reason: collision with root package name */
    public b f7624d;

    /* renamed from: e  reason: collision with root package name */
    public b f7625e;

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Code restructure failed: missing block: B:21:0x0052, code lost:
        if (r0.equals("Opacity") == false) goto L_0x0029;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void a(l2.c r6, com.airbnb.lottie.h r7) {
        /*
            r5 = this;
            r6.d()
            java.lang.String r0 = ""
        L_0x0005:
            boolean r1 = r6.k()
            if (r1 == 0) goto L_0x0090
            l2.c$a r1 = f7620g
            int r1 = r6.I(r1)
            if (r1 == 0) goto L_0x008a
            r2 = 1
            if (r1 == r2) goto L_0x001d
            r6.K()
            r6.P()
            goto L_0x0005
        L_0x001d:
            r0.hashCode()
            int r1 = r0.hashCode()
            r3 = 0
            r4 = -1
            switch(r1) {
                case 353103893: goto L_0x0055;
                case 397447147: goto L_0x004c;
                case 1041377119: goto L_0x0041;
                case 1379387491: goto L_0x0036;
                case 1383710113: goto L_0x002b;
                default: goto L_0x0029;
            }
        L_0x0029:
            r2 = r4
            goto L_0x005f
        L_0x002b:
            java.lang.String r1 = "Softness"
            boolean r1 = r0.equals(r1)
            if (r1 != 0) goto L_0x0034
            goto L_0x0029
        L_0x0034:
            r2 = 4
            goto L_0x005f
        L_0x0036:
            java.lang.String r1 = "Shadow Color"
            boolean r1 = r0.equals(r1)
            if (r1 != 0) goto L_0x003f
            goto L_0x0029
        L_0x003f:
            r2 = 3
            goto L_0x005f
        L_0x0041:
            java.lang.String r1 = "Direction"
            boolean r1 = r0.equals(r1)
            if (r1 != 0) goto L_0x004a
            goto L_0x0029
        L_0x004a:
            r2 = 2
            goto L_0x005f
        L_0x004c:
            java.lang.String r1 = "Opacity"
            boolean r1 = r0.equals(r1)
            if (r1 != 0) goto L_0x005f
            goto L_0x0029
        L_0x0055:
            java.lang.String r1 = "Distance"
            boolean r1 = r0.equals(r1)
            if (r1 != 0) goto L_0x005e
            goto L_0x0029
        L_0x005e:
            r2 = r3
        L_0x005f:
            switch(r2) {
                case 0: goto L_0x0082;
                case 1: goto L_0x007b;
                case 2: goto L_0x0074;
                case 3: goto L_0x006d;
                case 4: goto L_0x0066;
                default: goto L_0x0062;
            }
        L_0x0062:
            r6.P()
            goto L_0x0005
        L_0x0066:
            g2.b r1 = k2.d.e(r6, r7)
            r5.f7625e = r1
            goto L_0x0005
        L_0x006d:
            g2.a r1 = k2.d.c(r6, r7)
            r5.f7621a = r1
            goto L_0x0005
        L_0x0074:
            g2.b r1 = k2.d.f(r6, r7, r3)
            r5.f7623c = r1
            goto L_0x0005
        L_0x007b:
            g2.b r1 = k2.d.f(r6, r7, r3)
            r5.f7622b = r1
            goto L_0x0005
        L_0x0082:
            g2.b r1 = k2.d.e(r6, r7)
            r5.f7624d = r1
            goto L_0x0005
        L_0x008a:
            java.lang.String r0 = r6.y()
            goto L_0x0005
        L_0x0090:
            r6.f()
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: k2.k.a(l2.c, com.airbnb.lottie.h):void");
    }

    public j b(c cVar, h hVar) {
        b bVar;
        b bVar2;
        b bVar3;
        b bVar4;
        while (cVar.k()) {
            if (cVar.I(f7619f) != 0) {
                cVar.K();
                cVar.P();
            } else {
                cVar.c();
                while (cVar.k()) {
                    a(cVar, hVar);
                }
                cVar.e();
            }
        }
        a aVar = this.f7621a;
        if (aVar == null || (bVar = this.f7622b) == null || (bVar2 = this.f7623c) == null || (bVar3 = this.f7624d) == null || (bVar4 = this.f7625e) == null) {
            return null;
        }
        return new j(aVar, bVar, bVar2, bVar3, bVar4);
    }
}
