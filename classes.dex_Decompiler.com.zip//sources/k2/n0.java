package k2;

import l2.c;

public interface n0 {
    Object a(c cVar, float f10);
}
