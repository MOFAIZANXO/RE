package k2;

import com.airbnb.lottie.h;
import g2.b;
import h2.f;
import h2.r;
import java.util.ArrayList;
import java.util.Collections;
import l2.c;
import n2.a;
import q3.g;
import q5.d;

public abstract class q {

    /* renamed from: a  reason: collision with root package name */
    public static final c.a f7637a = c.a.a("nm", g.A, "o", "t", "s", "e", "w", "lc", "lj", "ml", "hd", d.f9357g);

    /* renamed from: b  reason: collision with root package name */
    public static final c.a f7638b = c.a.a("p", "k");

    /* renamed from: c  reason: collision with root package name */
    public static final c.a f7639c = c.a.a("n", "v");

    public static f a(c cVar, h hVar) {
        String str;
        g2.c cVar2;
        c cVar3 = cVar;
        h hVar2 = hVar;
        ArrayList arrayList = new ArrayList();
        float f10 = 0.0f;
        String str2 = null;
        h2.g gVar = null;
        g2.c cVar4 = null;
        g2.f fVar = null;
        g2.f fVar2 = null;
        b bVar = null;
        r.b bVar2 = null;
        r.c cVar5 = null;
        b bVar3 = null;
        boolean z10 = false;
        g2.d dVar = null;
        while (cVar.k()) {
            switch (cVar3.I(f7637a)) {
                case 0:
                    str2 = cVar.y();
                    continue;
                case 1:
                    str = str2;
                    cVar.d();
                    int i10 = -1;
                    while (cVar.k()) {
                        int I = cVar3.I(f7638b);
                        if (I != 0) {
                            cVar2 = cVar4;
                            if (I != 1) {
                                cVar.K();
                                cVar.P();
                            } else {
                                cVar4 = d.g(cVar3, hVar2, i10);
                            }
                        } else {
                            cVar2 = cVar4;
                            i10 = cVar.q();
                        }
                        cVar4 = cVar2;
                    }
                    g2.c cVar6 = cVar4;
                    cVar.f();
                    break;
                case 2:
                    String str3 = str2;
                    dVar = d.h(cVar, hVar);
                    continue;
                case 3:
                    str = str2;
                    gVar = cVar.q() == 1 ? h2.g.LINEAR : h2.g.RADIAL;
                    break;
                case 4:
                    String str4 = str2;
                    fVar = d.i(cVar, hVar);
                    continue;
                case 5:
                    String str5 = str2;
                    fVar2 = d.i(cVar, hVar);
                    continue;
                case 6:
                    String str6 = str2;
                    bVar = d.e(cVar, hVar);
                    continue;
                case 7:
                    str = str2;
                    bVar2 = r.b.values()[cVar.q() - 1];
                    break;
                case 8:
                    str = str2;
                    cVar5 = r.c.values()[cVar.q() - 1];
                    break;
                case 9:
                    str = str2;
                    f10 = (float) cVar.o();
                    break;
                case 10:
                    z10 = cVar.m();
                    continue;
                case 11:
                    cVar.c();
                    while (cVar.k()) {
                        cVar.d();
                        String str7 = null;
                        b bVar4 = null;
                        while (cVar.k()) {
                            int I2 = cVar3.I(f7639c);
                            if (I2 != 0) {
                                b bVar5 = bVar3;
                                if (I2 != 1) {
                                    cVar.K();
                                    cVar.P();
                                } else {
                                    bVar4 = d.e(cVar, hVar);
                                }
                                bVar3 = bVar5;
                            } else {
                                b bVar6 = bVar3;
                                str7 = cVar.y();
                            }
                        }
                        b bVar7 = bVar3;
                        cVar.f();
                        if (str7.equals("o")) {
                            bVar3 = bVar4;
                        } else {
                            if (str7.equals(d.f9357g) || str7.equals(g.A)) {
                                hVar2.u(true);
                                arrayList.add(bVar4);
                            }
                            bVar3 = bVar7;
                        }
                    }
                    b bVar8 = bVar3;
                    cVar.e();
                    if (arrayList.size() == 1) {
                        arrayList.add((b) arrayList.get(0));
                    }
                    bVar3 = bVar8;
                    continue;
                default:
                    String str8 = str2;
                    cVar.K();
                    cVar.P();
                    continue;
            }
            str2 = str;
        }
        String str9 = str2;
        if (dVar == null) {
            dVar = new g2.d(Collections.singletonList(new a(100)));
        }
        return new f(str9, gVar, cVar4, dVar, fVar, fVar2, bVar, bVar2, cVar5, f10, arrayList, bVar3, z10);
    }
}
