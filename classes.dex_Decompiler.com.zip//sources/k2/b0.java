package k2;

import android.graphics.PointF;
import l2.c;

public class b0 implements n0 {

    /* renamed from: a  reason: collision with root package name */
    public static final b0 f7595a = new b0();

    /* renamed from: b */
    public PointF a(c cVar, float f10) {
        c.b F = cVar.F();
        if (F == c.b.BEGIN_ARRAY) {
            return s.e(cVar, f10);
        }
        if (F == c.b.BEGIN_OBJECT) {
            return s.e(cVar, f10);
        }
        if (F == c.b.NUMBER) {
            PointF pointF = new PointF(((float) cVar.o()) * f10, ((float) cVar.o()) * f10);
            while (cVar.k()) {
                cVar.P();
            }
            return pointF;
        }
        throw new IllegalArgumentException("Cannot convert json to point. Next token is " + F);
    }
}
