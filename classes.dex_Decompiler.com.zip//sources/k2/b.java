package k2;

import com.airbnb.lottie.h;
import g2.k;
import l2.c;
import m4.a;

public abstract class b {

    /* renamed from: a  reason: collision with root package name */
    public static final c.a f7593a = c.a.a(a.f8143a);

    /* renamed from: b  reason: collision with root package name */
    public static final c.a f7594b = c.a.a("fc", "sc", "sw", "t");

    public static k a(c cVar, h hVar) {
        cVar.d();
        k kVar = null;
        while (cVar.k()) {
            if (cVar.I(f7593a) != 0) {
                cVar.K();
                cVar.P();
            } else {
                kVar = b(cVar, hVar);
            }
        }
        cVar.f();
        return kVar == null ? new k((g2.a) null, (g2.a) null, (g2.b) null, (g2.b) null) : kVar;
    }

    public static k b(c cVar, h hVar) {
        cVar.d();
        g2.a aVar = null;
        g2.a aVar2 = null;
        g2.b bVar = null;
        g2.b bVar2 = null;
        while (cVar.k()) {
            int I = cVar.I(f7594b);
            if (I == 0) {
                aVar = d.c(cVar, hVar);
            } else if (I == 1) {
                aVar2 = d.c(cVar, hVar);
            } else if (I == 2) {
                bVar = d.e(cVar, hVar);
            } else if (I != 3) {
                cVar.K();
                cVar.P();
            } else {
                bVar2 = d.e(cVar, hVar);
            }
        }
        cVar.f();
        return new k(aVar, aVar2, bVar, bVar2);
    }
}
