package k2;

import android.graphics.PointF;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import androidx.core.view.animation.PathInterpolatorCompat;
import h.h;
import java.lang.ref.WeakReference;
import l2.c;
import m2.g;
import n2.a;

public abstract class t {

    /* renamed from: a  reason: collision with root package name */
    public static final Interpolator f7643a = new LinearInterpolator();

    /* renamed from: b  reason: collision with root package name */
    public static h f7644b;

    /* renamed from: c  reason: collision with root package name */
    public static c.a f7645c = c.a.a("t", "s", "e", "o", "i", "h", "to", "ti");

    /* renamed from: d  reason: collision with root package name */
    public static c.a f7646d = c.a.a("x", "y");

    public static WeakReference a(int i10) {
        WeakReference weakReference;
        synchronized (t.class) {
            weakReference = (WeakReference) g().e(i10);
        }
        return weakReference;
    }

    public static Interpolator b(PointF pointF, PointF pointF2) {
        Interpolator interpolator;
        pointF.x = g.b(pointF.x, -1.0f, 1.0f);
        pointF.y = g.b(pointF.y, -100.0f, 100.0f);
        pointF2.x = g.b(pointF2.x, -1.0f, 1.0f);
        float b10 = g.b(pointF2.y, -100.0f, 100.0f);
        pointF2.y = b10;
        int i10 = m2.h.i(pointF.x, pointF.y, pointF2.x, b10);
        WeakReference a10 = a(i10);
        Interpolator interpolator2 = a10 != null ? (Interpolator) a10.get() : null;
        if (a10 == null || interpolator2 == null) {
            try {
                interpolator = PathInterpolatorCompat.create(pointF.x, pointF.y, pointF2.x, pointF2.y);
            } catch (IllegalArgumentException e10) {
                interpolator = "The Path cannot loop back on itself.".equals(e10.getMessage()) ? PathInterpolatorCompat.create(Math.min(pointF.x, 1.0f), pointF.y, Math.max(pointF2.x, 0.0f), pointF2.y) : new LinearInterpolator();
            }
            interpolator2 = interpolator;
            try {
                h(i10, new WeakReference(interpolator2));
            } catch (ArrayIndexOutOfBoundsException unused) {
            }
        }
        return interpolator2;
    }

    public static a c(c cVar, com.airbnb.lottie.h hVar, float f10, n0 n0Var, boolean z10, boolean z11) {
        return (!z10 || !z11) ? z10 ? d(hVar, cVar, f10, n0Var) : f(cVar, f10, n0Var) : e(hVar, cVar, f10, n0Var);
    }

    public static a d(com.airbnb.lottie.h hVar, c cVar, float f10, n0 n0Var) {
        Interpolator interpolator;
        Object obj;
        cVar.d();
        PointF pointF = null;
        Object obj2 = null;
        Object obj3 = null;
        PointF pointF2 = null;
        PointF pointF3 = null;
        float f11 = 0.0f;
        boolean z10 = false;
        PointF pointF4 = null;
        while (cVar.k()) {
            switch (cVar.I(f7645c)) {
                case 0:
                    f11 = (float) cVar.o();
                    break;
                case 1:
                    obj3 = n0Var.a(cVar, f10);
                    break;
                case 2:
                    obj2 = n0Var.a(cVar, f10);
                    break;
                case 3:
                    pointF = s.e(cVar, 1.0f);
                    break;
                case 4:
                    pointF4 = s.e(cVar, 1.0f);
                    break;
                case 5:
                    if (cVar.q() != 1) {
                        z10 = false;
                        break;
                    } else {
                        z10 = true;
                        break;
                    }
                case 6:
                    pointF2 = s.e(cVar, f10);
                    break;
                case 7:
                    pointF3 = s.e(cVar, f10);
                    break;
                default:
                    cVar.P();
                    break;
            }
        }
        cVar.f();
        if (z10) {
            interpolator = f7643a;
            obj = obj3;
        } else {
            interpolator = (pointF == null || pointF4 == null) ? f7643a : b(pointF, pointF4);
            obj = obj2;
        }
        a aVar = new a(hVar, obj3, obj, interpolator, f11, (Float) null);
        aVar.f8415o = pointF2;
        aVar.f8416p = pointF3;
        return aVar;
    }

    /* JADX WARNING: Can't fix incorrect switch cases order */
    /* JADX WARNING: Code restructure failed: missing block: B:68:0x017d, code lost:
        r14 = r3;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static n2.a e(com.airbnb.lottie.h r21, l2.c r22, float r23, k2.n0 r24) {
        /*
            r0 = r22
            r1 = r23
            r2 = r24
            r22.d()
            r3 = 0
            r6 = 0
            r7 = 0
            r8 = 0
            r9 = 0
            r10 = 0
            r11 = 0
            r12 = 0
            r13 = 0
            r14 = 0
            r15 = 0
            r16 = 0
        L_0x0016:
            boolean r17 = r22.k()
            if (r17 == 0) goto L_0x01a8
            l2.c$a r4 = f7645c
            int r4 = r0.I(r4)
            r5 = 1
            switch(r4) {
                case 0: goto L_0x019b;
                case 1: goto L_0x0191;
                case 2: goto L_0x0187;
                case 3: goto L_0x00f3;
                case 4: goto L_0x0044;
                case 5: goto L_0x003a;
                case 6: goto L_0x0035;
                case 7: goto L_0x0030;
                default: goto L_0x0026;
            }
        L_0x0026:
            r19 = r3
            r3 = r14
            r18 = r15
            r22.P()
            goto L_0x01a4
        L_0x0030:
            android.graphics.PointF r3 = k2.s.e(r22, r23)
            goto L_0x0016
        L_0x0035:
            android.graphics.PointF r15 = k2.s.e(r22, r23)
            goto L_0x0016
        L_0x003a:
            int r4 = r22.q()
            if (r4 != r5) goto L_0x0042
            r6 = r5
            goto L_0x0016
        L_0x0042:
            r6 = 0
            goto L_0x0016
        L_0x0044:
            l2.c$b r4 = r22.F()
            l2.c$b r5 = l2.c.b.BEGIN_OBJECT
            if (r4 != r5) goto L_0x00e8
            r22.d()
            r4 = 0
            r5 = 0
            r12 = 0
            r13 = 0
        L_0x0053:
            boolean r18 = r22.k()
            if (r18 == 0) goto L_0x00d2
            r18 = r15
            l2.c$a r15 = f7646d
            int r15 = r0.I(r15)
            if (r15 == 0) goto L_0x00a5
            r19 = r3
            r3 = 1
            if (r15 == r3) goto L_0x0070
            r22.P()
        L_0x006b:
            r15 = r18
            r3 = r19
            goto L_0x0053
        L_0x0070:
            l2.c$b r3 = r22.F()
            l2.c$b r5 = l2.c.b.NUMBER
            if (r3 != r5) goto L_0x0081
            r3 = r14
            double r13 = r22.o()
            float r13 = (float) r13
            r14 = r3
            r5 = r13
            goto L_0x006b
        L_0x0081:
            r3 = r14
            r22.c()
            double r13 = r22.o()
            float r13 = (float) r13
            l2.c$b r14 = r22.F()
            if (r14 != r5) goto L_0x0096
            double r14 = r22.o()
            float r5 = (float) r14
            goto L_0x0097
        L_0x0096:
            r5 = r13
        L_0x0097:
            r22.e()
            r14 = r3
            r15 = r18
            r3 = r19
            r20 = r13
            r13 = r5
            r5 = r20
            goto L_0x0053
        L_0x00a5:
            r19 = r3
            r3 = r14
            l2.c$b r4 = r22.F()
            l2.c$b r12 = l2.c.b.NUMBER
            if (r4 != r12) goto L_0x00b8
            double r14 = r22.o()
            float r12 = (float) r14
            r14 = r3
            r4 = r12
            goto L_0x006b
        L_0x00b8:
            r22.c()
            double r14 = r22.o()
            float r4 = (float) r14
            l2.c$b r14 = r22.F()
            if (r14 != r12) goto L_0x00cc
            double r14 = r22.o()
            float r12 = (float) r14
            goto L_0x00cd
        L_0x00cc:
            r12 = r4
        L_0x00cd:
            r22.e()
            r14 = r3
            goto L_0x006b
        L_0x00d2:
            r19 = r3
            r3 = r14
            r18 = r15
            android.graphics.PointF r14 = new android.graphics.PointF
            r14.<init>(r4, r5)
            android.graphics.PointF r4 = new android.graphics.PointF
            r4.<init>(r12, r13)
            r22.f()
            r13 = r4
            r12 = r14
            goto L_0x017d
        L_0x00e8:
            r19 = r3
            r3 = r14
            r18 = r15
            android.graphics.PointF r8 = k2.s.e(r22, r23)
            goto L_0x01a4
        L_0x00f3:
            r19 = r3
            r3 = r14
            r18 = r15
            l2.c$b r4 = r22.F()
            l2.c$b r5 = l2.c.b.BEGIN_OBJECT
            if (r4 != r5) goto L_0x017f
            r22.d()
            r4 = 0
            r5 = 0
            r9 = 0
            r11 = 0
        L_0x0107:
            boolean r14 = r22.k()
            if (r14 == 0) goto L_0x016c
            l2.c$a r14 = f7646d
            int r14 = r0.I(r14)
            if (r14 == 0) goto L_0x0144
            r15 = 1
            if (r14 == r15) goto L_0x011c
            r22.P()
            goto L_0x0107
        L_0x011c:
            l2.c$b r5 = r22.F()
            l2.c$b r11 = l2.c.b.NUMBER
            if (r5 != r11) goto L_0x012b
            double r14 = r22.o()
            float r11 = (float) r14
            r5 = r11
            goto L_0x0107
        L_0x012b:
            r22.c()
            double r14 = r22.o()
            float r5 = (float) r14
            l2.c$b r14 = r22.F()
            if (r14 != r11) goto L_0x013f
            double r14 = r22.o()
            float r11 = (float) r14
            goto L_0x0140
        L_0x013f:
            r11 = r5
        L_0x0140:
            r22.e()
            goto L_0x0107
        L_0x0144:
            l2.c$b r4 = r22.F()
            l2.c$b r9 = l2.c.b.NUMBER
            if (r4 != r9) goto L_0x0153
            double r14 = r22.o()
            float r9 = (float) r14
            r4 = r9
            goto L_0x0107
        L_0x0153:
            r22.c()
            double r14 = r22.o()
            float r4 = (float) r14
            l2.c$b r14 = r22.F()
            if (r14 != r9) goto L_0x0167
            double r14 = r22.o()
            float r9 = (float) r14
            goto L_0x0168
        L_0x0167:
            r9 = r4
        L_0x0168:
            r22.e()
            goto L_0x0107
        L_0x016c:
            android.graphics.PointF r14 = new android.graphics.PointF
            r14.<init>(r4, r5)
            android.graphics.PointF r4 = new android.graphics.PointF
            r4.<init>(r9, r11)
            r22.f()
            r11 = r4
            r9 = r14
            r15 = r18
        L_0x017d:
            r14 = r3
            goto L_0x01a4
        L_0x017f:
            android.graphics.PointF r7 = k2.s.e(r22, r23)
            r14 = r3
            r15 = r18
            goto L_0x01a4
        L_0x0187:
            r19 = r3
            r3 = r14
            r18 = r15
            java.lang.Object r16 = r2.a(r0, r1)
            goto L_0x01a4
        L_0x0191:
            r19 = r3
            r3 = r14
            r18 = r15
            java.lang.Object r10 = r2.a(r0, r1)
            goto L_0x01a4
        L_0x019b:
            r19 = r3
            r18 = r15
            double r3 = r22.o()
            float r14 = (float) r3
        L_0x01a4:
            r3 = r19
            goto L_0x0016
        L_0x01a8:
            r19 = r3
            r3 = r14
            r18 = r15
            r22.f()
            if (r6 == 0) goto L_0x01b8
            android.view.animation.Interpolator r0 = f7643a
            r11 = r10
        L_0x01b5:
            r12 = 0
            r13 = 0
            goto L_0x01dc
        L_0x01b8:
            if (r7 == 0) goto L_0x01c1
            if (r8 == 0) goto L_0x01c1
            android.view.animation.Interpolator r0 = b(r7, r8)
            goto L_0x01d9
        L_0x01c1:
            if (r9 == 0) goto L_0x01d7
            if (r11 == 0) goto L_0x01d7
            if (r12 == 0) goto L_0x01d7
            if (r13 == 0) goto L_0x01d7
            android.view.animation.Interpolator r0 = b(r9, r12)
            android.view.animation.Interpolator r1 = b(r11, r13)
            r12 = r0
            r13 = r1
            r11 = r16
            r0 = 0
            goto L_0x01dc
        L_0x01d7:
            android.view.animation.Interpolator r0 = f7643a
        L_0x01d9:
            r11 = r16
            goto L_0x01b5
        L_0x01dc:
            if (r12 == 0) goto L_0x01ed
            if (r13 == 0) goto L_0x01ed
            n2.a r0 = new n2.a
            r15 = 0
            r8 = r0
            r9 = r21
            r14 = r3
            r1 = r18
            r8.<init>(r9, r10, r11, r12, r13, r14, r15)
            goto L_0x01fb
        L_0x01ed:
            r1 = r18
            n2.a r2 = new n2.a
            r14 = 0
            r8 = r2
            r9 = r21
            r12 = r0
            r13 = r3
            r8.<init>(r9, r10, r11, r12, r13, r14)
            r0 = r2
        L_0x01fb:
            r0.f8415o = r1
            r3 = r19
            r0.f8416p = r3
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: k2.t.e(com.airbnb.lottie.h, l2.c, float, k2.n0):n2.a");
    }

    public static a f(c cVar, float f10, n0 n0Var) {
        return new a(n0Var.a(cVar, f10));
    }

    public static h g() {
        if (f7644b == null) {
            f7644b = new h();
        }
        return f7644b;
    }

    public static void h(int i10, WeakReference weakReference) {
        synchronized (t.class) {
            f7644b.i(i10, weakReference);
        }
    }
}
