package k2;

import com.airbnb.lottie.h;
import g2.b;
import h2.m;
import l2.c;

public abstract class f0 {

    /* renamed from: a  reason: collision with root package name */
    public static final c.a f7604a = c.a.a("nm", "r", "hd");

    public static m a(c cVar, h hVar) {
        boolean z10 = false;
        String str = null;
        b bVar = null;
        while (cVar.k()) {
            int I = cVar.I(f7604a);
            if (I == 0) {
                str = cVar.y();
            } else if (I == 1) {
                bVar = d.f(cVar, hVar, true);
            } else if (I != 2) {
                cVar.P();
            } else {
                z10 = cVar.m();
            }
        }
        if (z10) {
            return null;
        }
        return new m(str, bVar);
    }
}
