package k2;

import android.graphics.PointF;
import android.view.animation.Interpolator;
import com.airbnb.lottie.h;
import g2.b;
import g2.e;
import g2.g;
import g2.i;
import g2.l;
import g2.m;
import l2.c;
import m4.a;
import n2.d;

public abstract class c {

    /* renamed from: a  reason: collision with root package name */
    public static final c.a f7596a = c.a.a(a.f8143a, "p", "s", "rz", "r", "o", "so", "eo", "sk", "sa");

    /* renamed from: b  reason: collision with root package name */
    public static final c.a f7597b = c.a.a("k");

    public static boolean a(e eVar) {
        return eVar == null || (eVar.c() && ((PointF) ((n2.a) eVar.b().get(0)).f8402b).equals(0.0f, 0.0f));
    }

    public static boolean b(m mVar) {
        return mVar == null || (!(mVar instanceof i) && mVar.c() && ((PointF) ((n2.a) mVar.b().get(0)).f8402b).equals(0.0f, 0.0f));
    }

    public static boolean c(b bVar) {
        return bVar == null || (bVar.c() && ((Float) ((n2.a) bVar.b().get(0)).f8402b).floatValue() == 0.0f);
    }

    public static boolean d(g gVar) {
        return gVar == null || (gVar.c() && ((d) ((n2.a) gVar.b().get(0)).f8402b).a(1.0f, 1.0f));
    }

    public static boolean e(b bVar) {
        return bVar == null || (bVar.c() && ((Float) ((n2.a) bVar.b().get(0)).f8402b).floatValue() == 0.0f);
    }

    public static boolean f(b bVar) {
        return bVar == null || (bVar.c() && ((Float) ((n2.a) bVar.b().get(0)).f8402b).floatValue() == 0.0f);
    }

    public static l g(l2.c cVar, h hVar) {
        boolean z10;
        l2.c cVar2 = cVar;
        h hVar2 = hVar;
        boolean z11 = false;
        boolean z12 = cVar.F() == c.b.BEGIN_OBJECT;
        if (z12) {
            cVar.d();
        }
        b bVar = null;
        e eVar = null;
        m mVar = null;
        g gVar = null;
        b bVar2 = null;
        b bVar3 = null;
        g2.d dVar = null;
        b bVar4 = null;
        b bVar5 = null;
        while (cVar.k()) {
            switch (cVar2.I(f7596a)) {
                case 0:
                    boolean z13 = z11;
                    cVar.d();
                    while (cVar.k()) {
                        if (cVar2.I(f7597b) != 0) {
                            cVar.K();
                            cVar.P();
                        } else {
                            eVar = a.a(cVar, hVar);
                        }
                    }
                    cVar.f();
                    z11 = z13;
                    continue;
                case 1:
                    boolean z14 = z11;
                    mVar = a.b(cVar, hVar);
                    continue;
                case 2:
                    boolean z15 = z11;
                    gVar = d.j(cVar, hVar);
                    continue;
                case 3:
                    hVar2.a("Lottie doesn't support 3D layers.");
                    break;
                case 4:
                    break;
                case 5:
                    dVar = d.h(cVar, hVar);
                    continue;
                case 6:
                    bVar4 = d.f(cVar2, hVar2, z11);
                    continue;
                case 7:
                    bVar5 = d.f(cVar2, hVar2, z11);
                    continue;
                case 8:
                    bVar2 = d.f(cVar2, hVar2, z11);
                    continue;
                case 9:
                    bVar3 = d.f(cVar2, hVar2, z11);
                    continue;
                default:
                    boolean z16 = z11;
                    cVar.K();
                    cVar.P();
                    continue;
            }
            b f10 = d.f(cVar2, hVar2, z11);
            if (f10.b().isEmpty()) {
                n2.a aVar = r1;
                n2.a aVar2 = new n2.a(hVar, Float.valueOf(0.0f), Float.valueOf(0.0f), (Interpolator) null, 0.0f, Float.valueOf(hVar.f()));
                f10.b().add(aVar);
            } else if (((n2.a) f10.b().get(0)).f8402b == null) {
                z10 = false;
                f10.b().set(0, new n2.a(hVar, Float.valueOf(0.0f), Float.valueOf(0.0f), (Interpolator) null, 0.0f, Float.valueOf(hVar.f())));
                z11 = z10;
                bVar = f10;
            }
            z10 = false;
            z11 = z10;
            bVar = f10;
        }
        if (z12) {
            cVar.f();
        }
        e eVar2 = a(eVar) ? null : eVar;
        m mVar2 = b(mVar) ? null : mVar;
        b bVar6 = c(bVar) ? null : bVar;
        if (d(gVar)) {
            gVar = null;
        }
        return new l(eVar2, mVar2, gVar, bVar6, dVar, bVar4, bVar5, f(bVar2) ? null : bVar2, e(bVar3) ? null : bVar3);
    }
}
