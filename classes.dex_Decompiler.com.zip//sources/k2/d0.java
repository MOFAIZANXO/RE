package k2;

import com.airbnb.lottie.h;
import g2.b;
import g2.f;
import g2.m;
import h2.k;
import l2.c;

public abstract class d0 {

    /* renamed from: a  reason: collision with root package name */
    public static final c.a f7599a = c.a.a("nm", "p", "s", "r", "hd");

    public static k a(c cVar, h hVar) {
        String str = null;
        m mVar = null;
        f fVar = null;
        b bVar = null;
        boolean z10 = false;
        while (cVar.k()) {
            int I = cVar.I(f7599a);
            if (I == 0) {
                str = cVar.y();
            } else if (I == 1) {
                mVar = a.b(cVar, hVar);
            } else if (I == 2) {
                fVar = d.i(cVar, hVar);
            } else if (I == 3) {
                bVar = d.e(cVar, hVar);
            } else if (I != 4) {
                cVar.P();
            } else {
                z10 = cVar.m();
            }
        }
        return new k(str, mVar, fVar, bVar, z10);
    }
}
