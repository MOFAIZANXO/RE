package k2;

import com.airbnb.lottie.h;
import g2.a;
import g2.b;
import h2.r;
import java.util.ArrayList;
import java.util.Collections;
import l2.c;
import q3.g;
import q5.d;

public abstract class l0 {

    /* renamed from: a  reason: collision with root package name */
    public static final c.a f7628a = c.a.a("nm", com.google.android.material.navigation.c.W, "w", "o", "lc", "lj", "ml", "hd", d.f9357g);

    /* renamed from: b  reason: collision with root package name */
    public static final c.a f7629b = c.a.a("n", "v");

    public static r a(c cVar, h hVar) {
        c cVar2 = cVar;
        ArrayList arrayList = new ArrayList();
        float f10 = 0.0f;
        boolean z10 = false;
        String str = null;
        b bVar = null;
        a aVar = null;
        b bVar2 = null;
        r.b bVar3 = null;
        r.c cVar3 = null;
        g2.d dVar = null;
        while (cVar.k()) {
            switch (cVar2.I(f7628a)) {
                case 0:
                    h hVar2 = hVar;
                    str = cVar.y();
                    break;
                case 1:
                    h hVar3 = hVar;
                    aVar = d.c(cVar, hVar);
                    break;
                case 2:
                    h hVar4 = hVar;
                    bVar2 = d.e(cVar, hVar);
                    break;
                case 3:
                    h hVar5 = hVar;
                    dVar = d.h(cVar, hVar);
                    break;
                case 4:
                    h hVar6 = hVar;
                    bVar3 = r.b.values()[cVar.q() - 1];
                    break;
                case 5:
                    h hVar7 = hVar;
                    cVar3 = r.c.values()[cVar.q() - 1];
                    break;
                case 6:
                    h hVar8 = hVar;
                    f10 = (float) cVar.o();
                    break;
                case 7:
                    h hVar9 = hVar;
                    z10 = cVar.m();
                    break;
                case 8:
                    cVar.c();
                    while (cVar.k()) {
                        cVar.d();
                        String str2 = null;
                        b bVar4 = null;
                        while (cVar.k()) {
                            int I = cVar2.I(f7629b);
                            if (I == 0) {
                                str2 = cVar.y();
                            } else if (I != 1) {
                                cVar.K();
                                cVar.P();
                            } else {
                                bVar4 = d.e(cVar, hVar);
                            }
                        }
                        cVar.f();
                        str2.hashCode();
                        char c10 = 65535;
                        switch (str2.hashCode()) {
                            case 100:
                                if (str2.equals(d.f9357g)) {
                                    c10 = 0;
                                    break;
                                }
                                break;
                            case 103:
                                if (str2.equals(g.A)) {
                                    c10 = 1;
                                    break;
                                }
                                break;
                            case 111:
                                if (str2.equals("o")) {
                                    c10 = 2;
                                    break;
                                }
                                break;
                        }
                        switch (c10) {
                            case 0:
                            case 1:
                                hVar.u(true);
                                arrayList.add(bVar4);
                                break;
                            case 2:
                                h hVar10 = hVar;
                                bVar = bVar4;
                                break;
                            default:
                                h hVar11 = hVar;
                                break;
                        }
                    }
                    h hVar12 = hVar;
                    cVar.e();
                    if (arrayList.size() != 1) {
                        break;
                    } else {
                        arrayList.add((b) arrayList.get(0));
                        break;
                    }
                default:
                    h hVar13 = hVar;
                    cVar.P();
                    break;
            }
        }
        if (dVar == null) {
            dVar = new g2.d(Collections.singletonList(new n2.a(100)));
        }
        return new r(str, bVar, arrayList, aVar, dVar, bVar2, bVar3, cVar3, f10, z10);
    }
}
