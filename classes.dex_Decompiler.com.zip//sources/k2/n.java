package k2;

import l2.c;

public abstract class n {

    /* renamed from: a  reason: collision with root package name */
    public static final c.a f7633a = c.a.a("fFamily", "fName", "fStyle", "ascent");

    public static f2.c a(c cVar) {
        cVar.d();
        String str = null;
        String str2 = null;
        float f10 = 0.0f;
        String str3 = null;
        while (cVar.k()) {
            int I = cVar.I(f7633a);
            if (I == 0) {
                str = cVar.y();
            } else if (I == 1) {
                str3 = cVar.y();
            } else if (I == 2) {
                str2 = cVar.y();
            } else if (I != 3) {
                cVar.K();
                cVar.P();
            } else {
                f10 = (float) cVar.o();
            }
        }
        cVar.f();
        return new f2.c(str, str3, str2, f10);
    }
}
