package k2;

import l2.c;
import n2.d;

public class g0 implements n0 {

    /* renamed from: a  reason: collision with root package name */
    public static final g0 f7606a = new g0();

    /* renamed from: b */
    public d a(c cVar, float f10) {
        boolean z10 = cVar.F() == c.b.BEGIN_ARRAY;
        if (z10) {
            cVar.c();
        }
        float o10 = (float) cVar.o();
        float o11 = (float) cVar.o();
        while (cVar.k()) {
            cVar.P();
        }
        if (z10) {
            cVar.e();
        }
        return new d((o10 / 100.0f) * f10, (o11 / 100.0f) * f10);
    }
}
