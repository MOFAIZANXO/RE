package k2;

import f2.b;
import l2.c;

public class i implements n0 {

    /* renamed from: a  reason: collision with root package name */
    public static final i f7610a = new i();

    /* renamed from: b  reason: collision with root package name */
    public static final c.a f7611b = c.a.a("t", "f", "s", "j", "tr", "lh", "ls", "fc", "sc", "sw", "of");

    /* renamed from: b */
    public b a(c cVar, float f10) {
        b.a aVar = b.a.CENTER;
        cVar.d();
        b.a aVar2 = aVar;
        String str = null;
        String str2 = null;
        float f11 = 0.0f;
        float f12 = 0.0f;
        float f13 = 0.0f;
        float f14 = 0.0f;
        int i10 = 0;
        int i11 = 0;
        int i12 = 0;
        boolean z10 = true;
        while (cVar.k()) {
            switch (cVar.I(f7611b)) {
                case 0:
                    str = cVar.y();
                    break;
                case 1:
                    str2 = cVar.y();
                    break;
                case 2:
                    f11 = (float) cVar.o();
                    break;
                case 3:
                    int q10 = cVar.q();
                    aVar2 = b.a.CENTER;
                    if (q10 <= aVar2.ordinal() && q10 >= 0) {
                        aVar2 = b.a.values()[q10];
                        break;
                    }
                case 4:
                    i10 = cVar.q();
                    break;
                case 5:
                    f12 = (float) cVar.o();
                    break;
                case 6:
                    f13 = (float) cVar.o();
                    break;
                case 7:
                    i11 = s.d(cVar);
                    break;
                case 8:
                    i12 = s.d(cVar);
                    break;
                case 9:
                    f14 = (float) cVar.o();
                    break;
                case 10:
                    z10 = cVar.m();
                    break;
                default:
                    cVar.K();
                    cVar.P();
                    break;
            }
        }
        c cVar2 = cVar;
        cVar.f();
        return new b(str, str2, f11, aVar2, i10, f12, f13, i11, i12, f14, z10);
    }
}
