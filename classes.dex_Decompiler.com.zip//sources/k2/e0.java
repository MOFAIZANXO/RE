package k2;

import com.airbnb.lottie.h;
import g2.b;
import h2.l;
import l2.c;

public abstract class e0 {

    /* renamed from: a  reason: collision with root package name */
    public static final c.a f7602a = c.a.a("nm", com.google.android.material.navigation.c.W, "o", "tr", "hd");

    public static l a(c cVar, h hVar) {
        String str = null;
        b bVar = null;
        b bVar2 = null;
        g2.l lVar = null;
        boolean z10 = false;
        while (cVar.k()) {
            int I = cVar.I(f7602a);
            if (I == 0) {
                str = cVar.y();
            } else if (I == 1) {
                bVar = d.f(cVar, hVar, false);
            } else if (I == 2) {
                bVar2 = d.f(cVar, hVar, false);
            } else if (I == 3) {
                lVar = c.g(cVar, hVar);
            } else if (I != 4) {
                cVar.P();
            } else {
                z10 = cVar.m();
            }
        }
        return new l(str, bVar, bVar2, lVar, z10);
    }
}
