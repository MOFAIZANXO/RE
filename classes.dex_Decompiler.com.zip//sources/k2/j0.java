package k2;

import com.airbnb.lottie.h;
import h2.p;
import java.util.ArrayList;
import l2.c;

public abstract class j0 {

    /* renamed from: a  reason: collision with root package name */
    public static final c.a f7618a = c.a.a("nm", "hd", "it");

    public static p a(c cVar, h hVar) {
        ArrayList arrayList = new ArrayList();
        String str = null;
        boolean z10 = false;
        while (cVar.k()) {
            int I = cVar.I(f7618a);
            if (I == 0) {
                str = cVar.y();
            } else if (I == 1) {
                z10 = cVar.m();
            } else if (I != 2) {
                cVar.P();
            } else {
                cVar.c();
                while (cVar.k()) {
                    h2.c a10 = h.a(cVar, hVar);
                    if (a10 != null) {
                        arrayList.add(a10);
                    }
                }
                cVar.e();
            }
        }
        return new p(str, arrayList, z10);
    }
}
