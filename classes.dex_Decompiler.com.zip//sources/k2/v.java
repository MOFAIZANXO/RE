package k2;

import android.graphics.Color;
import android.graphics.Rect;
import android.view.animation.Interpolator;
import com.airbnb.lottie.h;
import g2.b;
import g2.j;
import g2.k;
import g2.l;
import i2.e;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import l2.c;
import q5.d;

public abstract class v {

    /* renamed from: a  reason: collision with root package name */
    public static final c.a f7648a = c.a.a("nm", "ind", "refId", "ty", "parent", "sw", "sh", "sc", "ks", "tt", "masksProperties", "shapes", "t", "ef", "sr", "st", "w", "h", "ip", "op", "tm", "cl", "hd");

    /* renamed from: b  reason: collision with root package name */
    public static final c.a f7649b = c.a.a(d.f9357g, m4.a.f8143a);

    /* renamed from: c  reason: collision with root package name */
    public static final c.a f7650c = c.a.a("ty", "nm");

    public static /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        public static final /* synthetic */ int[] f7651a;

        /* JADX WARNING: Can't wrap try/catch for region: R(6:0|1|2|3|4|6) */
        /* JADX WARNING: Code restructure failed: missing block: B:7:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        static {
            /*
                i2.e$b[] r0 = i2.e.b.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f7651a = r0
                i2.e$b r1 = i2.e.b.LUMA     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = f7651a     // Catch:{ NoSuchFieldError -> 0x001d }
                i2.e$b r1 = i2.e.b.LUMA_INVERTED     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: k2.v.a.<clinit>():void");
        }
    }

    public static e a(h hVar) {
        Rect b10 = hVar.b();
        List emptyList = Collections.emptyList();
        e.a aVar = e.a.PRE_COMP;
        List emptyList2 = Collections.emptyList();
        l lVar = r12;
        l lVar2 = new l();
        return new e(emptyList, hVar, "__container", -1, aVar, -1, (String) null, emptyList2, lVar, 0, 0, 0, 0.0f, 0.0f, b10.width(), b10.height(), (j) null, (k) null, Collections.emptyList(), e.b.NONE, (b) null, false, (h2.a) null, (j) null);
    }

    public static e b(c cVar, h hVar) {
        ArrayList arrayList;
        ArrayList arrayList2;
        float f10;
        c cVar2 = cVar;
        h hVar2 = hVar;
        e.b bVar = e.b.NONE;
        ArrayList arrayList3 = new ArrayList();
        ArrayList arrayList4 = new ArrayList();
        cVar.d();
        Float valueOf = Float.valueOf(1.0f);
        Float valueOf2 = Float.valueOf(0.0f);
        e.b bVar2 = bVar;
        e.a aVar = null;
        String str = null;
        l lVar = null;
        j jVar = null;
        k kVar = null;
        b bVar3 = null;
        h2.a aVar2 = null;
        j jVar2 = null;
        long j10 = 0;
        int i10 = 0;
        int i11 = 0;
        int i12 = 0;
        int i13 = 0;
        int i14 = 0;
        boolean z10 = false;
        float f11 = 1.0f;
        long j11 = -1;
        float f12 = 0.0f;
        float f13 = 0.0f;
        float f14 = 0.0f;
        String str2 = "UNSET";
        String str3 = null;
        while (cVar.k()) {
            switch (cVar2.I(f7648a)) {
                case 0:
                    str2 = cVar.y();
                    break;
                case 1:
                    j10 = (long) cVar.q();
                    break;
                case 2:
                    str = cVar.y();
                    break;
                case 3:
                    int q10 = cVar.q();
                    aVar = e.a.UNKNOWN;
                    if (q10 >= aVar.ordinal()) {
                        break;
                    } else {
                        aVar = e.a.values()[q10];
                        break;
                    }
                case 4:
                    j11 = (long) cVar.q();
                    break;
                case 5:
                    i10 = (int) (((float) cVar.q()) * m2.h.e());
                    break;
                case 6:
                    i11 = (int) (((float) cVar.q()) * m2.h.e());
                    break;
                case 7:
                    i12 = Color.parseColor(cVar.y());
                    break;
                case 8:
                    lVar = c.g(cVar, hVar);
                    break;
                case 9:
                    int q11 = cVar.q();
                    if (q11 < e.b.values().length) {
                        bVar2 = e.b.values()[q11];
                        int i15 = a.f7651a[bVar2.ordinal()];
                        if (i15 == 1) {
                            hVar2.a("Unsupported matte type: Luma");
                        } else if (i15 == 2) {
                            hVar2.a("Unsupported matte type: Luma Inverted");
                        }
                        hVar2.r(1);
                        break;
                    } else {
                        hVar2.a("Unsupported matte type: " + q11);
                        break;
                    }
                case 10:
                    cVar.c();
                    while (cVar.k()) {
                        arrayList3.add(x.a(cVar, hVar));
                    }
                    hVar2.r(arrayList3.size());
                    cVar.e();
                    break;
                case 11:
                    cVar.c();
                    while (cVar.k()) {
                        h2.c a10 = h.a(cVar, hVar);
                        if (a10 != null) {
                            arrayList4.add(a10);
                        }
                    }
                    cVar.e();
                    break;
                case 12:
                    cVar.d();
                    while (cVar.k()) {
                        int I = cVar2.I(f7649b);
                        if (I == 0) {
                            jVar = d.d(cVar, hVar);
                        } else if (I != 1) {
                            cVar.K();
                            cVar.P();
                        } else {
                            cVar.c();
                            if (cVar.k()) {
                                kVar = b.a(cVar, hVar);
                            }
                            while (cVar.k()) {
                                cVar.P();
                            }
                            cVar.e();
                        }
                    }
                    cVar.f();
                    break;
                case 13:
                    cVar.c();
                    ArrayList arrayList5 = new ArrayList();
                    while (cVar.k()) {
                        cVar.d();
                        while (cVar.k()) {
                            int I2 = cVar2.I(f7650c);
                            if (I2 == 0) {
                                int q12 = cVar.q();
                                if (q12 == 29) {
                                    aVar2 = e.b(cVar, hVar);
                                } else if (q12 == 25) {
                                    jVar2 = new k().b(cVar2, hVar2);
                                }
                            } else if (I2 != 1) {
                                cVar.K();
                                cVar.P();
                            } else {
                                arrayList5.add(cVar.y());
                            }
                        }
                        cVar.f();
                    }
                    cVar.e();
                    hVar2.a("Lottie doesn't support layer effects. If you are using them for  fills, strokes, trim paths etc. then try adding them directly as contents  in your shape. Found: " + arrayList5);
                    break;
                case 14:
                    f11 = (float) cVar.o();
                    break;
                case 15:
                    f13 = (float) cVar.o();
                    break;
                case 16:
                    i13 = (int) (((float) cVar.q()) * m2.h.e());
                    break;
                case 17:
                    i14 = (int) (((float) cVar.q()) * m2.h.e());
                    break;
                case 18:
                    f12 = (float) cVar.o();
                    break;
                case 19:
                    f14 = (float) cVar.o();
                    break;
                case 20:
                    bVar3 = d.f(cVar2, hVar2, false);
                    break;
                case 21:
                    str3 = cVar.y();
                    break;
                case 22:
                    z10 = cVar.m();
                    break;
                default:
                    cVar.K();
                    cVar.P();
                    break;
            }
        }
        cVar.f();
        ArrayList arrayList6 = new ArrayList();
        if (f12 > 0.0f) {
            n2.a aVar3 = r0;
            arrayList = arrayList3;
            arrayList2 = arrayList6;
            n2.a aVar4 = new n2.a(hVar, valueOf2, valueOf2, (Interpolator) null, 0.0f, Float.valueOf(f12));
            arrayList2.add(aVar3);
            f10 = 0.0f;
        } else {
            arrayList = arrayList3;
            arrayList2 = arrayList6;
            f10 = 0.0f;
        }
        if (f14 <= f10) {
            f14 = hVar.f();
        }
        h hVar3 = hVar;
        arrayList2.add(new n2.a(hVar3, valueOf, valueOf, (Interpolator) null, f12, Float.valueOf(f14)));
        arrayList2.add(new n2.a(hVar3, valueOf2, valueOf2, (Interpolator) null, f14, Float.valueOf(Float.MAX_VALUE)));
        if (str2.endsWith(".ai") || "ai".equals(str3)) {
            hVar2.a("Convert your Illustrator layers to shape layers.");
        }
        return new e(arrayList4, hVar, str2, j10, aVar, j11, str, arrayList, lVar, i10, i11, i12, f11, f13, i13, i14, jVar, kVar, arrayList2, bVar2, bVar3, z10, aVar2, jVar2);
    }
}
