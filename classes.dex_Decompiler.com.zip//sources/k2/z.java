package k2;

import com.airbnb.lottie.h;
import d2.i;
import l2.c;

public abstract class z {
    public static i a(c cVar, h hVar) {
        return new i(hVar, t.c(cVar, hVar, m2.h.e(), a0.f7592a, cVar.F() == c.b.BEGIN_OBJECT, false));
    }
}
