package k2;

import com.airbnb.lottie.h;
import g2.a;
import g2.b;
import g2.f;
import g2.g;
import g2.j;
import java.util.List;
import l2.c;

public abstract class d {
    public static List a(c cVar, float f10, h hVar, n0 n0Var) {
        return u.a(cVar, hVar, f10, n0Var, false);
    }

    public static List b(c cVar, h hVar, n0 n0Var) {
        return u.a(cVar, hVar, 1.0f, n0Var, false);
    }

    public static a c(c cVar, h hVar) {
        return new a(b(cVar, hVar, g.f7605a));
    }

    public static j d(c cVar, h hVar) {
        return new j(b(cVar, hVar, i.f7610a));
    }

    public static b e(c cVar, h hVar) {
        return f(cVar, hVar, true);
    }

    public static b f(c cVar, h hVar, boolean z10) {
        return new b(a(cVar, z10 ? m2.h.e() : 1.0f, hVar, l.f7627a));
    }

    public static g2.c g(c cVar, h hVar, int i10) {
        return new g2.c(b(cVar, hVar, new o(i10)));
    }

    public static g2.d h(c cVar, h hVar) {
        return new g2.d(b(cVar, hVar, r.f7640a));
    }

    public static f i(c cVar, h hVar) {
        return new f(u.a(cVar, hVar, m2.h.e(), b0.f7595a, true));
    }

    public static g j(c cVar, h hVar) {
        return new g(b(cVar, hVar, g0.f7606a));
    }

    public static g2.h k(c cVar, h hVar) {
        return new g2.h(a(cVar, m2.h.e(), hVar, h0.f7608a));
    }
}
