package k2;

import android.graphics.PointF;
import l2.c;

public class a0 implements n0 {

    /* renamed from: a  reason: collision with root package name */
    public static final a0 f7592a = new a0();

    /* renamed from: b */
    public PointF a(c cVar, float f10) {
        return s.e(cVar, f10);
    }
}
