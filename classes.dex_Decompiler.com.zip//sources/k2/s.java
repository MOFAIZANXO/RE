package k2;

import android.graphics.Color;
import android.graphics.PointF;
import java.util.ArrayList;
import java.util.List;
import l2.c;

public abstract class s {

    /* renamed from: a  reason: collision with root package name */
    public static final c.a f7641a = c.a.a("x", "y");

    public static /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        public static final /* synthetic */ int[] f7642a;

        /* JADX WARNING: Can't wrap try/catch for region: R(6:0|1|2|3|4|(3:5|6|8)) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        static {
            /*
                l2.c$b[] r0 = l2.c.b.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f7642a = r0
                l2.c$b r1 = l2.c.b.NUMBER     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = f7642a     // Catch:{ NoSuchFieldError -> 0x001d }
                l2.c$b r1 = l2.c.b.BEGIN_ARRAY     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                int[] r0 = f7642a     // Catch:{ NoSuchFieldError -> 0x0028 }
                l2.c$b r1 = l2.c.b.BEGIN_OBJECT     // Catch:{ NoSuchFieldError -> 0x0028 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
                r2 = 3
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0028 }
            L_0x0028:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: k2.s.a.<clinit>():void");
        }
    }

    public static PointF a(c cVar, float f10) {
        cVar.c();
        float o10 = (float) cVar.o();
        float o11 = (float) cVar.o();
        while (cVar.F() != c.b.END_ARRAY) {
            cVar.P();
        }
        cVar.e();
        return new PointF(o10 * f10, o11 * f10);
    }

    public static PointF b(c cVar, float f10) {
        float o10 = (float) cVar.o();
        float o11 = (float) cVar.o();
        while (cVar.k()) {
            cVar.P();
        }
        return new PointF(o10 * f10, o11 * f10);
    }

    public static PointF c(c cVar, float f10) {
        cVar.d();
        float f11 = 0.0f;
        float f12 = 0.0f;
        while (cVar.k()) {
            int I = cVar.I(f7641a);
            if (I == 0) {
                f11 = g(cVar);
            } else if (I != 1) {
                cVar.K();
                cVar.P();
            } else {
                f12 = g(cVar);
            }
        }
        cVar.f();
        return new PointF(f11 * f10, f12 * f10);
    }

    public static int d(c cVar) {
        cVar.c();
        int o10 = (int) (cVar.o() * 255.0d);
        int o11 = (int) (cVar.o() * 255.0d);
        int o12 = (int) (cVar.o() * 255.0d);
        while (cVar.k()) {
            cVar.P();
        }
        cVar.e();
        return Color.argb(255, o10, o11, o12);
    }

    public static PointF e(c cVar, float f10) {
        int i10 = a.f7642a[cVar.F().ordinal()];
        if (i10 == 1) {
            return b(cVar, f10);
        }
        if (i10 == 2) {
            return a(cVar, f10);
        }
        if (i10 == 3) {
            return c(cVar, f10);
        }
        throw new IllegalArgumentException("Unknown point starts with " + cVar.F());
    }

    public static List f(c cVar, float f10) {
        ArrayList arrayList = new ArrayList();
        cVar.c();
        while (cVar.F() == c.b.BEGIN_ARRAY) {
            cVar.c();
            arrayList.add(e(cVar, f10));
            cVar.e();
        }
        cVar.e();
        return arrayList;
    }

    public static float g(c cVar) {
        c.b F = cVar.F();
        int i10 = a.f7642a[F.ordinal()];
        if (i10 == 1) {
            return (float) cVar.o();
        }
        if (i10 == 2) {
            cVar.c();
            float o10 = (float) cVar.o();
            while (cVar.k()) {
                cVar.P();
            }
            cVar.e();
            return o10;
        }
        throw new IllegalArgumentException("Unknown value for token of type " + F);
    }
}
