package k2;

import com.airbnb.lottie.h;
import g2.b;
import g2.e;
import g2.i;
import g2.m;
import java.util.ArrayList;
import l2.c;

public abstract class a {

    /* renamed from: a  reason: collision with root package name */
    public static final c.a f7591a = c.a.a("k", "x", "y");

    public static e a(c cVar, h hVar) {
        ArrayList arrayList = new ArrayList();
        if (cVar.F() == c.b.BEGIN_ARRAY) {
            cVar.c();
            while (cVar.k()) {
                arrayList.add(z.a(cVar, hVar));
            }
            cVar.e();
            u.b(arrayList);
        } else {
            arrayList.add(new n2.a(s.e(cVar, m2.h.e())));
        }
        return new e(arrayList);
    }

    public static m b(c cVar, h hVar) {
        cVar.d();
        e eVar = null;
        b bVar = null;
        boolean z10 = false;
        b bVar2 = null;
        while (cVar.F() != c.b.END_OBJECT) {
            int I = cVar.I(f7591a);
            if (I != 0) {
                if (I != 1) {
                    if (I != 2) {
                        cVar.K();
                        cVar.P();
                    } else if (cVar.F() == c.b.STRING) {
                        cVar.P();
                    } else {
                        bVar = d.e(cVar, hVar);
                    }
                } else if (cVar.F() == c.b.STRING) {
                    cVar.P();
                } else {
                    bVar2 = d.e(cVar, hVar);
                }
                z10 = true;
            } else {
                eVar = a(cVar, hVar);
            }
        }
        cVar.f();
        if (z10) {
            hVar.a("Lottie doesn't support expressions.");
        }
        return eVar != null ? eVar : new i(bVar2, bVar);
    }
}
