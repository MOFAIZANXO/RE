package k2;

import android.graphics.PointF;
import f2.a;
import h2.n;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import l2.c;
import m2.g;

public class h0 implements n0 {

    /* renamed from: a  reason: collision with root package name */
    public static final h0 f7608a = new h0();

    /* renamed from: b  reason: collision with root package name */
    public static final c.a f7609b = c.a.a(com.google.android.material.navigation.c.W, "v", "i", "o");

    /* renamed from: b */
    public n a(c cVar, float f10) {
        if (cVar.F() == c.b.BEGIN_ARRAY) {
            cVar.c();
        }
        cVar.d();
        List list = null;
        List list2 = null;
        List list3 = null;
        boolean z10 = false;
        while (cVar.k()) {
            int I = cVar.I(f7609b);
            if (I == 0) {
                z10 = cVar.m();
            } else if (I == 1) {
                list = s.f(cVar, f10);
            } else if (I == 2) {
                list2 = s.f(cVar, f10);
            } else if (I != 3) {
                cVar.K();
                cVar.P();
            } else {
                list3 = s.f(cVar, f10);
            }
        }
        cVar.f();
        if (cVar.F() == c.b.END_ARRAY) {
            cVar.e();
        }
        if (list == null || list2 == null || list3 == null) {
            throw new IllegalArgumentException("Shape data was missing information.");
        } else if (list.isEmpty()) {
            return new n(new PointF(), false, Collections.emptyList());
        } else {
            int size = list.size();
            PointF pointF = (PointF) list.get(0);
            ArrayList arrayList = new ArrayList(size);
            for (int i10 = 1; i10 < size; i10++) {
                PointF pointF2 = (PointF) list.get(i10);
                int i11 = i10 - 1;
                arrayList.add(new a(g.a((PointF) list.get(i11), (PointF) list3.get(i11)), g.a(pointF2, (PointF) list2.get(i10)), pointF2));
            }
            if (z10) {
                PointF pointF3 = (PointF) list.get(0);
                int i12 = size - 1;
                arrayList.add(new a(g.a((PointF) list.get(i12), (PointF) list3.get(i12)), g.a(pointF3, (PointF) list2.get(0)), pointF3));
            }
            return new n(pointF, z10, arrayList);
        }
    }
}
