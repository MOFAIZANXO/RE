package k2;

import com.airbnb.lottie.h;
import g2.m;
import h2.b;
import l2.c;
import q5.d;

public abstract class f {

    /* renamed from: a  reason: collision with root package name */
    public static final c.a f7603a = c.a.a("nm", "p", "s", "hd", d.f9357g);

    public static b a(c cVar, h hVar, int i10) {
        boolean z10 = i10 == 3;
        boolean z11 = false;
        String str = null;
        m mVar = null;
        g2.f fVar = null;
        while (cVar.k()) {
            int I = cVar.I(f7603a);
            if (I == 0) {
                str = cVar.y();
            } else if (I == 1) {
                mVar = a.b(cVar, hVar);
            } else if (I == 2) {
                fVar = d.i(cVar, hVar);
            } else if (I == 3) {
                z11 = cVar.m();
            } else if (I != 4) {
                cVar.K();
                cVar.P();
            } else {
                z10 = cVar.q() == 3;
            }
        }
        return new b(str, mVar, fVar, z10, z11);
    }
}
