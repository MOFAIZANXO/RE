package k2;

import l2.c;

public class r implements n0 {

    /* renamed from: a  reason: collision with root package name */
    public static final r f7640a = new r();

    /* renamed from: b */
    public Integer a(c cVar, float f10) {
        return Integer.valueOf(Math.round(s.g(cVar) * f10));
    }
}
