package k2;

import l2.c;

public class l implements n0 {

    /* renamed from: a  reason: collision with root package name */
    public static final l f7627a = new l();

    /* renamed from: b */
    public Float a(c cVar, float f10) {
        return Float.valueOf(s.g(cVar) * f10);
    }
}
