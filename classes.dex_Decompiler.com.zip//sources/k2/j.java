package k2;

import g2.a;
import g2.b;

public class j {

    /* renamed from: a  reason: collision with root package name */
    public final a f7613a;

    /* renamed from: b  reason: collision with root package name */
    public final b f7614b;

    /* renamed from: c  reason: collision with root package name */
    public final b f7615c;

    /* renamed from: d  reason: collision with root package name */
    public final b f7616d;

    /* renamed from: e  reason: collision with root package name */
    public final b f7617e;

    public j(a aVar, b bVar, b bVar2, b bVar3, b bVar4) {
        this.f7613a = aVar;
        this.f7614b = bVar;
        this.f7615c = bVar2;
        this.f7616d = bVar3;
        this.f7617e = bVar4;
    }

    public a a() {
        return this.f7613a;
    }

    public b b() {
        return this.f7615c;
    }

    public b c() {
        return this.f7616d;
    }

    public b d() {
        return this.f7614b;
    }

    public b e() {
        return this.f7617e;
    }
}
