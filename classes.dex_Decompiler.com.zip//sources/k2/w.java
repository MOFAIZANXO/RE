package k2;

import android.graphics.Rect;
import com.airbnb.lottie.e0;
import com.airbnb.lottie.h;
import f2.d;
import h.e;
import i2.e;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import l2.c;

public abstract class w {

    /* renamed from: a  reason: collision with root package name */
    public static final c.a f7652a = c.a.a("w", "h", "ip", "op", "fr", "v", "layers", "assets", "fonts", "chars", "markers");

    /* renamed from: b  reason: collision with root package name */
    public static c.a f7653b = c.a.a("id", "layers", "w", "h", "p", "u");

    /* renamed from: c  reason: collision with root package name */
    public static final c.a f7654c = c.a.a("list");

    /* renamed from: d  reason: collision with root package name */
    public static final c.a f7655d = c.a.a("cm", "tm", "dr");

    public static h a(c cVar) {
        ArrayList arrayList;
        HashMap hashMap;
        c cVar2 = cVar;
        float e10 = m2.h.e();
        e eVar = new e();
        ArrayList arrayList2 = new ArrayList();
        HashMap hashMap2 = new HashMap();
        HashMap hashMap3 = new HashMap();
        HashMap hashMap4 = new HashMap();
        ArrayList arrayList3 = new ArrayList();
        h.h hVar = new h.h();
        h hVar2 = new h();
        cVar.d();
        float f10 = 0.0f;
        float f11 = 0.0f;
        float f12 = 0.0f;
        int i10 = 0;
        int i11 = 0;
        while (cVar.k()) {
            switch (cVar2.I(f7652a)) {
                case 0:
                    HashMap hashMap5 = hashMap4;
                    ArrayList arrayList4 = arrayList3;
                    i10 = cVar.q();
                    continue;
                case 1:
                    HashMap hashMap6 = hashMap4;
                    ArrayList arrayList5 = arrayList3;
                    i11 = cVar.q();
                    continue;
                case 2:
                    HashMap hashMap7 = hashMap4;
                    ArrayList arrayList6 = arrayList3;
                    f10 = (float) cVar.o();
                    continue;
                case 3:
                    hashMap = hashMap4;
                    arrayList = arrayList3;
                    f11 = ((float) cVar.o()) - 0.01f;
                    break;
                case 4:
                    hashMap = hashMap4;
                    arrayList = arrayList3;
                    f12 = (float) cVar.o();
                    break;
                case 5:
                    String[] split = cVar.y().split("\\.");
                    if (!m2.h.j(Integer.parseInt(split[0]), Integer.parseInt(split[1]), Integer.parseInt(split[2]), 4, 4, 0)) {
                        hVar2.a("Lottie only supports bodymovin >= 4.4.0");
                        break;
                    }
                    break;
                case 6:
                    e(cVar2, hVar2, arrayList2, eVar);
                    break;
                case 7:
                    b(cVar2, hVar2, hashMap2, hashMap3);
                    break;
                case 8:
                    d(cVar2, hashMap4);
                    break;
                case 9:
                    c(cVar2, hVar2, hVar);
                    break;
                case 10:
                    f(cVar2, arrayList3);
                    break;
                default:
                    hashMap = hashMap4;
                    arrayList = arrayList3;
                    cVar.K();
                    cVar.P();
                    break;
            }
            hashMap = hashMap4;
            arrayList = arrayList3;
            hashMap4 = hashMap;
            arrayList3 = arrayList;
            cVar2 = cVar;
        }
        ArrayList arrayList7 = arrayList3;
        hVar2.s(new Rect(0, 0, (int) (((float) i10) * e10), (int) (((float) i11) * e10)), f10, f11, f12, arrayList2, eVar, hashMap2, hashMap3, hVar, hashMap4, arrayList3);
        return hVar2;
    }

    public static void b(c cVar, h hVar, Map map, Map map2) {
        cVar.c();
        while (cVar.k()) {
            ArrayList arrayList = new ArrayList();
            e eVar = new e();
            cVar.d();
            int i10 = 0;
            int i11 = 0;
            String str = null;
            String str2 = null;
            String str3 = null;
            while (cVar.k()) {
                int I = cVar.I(f7653b);
                if (I == 0) {
                    str = cVar.y();
                } else if (I == 1) {
                    cVar.c();
                    while (cVar.k()) {
                        i2.e b10 = v.b(cVar, hVar);
                        eVar.j(b10.d(), b10);
                        arrayList.add(b10);
                    }
                    cVar.e();
                } else if (I == 2) {
                    i10 = cVar.q();
                } else if (I == 3) {
                    i11 = cVar.q();
                } else if (I == 4) {
                    str2 = cVar.y();
                } else if (I != 5) {
                    cVar.K();
                    cVar.P();
                } else {
                    str3 = cVar.y();
                }
            }
            cVar.f();
            if (str2 != null) {
                e0 e0Var = new e0(i10, i11, str, str2, str3);
                map2.put(e0Var.d(), e0Var);
            } else {
                map.put(str, arrayList);
            }
        }
        cVar.e();
    }

    public static void c(c cVar, h hVar, h.h hVar2) {
        cVar.c();
        while (cVar.k()) {
            d a10 = m.a(cVar, hVar);
            hVar2.i(a10.hashCode(), a10);
        }
        cVar.e();
    }

    public static void d(c cVar, Map map) {
        cVar.d();
        while (cVar.k()) {
            if (cVar.I(f7654c) != 0) {
                cVar.K();
                cVar.P();
            } else {
                cVar.c();
                while (cVar.k()) {
                    f2.c a10 = n.a(cVar);
                    map.put(a10.b(), a10);
                }
                cVar.e();
            }
        }
        cVar.f();
    }

    public static void e(c cVar, h hVar, List list, e eVar) {
        cVar.c();
        int i10 = 0;
        while (cVar.k()) {
            i2.e b10 = v.b(cVar, hVar);
            if (b10.f() == e.a.IMAGE) {
                i10++;
            }
            list.add(b10);
            eVar.j(b10.d(), b10);
            if (i10 > 4) {
                m2.d.c("You have " + i10 + " images. Lottie should primarily be used with shapes. If you are using Adobe Illustrator, convert the Illustrator layers to shape layers.");
            }
        }
        cVar.e();
    }

    public static void f(c cVar, List list) {
        cVar.c();
        while (cVar.k()) {
            cVar.d();
            float f10 = 0.0f;
            String str = null;
            float f11 = 0.0f;
            while (cVar.k()) {
                int I = cVar.I(f7655d);
                if (I == 0) {
                    str = cVar.y();
                } else if (I == 1) {
                    f10 = (float) cVar.o();
                } else if (I != 2) {
                    cVar.K();
                    cVar.P();
                } else {
                    f11 = (float) cVar.o();
                }
            }
            cVar.f();
            list.add(new f2.h(str, f10, f11));
        }
        cVar.e();
    }
}
