package k2;

import com.airbnb.lottie.h;
import com.samsung.android.rubin.sdk.module.odm.OdmProviderContract;
import f2.d;
import h2.p;
import java.util.ArrayList;
import l2.c;

public abstract class m {

    /* renamed from: a  reason: collision with root package name */
    public static final c.a f7630a = c.a.a("ch", "size", "w", "style", "fFamily", OdmProviderContract.OdmResult.COLUMN_DATA);

    /* renamed from: b  reason: collision with root package name */
    public static final c.a f7631b = c.a.a("shapes");

    public static d a(c cVar, h hVar) {
        ArrayList arrayList = new ArrayList();
        cVar.d();
        double d10 = 0.0d;
        String str = null;
        String str2 = null;
        char c10 = 0;
        double d11 = 0.0d;
        while (cVar.k()) {
            int I = cVar.I(f7630a);
            if (I == 0) {
                c10 = cVar.y().charAt(0);
            } else if (I == 1) {
                d11 = cVar.o();
            } else if (I == 2) {
                d10 = cVar.o();
            } else if (I == 3) {
                str = cVar.y();
            } else if (I == 4) {
                str2 = cVar.y();
            } else if (I != 5) {
                cVar.K();
                cVar.P();
            } else {
                cVar.d();
                while (cVar.k()) {
                    if (cVar.I(f7631b) != 0) {
                        cVar.K();
                        cVar.P();
                    } else {
                        cVar.c();
                        while (cVar.k()) {
                            arrayList.add((p) h.a(cVar, hVar));
                        }
                        cVar.e();
                    }
                }
                cVar.f();
            }
        }
        cVar.f();
        return new d(arrayList, c10, d11, d10, str, str2);
    }
}
