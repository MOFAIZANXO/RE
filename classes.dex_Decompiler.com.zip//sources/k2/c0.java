package k2;

import com.airbnb.lottie.h;
import g2.b;
import g2.m;
import h2.j;
import l2.c;
import q5.d;

public abstract class c0 {

    /* renamed from: a  reason: collision with root package name */
    public static final c.a f7598a = c.a.a("nm", "sy", "pt", "p", "r", "or", "os", "ir", "is", "hd", d.f9357g);

    public static j a(c cVar, h hVar, int i10) {
        c cVar2 = cVar;
        h hVar2 = hVar;
        boolean z10 = false;
        boolean z11 = i10 == 3;
        String str = null;
        j.a aVar = null;
        b bVar = null;
        m mVar = null;
        b bVar2 = null;
        b bVar3 = null;
        b bVar4 = null;
        b bVar5 = null;
        b bVar6 = null;
        while (cVar.k()) {
            switch (cVar2.I(f7598a)) {
                case 0:
                    str = cVar.y();
                    break;
                case 1:
                    aVar = j.a.a(cVar.q());
                    break;
                case 2:
                    bVar = d.f(cVar2, hVar2, false);
                    break;
                case 3:
                    mVar = a.b(cVar, hVar);
                    break;
                case 4:
                    bVar2 = d.f(cVar2, hVar2, false);
                    break;
                case 5:
                    bVar4 = d.e(cVar, hVar);
                    break;
                case 6:
                    bVar6 = d.f(cVar2, hVar2, false);
                    break;
                case 7:
                    bVar3 = d.e(cVar, hVar);
                    break;
                case 8:
                    bVar5 = d.f(cVar2, hVar2, false);
                    break;
                case 9:
                    z10 = cVar.m();
                    break;
                case 10:
                    if (cVar.q() != 3) {
                        z11 = false;
                        break;
                    } else {
                        z11 = true;
                        break;
                    }
                default:
                    cVar.K();
                    cVar.P();
                    break;
            }
        }
        return new j(str, aVar, bVar, mVar, bVar2, bVar3, bVar4, bVar5, bVar6, z10, z11);
    }
}
