package k2;

import h2.i;
import l2.c;

public abstract class y {

    /* renamed from: a  reason: collision with root package name */
    public static final c.a f7656a = c.a.a("nm", "mm", "hd");

    public static i a(c cVar) {
        String str = null;
        boolean z10 = false;
        i.a aVar = null;
        while (cVar.k()) {
            int I = cVar.I(f7656a);
            if (I == 0) {
                str = cVar.y();
            } else if (I == 1) {
                aVar = i.a.a(cVar.q());
            } else if (I != 2) {
                cVar.K();
                cVar.P();
            } else {
                z10 = cVar.m();
            }
        }
        return new i(str, aVar, z10);
    }
}
