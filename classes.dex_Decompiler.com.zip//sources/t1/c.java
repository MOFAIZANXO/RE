package t1;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import u1.d;
import w1.p;

public abstract class c implements s1.a {

    /* renamed from: a  reason: collision with root package name */
    public final List f9843a = new ArrayList();

    /* renamed from: b  reason: collision with root package name */
    public Object f9844b;

    /* renamed from: c  reason: collision with root package name */
    public d f9845c;

    /* renamed from: d  reason: collision with root package name */
    public a f9846d;

    public interface a {
        void a(List list);

        void b(List list);
    }

    public c(d dVar) {
        this.f9845c = dVar;
    }

    public void a(Object obj) {
        this.f9844b = obj;
        h(this.f9846d, obj);
    }

    public abstract boolean b(p pVar);

    public abstract boolean c(Object obj);

    public boolean d(String str) {
        Object obj = this.f9844b;
        return obj != null && c(obj) && this.f9843a.contains(str);
    }

    public void e(Iterable iterable) {
        this.f9843a.clear();
        Iterator it = iterable.iterator();
        while (it.hasNext()) {
            p pVar = (p) it.next();
            if (b(pVar)) {
                this.f9843a.add(pVar.f10358a);
            }
        }
        if (this.f9843a.isEmpty()) {
            this.f9845c.c(this);
        } else {
            this.f9845c.a(this);
        }
        h(this.f9846d, this.f9844b);
    }

    public void f() {
        if (!this.f9843a.isEmpty()) {
            this.f9843a.clear();
            this.f9845c.c(this);
        }
    }

    public void g(a aVar) {
        if (this.f9846d != aVar) {
            this.f9846d = aVar;
            h(aVar, this.f9844b);
        }
    }

    public final void h(a aVar, Object obj) {
        if (!this.f9843a.isEmpty() && aVar != null) {
            if (obj == null || c(obj)) {
                aVar.b(this.f9843a);
            } else {
                aVar.a(this.f9843a);
            }
        }
    }
}
