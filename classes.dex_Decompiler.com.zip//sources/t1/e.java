package t1;

import android.content.Context;
import n1.l;
import n1.m;
import s1.b;
import u1.g;
import w1.p;
import z1.a;

public class e extends c {

    /* renamed from: e  reason: collision with root package name */
    public static final String f9847e = l.f("NetworkMeteredCtrlr");

    public e(Context context, a aVar) {
        super(g.c(context, aVar).d());
    }

    public boolean b(p pVar) {
        return pVar.f10367j.b() == m.METERED;
    }

    /* renamed from: i */
    public boolean c(b bVar) {
        return !bVar.a() || !bVar.b();
    }
}
