package t1;

import android.content.Context;
import n1.m;
import s1.b;
import u1.g;
import w1.p;
import z1.a;

public class d extends c {
    public d(Context context, a aVar) {
        super(g.c(context, aVar).d());
    }

    public boolean b(p pVar) {
        return pVar.f10367j.b() == m.CONNECTED;
    }

    /* renamed from: i */
    public boolean c(b bVar) {
        return !bVar.a() || !bVar.d();
    }
}
