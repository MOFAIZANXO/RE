package t1;

import android.content.Context;
import u1.g;
import w1.p;
import z1.a;

public class h extends c {
    public h(Context context, a aVar) {
        super(g.c(context, aVar).e());
    }

    public boolean b(p pVar) {
        return pVar.f10367j.i();
    }

    /* renamed from: i */
    public boolean c(Boolean bool) {
        return !bool.booleanValue();
    }
}
