package t1;

import android.content.Context;
import u1.g;
import w1.p;

public class a extends c {
    public a(Context context, z1.a aVar) {
        super(g.c(context, aVar).a());
    }

    public boolean b(p pVar) {
        return pVar.f10367j.g();
    }

    /* renamed from: i */
    public boolean c(Boolean bool) {
        return !bool.booleanValue();
    }
}
