package x8;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;

public class l1 extends RecyclerView.t0 {

    /* renamed from: u  reason: collision with root package name */
    public TextView f10997u;

    /* renamed from: v  reason: collision with root package name */
    public ImageView f10998v;

    public l1(View view) {
        super(view);
        this.f10997u = (TextView) view.findViewById(2131362722);
        this.f10998v = (ImageView) view.findViewById(2131362721);
    }
}
