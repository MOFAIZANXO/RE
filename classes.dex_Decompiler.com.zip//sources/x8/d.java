package x8;

import android.view.View;
import com.samsung.android.sm.core.data.AppData;

public final /* synthetic */ class d implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ g f10925a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ AppData f10926b;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ i f10927f;

    public /* synthetic */ d(g gVar, AppData appData, i iVar) {
        this.f10925a = gVar;
        this.f10926b = appData;
        this.f10927f = iVar;
    }

    public final void onClick(View view) {
        this.f10925a.b0(this.f10926b, this.f10927f, view);
    }
}
