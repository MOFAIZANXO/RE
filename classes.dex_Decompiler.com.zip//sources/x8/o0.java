package x8;

import androidx.lifecycle.t;
import w8.g;

public final /* synthetic */ class o0 implements t {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ u0 f11010a;

    public /* synthetic */ o0(u0 u0Var) {
        this.f11010a = u0Var;
    }

    public final void a(Object obj) {
        this.f11010a.x0((g) obj);
    }
}
