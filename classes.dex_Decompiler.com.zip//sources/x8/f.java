package x8;

import android.widget.ImageView;
import android.widget.TextView;

public final /* synthetic */ class f implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ g f10932a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ TextView f10933b;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ ImageView f10934f;

    public /* synthetic */ f(g gVar, TextView textView, ImageView imageView) {
        this.f10932a = gVar;
        this.f10933b = textView;
        this.f10934f = imageView;
    }

    public final void run() {
        this.f10932a.c0(this.f10933b, this.f10934f);
    }
}
