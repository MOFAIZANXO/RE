package x8;

import android.view.View;
import com.samsung.android.sm.core.data.AppData;

public final /* synthetic */ class v0 implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ w0 f11072a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ AppData f11073b;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ i f11074f;

    public /* synthetic */ v0(w0 w0Var, AppData appData, i iVar) {
        this.f11072a = w0Var;
        this.f11073b = appData;
        this.f11074f = iVar;
    }

    public final void onClick(View view) {
        this.f11072a.S(this.f11073b, this.f11074f, view);
    }
}
