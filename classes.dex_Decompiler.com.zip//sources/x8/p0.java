package x8;

import androidx.lifecycle.t;
import w8.g;

public final /* synthetic */ class p0 implements t {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ u0 f11015a;

    public /* synthetic */ p0(u0 u0Var) {
        this.f11015a = u0Var;
    }

    public final void a(Object obj) {
        this.f11015a.y0((g) obj);
    }
}
