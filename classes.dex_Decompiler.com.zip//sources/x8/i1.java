package x8;

import com.samsung.android.sm.core.data.AppData;
import java.util.function.Predicate;

public final /* synthetic */ class i1 implements Predicate {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ k1 f10966a;

    public /* synthetic */ i1(k1 k1Var) {
        this.f10966a = k1Var;
    }

    public final boolean test(Object obj) {
        return this.f10966a.T((AppData) obj);
    }
}
