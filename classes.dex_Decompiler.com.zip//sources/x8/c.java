package x8;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public final /* synthetic */ class c implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ g f10921a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ TextView f10922b;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ ImageView f10923f;

    public /* synthetic */ c(g gVar, TextView textView, ImageView imageView) {
        this.f10921a = gVar;
        this.f10922b = textView;
        this.f10923f = imageView;
    }

    public final void onClick(View view) {
        this.f10921a.d0(this.f10922b, this.f10923f, view);
    }
}
