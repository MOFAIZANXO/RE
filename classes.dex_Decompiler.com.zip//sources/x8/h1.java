package x8;

import com.samsung.android.sm.core.data.AppData;
import java.util.function.Predicate;

public final /* synthetic */ class h1 implements Predicate {
    public final boolean test(Object obj) {
        return k1.W((AppData) obj);
    }
}
