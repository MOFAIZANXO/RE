package x8;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import com.samsung.android.sm.core.data.AppData;
import com.samsung.android.sm.core.data.PkgUid;
import java.util.ArrayList;
import w6.q;

public class y0 extends b {
    public y0(Context context, q qVar, b0 b0Var) {
        super(context, qVar, b0Var);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void T(AppData appData, i iVar, View view) {
        PkgUid pkgUid = new PkgUid(appData.z(), appData.G());
        CheckBox checkBox = iVar.f10963y;
        checkBox.setChecked(!checkBox.isChecked());
        this.f10908f.g(0, pkgUid);
    }

    /* renamed from: N */
    public void w(i iVar, int i10) {
        super.N(iVar, i10);
        AppData appData = (AppData) this.f10909g.get(i10);
        if (appData != null) {
            iVar.f10962x.setVisibility(4);
            iVar.f10963y.setContentDescription(iVar.f10960v.getText());
            iVar.f2105a.setOnClickListener(new x0(this, appData, iVar));
            iVar.f10964z.setBackgroundColor(this.f10906d.getColor(2131100751));
        }
    }

    public ArrayList S() {
        return new ArrayList(this.f10909g);
    }

    /* renamed from: U */
    public i y(ViewGroup viewGroup, int i10) {
        return new i(LayoutInflater.from(this.f10906d).inflate(2131558618, viewGroup, false));
    }
}
