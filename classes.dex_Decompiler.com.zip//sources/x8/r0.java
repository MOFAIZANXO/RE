package x8;

public final /* synthetic */ class r0 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ u0 f11025a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ int[] f11026b;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ int f11027f;

    public /* synthetic */ r0(u0 u0Var, int[] iArr, int i10) {
        this.f11025a = u0Var;
        this.f11026b = iArr;
        this.f11027f = i10;
    }

    public final void run() {
        this.f11025a.A0(this.f11026b, this.f11027f);
    }
}
