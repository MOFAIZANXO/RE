package x8;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.MenuItem;
import android.view.ViewGroup;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.samsung.android.sm.core.data.AppData;
import com.samsung.android.util.SemLog;
import d7.b;
import f7.y0;
import java.util.ArrayList;
import java.util.List;
import w6.q;

public class u extends ViewGroup {

    /* renamed from: a  reason: collision with root package name */
    public String f11033a;

    /* renamed from: b  reason: collision with root package name */
    public final Context f11034b;

    /* renamed from: f  reason: collision with root package name */
    public final q f11035f;

    /* renamed from: g  reason: collision with root package name */
    public q f11036g;

    /* renamed from: h  reason: collision with root package name */
    public q f11037h;

    /* renamed from: i  reason: collision with root package name */
    public int f11038i;

    /* renamed from: j  reason: collision with root package name */
    public y0 f11039j;

    /* renamed from: k  reason: collision with root package name */
    public final c0 f11040k;

    /* renamed from: l  reason: collision with root package name */
    public BottomNavigationView f11041l;

    /* renamed from: m  reason: collision with root package name */
    public final s6.a f11042m;

    /* renamed from: n  reason: collision with root package name */
    public LinearLayoutManager f11043n;

    /* renamed from: o  reason: collision with root package name */
    public j f11044o = new a();

    /* renamed from: p  reason: collision with root package name */
    public j f11045p = new r(this);

    public class a implements j {
        public a() {
        }

        public void a(boolean z10) {
            u.this.u(z10);
        }

        public void b() {
            u.this.f11040k.c();
        }
    }

    public u(Context context, c0 c0Var, s6.a aVar) {
        super(context);
        this.f11034b = context;
        this.f11035f = new q(context);
        this.f11038i = 1000;
        this.f11040k = c0Var;
        this.f11042m = aVar;
    }

    private int getAdapterType() {
        return this.f11038i == 1000 ? 2001 : 2002;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ boolean j(MenuItem menuItem) {
        int itemId = menuItem.getItemId();
        if (itemId == 2131362452) {
            h(this.f11038i);
            this.f11040k.b(1000, false);
        } else if (itemId != 2131362457) {
            SemLog.e("ExceptedAppsListElement", "onNavigationItemSelected Wrong case!!");
        } else {
            this.f11040k.b(1000, true);
        }
        return false;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void k() {
        this.f11039j.D.c3(this.f11036g.O());
    }

    public List f(int i10) {
        if (i10 != 1001) {
            q qVar = this.f11036g;
            if (qVar == null) {
                return null;
            }
            return qVar.P();
        }
        q qVar2 = this.f11037h;
        if (qVar2 == null) {
            return null;
        }
        return qVar2.P();
    }

    public void g() {
        p();
        o();
    }

    public q getAdapter() {
        return getMode() == 1001 ? this.f11037h : this.f11036g;
    }

    public String[] getCheckedList() {
        List<AppData> f10 = f(getMode());
        if (f10 == null) {
            return null;
        }
        String[] strArr = new String[f10.size()];
        int i10 = 0;
        for (AppData appData : f10) {
            if (appData != null) {
                strArr[i10] = appData.C().d();
                i10++;
            }
        }
        return strArr;
    }

    public int getMode() {
        return this.f11038i;
    }

    public void h(int i10) {
        if (i10 == 1002) {
            String string = getContext().getString(2131952756);
            this.f11033a = string;
            b.c(string, this.f11034b.getString(2131952141));
            return;
        }
        String string2 = getContext().getString(2131952755);
        this.f11033a = string2;
        b.c(string2, this.f11034b.getString(2131952139));
    }

    public void i(int i10) {
        if (i10 == 1002) {
            String string = getContext().getString(2131952756);
            this.f11033a = string;
            b.c(string, this.f11034b.getString(2131952143));
            return;
        }
        String string2 = getContext().getString(2131952755);
        this.f11033a = string2;
        b.c(string2, this.f11034b.getString(2131952140));
    }

    public void l() {
        this.f11035f.m();
    }

    public void m() {
        this.f11035f.n();
    }

    public void n() {
        boolean k10 = this.f11042m.k();
        getAdapter().N(!k10);
        u(!k10);
        i(this.f11038i);
    }

    public final void o() {
        BottomNavigationView bottomNavigationView = this.f11039j.f6289z;
        this.f11041l = bottomNavigationView;
        bottomNavigationView.getMenu().findItem(2131362457).setShowAsAction(2);
        this.f11041l.getMenu().findItem(2131362452).setShowAsAction(2);
        this.f11041l.setOnItemSelectedListener(new s(this));
    }

    public void onLayout(boolean z10, int i10, int i11, int i12, int i13) {
    }

    public final void p() {
        if (this.f11036g == null) {
            q qVar = new q(this.f11034b, this.f11035f, getAdapterType());
            this.f11036g = qVar;
            qVar.I(true);
        }
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this.f11034b);
        this.f11043n = linearLayoutManager;
        this.f11039j.D.setLayoutManager(linearLayoutManager);
        this.f11039j.D.setAdapter(this.f11036g);
        this.f11036g.X(this.f11044o);
        this.f11039j.D.k3(true);
        this.f11039j.D.j3(true);
        this.f11039j.D.setRoundedCorners(15);
        this.f11039j.D.h3(true);
        this.f11039j.D.setItemAnimator((RecyclerView.z) null);
        this.f11039j.D.setNestedScrollingEnabled(true);
        if (this.f11037h == null) {
            q qVar2 = new q(this.f11034b, this.f11035f, 2002);
            this.f11037h = qVar2;
            qVar2.I(true);
        }
        this.f11039j.E.setLayoutManager(new LinearLayoutManager(this.f11034b));
        this.f11039j.E.setAdapter(this.f11037h);
        this.f11037h.X(this.f11045p);
        this.f11039j.E.k3(true);
        this.f11039j.E.j3(true);
        this.f11039j.E.setRoundedCorners(15);
        this.f11039j.E.h3(true);
        this.f11039j.E.setItemAnimator((RecyclerView.z) null);
        this.f11039j.E.setNestedScrollingEnabled(true);
    }

    public void q() {
        if (this.f11038i != 1001) {
            this.f11036g.Z(getAdapterType());
            if (this.f11038i != 1002) {
                return;
            }
            if (this.f11036g.O() == this.f11043n.a2() || this.f11036g.O() == this.f11043n.c2()) {
                new Handler(Looper.getMainLooper()).postDelayed(new t(this), 200);
            }
        }
    }

    public void r() {
        this.f11040k.a(false);
        this.f11039j.D.setVisibility(8);
        this.f11039j.E.setVisibility(8);
        this.f11037h.Y(new ArrayList());
        this.f11039j.E.c3(0);
        this.f11039j.F.setVisibility(8);
        this.f11039j.A.setVisibility(8);
        this.f11039j.G.setVisibility(0);
    }

    public void s() {
        if (getMode() != 1001) {
            this.f11040k.a(getMode() == 1000);
            this.f11037h.Y(new ArrayList());
            this.f11039j.E.setVisibility(8);
            this.f11039j.D.setVisibility(0);
        } else {
            this.f11039j.D.setVisibility(8);
            this.f11039j.E.setVisibility(0);
        }
        v(getAdapter().j());
        this.f11039j.G.setVisibility(8);
        setDescription(getMode());
    }

    public void setBinding(y0 y0Var) {
        this.f11039j = y0Var;
    }

    public void setCustomActionBarView(int i10) {
        this.f11042m.p(getAdapter().j() != 0);
        if (i10 != 1000) {
            u(getAdapter().R());
        } else {
            this.f11042m.f(this.f11034b.getString(2131951708));
        }
        w(i10);
    }

    public void setDataList(List<AppData> list) {
        getAdapter().Y(list);
    }

    public void setDescription(int i10) {
        if (i10 != 1000 || this.f11036g.j() <= 0) {
            this.f11039j.F.setVisibility(8);
            return;
        }
        this.f11039j.F.setText(this.f11034b.getResources().getString(2131952290));
        this.f11039j.F.setVisibility(0);
    }

    public void setHideCustomActionBarView(int i10) {
        this.f11042m.f("");
        w(i10);
    }

    public void setMode(int i10) {
        SemLog.d("ExceptedAppsListElement", "type :" + i10);
        this.f11038i = i10;
        if (i10 != 1000) {
            this.f11042m.u();
        } else if (this.f11042m.j()) {
            this.f11042m.l();
        }
        t(true);
    }

    public void setSelectedItems(String[] strArr) {
        if (getAdapter() != null) {
            getAdapter().a0(strArr);
            u(strArr.length == getAdapter().j());
        }
    }

    public void t(boolean z10) {
        if (this.f11038i == 1000 || z10) {
            this.f11041l.setVisibility(8);
            return;
        }
        this.f11041l.setVisibility(0);
        this.f11041l.getMenu().findItem(2131362457).setTitle(this.f11038i == 1002 ? 2131951867 : 2131951654).setContentDescription(this.f11038i == 1002 ? this.f11034b.getResources().getString(2131951867) : this.f11034b.getResources().getString(2131951654));
    }

    public final void u(boolean z10) {
        String str;
        this.f11042m.i(z10);
        if (f(getMode()).size() > 0) {
            str = this.f11034b.getResources().getString(2131953123, new Object[]{Integer.valueOf(f(getMode()).size())});
            this.f11041l.getMenu().findItem(2131362457).setEnabled(true);
        } else {
            str = this.f11034b.getResources().getString(2131951688);
            this.f11041l.getMenu().findItem(2131362457).setEnabled(false);
        }
        this.f11042m.f(str);
    }

    public void v(int i10) {
        this.f11039j.A.setVisibility(i10 == 0 ? 0 : 8);
    }

    public final void w(int i10) {
        this.f11040k.a(i10 == 1000);
    }
}
