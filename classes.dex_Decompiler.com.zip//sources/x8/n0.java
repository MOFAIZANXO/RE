package x8;

import androidx.lifecycle.t;
import w8.g;

public final /* synthetic */ class n0 implements t {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ u0 f11005a;

    public /* synthetic */ n0(u0 u0Var) {
        this.f11005a = u0Var;
    }

    public final void a(Object obj) {
        this.f11005a.w0((g) obj);
    }
}
