package x8;

public final /* synthetic */ class r implements j {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ u f11024a;

    public /* synthetic */ r(u uVar) {
        this.f11024a = uVar;
    }

    public final void a(boolean z10) {
        this.f11024a.u(z10);
    }
}
