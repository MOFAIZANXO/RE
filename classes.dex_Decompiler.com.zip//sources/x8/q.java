package x8;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import androidx.recyclerview.widget.RecyclerView;
import com.samsung.android.sm.core.data.AppData;
import com.samsung.android.sm.core.data.PkgUid;
import com.samsung.android.util.SemLog;
import d7.b;
import f7.m1;
import java.util.ArrayList;
import java.util.List;
import w6.i0;
import w6.t;
import x6.h;

public class q extends RecyclerView.t {

    /* renamed from: d  reason: collision with root package name */
    public final String f11016d;

    /* renamed from: e  reason: collision with root package name */
    public final Context f11017e;

    /* renamed from: f  reason: collision with root package name */
    public int f11018f;

    /* renamed from: g  reason: collision with root package name */
    public final List f11019g = new ArrayList();

    /* renamed from: h  reason: collision with root package name */
    public final w6.q f11020h;

    /* renamed from: i  reason: collision with root package name */
    public j f11021i;

    /* renamed from: j  reason: collision with root package name */
    public int f11022j = 0;

    public q(Context context, w6.q qVar, int i10) {
        this.f11017e = context;
        this.f11020h = qVar;
        this.f11018f = i10;
        this.f11016d = context.getResources().getString(2131952754);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void S(AppData appData, k kVar, int i10, View view) {
        switch (this.f11018f) {
            case 2000:
            case 2001:
                PkgUid pkgUid = new PkgUid(appData.z(), appData.G());
                b.f(this.f11016d, this.f11017e.getString(2131952144), appData.z());
                V(pkgUid);
                return;
            case 2002:
                b0(kVar, i10);
                j jVar = this.f11021i;
                if (jVar != null) {
                    jVar.a(R());
                    return;
                }
                return;
            default:
                SemLog.e("ExceptedAppsListAdapter", "Click Type Error");
                return;
        }
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void T(AppData appData, k kVar, int i10, View view) {
        switch (this.f11018f) {
            case 2000:
            case 2001:
                PkgUid pkgUid = new PkgUid(appData.z(), appData.G());
                b.f(this.f11016d, this.f11017e.getString(2131952144), appData.z());
                V(pkgUid);
                return;
            case 2002:
                b0(kVar, i10);
                j jVar = this.f11021i;
                if (jVar != null) {
                    jVar.a(R());
                    return;
                }
                return;
            default:
                SemLog.e("ExceptedAppsListAdapter", "Click Type Error");
                return;
        }
    }

    /* access modifiers changed from: private */
    public /* synthetic */ boolean U(RecyclerView.t0 t0Var, k kVar, int i10, View view) {
        if (this.f11018f != 2001) {
            return false;
        }
        if (this.f11021i == null) {
            return true;
        }
        this.f11022j = t0Var.k();
        b0(kVar, i10);
        this.f11021i.b();
        this.f11021i.a(R());
        return true;
    }

    public void N(boolean z10) {
        for (AppData appData : this.f11019g) {
            if (appData.z() != null) {
                appData.M(z10);
            }
        }
        o();
    }

    public int O() {
        return this.f11022j;
    }

    public List P() {
        ArrayList arrayList = new ArrayList();
        for (AppData appData : this.f11019g) {
            if (appData.r()) {
                arrayList.add(appData);
            }
        }
        return arrayList;
    }

    public void Q() {
        for (AppData M : this.f11019g) {
            M.M(false);
        }
        o();
    }

    public boolean R() {
        return this.f11019g.size() != 0 && this.f11019g.size() == P().size();
    }

    public final void V(PkgUid pkgUid) {
        t tVar = new t(this.f11017e);
        if (tVar.a(pkgUid) != null) {
            i0.n(tVar.a(pkgUid), pkgUid);
        }
    }

    /* renamed from: W */
    public h y(ViewGroup viewGroup, int i10) {
        return new k(m1.O(LayoutInflater.from(this.f11017e), viewGroup, false));
    }

    public void X(j jVar) {
        this.f11021i = jVar;
    }

    public void Y(List list) {
        this.f11019g.clear();
        this.f11019g.addAll(list);
        o();
    }

    public void Z(int i10) {
        if (i10 == 2001) {
            Q();
        }
        this.f11018f = i10;
        o();
    }

    public void a0(String[] strArr) {
        for (AppData appData : this.f11019g) {
            String d10 = appData.C().d();
            for (String equals : strArr) {
                if (d10.equals(equals)) {
                    appData.M(true);
                }
            }
        }
        o();
    }

    public final void b0(k kVar, int i10) {
        CheckBox checkBox = kVar.f10986y;
        if (checkBox != null) {
            checkBox.setChecked(!((AppData) this.f11019g.get(i10)).r());
            ((AppData) this.f11019g.get(i10)).M(!((AppData) this.f11019g.get(i10)).r());
        }
    }

    public int j() {
        return this.f11019g.size();
    }

    public long k(int i10) {
        return this.f11019g.get(i10) == null ? (long) i10 : (long) ((AppData) this.f11019g.get(i10)).hashCode();
    }

    public void w(RecyclerView.t0 t0Var, int i10) {
        AppData appData = (AppData) this.f11019g.get(i10);
        if (appData != null) {
            k kVar = (k) t0Var;
            kVar.P();
            if (appData.z() != null) {
                this.f11020h.k(appData.C(), kVar.f10984w);
                kVar.f10985x.setVisibility(8);
                kVar.f10983v.setText(appData.u());
                kVar.f10986y.setChecked(appData.r());
                kVar.f10986y.jumpDrawablesToCurrentState();
                if (this.f11018f == 2002) {
                    kVar.f10986y.setVisibility(0);
                    kVar.f10986y.setContentDescription(kVar.f10983v.getText());
                } else {
                    kVar.f10986y.setChecked(false);
                    kVar.f10986y.setVisibility(8);
                }
                if (i10 == j() - 1) {
                    kVar.f2105a.findViewById(2131362202).setVisibility(8);
                    kVar.f2105a.setOnClickListener(new n(this, appData, kVar, i10));
                } else {
                    kVar.f2105a.findViewById(2131362202).setVisibility(0);
                }
                kVar.f2105a.setOnClickListener(new o(this, appData, kVar, i10));
                kVar.f2105a.setOnLongClickListener(new p(this, t0Var, kVar, i10));
            }
        }
    }
}
