package x8;

import android.view.View;
import com.samsung.android.sm.core.data.AppData;

public final /* synthetic */ class x0 implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ y0 f11078a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ AppData f11079b;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ i f11080f;

    public /* synthetic */ x0(y0 y0Var, AppData appData, i iVar) {
        this.f11078a = y0Var;
        this.f11079b = appData;
        this.f11080f = iVar;
    }

    public final void onClick(View view) {
        this.f11078a.T(this.f11079b, this.f11080f, view);
    }
}
