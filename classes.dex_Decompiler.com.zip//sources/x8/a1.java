package x8;

import com.samsung.android.sm.core.data.AppData;
import java.util.function.Consumer;

public final /* synthetic */ class a1 implements Consumer {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ b1 f10905a;

    public /* synthetic */ a1(b1 b1Var) {
        this.f10905a = b1Var;
    }

    public final void accept(Object obj) {
        this.f10905a.J((AppData) obj);
    }
}
