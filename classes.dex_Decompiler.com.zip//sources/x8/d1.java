package x8;

import com.google.android.material.appbar.AppBarLayout;
import com.samsung.android.sm.ram.ui.ResidentAppsActivity;

public final /* synthetic */ class d1 implements AppBarLayout.g {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ResidentAppsActivity f10928a;

    public /* synthetic */ d1(ResidentAppsActivity residentAppsActivity) {
        this.f10928a = residentAppsActivity;
    }

    public final void a(AppBarLayout appBarLayout, int i10) {
        this.f10928a.h0(appBarLayout, i10);
    }
}
