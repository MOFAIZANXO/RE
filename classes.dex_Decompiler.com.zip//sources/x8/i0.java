package x8;

import android.animation.ValueAnimator;

public final /* synthetic */ class i0 implements ValueAnimator.AnimatorUpdateListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ j0 f10965a;

    public /* synthetic */ i0(j0 j0Var) {
        this.f10965a = j0Var;
    }

    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        this.f10965a.I(valueAnimator);
    }
}
