package x8;

public final /* synthetic */ class k0 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ u0 f10988a;

    public /* synthetic */ k0(u0 u0Var) {
        this.f10988a = u0Var;
    }

    public final void run() {
        this.f10988a.B0();
    }
}
