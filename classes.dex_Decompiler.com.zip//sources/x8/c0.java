package x8;

public interface c0 {
    void a(boolean z10);

    void b(int i10, boolean z10);

    void c();
}
