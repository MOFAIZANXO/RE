package x8;

import android.view.View;
import com.samsung.android.sm.core.data.AppData;

public final /* synthetic */ class o implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ q f11006a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ AppData f11007b;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ k f11008f;

    /* renamed from: g  reason: collision with root package name */
    public final /* synthetic */ int f11009g;

    public /* synthetic */ o(q qVar, AppData appData, k kVar, int i10) {
        this.f11006a = qVar;
        this.f11007b = appData;
        this.f11008f = kVar;
        this.f11009g = i10;
    }

    public final void onClick(View view) {
        this.f11006a.T(this.f11007b, this.f11008f, this.f11009g, view);
    }
}
