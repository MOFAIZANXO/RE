package x8;

import com.samsung.android.sm.core.data.AppData;
import java.util.function.Consumer;

public final /* synthetic */ class l0 implements Consumer {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ u0 f10996a;

    public /* synthetic */ l0(u0 u0Var) {
        this.f10996a = u0Var;
    }

    public final void accept(Object obj) {
        this.f10996a.v0((AppData) obj);
    }
}
