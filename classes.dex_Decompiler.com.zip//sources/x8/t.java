package x8;

public final /* synthetic */ class t implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ u f11030a;

    public /* synthetic */ t(u uVar) {
        this.f11030a = uVar;
    }

    public final void run() {
        this.f11030a.k();
    }
}
