package x8;

import androidx.lifecycle.t;
import w8.g;

public final /* synthetic */ class q0 implements t {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ u0 f11023a;

    public /* synthetic */ q0(u0 u0Var) {
        this.f11023a = u0Var;
    }

    public final void a(Object obj) {
        this.f11023a.z0((g) obj);
    }
}
