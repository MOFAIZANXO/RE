package x8;

import a9.b;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.samsung.android.sm.core.data.AppData;
import com.samsung.android.sm.core.data.PkgUid;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import p5.x;
import w6.q;
import w6.t;

public class k1 extends RecyclerView.t {

    /* renamed from: d  reason: collision with root package name */
    public final Context f10989d;

    /* renamed from: e  reason: collision with root package name */
    public final b0 f10990e;

    /* renamed from: f  reason: collision with root package name */
    public final q f10991f;

    /* renamed from: g  reason: collision with root package name */
    public final List f10992g = new ArrayList();

    /* renamed from: h  reason: collision with root package name */
    public final List f10993h = new ArrayList();

    public static class a extends RecyclerView.t0 {

        /* renamed from: u  reason: collision with root package name */
        public TextView f10994u;

        public a(View view) {
            super(view);
            this.f10994u = (TextView) view.findViewById(2131362672);
        }
    }

    public k1(Context context, q qVar, b0 b0Var) {
        this.f10989d = context;
        this.f10991f = qVar;
        this.f10990e = b0Var;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void S(AppData appData, i iVar, View view) {
        PkgUid pkgUid = new PkgUid(appData.z(), appData.G());
        CheckBox checkBox = iVar.f10963y;
        checkBox.setChecked(!checkBox.isChecked());
        this.f10990e.g(17, pkgUid);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ boolean T(AppData appData) {
        return !this.f10993h.contains(appData.C());
    }

    public static /* synthetic */ boolean U(AppData appData) {
        return appData.s() == 256;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ boolean V(AppData appData) {
        return this.f10993h.contains(appData.C());
    }

    public static /* synthetic */ boolean W(AppData appData) {
        return appData.s() == 256;
    }

    public final void P(i iVar, int i10, AppData appData) {
        String u10 = appData.u();
        t tVar = new t(this.f10989d);
        if (u10 == null || u10.isEmpty()) {
            u10 = tVar.d(appData.C());
        }
        if (u10 != null) {
            u10 = u10.replace("\n", " ");
        }
        iVar.f10960v.setText(u10);
        iVar.f10962x.setText(b.d(this.f10989d, appData.x()));
        iVar.f10963y.setChecked(!this.f10993h.contains(appData.C()));
        iVar.f10963y.setVisibility(0);
        CheckBox checkBox = iVar.f10963y;
        checkBox.setContentDescription(iVar.f10960v.getText() + ", " + iVar.f10962x.getText());
        TextView textView = iVar.f10960v;
        if (u10 == null) {
            u10 = appData.u();
        }
        textView.setText(u10);
        this.f10991f.k(appData.C(), iVar.f10961w);
        iVar.f2105a.setOnClickListener(new f1(this, appData, iVar));
        Z(iVar, i10);
    }

    public ArrayList Q() {
        return (ArrayList) this.f10992g.stream().filter(new i1(this)).filter(new j1()).collect(Collectors.toCollection(new x()));
    }

    public ArrayList R() {
        return (ArrayList) this.f10992g.stream().filter(new g1(this)).filter(new h1()).collect(Collectors.toCollection(new x()));
    }

    public void X(List list) {
        this.f10992g.clear();
        this.f10992g.addAll(list);
        o();
    }

    public void Y(Set set) {
        this.f10993h.clear();
        this.f10993h.addAll(set);
    }

    public final void Z(i iVar, int i10) {
        int l10 = l(i10 - 1);
        int l11 = l(i10 + 1);
        if (l10 == 0 || i10 == 1) {
            if (l11 == 0 || i10 == j() - 1) {
                iVar.f10964z.setRoundedCorners(15);
                iVar.f2105a.findViewById(2131362202).setVisibility(8);
                return;
            }
            iVar.f2105a.findViewById(2131362202).setVisibility(0);
            iVar.f10964z.setRoundedCorners(3);
        } else if (i10 == j() - 1 || l11 == 0) {
            iVar.f10964z.setRoundedCorners(12);
            iVar.f2105a.findViewById(2131362202).setVisibility(8);
        } else {
            iVar.f2105a.findViewById(2131362202).setVisibility(0);
            iVar.f10964z.setRoundedCorners(0);
        }
    }

    public int j() {
        return this.f10992g.size();
    }

    public int l(int i10) {
        if (i10 < 0 || i10 >= this.f10992g.size()) {
            return -1;
        }
        return ((AppData) this.f10992g.get(i10)).s() == 256 ? 1 : 0;
    }

    public void w(RecyclerView.t0 t0Var, int i10) {
        int m10 = t0Var.m();
        if (m10 == 0) {
            ((a) t0Var).f10994u.setText(a7.b.e("screen.res.tablet") ? this.f10989d.getString(2131952670) : this.f10989d.getString(2131952669));
        } else if (m10 == 1) {
            i iVar = (i) t0Var;
            AppData appData = (AppData) this.f10992g.get(i10);
            if (appData != null) {
                P(iVar, i10, appData);
            }
        }
    }

    public RecyclerView.t0 y(ViewGroup viewGroup, int i10) {
        LayoutInflater from = LayoutInflater.from(this.f10989d);
        return i10 == 1 ? new i(from.inflate(2131558618, viewGroup, false)) : new a(from.inflate(2131558488, viewGroup, false));
    }
}
