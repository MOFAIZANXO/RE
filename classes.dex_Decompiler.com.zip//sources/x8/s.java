package x8;

import android.view.MenuItem;
import com.google.android.material.navigation.NavigationBarView;

public final /* synthetic */ class s implements NavigationBarView.c {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ u f11028a;

    public /* synthetic */ s(u uVar) {
        this.f11028a = uVar;
    }

    public final boolean a(MenuItem menuItem) {
        return this.f11028a.j(menuItem);
    }
}
