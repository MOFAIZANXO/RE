package x8;

import android.view.View;
import com.samsung.android.sm.ram.ui.RamActivity2;

public final /* synthetic */ class e0 implements View.OnLayoutChangeListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ RamActivity2 f10930a;

    public /* synthetic */ e0(RamActivity2 ramActivity2) {
        this.f10930a = ramActivity2;
    }

    public final void onLayoutChange(View view, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17) {
        this.f10930a.g0(view, i10, i11, i12, i13, i14, i15, i16, i17);
    }
}
