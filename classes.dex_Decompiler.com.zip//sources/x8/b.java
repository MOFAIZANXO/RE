package x8;

import android.content.Context;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.samsung.android.sm.core.data.AppData;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import p5.x;
import w6.q;
import w6.t;

public abstract class b extends RecyclerView.t {

    /* renamed from: d  reason: collision with root package name */
    public final Context f10906d;

    /* renamed from: e  reason: collision with root package name */
    public final q f10907e;

    /* renamed from: f  reason: collision with root package name */
    public final b0 f10908f;

    /* renamed from: g  reason: collision with root package name */
    public final List f10909g = new ArrayList();

    /* renamed from: h  reason: collision with root package name */
    public final List f10910h = new ArrayList();

    public b(Context context, q qVar, b0 b0Var) {
        this.f10906d = context;
        this.f10907e = qVar;
        this.f10908f = b0Var;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ boolean M(AppData appData) {
        return !this.f10910h.contains(appData.C());
    }

    public ArrayList L() {
        return (ArrayList) this.f10909g.stream().filter(new a(this)).collect(Collectors.toCollection(new x()));
    }

    public void N(i iVar, int i10) {
        t tVar = new t(this.f10906d);
        AppData appData = (AppData) this.f10909g.get(i10);
        if (appData != null) {
            String u10 = appData.u();
            if (u10 == null || u10.isEmpty()) {
                u10 = tVar.d(appData.C());
            }
            if (u10 != null) {
                u10 = u10.replace("\n", " ");
            }
            TextView textView = iVar.f10960v;
            if (u10 == null) {
                u10 = appData.u();
            }
            textView.setText(u10);
            P(iVar, i10);
            iVar.f10963y.setChecked(!this.f10910h.contains(appData.C()));
            iVar.f10963y.setVisibility(0);
            this.f10907e.k(appData.C(), iVar.f10961w);
        }
    }

    public void O(List list) {
        this.f10909g.clear();
        this.f10909g.addAll(list);
        o();
    }

    public void P(i iVar, int i10) {
        if (i10 == this.f10909g.size() - 1) {
            iVar.A.setVisibility(8);
        } else {
            iVar.A.setVisibility(0);
        }
    }

    public void Q(Set set) {
        this.f10910h.clear();
        this.f10910h.addAll(set);
    }

    public int j() {
        return this.f10909g.size();
    }

    public long k(int i10) {
        return (long) i10;
    }
}
