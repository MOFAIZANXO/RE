package x8;

import android.view.View;
import com.samsung.android.sm.core.data.AppData;

public final /* synthetic */ class f1 implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ k1 f10936a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ AppData f10937b;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ i f10938f;

    public /* synthetic */ f1(k1 k1Var, AppData appData, i iVar) {
        this.f10936a = k1Var;
        this.f10937b = appData;
        this.f10938f = iVar;
    }

    public final void onClick(View view) {
        this.f10936a.S(this.f10937b, this.f10938f, view);
    }
}
