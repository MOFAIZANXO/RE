package x8;

import androidx.lifecycle.t;
import com.samsung.android.sm.ram.ui.ExceptedAppsListActivity;
import java.util.List;

public final /* synthetic */ class l implements t {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ExceptedAppsListActivity f10995a;

    public /* synthetic */ l(ExceptedAppsListActivity exceptedAppsListActivity) {
        this.f10995a = exceptedAppsListActivity;
    }

    public final void a(Object obj) {
        this.f10995a.t0((List) obj);
    }
}
