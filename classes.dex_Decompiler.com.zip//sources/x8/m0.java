package x8;

import android.content.Intent;
import f6.a;

public final /* synthetic */ class m0 implements a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ u0 f11000a;

    public /* synthetic */ m0(u0 u0Var) {
        this.f11000a = u0Var;
    }

    public final void a(Intent intent, String str) {
        this.f11000a.t0(intent, str);
    }
}
