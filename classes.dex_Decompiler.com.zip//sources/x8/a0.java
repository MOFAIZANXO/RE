package x8;

import android.view.View;
import com.samsung.android.sm.ram.ui.a;

public final /* synthetic */ class a0 implements View.OnLayoutChangeListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ a f10904a;

    public /* synthetic */ a0(a aVar) {
        this.f10904a = aVar;
    }

    public final void onLayoutChange(View view, int i10, int i11, int i12, int i13, int i14, int i15, int i16, int i17) {
        this.f10904a.M(view, i10, i11, i12, i13, i14, i15, i16, i17);
    }
}
