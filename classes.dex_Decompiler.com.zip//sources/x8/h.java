package x8;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.samsung.android.sm.core.data.AppData;
import f7.m1;
import java.util.ArrayList;
import java.util.List;
import w6.q;

public class h extends RecyclerView.t {

    /* renamed from: d  reason: collision with root package name */
    public final Context f10951d;

    /* renamed from: e  reason: collision with root package name */
    public final q f10952e;

    /* renamed from: f  reason: collision with root package name */
    public final ArrayList f10953f = new ArrayList();

    public static class a extends x6.h {

        /* renamed from: v  reason: collision with root package name */
        public TextView f10954v;

        /* renamed from: w  reason: collision with root package name */
        public ImageView f10955w;

        /* renamed from: x  reason: collision with root package name */
        public View f10956x;

        /* renamed from: y  reason: collision with root package name */
        public TextView f10957y;

        public a(View view) {
            super(view);
        }

        public final void Q() {
            this.f10954v = (TextView) this.f2105a.findViewById(2131361919);
            this.f10955w = (ImageView) this.f2105a.findViewById(2131361913);
            this.f10956x = this.f2105a.findViewById(2131362202);
            this.f10957y = (TextView) this.f2105a.findViewById(2131361912);
        }
    }

    public h(Context context, q qVar) {
        this.f10951d = context;
        this.f10952e = qVar;
    }

    public ArrayList K() {
        return this.f10953f;
    }

    /* renamed from: L */
    public void w(a aVar, int i10) {
        AppData appData = (AppData) this.f10953f.get(i10);
        if (appData != null) {
            aVar.Q();
            O(aVar, appData);
        }
    }

    /* renamed from: M */
    public a y(ViewGroup viewGroup, int i10) {
        return new a(m1.N(LayoutInflater.from(this.f10951d)).z());
    }

    public void N() {
        if (!this.f10953f.isEmpty()) {
            ArrayList arrayList = this.f10953f;
            arrayList.remove(arrayList.get(0));
            u(0);
        }
    }

    public final void O(a aVar, AppData appData) {
        aVar.f10954v.setText(appData.u());
        this.f10952e.k(appData.C(), aVar.f10955w);
        aVar.f10956x.setVisibility(8);
        aVar.f10957y.setVisibility(8);
    }

    public void P(List list) {
        this.f10953f.clear();
        int i10 = 0;
        while (i10 < list.size() && i10 < 6) {
            AppData appData = (AppData) list.get(i10);
            appData.L((long) i10);
            this.f10953f.add(appData);
            i10++;
        }
    }

    public int j() {
        return this.f10953f.size();
    }

    public long k(int i10) {
        if (i10 >= this.f10953f.size()) {
            return 0;
        }
        return ((AppData) this.f10953f.get(i10)).q();
    }
}
