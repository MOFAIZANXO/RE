package x8;

import com.samsung.android.sm.core.data.AppData;
import com.samsung.android.sm.ram.ui.ResidentAppsActivity;
import java.util.ArrayList;
import java.util.function.Predicate;

public final /* synthetic */ class e1 implements Predicate {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ArrayList f10931a;

    public /* synthetic */ e1(ArrayList arrayList) {
        this.f10931a = arrayList;
    }

    public final boolean test(Object obj) {
        return ResidentAppsActivity.i0(this.f10931a, (AppData) obj);
    }
}
