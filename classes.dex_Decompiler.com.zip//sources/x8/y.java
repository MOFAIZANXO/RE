package x8;

import android.content.DialogInterface;
import com.samsung.android.sm.ram.ui.a;

public final /* synthetic */ class y implements DialogInterface.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ a f11081a;

    public /* synthetic */ y(a aVar) {
        this.f11081a = aVar;
    }

    public final void onClick(DialogInterface dialogInterface, int i10) {
        this.f11081a.N(dialogInterface, i10);
    }
}
