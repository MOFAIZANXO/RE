package x8;

public interface v {
    void l(int i10);
}
