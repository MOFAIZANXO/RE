package x8;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.lifecycle.g0;
import androidx.lifecycle.t;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.samsung.android.sm.common.utils.AppRestrictUtil;
import com.samsung.android.sm.core.data.AppData;
import com.samsung.android.sm.core.data.PkgUid;
import com.samsung.android.sm.ram.data.RamData;
import com.samsung.android.sm.ram.model.holder.DeviceMemInfo;
import com.samsung.android.util.SemLog;
import d7.b;
import f7.o1;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import v6.a;
import w6.q;
import w8.g;

public class b1 extends a implements View.OnClickListener, b0 {

    /* renamed from: f  reason: collision with root package name */
    public String f10911f = "RamMainFragment";

    /* renamed from: g  reason: collision with root package name */
    public DeviceMemInfo f10912g = new DeviceMemInfo();

    /* renamed from: h  reason: collision with root package name */
    public o1 f10913h;

    /* renamed from: i  reason: collision with root package name */
    public q f10914i;

    /* renamed from: j  reason: collision with root package name */
    public y0 f10915j;

    /* renamed from: k  reason: collision with root package name */
    public ArrayList f10916k;

    /* renamed from: l  reason: collision with root package name */
    public final Set f10917l = new HashSet();

    /* renamed from: m  reason: collision with root package name */
    public long f10918m;

    /* renamed from: n  reason: collision with root package name */
    public int f10919n;

    /* renamed from: o  reason: collision with root package name */
    public final t f10920o = new z0(this);

    /* access modifiers changed from: private */
    public /* synthetic */ void J(AppData appData) {
        b.f(this.f10246b.getString(2131952753), this.f10246b.getString(2131952277), appData.z());
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void K(g gVar) {
        SemLog.i("DC.RamManualFixFragment", "DevMem ob : " + gVar.f10537a);
        this.f10912g = (DeviceMemInfo) gVar.f10538b;
    }

    public static b1 L() {
        return new b1();
    }

    public final Bundle B() {
        Bundle bundle = new Bundle();
        RamData ramData = new RamData();
        ramData.f5214i = this.f10915j.L();
        ramData.p(this.f10919n);
        ramData.q(2);
        bundle.putParcelable("key_clean_datas", ramData);
        bundle.putLong("key_clean_mem_size", this.f10918m);
        bundle.putInt("key_clean_list_size_delete_item", C());
        return bundle;
    }

    public final int C() {
        if (this.f10915j.L().size() < 7) {
            return this.f10915j.L().size();
        }
        return 6;
    }

    public final Bundle D() {
        Bundle bundle = new Bundle();
        bundle.putBoolean("RESULT_CLEAN", (this.f10919n & 17) != 0);
        bundle.putParcelable("MEMORY_INFO", this.f10912g);
        bundle.putLong("key_clean_mem_size", this.f10918m);
        return bundle;
    }

    public final void E(ViewGroup viewGroup) {
        this.f10245a = (v6.b) getActivity();
        if (viewGroup != null) {
            viewGroup.removeAllViewsInLayout();
        }
        this.f10913h = o1.N(LayoutInflater.from(this.f10246b), viewGroup, false);
        this.f10915j = new y0(this.f10246b, this.f10914i, this);
        G();
        H();
        F();
    }

    public void F() {
        this.f10913h.E.f6231y.setText(this.f10246b.getString(2131952696));
        this.f10913h.E.f6231y.setOnClickListener(this);
        this.f10913h.E.f6232z.setText(this.f10246b.getString(2131952698));
        this.f10913h.E.f6232z.setOnClickListener(this);
    }

    public void G() {
        if (this.f10913h.G.getAdapter() == null) {
            this.f10913h.G.setAdapter(this.f10915j);
            this.f10913h.G.setLayoutManager(new LinearLayoutManager(this.f10246b));
        }
        this.f10913h.G.setRoundedCorners(15);
        this.f10915j.O(this.f10916k);
        this.f10915j.Q(this.f10917l);
        this.f10915j.o();
    }

    public void H() {
        this.f10913h.B.t(-150);
        int j10 = this.f10915j.j();
        this.f10913h.C.setText(this.f10246b.getResources().getQuantityString(2131820556, j10, new Object[]{Integer.valueOf(j10)}));
        this.f10913h.H.setText(this.f10246b.getResources().getQuantityString(2131820571, j10, new Object[]{Integer.valueOf(j10)}));
    }

    public final void I(ArrayList arrayList) {
        arrayList.forEach(new a1(this));
    }

    public void M() {
        Bundle bundle = new Bundle();
        String str = this.f10911f;
        str.hashCode();
        if (str.equals("RamCleanFragment")) {
            bundle = B();
        } else if (str.equals("RamMainFragment")) {
            bundle = D();
        }
        v6.b bVar = this.f10245a;
        if (bVar != null) {
            bVar.h(this.f10911f, bundle);
        }
    }

    public final void N() {
        boolean z10 = !this.f10915j.L().isEmpty();
        this.f10913h.E.f6231y.setEnabled(z10);
        this.f10913h.E.f6231y.setAlpha(z10 ? 1.0f : 0.4f);
    }

    public void g(int i10, PkgUid pkgUid) {
        if (this.f10917l.contains(pkgUid)) {
            this.f10917l.remove(pkgUid);
        } else {
            this.f10917l.add(pkgUid);
        }
        this.f10915j.Q(this.f10917l);
        N();
    }

    public void onAttach(Context context) {
        super.onAttach(context);
        q qVar = new q(context.getApplicationContext());
        this.f10914i = qVar;
        qVar.m();
        Bundle arguments = getArguments();
        if (arguments != null) {
            RamData ramData = (RamData) arguments.getParcelable("key_clean_datas");
            if (ramData != null) {
                this.f10919n = ramData.d();
                this.f10916k = ramData.f5214i;
            }
            this.f10918m = arguments.getLong("key_clean_mem_size");
        }
    }

    public void onClick(View view) {
        if (view.getId() == 2131362806) {
            this.f10911f = "RamMainFragment";
            M();
        } else if (view.getId() == 2131362417) {
            this.f10911f = "RamCleanFragment";
            new AppRestrictUtil(this.f10246b).s(0, "added_from_anomaly_manual", this.f10915j.L());
            I(this.f10915j.L());
            M();
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setHasOptionsMenu(false);
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        if (bundle != null) {
            this.f10916k = bundle.getParcelableArrayList("KEY_PACKAGE_CLEAN");
        }
        b9.b bVar = (b9.b) new g0(this).a(b9.b.class);
        bVar.s().n(getViewLifecycleOwner(), this.f10920o);
        bVar.t();
        E(viewGroup);
        return this.f10913h.z();
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putParcelableArrayList("KEY_PACKAGE_CLEAN", this.f10915j.S());
    }

    public void onStop() {
        super.onStop();
        this.f10914i.n();
    }

    public boolean y(boolean z10) {
        SemLog.i("DC.RamManualFixFragment", "onBackPressed : " + z10);
        M();
        return true;
    }
}
