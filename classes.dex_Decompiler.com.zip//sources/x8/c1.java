package x8;

import android.view.View;
import com.samsung.android.sm.ram.ui.ResidentAppsActivity;

public final /* synthetic */ class c1 implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ResidentAppsActivity f10924a;

    public /* synthetic */ c1(ResidentAppsActivity residentAppsActivity) {
        this.f10924a = residentAppsActivity;
    }

    public final void onClick(View view) {
        this.f10924a.j0(view);
    }
}
