package x8;

import androidx.lifecycle.t;
import w8.g;

public final /* synthetic */ class z0 implements t {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ b1 f11083a;

    public /* synthetic */ z0(b1 b1Var) {
        this.f11083a = b1Var;
    }

    public final void a(Object obj) {
        this.f11083a.K((g) obj);
    }
}
