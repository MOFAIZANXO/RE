package x8;

import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.samsung.android.sm.common.view.RoundedCornerLinearLayout;
import com.samsung.android.sm.core.data.AppData;
import com.samsung.android.sm.core.data.PkgUid;
import com.samsung.android.util.SemLog;
import d7.b;
import j6.a;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import w6.q;
import x6.e;

public class g extends e {

    /* renamed from: l  reason: collision with root package name */
    public final Context f10939l;

    /* renamed from: m  reason: collision with root package name */
    public final Resources f10940m;

    /* renamed from: n  reason: collision with root package name */
    public final q f10941n;

    /* renamed from: o  reason: collision with root package name */
    public final String f10942o;

    /* renamed from: p  reason: collision with root package name */
    public Set f10943p;

    /* renamed from: q  reason: collision with root package name */
    public final ArrayList f10944q;

    /* renamed from: r  reason: collision with root package name */
    public final b0 f10945r;

    /* renamed from: s  reason: collision with root package name */
    public boolean f10946s = false;

    /* renamed from: t  reason: collision with root package name */
    public boolean f10947t = false;

    /* renamed from: u  reason: collision with root package name */
    public final v f10948u;

    public g(Context context, q qVar, b0 b0Var, RecyclerView recyclerView, v vVar) {
        this.f10939l = context;
        Resources resources = context.getResources();
        this.f10940m = resources;
        this.f10879g = recyclerView;
        this.f10941n = qVar;
        this.f10945r = b0Var;
        this.f10944q = new ArrayList();
        this.f10942o = resources.getString(2131952753);
        this.f10948u = vVar;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void b0(AppData appData, i iVar, View view) {
        PkgUid pkgUid = new PkgUid(appData.z(), appData.G());
        CheckBox checkBox = iVar.f10963y;
        checkBox.setChecked(!checkBox.isChecked());
        this.f10945r.g(1, pkgUid);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void c0(TextView textView, ImageView imageView) {
        if (Z()) {
            textView.setText(2131951659);
            new a().a(this.f10939l.getApplicationContext().getResources(), textView, 2131951660);
            int size = this.f10944q.size() - 3;
            for (int i10 = 0; i10 < size; i10++) {
                this.f10881i.add(this.f10880h.remove(3));
            }
            e.f10875k = 3;
            t(3, size);
            this.f10946s = true;
        } else {
            new a().a(this.f10939l.getApplicationContext().getResources(), textView, 2131952649);
            if (this.f10881i.size() <= 6) {
                textView.setText(2131952648);
                Iterator it = this.f10881i.iterator();
                while (it.hasNext()) {
                    this.f10880h.add(e.f10875k, it.next());
                    e.f10875k++;
                }
                this.f10881i.clear();
                s(3, this.f10881i.size());
            } else {
                textView.setText(2131951659);
                int i11 = e.f10875k + 1;
                for (int i12 = 0; i12 < 6; i12++) {
                    this.f10880h.add(e.f10875k, this.f10881i.remove(0));
                    e.f10875k++;
                }
                s(i11, 6);
            }
        }
        o();
        L(Z());
        imageView.animate().rotation(Z() ? -180.0f : 0.0f).setInterpolator(new LinearInterpolator()).setDuration(400).withLayer();
        b.f(this.f10942o, this.f10940m.getString(2131952151), Z() ? "0" : "1");
        this.f10947t = true;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void d0(TextView textView, ImageView imageView, View view) {
        new Handler(Looper.getMainLooper()).postDelayed(new f(this, textView, imageView), 170);
    }

    public static /* synthetic */ void e0(l1 l1Var) {
        l1Var.f2105a.semRequestAccessibilityFocus();
        l1Var.f2105a.performAccessibilityAction(64, (Bundle) null);
    }

    public final void T(int i10, i iVar) {
        if (i10 < this.f10880h.size()) {
            AppData appData = (AppData) this.f10880h.get(i10);
            iVar.B = appData.z();
            iVar.f10960v.setText(appData.u());
            iVar.C = appData.G();
            iVar.f10962x.setText(a9.b.d(this.f10939l, appData.x()));
            iVar.f10963y.setChecked(!this.f10943p.contains(appData.C()));
            iVar.f10963y.setVisibility(0);
            CheckBox checkBox = iVar.f10963y;
            checkBox.setContentDescription(iVar.f10960v.getText() + ", " + iVar.f10962x.getText());
            if (a0(i10)) {
                iVar.A.setVisibility(8);
            } else {
                iVar.A.setVisibility(0);
            }
            iVar.f2105a.setOnClickListener(new d(this, appData, iVar));
            this.f10941n.k(appData.C(), iVar.f10961w);
            return;
        }
        SemLog.w("BgAppAdapter", "Wrong item position (bindView) : " + i10);
    }

    public final void U(l1 l1Var) {
        TextView textView = l1Var.f10997u;
        ImageView imageView = l1Var.f10998v;
        l1Var.f2105a.setSoundEffectsEnabled(false);
        l1Var.f2105a.setHapticFeedbackEnabled(false);
        if (Z()) {
            textView.setText(2131952648);
            imageView.setRotation(-180.0f);
            imageView.setContentDescription(this.f10939l.getString(2131952293));
            ((RoundedCornerLinearLayout) l1Var.f2105a).setRoundedCorners(0);
        } else {
            textView.setText(2131951659);
            textView.semSetButtonShapeEnabled(true);
            imageView.setRotation(0.0f);
            imageView.setContentDescription(this.f10939l.getString(2131952294));
            new a().a(this.f10939l.getApplicationContext().getResources(), textView, 2131951660);
        }
        if (this.f10947t) {
            W();
            X(l1Var);
            this.f10946s = false;
            this.f10947t = false;
        }
        l1Var.f2105a.setOnClickListener(new c(this, textView, imageView));
    }

    public void V() {
        if (!this.f10882j) {
            this.f10880h.clear();
            this.f10881i.clear();
            e.f10875k = 3;
            ArrayList arrayList = this.f10944q;
            if (arrayList != null && !arrayList.isEmpty()) {
                Iterator it = this.f10944q.iterator();
                while (it.hasNext()) {
                    AppData appData = (AppData) it.next();
                    if (this.f10880h.size() < 3) {
                        this.f10880h.add(appData);
                    } else {
                        this.f10881i.add(appData);
                    }
                }
                if (!this.f10881i.isEmpty()) {
                    this.f10880h.add(e.f10875k, f0());
                } else if (this.f10880h.size() < e.f10875k) {
                    e.f10875k = this.f10880h.size();
                }
            }
            O();
        }
    }

    public final void W() {
        this.f10948u.l(M());
    }

    public final void X(l1 l1Var) {
        if (w6.a.b(this.f10939l)) {
            new Handler(Looper.getMainLooper()).postDelayed(new e(l1Var), this.f10946s ? 600 : 500);
        }
    }

    public int Y() {
        return this.f10944q.size();
    }

    public final boolean Z() {
        return this.f10881i.isEmpty();
    }

    public final boolean a0(int i10) {
        return i10 == e.f10875k - 1;
    }

    public final AppData f0() {
        return new AppData();
    }

    public void g0(List list, Set set) {
        this.f10943p = set;
        this.f10944q.clear();
        this.f10944q.addAll(list);
    }

    public int l(int i10) {
        int i11 = e.f10875k;
        if (i10 < i11) {
            return 1;
        }
        return i10 == i11 ? 2 : 3;
    }

    public void w(RecyclerView.t0 t0Var, int i10) {
        if (t0Var instanceof i) {
            T(i10, (i) t0Var);
        } else if (t0Var instanceof l1) {
            U((l1) t0Var);
        }
    }

    public RecyclerView.t0 y(ViewGroup viewGroup, int i10) {
        LayoutInflater from = LayoutInflater.from(this.f10939l);
        if (i10 == 2) {
            l1 l1Var = new l1(from.inflate(2131558728, viewGroup, false));
            l1Var.f2105a.measure(0, 0);
            this.f10877e = l1Var.f2105a.getMeasuredHeight();
            return l1Var;
        }
        i iVar = new i(from.inflate(2131558618, viewGroup, false));
        iVar.f2105a.measure(0, 0);
        this.f10876d = iVar.f2105a.getMeasuredHeight();
        return iVar;
    }
}
