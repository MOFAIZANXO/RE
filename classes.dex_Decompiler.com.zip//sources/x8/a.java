package x8;

import com.samsung.android.sm.core.data.AppData;
import java.util.function.Predicate;

public final /* synthetic */ class a implements Predicate {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ b f10903a;

    public /* synthetic */ a(b bVar) {
        this.f10903a = bVar;
    }

    public final boolean test(Object obj) {
        return this.f10903a.M((AppData) obj);
    }
}
