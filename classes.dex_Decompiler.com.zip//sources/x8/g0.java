package x8;

public final /* synthetic */ class g0 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ j0 f10949a;

    public /* synthetic */ g0(j0 j0Var) {
        this.f10949a = j0Var;
    }

    public final void run() {
        this.f10949a.L();
    }
}
