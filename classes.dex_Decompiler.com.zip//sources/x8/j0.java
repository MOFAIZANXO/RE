package x8;

import a7.f;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.PathInterpolator;
import androidx.core.view.PointerIconCompat;
import androidx.lifecycle.g0;
import androidx.lifecycle.t;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.samsung.android.sm.common.visualeffect.interpolator.SineInOut90;
import com.samsung.android.sm.ram.data.RamData;
import com.samsung.android.sm.ram.model.holder.DeviceMemInfo;
import com.samsung.android.util.SemLog;
import f6.c;
import f6.d;
import f7.u0;
import java.util.ArrayList;
import v6.b;
import w6.e0;
import w6.i0;
import w6.q;
import w8.g;

public class j0 extends v6.a implements c {

    /* renamed from: f  reason: collision with root package name */
    public int f10967f = 0;

    /* renamed from: g  reason: collision with root package name */
    public int f10968g = 0;

    /* renamed from: h  reason: collision with root package name */
    public u0 f10969h;

    /* renamed from: i  reason: collision with root package name */
    public DeviceMemInfo f10970i = new DeviceMemInfo();

    /* renamed from: j  reason: collision with root package name */
    public int f10971j;

    /* renamed from: k  reason: collision with root package name */
    public long f10972k;

    /* renamed from: l  reason: collision with root package name */
    public ArrayList f10973l = new ArrayList();

    /* renamed from: m  reason: collision with root package name */
    public ArrayList f10974m = new ArrayList();

    /* renamed from: n  reason: collision with root package name */
    public q f10975n;

    /* renamed from: o  reason: collision with root package name */
    public float f10976o = 0.0f;

    /* renamed from: p  reason: collision with root package name */
    public h f10977p;

    /* renamed from: q  reason: collision with root package name */
    public final d f10978q = new d(this);

    /* renamed from: r  reason: collision with root package name */
    public ValueAnimator f10979r;

    /* renamed from: s  reason: collision with root package name */
    public final Handler f10980s = new Handler(Looper.getMainLooper());

    /* renamed from: t  reason: collision with root package name */
    public final t f10981t = new f0(this);

    public class a extends AnimatorListenerAdapter {
        public a() {
        }

        public void onAnimationEnd(Animator animator) {
            super.onAnimationEnd(animator);
            SemLog.d("DC.RamCleanAnimFragment", "clean percent animationEnd");
            j0.this.P();
        }
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void I(ValueAnimator valueAnimator) {
        float floatValue = ((Float) valueAnimator.getAnimatedValue()).floatValue();
        this.f10976o = floatValue;
        e0.f(this.f10246b, this.f10969h.A.f6225z, (int) floatValue);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void J(g gVar) {
        SemLog.i("DC.RamCleanAnimFragment", "DevMem ob : " + gVar.f10537a);
        this.f10970i = (DeviceMemInfo) gVar.f10538b;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void K(float f10) {
        D(f10);
        Q();
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void L() {
        SemLog.d("DC.RamCleanAnimFragment", "playRemoveAllItemAnim");
        this.f10977p.N();
        if (this.f10977p.j() > 0) {
            this.f10978q.sendEmptyMessageDelayed(PointerIconCompat.TYPE_CONTEXT_MENU, 500);
        }
    }

    public static j0 M() {
        return new j0();
    }

    public final void D(float f10) {
        this.f10979r.setFloatValues(new float[]{f10, 100.0f});
        this.f10979r.setInterpolator(new PathInterpolator(0.17f, 0.17f, 0.83f, 0.83f));
        this.f10979r.setDuration(((long) this.f10971j) * 1001);
        this.f10979r.addUpdateListener(new i0(this));
        this.f10979r.addListener(new a());
        this.f10978q.sendEmptyMessage(PointerIconCompat.TYPE_CONTEXT_MENU);
        this.f10979r.start();
    }

    public final void E(ViewGroup viewGroup) {
        SemLog.d("DC.RamCleanAnimFragment", "initAllViews");
        this.f10245a = (b) getActivity();
        if (viewGroup != null) {
            viewGroup.removeAllViewsInLayout();
        }
        this.f10969h = u0.N(LayoutInflater.from(this.f10246b), viewGroup, false);
        G();
        F();
        N(this.f10976o);
    }

    public void F() {
        this.f10969h.f6277z.f6282y.setLayoutManager(new LinearLayoutManager(this.f10246b));
        this.f10969h.f6277z.f6282y.setAdapter(this.f10977p);
        this.f10969h.f6277z.f6282y.m3(false);
        R();
    }

    public void G() {
        this.f10969h.A.C.startSearchAnimation();
        if (H()) {
            this.f10969h.A.D.setText(this.f10246b.getString(2131951938));
        } else {
            this.f10969h.A.D.setText(this.f10246b.getString(2131951866));
        }
        this.f10969h.A.F.setVisibility(8);
        this.f10969h.A.E.setVisibility(8);
        this.f10969h.A.f6225z.setVisibility(0);
    }

    public final boolean H() {
        return (this.f10967f & 1) != 0 && this.f10968g == 0;
    }

    public final void N(float f10) {
        if (this.f10979r == null) {
            this.f10979r = new ValueAnimator();
        }
        this.f10980s.postDelayed(new h0(this, f10), 500);
    }

    public final void O() {
        this.f10980s.postDelayed(new g0(this), 500);
    }

    public void P() {
        String str;
        Bundle bundle = new Bundle();
        SemLog.d("DC.RamCleanAnimFragment", "showNextFragment : " + this.f10967f + ", size : " + this.f10974m.size());
        RamData ramData = new RamData();
        boolean z10 = true;
        if ((this.f10967f & 17) == 0 || this.f10968g != 0 || this.f10974m.size() <= 0) {
            if ((this.f10967f & 1) == 0) {
                z10 = false;
            }
            bundle.putBoolean("RESULT_CLEAN", z10);
            str = "RamMainFragment";
        } else {
            ramData.p(this.f10967f);
            ramData.q(1);
            ramData.f5214i = new ArrayList(this.f10974m);
            bundle.putParcelable("key_clean_datas", ramData);
            str = "RamManualFixFragment";
        }
        bundle.putParcelable("MEMORY_INFO", this.f10970i);
        bundle.putLong("key_clean_mem_size", this.f10972k);
        b bVar = this.f10245a;
        if (bVar != null) {
            bVar.h(str, bundle);
        }
    }

    public final void Q() {
        AlphaAnimation alphaAnimation = new AlphaAnimation(1.0f, 0.0f);
        alphaAnimation.setDuration(200);
        alphaAnimation.setInterpolator(new SineInOut90());
        alphaAnimation.setStartOffset((((long) this.f10971j) * 1001) - 200);
        this.f10969h.A.D.startAnimation(alphaAnimation);
    }

    public final void R() {
        if (H()) {
            this.f10977p.P(this.f10973l);
        } else {
            this.f10977p.P(this.f10974m);
        }
        this.f10977p.o();
    }

    public void handleMessage(Message message) {
        if (!f.f(getActivity())) {
            SemLog.w("DC.RamCleanAnimFragment", "Activity is not interactive. Skip UI update : " + message.what);
        }
        if (message.what == 1001) {
            O();
        }
    }

    public void onAttach(Context context) {
        super.onAttach(context);
        Bundle arguments = getArguments();
        if (arguments != null) {
            RamData ramData = (RamData) arguments.getParcelable("key_clean_datas");
            if (ramData != null) {
                this.f10973l = ramData.f5213h;
                this.f10974m = ramData.f5214i;
                this.f10967f = ramData.d();
                this.f10968g = ramData.e();
            }
            this.f10971j = arguments.getInt("key_clean_list_size_delete_item");
            this.f10972k = arguments.getLong("key_clean_mem_size");
        }
        q qVar = new q(this.f10246b.getApplicationContext());
        this.f10975n = qVar;
        this.f10977p = new h(this.f10246b, qVar);
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        if (bundle != null) {
            ArrayList parcelableArrayList = bundle.getParcelableArrayList("KEY_PACKAGE_CLEAN");
            this.f10973l = parcelableArrayList;
            this.f10971j = parcelableArrayList != null ? parcelableArrayList.size() : 0;
            this.f10976o = bundle.getFloat("KEY_PERCENT", 0.0f);
        }
        b9.b bVar = (b9.b) new g0(this).a(b9.b.class);
        bVar.s().n(getViewLifecycleOwner(), this.f10981t);
        bVar.t();
        E(viewGroup);
        return this.f10969h.z();
    }

    public void onDestroy() {
        this.f10245a = null;
        Handler handler = this.f10980s;
        if (handler != null) {
            handler.removeCallbacksAndMessages((Object) null);
        }
        ValueAnimator valueAnimator = this.f10979r;
        if (valueAnimator != null) {
            valueAnimator.cancel();
        }
        super.onDestroy();
        this.f10978q.removeCallbacksAndMessages((Object) null);
    }

    public boolean onOptionsItemSelected(MenuItem menuItem) {
        if (menuItem.getItemId() == 16908332) {
            return true;
        }
        return super.onOptionsItemSelected(menuItem);
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        bundle.putFloat("KEY_PERCENT", this.f10976o);
        bundle.putParcelableArrayList("KEY_PACKAGE_CLEAN", this.f10977p.K());
    }

    public void onStart() {
        super.onStart();
        this.f10975n.m();
    }

    public void onStop() {
        super.onStop();
        this.f10975n.n();
    }

    public boolean y(boolean z10) {
        SemLog.i("DC.RamCleanAnimFragment", "onBackPressed : " + z10);
        i0.s(this.f10246b);
        return true;
    }
}
