package x8;

import com.samsung.android.sm.core.data.AppData;
import java.util.function.Predicate;

public final /* synthetic */ class j1 implements Predicate {
    public final boolean test(Object obj) {
        return k1.U((AppData) obj);
    }
}
