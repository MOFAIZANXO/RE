package x8;

import com.samsung.android.sm.core.data.AppData;
import java.util.function.Predicate;

public final /* synthetic */ class g1 implements Predicate {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ k1 f10950a;

    public /* synthetic */ g1(k1 k1Var) {
        this.f10950a = k1Var;
    }

    public final boolean test(Object obj) {
        return this.f10950a.V((AppData) obj);
    }
}
