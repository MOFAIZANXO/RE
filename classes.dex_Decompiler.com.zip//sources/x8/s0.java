package x8;

public final /* synthetic */ class s0 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ u0 f11029a;

    public /* synthetic */ s0(u0 u0Var) {
        this.f11029a = u0Var;
    }

    public final void run() {
        this.f11029a.C0();
    }
}
