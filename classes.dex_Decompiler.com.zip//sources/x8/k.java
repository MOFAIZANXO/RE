package x8;

import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import f7.m1;
import x6.h;

public class k extends h {

    /* renamed from: v  reason: collision with root package name */
    public TextView f10983v;

    /* renamed from: w  reason: collision with root package name */
    public ImageView f10984w;

    /* renamed from: x  reason: collision with root package name */
    public TextView f10985x;

    /* renamed from: y  reason: collision with root package name */
    public CheckBox f10986y;

    /* renamed from: z  reason: collision with root package name */
    public m1 f10987z;

    public k(m1 m1Var) {
        super(m1Var.z());
        this.f10987z = m1Var;
    }

    public void P() {
        CheckBox checkBox = this.f10987z.C;
        this.f10986y = checkBox;
        checkBox.setImportantForAccessibility(1);
        m1 m1Var = this.f10987z;
        this.f10984w = m1Var.f6250z;
        TextView textView = m1Var.B;
        this.f10983v = textView;
        textView.setImportantForAccessibility(2);
        this.f10985x = this.f10987z.f6249y;
    }
}
