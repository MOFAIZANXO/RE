package x8;

import androidx.lifecycle.t;
import w8.g;

public final /* synthetic */ class f0 implements t {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ j0 f10935a;

    public /* synthetic */ f0(j0 j0Var) {
        this.f10935a = j0Var;
    }

    public final void a(Object obj) {
        this.f10935a.J((g) obj);
    }
}
