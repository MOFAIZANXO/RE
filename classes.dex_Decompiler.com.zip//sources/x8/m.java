package x8;

import androidx.lifecycle.t;
import com.samsung.android.sm.ram.ui.ExceptedAppsListActivity;
import java.util.List;

public final /* synthetic */ class m implements t {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ExceptedAppsListActivity f10999a;

    public /* synthetic */ m(ExceptedAppsListActivity exceptedAppsListActivity) {
        this.f10999a = exceptedAppsListActivity;
    }

    public final void a(Object obj) {
        this.f10999a.u0((List) obj);
    }
}
