package x8;

import android.content.DialogInterface;

public final /* synthetic */ class d0 implements DialogInterface.OnClickListener {
    public final void onClick(DialogInterface dialogInterface, int i10) {
        dialogInterface.dismiss();
    }
}
