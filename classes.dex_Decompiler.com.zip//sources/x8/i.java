package x8;

import android.view.View;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import com.samsung.android.sm.common.view.RoundedCornerRelativeLayout;
import x6.h;

public class i extends h {
    public View A;
    public String B;
    public int C;

    /* renamed from: v  reason: collision with root package name */
    public TextView f10960v;

    /* renamed from: w  reason: collision with root package name */
    public ImageView f10961w;

    /* renamed from: x  reason: collision with root package name */
    public TextView f10962x;

    /* renamed from: y  reason: collision with root package name */
    public CheckBox f10963y;

    /* renamed from: z  reason: collision with root package name */
    public RoundedCornerRelativeLayout f10964z;

    public i(View view) {
        super(view);
        this.f10960v = (TextView) view.findViewById(2131361919);
        this.f10961w = (ImageView) view.findViewById(2131361913);
        this.f10962x = (TextView) view.findViewById(2131361912);
        this.f10963y = (CheckBox) view.findViewById(2131362090);
        this.A = view.findViewById(2131362202);
        this.f10964z = (RoundedCornerRelativeLayout) view.findViewById(2131361915);
    }
}
