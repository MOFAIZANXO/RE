package x8;

import android.view.View;

public final /* synthetic */ class t0 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ u0 f11031a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ View f11032b;

    public /* synthetic */ t0(u0 u0Var, View view) {
        this.f11031a = u0Var;
        this.f11032b = view;
    }

    public final void run() {
        this.f11031a.u0(this.f11032b);
    }
}
