package x8;

public interface j {
    void a(boolean z10);

    void b() {
    }
}
