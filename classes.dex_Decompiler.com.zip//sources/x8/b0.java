package x8;

import com.samsung.android.sm.core.data.PkgUid;

public interface b0 {
    void g(int i10, PkgUid pkgUid);
}
