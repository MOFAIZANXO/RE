package x8;

public final /* synthetic */ class e implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ l1 f10929a;

    public /* synthetic */ e(l1 l1Var) {
        this.f10929a = l1Var;
    }

    public final void run() {
        g.e0(this.f10929a);
    }
}
