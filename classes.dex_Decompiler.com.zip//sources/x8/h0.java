package x8;

public final /* synthetic */ class h0 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ j0 f10958a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ float f10959b;

    public /* synthetic */ h0(j0 j0Var, float f10) {
        this.f10958a = j0Var;
        this.f10959b = f10;
    }

    public final void run() {
        this.f10958a.K(this.f10959b);
    }
}
