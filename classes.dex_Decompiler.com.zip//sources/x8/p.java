package x8;

import android.view.View;
import androidx.recyclerview.widget.RecyclerView;

public final /* synthetic */ class p implements View.OnLongClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ q f11011a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ RecyclerView.t0 f11012b;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ k f11013f;

    /* renamed from: g  reason: collision with root package name */
    public final /* synthetic */ int f11014g;

    public /* synthetic */ p(q qVar, RecyclerView.t0 t0Var, k kVar, int i10) {
        this.f11011a = qVar;
        this.f11012b = t0Var;
        this.f11013f = kVar;
        this.f11014g = i10;
    }

    public final boolean onLongClick(View view) {
        return this.f11011a.U(this.f11012b, this.f11013f, this.f11014g, view);
    }
}
