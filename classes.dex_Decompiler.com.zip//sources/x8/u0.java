package x8;

import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.widget.Toast;
import androidx.core.view.PointerIconCompat;
import androidx.core.widget.NestedScrollView;
import androidx.lifecycle.g0;
import androidx.lifecycle.j0;
import androidx.lifecycle.t;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import b9.e;
import com.samsung.android.sm.common.utils.AppRestrictUtil;
import com.samsung.android.sm.common.view.RoundedCornerLinearLayout;
import com.samsung.android.sm.common.visualeffect.interpolator.SineInOut90;
import com.samsung.android.sm.common.visualeffect.progress.ProgressListener;
import com.samsung.android.sm.common.visualeffect.progress.ProgressListenerAdapter;
import com.samsung.android.sm.core.data.AppData;
import com.samsung.android.sm.core.data.PkgUid;
import com.samsung.android.sm.ram.data.RamData;
import com.samsung.android.sm.ram.model.holder.DeviceMemInfo;
import com.samsung.android.util.SemLog;
import f7.e1;
import java.util.ArrayList;
import java.util.List;
import w6.i0;
import w6.q;
import w6.u;
import w6.x;
import w6.z;
import w8.f;
import w8.g;
import w8.h;

public class u0 extends v6.a implements View.OnClickListener, b0, v {
    public int A = -1;
    public final ProgressListener B = new a();
    public final t C = new n0(this);
    public final t D = new o0(this);
    public final t E = new p0(this);
    public final t F = new q0(this);

    /* renamed from: f  reason: collision with root package name */
    public Resources f11047f;

    /* renamed from: g  reason: collision with root package name */
    public q f11048g;

    /* renamed from: h  reason: collision with root package name */
    public g f11049h;

    /* renamed from: i  reason: collision with root package name */
    public e1 f11050i;

    /* renamed from: j  reason: collision with root package name */
    public b9.a f11051j;

    /* renamed from: k  reason: collision with root package name */
    public b9.b f11052k;

    /* renamed from: l  reason: collision with root package name */
    public DeviceMemInfo f11053l = new DeviceMemInfo();

    /* renamed from: m  reason: collision with root package name */
    public w8.d f11054m = new w8.d();

    /* renamed from: n  reason: collision with root package name */
    public w8.d f11055n = new w8.d();

    /* renamed from: o  reason: collision with root package name */
    public long f11056o;

    /* renamed from: p  reason: collision with root package name */
    public boolean f11057p = true;

    /* renamed from: q  reason: collision with root package name */
    public boolean f11058q = false;

    /* renamed from: r  reason: collision with root package name */
    public boolean f11059r = true;

    /* renamed from: s  reason: collision with root package name */
    public boolean f11060s = false;

    /* renamed from: t  reason: collision with root package name */
    public boolean f11061t = false;

    /* renamed from: u  reason: collision with root package name */
    public int f11062u = 0;

    /* renamed from: v  reason: collision with root package name */
    public String f11063v;

    /* renamed from: w  reason: collision with root package name */
    public MenuItem f11064w;

    /* renamed from: x  reason: collision with root package name */
    public w0 f11065x;

    /* renamed from: y  reason: collision with root package name */
    public e f11066y;

    /* renamed from: z  reason: collision with root package name */
    public f f11067z = new f();

    public class a extends ProgressListenerAdapter {
        public a() {
        }

        public void onAnimStatusChanged(int i10) {
            if (i10 == 5 && u0.this.f11062u < 3) {
                u0.this.J0(2000, true);
                u0.this.f11062u = 0;
                u0.this.Y0();
                u0.this.f11062u = 2;
                u0.this.V();
                if (u0.this.f11058q) {
                    u0.this.f11058q = false;
                    u0.this.M0();
                }
            }
        }
    }

    public class b implements g0.b {
        public b() {
        }

        /* renamed from: c */
        public b9.a a(Class cls) {
            if (cls == b9.a.class && u0.this.getActivity() != null) {
                return new b9.a(u0.this.getActivity().getApplication(), true);
            }
            throw new UnsupportedOperationException("Unexpected class type");
        }
    }

    public class c extends RecyclerView.h0 {
        public c() {
        }

        public void a(RecyclerView recyclerView, int i10) {
            if (u0.this.f11059r && i10 != 0) {
                d7.b.c(u0.this.f11063v, u0.this.f10246b.getString(2131952150));
                u0.this.f11059r = false;
            }
        }

        public void b(RecyclerView recyclerView, int i10, int i11) {
        }
    }

    public class d extends View.AccessibilityDelegate {
        public d() {
        }

        public void sendAccessibilityEvent(View view, int i10) {
            if (i10 == 32768) {
                u0.this.f11050i.f6218z.F.setContentDescription(u0.this.f11050i.f6218z.G.getText());
            }
            super.sendAccessibilityEvent(view, i10);
        }
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void A0(int[] iArr, int i10) {
        this.f11050i.f6218z.C.getLocationOnScreen(iArr);
        G0(iArr[1] + i10);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void B0() {
        this.f11050i.C.D.setVisibility(0);
        this.f11050i.C.F.setVisibility(0);
        this.f11050i.C.E.setVisibility(0);
        X0(this.f11053l);
        W0();
        N0();
        R0();
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void C0() {
        l0();
        V0();
        P0();
        T0();
        S0();
        this.f11050i.A.f6210z.setVisibility(0);
        H0(0);
    }

    public static u0 E0() {
        return new u0();
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void t0(Intent intent, String str) {
        SemLog.d("DC.RamFragment2", "doExecute");
        if (intent != null && intent.getBooleanExtra("memory optimize", false) && this.f10246b != null) {
            if (n0() || this.f11061t) {
                Toast.makeText(this.f10246b, 2131951899, 0).show();
                return;
            }
            this.f11062u = 1;
            this.f11058q = true;
        }
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void u0(View view) {
        int[] iArr = new int[2];
        view.getLocationOnScreen(iArr);
        G0(iArr[1]);
        x.d(view, x.i(new Bundle()));
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void v0(AppData appData) {
        d7.b.f(this.f10246b.getString(2131952753), this.f10246b.getString(2131952277), appData.z());
        if (this.A == 1) {
            d7.b.f(this.f10246b.getResources().getString(2131952785), this.f10246b.getString(2131952022), appData.z());
        }
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void w0(g gVar) {
        SemLog.i("DC.RamFragment2", "Ram issue ob : " + gVar.f10537a);
        this.f11067z = (f) gVar.f10538b;
        h hVar = gVar.f10537a;
        if (hVar == h.SELECTION_CHANGE) {
            T0();
            S0();
            U0();
        } else if (hVar == h.SCAN && !this.f11061t && !r0()) {
            V0();
            T0();
        }
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void x0(g gVar) {
        SemLog.i("DC.RamFragment2", "DevMem ob : " + gVar.f10537a);
        this.f11053l = (DeviceMemInfo) gVar.f10538b;
        if (this.f11062u == 1) {
            this.f11062u = 2;
            Y0();
        }
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void y0(g gVar) {
        SemLog.i("DC.RamFragment2", "Cache scan BgApp ob : " + gVar.f10537a);
        w8.d dVar = (w8.d) gVar.f10538b;
        this.f11054m = dVar;
        if (dVar.j() > 0) {
            this.f11056o = this.f11054m.j();
        }
        h hVar = gVar.f10537a;
        if (hVar == h.SCAN) {
            this.f11052k.t();
            if (!this.f11057p && !p0() && !this.f11061t) {
                P0();
                T0();
            }
            if (!this.f11061t) {
                S0();
            }
            this.f11057p = false;
        } else if (hVar == h.SELECTION_CHANGE) {
            S0();
        }
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void z0(g gVar) {
        SemLog.i("DC.RamFragment2", "Resident App ob : " + gVar.f10537a);
        this.f11055n = (w8.d) gVar.f10538b;
    }

    public final void D0() {
        this.f11051j.t(1005);
        this.f11051j.t(PointerIconCompat.TYPE_WAIT);
        this.f11066y.v();
    }

    public final void F0(View view, long j10) {
        AlphaAnimation alphaAnimation = new AlphaAnimation(0.0f, 1.0f);
        alphaAnimation.setDuration(200);
        alphaAnimation.setInterpolator(new SineInOut90());
        alphaAnimation.setStartOffset(j10);
        view.startAnimation(alphaAnimation);
    }

    public final void G0(int i10) {
        NestedScrollView nestedScrollView;
        if (getActivity() != null && (nestedScrollView = (NestedScrollView) getActivity().findViewById(2131362162)) != null) {
            nestedScrollView.smoothScrollTo(0, i10);
        }
    }

    public final void H0(int i10) {
        this.f11050i.f6218z.F.setVisibility(i10);
        this.f11050i.f6218z.B.setVisibility(i10);
    }

    public final void I0() {
        a9.b.l(this.f10246b, this.f11050i.C.D, this.f11053l.a(), 2131952993, false);
        F0(this.f11050i.C.D, 0);
        new Handler().postDelayed(new k0(this), 800);
    }

    public final void J0(int i10, boolean z10) {
        switch (i10) {
            case 2000:
                this.f11050i.C.D.setVisibility(0);
                this.f11050i.C.F.setVisibility(0);
                this.f11050i.C.E.setVisibility(0);
                H0(0);
                V0();
                P0();
                T0();
                if (z10) {
                    N0();
                    return;
                }
                return;
            case 2001:
                this.f11050i.C.D.setText(2131952710);
                this.f11050i.C.D.setVisibility(0);
                this.f11050i.A.f6209y.setEnabled(false);
                this.f11050i.A.f6209y.setVisibility(8);
                H0(8);
                this.f11050i.A.A.setVisibility(8);
                this.f11050i.C.F.setVisibility(8);
                this.f11050i.C.E.setVisibility(8);
                this.f11050i.E.A.setVisibility(8);
                this.f11050i.D.f6230z.setVisibility(8);
                this.f11050i.A.f6209y.setText(2131951936);
                AlphaAnimation alphaAnimation = new AlphaAnimation(0.0f, 1.0f);
                alphaAnimation.setDuration(500);
                alphaAnimation.setInterpolator(new SineInOut90());
                this.f11050i.C.D.startAnimation(alphaAnimation);
                return;
            case 2002:
                I0();
                return;
            default:
                return;
        }
    }

    public void K0(int i10) {
        this.A = i10;
    }

    public final void L0() {
        this.f11050i.A.f6209y.setEnabled(false);
        this.f11050i.A.f6209y.setVisibility(8);
        this.f11050i.E.A.setVisibility(8);
        this.f11050i.D.f6230z.setVisibility(8);
        H0(8);
        new Handler().postDelayed(new s0(this), 800);
    }

    public void M0() {
        Bundle bundle;
        String str = "RamCleanFragment";
        if (!q0() && !s0()) {
            bundle = Z(17);
        } else if (s0()) {
            bundle = Z(1);
        } else {
            bundle = Z(16);
            str = "RamManualFixFragment";
        }
        this.f11051j.u();
        this.f11051j.w(this.f11063v, this.f11047f.getString(2131952148), this.f11056o);
        v6.b bVar = this.f10245a;
        if (bVar != null) {
            bVar.h(str, bundle);
        }
    }

    public final void N0() {
        if (!this.f11061t) {
            F0(this.f11050i.C.D, 0);
        }
        F0(this.f11050i.C.F, 0);
        F0(this.f11050i.C.E, 0);
        F0(this.f11050i.A.f6209y, 0);
        F0(this.f11050i.A.A, 0);
        if (a9.a.f(this.f10246b)) {
            F0(this.f11050i.C.A, 0);
        }
    }

    public final void O0(int i10) {
        AlphaAnimation alphaAnimation = new AlphaAnimation(1.0f, 0.0f);
        alphaAnimation.setDuration(200);
        alphaAnimation.setInterpolator(new SineInOut90());
        alphaAnimation.setStartOffset((((((long) i10) * 2000) / 100) + 370) - 200);
        this.f11050i.C.D.startAnimation(alphaAnimation);
    }

    public final void P0() {
        SemLog.d("DC.RamFragment2", "updateBgAppList : " + this.f11054m.h().size());
        this.f11049h.g0(this.f11054m.h(), this.f11054m.c());
        this.f11049h.V();
        this.f11049h.o();
        this.f11050i.E.A.setVisibility(this.f11049h.Y() <= 0 ? 8 : 0);
    }

    public final void Q0() {
        X0(this.f11053l);
        W0();
        S0();
        V0();
        P0();
    }

    public void R0() {
        this.f11051j.y(false);
        this.f11061t = false;
        this.f11050i.A.A.setVisibility(0);
        this.f11050i.A.A.setText(u.b(this.f10246b, 2131951943, this.f11056o * 1024));
        L0();
    }

    public final void S0() {
        if (!this.f11067z.i().isEmpty() && !s0()) {
            this.f11050i.A.f6209y.setText(2131952310);
        } else if (o0()) {
            this.f11050i.A.f6209y.setText(n0() ? 2131953058 : 2131951936);
        } else {
            long i10 = this.f11054m.i();
            this.f11056o = i10;
            this.f11050i.A.f6209y.setText(a9.b.e(this.f10246b, 2131951937, i10));
        }
        this.f11050i.A.f6209y.setEnabled(!o0());
    }

    public void T0() {
        if (this.f11061t) {
            return;
        }
        if (!r0() && p0()) {
            this.f11050i.A.A.setVisibility(0);
            this.f11050i.A.f6209y.setVisibility(0);
            this.f11050i.A.A.setText(this.f10246b.getResources().getQuantityString(2131820571, this.f11067z.i().size(), new Object[]{Integer.valueOf(this.f11067z.i().size())}));
        } else if (!r0()) {
            this.f11050i.A.A.setVisibility(0);
            this.f11050i.A.f6209y.setVisibility(0);
            this.f11050i.A.A.setText(this.f10246b.getString(2131952647));
        } else if (!p0()) {
            this.f11050i.A.A.setVisibility(0);
            this.f11050i.A.f6209y.setVisibility(0);
            this.f11050i.A.A.setText(this.f10246b.getString(2131952646));
        } else {
            this.f11050i.A.A.setVisibility(8);
            this.f11050i.A.f6209y.setEnabled(false);
            this.f11050i.A.f6209y.setVisibility(8);
        }
    }

    public final void U0() {
        String string = this.f10246b.getResources().getString(2131951843);
        if (a0().size() > 1) {
            string = this.f10246b.getResources().getString(2131951844);
        }
        this.f11050i.D.f6229y.setAlpha(!s0() ? 1.0f : 0.4f);
        this.f11050i.D.f6229y.setEnabled(true ^ s0());
        this.f11050i.D.f6229y.setText(string);
    }

    public final void V() {
        RoundedCornerLinearLayout roundedCornerLinearLayout;
        if (getActivity() != null) {
            String b10 = x.b(getActivity().getIntent());
            SemLog.d("DC.RamFragment2", "search key : " + b10);
            if (b10 != null && !TextUtils.isEmpty(b10)) {
                char c10 = 65535;
                switch (b10.hashCode()) {
                    case -1351880692:
                        if (b10.equals("key_excluded_app")) {
                            c10 = 0;
                            break;
                        }
                        break;
                    case -1061919199:
                        if (b10.equals("key_resident_apps")) {
                            c10 = 1;
                            break;
                        }
                        break;
                    case 2122858235:
                        if (b10.equals("key_ram_plus")) {
                            c10 = 2;
                            break;
                        }
                        break;
                }
                switch (c10) {
                    case 0:
                        roundedCornerLinearLayout = this.f11050i.f6218z.H;
                        break;
                    case 1:
                        roundedCornerLinearLayout = this.f11050i.f6218z.F;
                        break;
                    case 2:
                        roundedCornerLinearLayout = this.f11050i.f6218z.C;
                        break;
                    default:
                        SemLog.e("DC.RamFragment2", "checkSearchKey Wrong case!!");
                        roundedCornerLinearLayout = null;
                        break;
                }
                if (roundedCornerLinearLayout != null) {
                    g0(roundedCornerLinearLayout);
                }
            }
        }
    }

    public final void V0() {
        SemLog.d("DC.RamFragment2", "updateIssueHistoryList : " + this.f11067z.i().size());
        this.f11065x.O(this.f11067z.i());
        this.f11065x.Q(this.f11067z.c());
        this.f11065x.o();
        int i10 = 0;
        this.f11050i.D.f6230z.setVisibility(0);
        RoundedCornerLinearLayout roundedCornerLinearLayout = this.f11050i.D.f6230z;
        if (this.f11065x.j() <= 0) {
            i10 = 8;
        }
        roundedCornerLinearLayout.setVisibility(i10);
        U0();
    }

    public final void W() {
        this.f11050i.A.f6209y.setEnabled(false);
        this.f11050i.A.f6209y.setText(2131951936);
        this.f11050i.A.f6209y.setOnClickListener(this);
    }

    public final void W0() {
        if (a9.a.g(this.f10246b)) {
            this.f11050i.C.A.setVisibility(8);
            this.f11050i.f6218z.D.setText(a9.a.e(this.f10246b));
        } else if (a9.a.f(this.f10246b)) {
            this.f11050i.C.A.setText(a9.a.d(this.f10246b));
            this.f11050i.C.A.setVisibility(0);
            MenuItem menuItem = this.f11064w;
            if (menuItem != null) {
                menuItem.setVisible(true);
            }
        }
    }

    public ArrayList X() {
        return this.f11054m.h();
    }

    public final void X0(DeviceMemInfo deviceMemInfo) {
        long b10 = deviceMemInfo.b();
        long f10 = a9.b.f(deviceMemInfo);
        long g10 = a9.b.g(deviceMemInfo);
        long a10 = deviceMemInfo.a();
        String c10 = z.c(this.f10246b, g10);
        String c11 = z.c(this.f10246b, b10);
        String c12 = z.c(this.f10246b, f10);
        this.f11050i.C.E.setText(this.f10246b.getString(2131952686, new Object[]{c12}));
        this.f11050i.C.F.setText(a9.b.h(this.f10246b, c10, c11, 2131953146));
        a9.b.l(this.f10246b, this.f11050i.C.D, a10, 2131952993, false);
    }

    public final g0.b Y() {
        return new b();
    }

    public final void Y0() {
        SemLog.d("DC.RamFragment2", "updateView : " + this.f11062u);
        int i10 = this.f11062u;
        if (i10 == 0) {
            Q0();
        } else if (i10 == 1) {
            W();
            J0(2001, true);
            this.f11050i.C.C.startSearchAnimation();
            if (this.f11058q) {
                this.f11052k.t();
            }
        } else if (i10 == 2) {
            f0();
            DeviceMemInfo deviceMemInfo = this.f11053l;
            if (deviceMemInfo != null) {
                int e10 = (int) deviceMemInfo.e();
                this.f11050i.C.C.startFadeOutAnimBar(e10);
                O0(e10);
            }
        } else if (i10 == 4) {
            this.f11050i.C.C.startProgressAnim((int) this.f11053l.e());
            J0(2002, false);
        }
    }

    public final Bundle Z(int i10) {
        Bundle bundle = new Bundle();
        RamData ramData = new RamData();
        ramData.f5213h = new ArrayList(b0());
        ramData.f5214i = a0();
        ramData.p(i10);
        ramData.q(0);
        bundle.putParcelable("key_clean_datas", ramData);
        bundle.putInt("key_clean_list_size_delete_item", c0(i10));
        bundle.putLong("key_clean_mem_size", this.f11056o);
        return bundle;
    }

    public ArrayList a0() {
        return this.f11067z.a(d0());
    }

    public List b0() {
        return this.f11054m.a(X());
    }

    public final int c0(int i10) {
        ArrayList arrayList = (i10 & 1) != 0 ? new ArrayList(b0()) : a0();
        if (arrayList.size() < 7) {
            return arrayList.size();
        }
        return 6;
    }

    public ArrayList d0() {
        return this.f11067z.i();
    }

    public void e0(Intent intent) {
        new m0(this).a(intent, "memory optimize");
    }

    public final void f0() {
        if (getActivity() != null) {
            e0(getActivity().getIntent());
        }
    }

    public void g(int i10, PkgUid pkgUid) {
        SemLog.d("DC.RamFragment2", "onSelected : " + i10);
        if ((i10 & 1) != 0) {
            this.f11051j.v(pkgUid);
        } else {
            this.f11066y.u(pkgUid);
        }
    }

    public final void g0(View view) {
        view.postDelayed(new t0(this, view), 100);
    }

    public final void h0(ViewGroup viewGroup) {
        if (getActivity() != null) {
            this.f10245a = (v6.b) getActivity();
            if (viewGroup != null) {
                viewGroup.removeAllViewsInLayout();
            }
            e1 N = e1.N(LayoutInflater.from(this.f10246b), viewGroup, false);
            this.f11050i = N;
            this.f11049h = new g(this.f10246b, this.f11048g, this, N.E.f6240y, this);
            this.f11065x = new w0(this.f10246b, this.f11048g, this);
            k0();
            j0();
            i0();
        }
    }

    public void i0() {
        if (this.f11061t) {
            H0(8);
        }
        this.f11050i.f6218z.F.setOnClickListener(this);
        this.f11050i.f6218z.H.setOnClickListener(this);
        if (a9.a.g(getContext())) {
            this.f11050i.f6218z.C.setOnClickListener(this);
            StringBuilder sb2 = new StringBuilder(this.f11050i.f6218z.E.getText());
            sb2.append(", ");
            sb2.append(a9.a.e(this.f10246b));
            this.f11050i.f6218z.C.setContentDescription(sb2);
        } else {
            this.f11050i.f6218z.A.setVisibility(8);
            this.f11050i.f6218z.C.setVisibility(8);
        }
        this.f11050i.f6218z.F.setRoundedCorners(15);
        this.f11050i.f6218z.B.setRoundedCorners(15);
        this.f11050i.f6218z.F.setAccessibilityDelegate(new d());
    }

    public void j0() {
        if (!this.f11061t) {
            l0();
            V0();
        } else {
            this.f11050i.D.f6230z.setVisibility(8);
            this.f11050i.E.A.setVisibility(8);
        }
        this.f11050i.D.B.setRoundedCorners(15);
        this.f11050i.D.f6229y.setOnClickListener(this);
        this.f11050i.E.f6240y.setRoundedCorners(15);
    }

    public void k0() {
        String string = this.f10246b.getString(2131952646);
        String string2 = this.f10246b.getString(2131951936);
        if (!this.f11061t) {
            this.f11050i.A.A.setText(string);
            this.f11050i.A.f6209y.setText(string2);
            this.f11050i.A.f6209y.setEnabled(false);
        } else {
            this.f11050i.A.A.setVisibility(8);
            this.f11050i.A.f6209y.setEnabled(false);
            this.f11050i.A.f6209y.setVisibility(8);
        }
        this.f11050i.A.f6209y.setOnClickListener(this);
        this.f11050i.C.C.setListener(this.B);
    }

    public void l(int i10) {
        new Handler(Looper.getMainLooper()).postDelayed(new r0(this, new int[2], i10), 100);
    }

    public final void l0() {
        if (this.f11050i.D.A.getAdapter() == null) {
            this.f11050i.D.A.setAdapter(this.f11065x);
            this.f11050i.D.A.setLayoutManager(new LinearLayoutManager(this.f10246b));
        }
        if (this.f11050i.E.f6240y.getAdapter() == null) {
            this.f11050i.E.f6240y.setAdapter(this.f11049h);
            this.f11050i.E.f6240y.setLayoutManager(new LinearLayoutManager(this.f10246b));
        }
        this.f11050i.E.f6240y.z0(new c());
    }

    public final void m0(ArrayList arrayList) {
        arrayList.forEach(new l0(this));
    }

    public final boolean n0() {
        return p0() && r0();
    }

    public final boolean o0() {
        return s0() && q0();
    }

    public void onActivityCreated(Bundle bundle) {
        super.onActivityCreated(bundle);
        if (bundle != null) {
            SemLog.d("DC.RamFragment2", "get viewStatus from savedInstanceState");
            this.f11062u = bundle.getInt("VIEW_STATUS");
        }
        b9.b bVar = (b9.b) new g0(requireActivity()).a(b9.b.class);
        this.f11052k = bVar;
        bVar.s().n(getViewLifecycleOwner(), this.D);
        this.f11051j = (b9.a) new g0((j0) requireActivity(), Y()).a(b9.a.class);
        this.f11066y = (e) new g0(requireActivity()).a(e.class);
        this.f11051j.s(1005).n(getViewLifecycleOwner(), this.F);
        this.f11051j.s(PointerIconCompat.TYPE_WAIT).n(getViewLifecycleOwner(), this.E);
        this.f11066y.t().n(getViewLifecycleOwner(), this.C);
        D0();
    }

    public void onAttach(Context context) {
        super.onAttach(context);
        this.f10246b = context;
        this.f11047f = context.getResources();
        this.f11048g = new q(this.f10246b.getApplicationContext());
        Bundle arguments = getArguments();
        if (arguments != null) {
            this.f11061t = arguments.getBoolean("RESULT_CLEAN");
            this.f11053l = (DeviceMemInfo) arguments.getParcelable("MEMORY_INFO");
            this.f11056o = arguments.getLong("key_clean_mem_size");
        }
    }

    public void onClick(View view) {
        if (view.getId() == 2131362043) {
            M0();
        } else if (view.getId() == 2131362736) {
            Intent intent = new Intent();
            intent.setAction("com.samsung.android.sm.ACTION_RAM_EXCEPTED_APPS");
            this.f10246b.startActivity(intent);
            d7.b.c(this.f11063v, this.f11047f.getString(2131952147));
            this.f11060s = true;
        } else if (view.getId() == 2131362670) {
            Intent intent2 = new Intent();
            RamData ramData = new RamData();
            ramData.f5215j = new ArrayList(this.f11055n.h());
            intent2.putExtra("key_list_status", ramData);
            intent2.setAction("com.samsung.android.sm.ACTION_SYSTEM_AND_OTHERS_ACTIVITY");
            intent2.setPackage(this.f10246b.getPackageName());
            this.f10246b.startActivity(intent2);
            this.f11060s = true;
        } else if (view.getId() == 2131362640) {
            Intent intent3 = new Intent();
            intent3.setAction("com.samsung.android.sm.ACTION_RAM_PLUS_ACTIVITY");
            intent3.setPackage(this.f10246b.getPackageName());
            this.f10246b.startActivity(intent3);
            this.f11060s = true;
            d7.b.c(this.f11063v, this.f11047f.getString(2131952149));
        } else if (view.getId() == 2131362324) {
            ArrayList a02 = a0();
            new AppRestrictUtil(this.f10246b).s(0, "added_from_anomaly_manual", a02);
            m0(a02);
            v6.b bVar = this.f10245a;
            if (bVar != null) {
                bVar.h("RamCleanFragment", Z(0));
            }
        }
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater menuInflater) {
        if (a9.a.f(this.f10246b) && !a9.a.g(this.f10246b)) {
            menuInflater.inflate(2131689480, menu);
            MenuItem findItem = menu.findItem(2131362458);
            this.f11064w = findItem;
            findItem.setVisible(false);
        }
        super.onCreateOptionsMenu(menu, menuInflater);
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        this.f11063v = this.f11047f.getString(2131952753);
        h0(viewGroup);
        setHasOptionsMenu(true);
        return this.f11050i.z();
    }

    public void onDestroy() {
        if (this.f10245a != null) {
            this.f10245a = null;
        }
        super.onDestroy();
    }

    public void onResume() {
        super.onResume();
        this.f11051j.x(this.f11063v);
        n6.b.b(this.f10246b, 2012);
        if (this.f11061t) {
            this.f11062u = 4;
            Y0();
            return;
        }
        int i10 = this.f11062u;
        if (i10 == 2 && !this.f11060s) {
            Y0();
        } else if (i10 < 3 && !this.f11060s) {
            this.f11062u = 1;
            Y0();
        } else if (this.f11060s) {
            D0();
            this.f11060s = false;
        }
    }

    public void onSaveInstanceState(Bundle bundle) {
        bundle.putInt("VIEW_STATUS", this.f11062u);
        super.onSaveInstanceState(bundle);
    }

    public void onStart() {
        super.onStart();
        this.f11048g.m();
    }

    public void onStop() {
        this.f11048g.n();
        super.onStop();
    }

    public final boolean p0() {
        return this.f11054m.k();
    }

    public final boolean q0() {
        return this.f11054m.d() || this.f11054m.i() == 0;
    }

    public final boolean r0() {
        return this.f11067z.j();
    }

    public final boolean s0() {
        return this.f11067z.d();
    }

    public boolean y(boolean z10) {
        i0.s(this.f10246b);
        return true;
    }
}
