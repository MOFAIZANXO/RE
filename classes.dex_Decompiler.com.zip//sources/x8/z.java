package x8;

import android.content.DialogInterface;
import com.samsung.android.sm.ram.ui.a;

public final /* synthetic */ class z implements DialogInterface.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ a f11082a;

    public /* synthetic */ z(a aVar) {
        this.f11082a = aVar;
    }

    public final void onClick(DialogInterface dialogInterface, int i10) {
        this.f11082a.O(dialogInterface, i10);
    }
}
