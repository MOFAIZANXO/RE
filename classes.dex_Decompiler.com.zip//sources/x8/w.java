package x8;

import android.view.View;
import com.samsung.android.sm.core.data.AppData;

public final /* synthetic */ class w implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ x f11075a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ AppData f11076b;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ i f11077f;

    public /* synthetic */ w(x xVar, AppData appData, i iVar) {
        this.f11075a = xVar;
        this.f11076b = appData;
        this.f11077f = iVar;
    }

    public final void onClick(View view) {
        this.f11075a.S(this.f11076b, this.f11077f, view);
    }
}
