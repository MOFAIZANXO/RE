package b8;

import androidx.lifecycle.q;
import androidx.lifecycle.t;
import java.util.ArrayList;

public final /* synthetic */ class a implements t {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ q f2857a;

    public /* synthetic */ a(q qVar) {
        this.f2857a = qVar;
    }

    public final void a(Object obj) {
        this.f2857a.r((ArrayList) obj);
    }
}
