package b8;

import android.content.Context;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.q;
import c8.a;
import c8.c;
import c8.d;
import com.samsung.android.sm.anomaly.data.AnomalyAppData;
import com.samsung.android.sm.core.data.PkgUid;
import com.samsung.android.sm.history.data.AppIssueHistoryData;
import java.util.ArrayList;
import java.util.Objects;

public class b {

    /* renamed from: a  reason: collision with root package name */
    public a f2858a;

    /* renamed from: b  reason: collision with root package name */
    public c f2859b;

    /* renamed from: c  reason: collision with root package name */
    public t4.b f2860c = new t4.b();

    /* renamed from: d  reason: collision with root package name */
    public Context f2861d;

    /* renamed from: e  reason: collision with root package name */
    public final q f2862e = new q();

    /* renamed from: f  reason: collision with root package name */
    public final q f2863f = new q();

    public b(Context context) {
        this.f2861d = context;
        this.f2858a = new c8.b(context);
        this.f2859b = new d(context);
    }

    public void a(long j10) {
        this.f2858a.e(j10);
    }

    public void b() {
        this.f2858a.a();
    }

    public void c(AnomalyAppData anomalyAppData) {
        this.f2860c.h(this.f2861d, anomalyAppData);
    }

    public void d() {
        this.f2858a.j();
    }

    public ArrayList e() {
        return this.f2860c.j(this.f2861d);
    }

    public LiveData f(int i10) {
        q qVar = this.f2862e;
        LiveData b10 = this.f2858a.b(i10);
        q qVar2 = this.f2862e;
        Objects.requireNonNull(qVar2);
        qVar.v(b10, new a(qVar2));
        return this.f2862e;
    }

    public ArrayList g() {
        return this.f2858a.g();
    }

    public long h() {
        return this.f2858a.d();
    }

    public LiveData i(AppIssueHistoryData appIssueHistoryData, int i10) {
        q qVar = this.f2863f;
        LiveData h10 = this.f2858a.h(appIssueHistoryData, i10);
        q qVar2 = this.f2863f;
        Objects.requireNonNull(qVar2);
        qVar.v(h10, new a(qVar2));
        return this.f2863f;
    }

    public ArrayList j(long j10) {
        return this.f2859b.a(j10);
    }

    public void k(ArrayList arrayList) {
        this.f2858a.i(arrayList);
    }

    public boolean l() {
        return this.f2858a.l();
    }

    public void m(int i10) {
        this.f2862e.u((ArrayList) this.f2858a.b(i10).j());
    }

    public void n(AppIssueHistoryData appIssueHistoryData, int i10) {
        this.f2863f.u((ArrayList) this.f2858a.h(appIssueHistoryData, i10).j());
    }

    public void o(int i10) {
        this.f2858a.f(i10);
    }

    public void p(Context context, PkgUid pkgUid) {
        this.f2858a.c(context, pkgUid);
    }
}
