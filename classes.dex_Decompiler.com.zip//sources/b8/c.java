package b8;

import android.content.Context;
import android.content.Intent;
import androidx.work.b;
import com.samsung.android.sm.history.SdhmsIntegrationWorker;
import com.samsung.android.util.SemLog;
import java.util.ArrayList;
import n1.e;
import n1.n;
import n1.w;

public abstract class c {
    public static void a(Context context) {
        SemLog.d("DC.SdhmsIntegrationManager", "doSdhmsIntegrate : do Sdhms integration work in WorkManager");
        d(context, new b.a().a());
    }

    public static void b(Context context, Intent intent) {
        if (intent.hasExtra("package_name")) {
            SemLog.d("DC.SdhmsIntegrationManager", "doSdhmsIntegrate : do Sdhms integration work in WorkManager with intent");
            c(context, intent);
            return;
        }
        a(context);
    }

    public static void c(Context context, Intent intent) {
        ArrayList<String> stringArrayListExtra = intent.getStringArrayListExtra("package_name");
        ArrayList<Integer> integerArrayListExtra = intent.getIntegerArrayListExtra("uid");
        if (stringArrayListExtra != null && integerArrayListExtra != null && integerArrayListExtra.size() == stringArrayListExtra.size()) {
            int[] iArr = new int[stringArrayListExtra.size()];
            String[] strArr = new String[stringArrayListExtra.size()];
            for (int i10 = 0; i10 < stringArrayListExtra.size(); i10++) {
                strArr[i10] = stringArrayListExtra.get(i10);
                if (integerArrayListExtra.get(i10) != null) {
                    iArr[i10] = integerArrayListExtra.get(i10).intValue();
                } else {
                    iArr[i10] = 0;
                }
            }
            d(context, new b.a().e("package_name", strArr).d("uid", iArr).a());
        }
    }

    public static void d(Context context, b bVar) {
        w.f(context).e("sdhms", e.KEEP, (n) ((n.a) new n.a(SdhmsIntegrationWorker.class).f(bVar)).b());
    }
}
