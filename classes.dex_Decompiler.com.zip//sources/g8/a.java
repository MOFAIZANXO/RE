package g8;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import android.util.Log;

public abstract class a extends BroadcastReceiver {
    public abstract void a(String str, String str2);

    public abstract void b(String str, String str2, String str3);

    public void onReceive(Context context, Intent intent) {
        if ("com.samsung.android.sm.iafd.ACTION_SEND_LOGGING".equals(intent.getAction())) {
            String stringExtra = intent.getStringExtra("screenId");
            String stringExtra2 = intent.getStringExtra("eventId");
            if (TextUtils.isEmpty(stringExtra) || TextUtils.isEmpty(stringExtra2)) {
                Log.e("BaseLoggingReceiver", " screenId or eventId is empty, just return");
                return;
            }
            String stringExtra3 = intent.getStringExtra("value");
            if (TextUtils.isEmpty(stringExtra3)) {
                a(stringExtra, stringExtra2);
            } else {
                b(stringExtra, stringExtra2, stringExtra3);
            }
        }
    }
}
