package x2;

public abstract class a {
}
