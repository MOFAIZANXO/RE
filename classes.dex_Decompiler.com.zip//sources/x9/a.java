package x9;

public interface a {
    void b();

    void j(int i10);

    void p();
}
