package x9;

import com.samsung.android.sm.score.data.DetailItem;
import java.util.Objects;
import java.util.function.Predicate;

public final /* synthetic */ class o implements Predicate {
    public final boolean test(Object obj) {
        return Objects.nonNull((DetailItem) obj);
    }
}
