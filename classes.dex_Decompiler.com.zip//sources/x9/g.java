package x9;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import com.samsung.android.sm.score.data.DetailItem;
import f7.a2;
import f7.c2;
import f7.e2;
import f7.g2;
import w6.g0;
import x9.e;

public abstract class g {

    public static class a extends e {
        public void P(DetailItem detailItem) {
        }

        public a(e2 e2Var) {
            super(e2Var.z());
        }
    }

    public static class b extends e {

        /* renamed from: w  reason: collision with root package name */
        public final a2 f11119w;

        public void P(DetailItem detailItem) {
            String str = detailItem.f5329f;
            this.f11119w.f6203y.setText(str);
            g0.d(this.f11114v, this.f11119w.f6203y, str);
        }

        public b(a2 a2Var) {
            super(a2Var.z());
            this.f11119w = a2Var;
        }
    }

    public static class c extends e {

        /* renamed from: w  reason: collision with root package name */
        public final g2 f11120w;

        /* access modifiers changed from: private */
        public /* synthetic */ void T(DetailItem detailItem, e.a aVar, View view) {
            boolean z10 = !this.f11120w.f6227z.isChecked();
            this.f11120w.f6227z.setChecked(z10);
            detailItem.f5331h = z10 ? 1 : 0;
            aVar.a(detailItem, k(), z10);
        }

        public void P(DetailItem detailItem) {
            String str = detailItem.f5329f;
            boolean z10 = false;
            if (str == null || TextUtils.isEmpty(str)) {
                this.f11120w.C.setVisibility(8);
            } else {
                this.f11120w.C.setText(detailItem.f5329f);
                this.f11120w.C.setVisibility(0);
            }
            this.f11120w.B.setImageDrawable(detailItem.f5330g);
            CheckBox checkBox = this.f11120w.f6227z;
            if (detailItem.f5331h == 1) {
                z10 = true;
            }
            checkBox.setChecked(z10);
        }

        public void Q(DetailItem detailItem, DetailItem detailItem2) {
            if (detailItem == null || detailItem2 == null || detailItem.f5328b != detailItem2.f5328b) {
                this.f11120w.f6226y.setVisibility(8);
            } else {
                this.f11120w.f6226y.setVisibility(0);
            }
        }

        public void R(DetailItem detailItem, e.a aVar) {
            this.f11120w.A.setOnClickListener(new i(this, detailItem, aVar));
        }

        public c(g2 g2Var) {
            super(g2Var.z());
            this.f11120w = g2Var;
        }
    }

    public static class d extends e {

        /* renamed from: w  reason: collision with root package name */
        public final c2 f11121w;

        public void P(DetailItem detailItem) {
            String str = detailItem.f5329f;
            int i10 = detailItem.f5331h;
            if (str == null || !str.isEmpty()) {
                this.f11121w.C.setVisibility(0);
                this.f11121w.C.setText(str);
            } else {
                this.f11121w.C.setVisibility(8);
            }
            this.f11121w.f6212z.setImageDrawable(detailItem.f5330g);
            if (this.f11121w.f6212z.getDrawable() != null) {
                this.f11121w.f6212z.getDrawable().setTint(this.f11114v.getColor(2131099708));
            }
            if (i10 == 3) {
                this.f11121w.f6211y.setVisibility(8);
                this.f11121w.A.setColor(this.f11114v.getColor(2131100268));
                this.f11121w.A.setVisibility(0);
                this.f11121w.A.drawImmediately();
            } else if (i10 == 2) {
                this.f11121w.A.setColor(this.f11114v.getColor(2131100267));
                this.f11121w.A.setVisibility(0);
                this.f11121w.A.drawImmediately();
                this.f11121w.f6211y.setVisibility(8);
            } else if (i10 == 1) {
                this.f11121w.A.setColor(this.f11114v.getColor(2131100267));
                this.f11121w.A.setVisibility(0);
                this.f11121w.f6211y.setVisibility(8);
                this.f11121w.A.playAnimation();
                detailItem.f5331h = 2;
            } else {
                this.f11121w.A.setVisibility(8);
                this.f11121w.f6211y.setVisibility(0);
            }
        }

        public d(c2 c2Var) {
            super(c2Var.z());
            this.f11121w = c2Var;
        }
    }

    public static e a(ViewGroup viewGroup, LayoutInflater layoutInflater, int i10) {
        if (i10 != 110) {
            if (i10 != 111) {
                if (i10 != 120) {
                    if (i10 != 121) {
                        if (i10 != 220) {
                            if (i10 != 221) {
                                if (i10 != 310) {
                                    if (i10 != 311) {
                                        if (i10 != 320) {
                                            if (i10 != 321) {
                                                if (i10 != 440) {
                                                    if (i10 != 441) {
                                                        return i10 < 7000 ? new d(c2.N(layoutInflater, viewGroup, false)) : new a(e2.N(layoutInflater, viewGroup, false));
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            return new c(g2.N(layoutInflater, viewGroup, false));
        }
        return new b(a2.N(layoutInflater, viewGroup, false));
    }
}
