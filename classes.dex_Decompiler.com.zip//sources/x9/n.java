package x9;

import com.samsung.android.sm.score.data.DetailItem;
import java.util.function.Predicate;

public final /* synthetic */ class n implements Predicate {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f11126a;

    public /* synthetic */ n(int i10) {
        this.f11126a = i10;
    }

    public final boolean test(Object obj) {
        return a0.u0(this.f11126a, (DetailItem) obj);
    }
}
