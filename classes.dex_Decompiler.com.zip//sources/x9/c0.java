package x9;

import java.util.ArrayList;
import java.util.function.Function;

public final /* synthetic */ class c0 implements Function {
    public final Object apply(Object obj) {
        return ((ArrayList) obj).stream();
    }
}
