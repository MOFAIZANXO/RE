package x9;

public interface b0 {
    void o(boolean z10);
}
