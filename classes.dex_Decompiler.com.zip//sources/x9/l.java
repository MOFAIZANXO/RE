package x9;

import o9.e;

public class l {
    public int a(Integer num) {
        if (num == null) {
            return -1;
        }
        int intValue = num.intValue() / 10;
        if (e(Integer.valueOf(intValue))) {
            return intValue;
        }
        return -1;
    }

    public int b(Integer num) {
        if (e.f8664b.contains(num)) {
            return num.intValue() - 1;
        }
        return -1;
    }

    public int c(Integer num) {
        if (num == null) {
            return -1;
        }
        if (e.f8663a.contains(num)) {
            return num.intValue();
        }
        int intValue = num.intValue();
        if (intValue == 110 || intValue == 111) {
            return 1110;
        }
        if (intValue == 120 || intValue == 121) {
            return 1210;
        }
        if (intValue == 220 || intValue == 221) {
            return 2210;
        }
        if (intValue == 310 || intValue == 311) {
            return 3110;
        }
        if (intValue == 320 || intValue == 321) {
            return 3210;
        }
        return (intValue == 440 || intValue == 441) ? 4410 : -1;
    }

    public boolean d(Integer num) {
        if (num == null) {
            return false;
        }
        return num.equals(310) || num.equals(320) || num.equals(110) || num.equals(120) || num.equals(220);
    }

    public boolean e(Integer num) {
        if (num == null) {
            return false;
        }
        return e.f8664b.contains(num);
    }
}
