package x9;

import com.samsung.android.sm.score.data.DetailItem;
import java.util.function.Predicate;

public final /* synthetic */ class z implements Predicate {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f11136a;

    public /* synthetic */ z(int i10) {
        this.f11136a = i10;
    }

    public final boolean test(Object obj) {
        return a0.t0(this.f11136a, (DetailItem) obj);
    }
}
