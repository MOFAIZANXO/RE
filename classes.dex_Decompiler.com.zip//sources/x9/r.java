package x9;

import com.samsung.android.sm.score.data.DetailItem;
import x9.e;

public final /* synthetic */ class r implements e.a {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ a0 f11128a;

    public /* synthetic */ r(a0 a0Var) {
        this.f11128a = a0Var;
    }

    public final void a(DetailItem detailItem, int i10, boolean z10) {
        this.f11128a.q0(detailItem, i10, z10);
    }
}
