package x9;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.recyclerview.widget.RecyclerView;
import com.samsung.android.sm.core.data.PkgUid;
import f7.y1;
import java.util.ArrayList;
import java.util.List;
import w6.t;

public class f0 extends RecyclerView.t {

    /* renamed from: d  reason: collision with root package name */
    public final Context f11115d;

    /* renamed from: e  reason: collision with root package name */
    public final t f11116e;

    /* renamed from: f  reason: collision with root package name */
    public final List f11117f = new ArrayList();

    public static class a extends RecyclerView.t0 {

        /* renamed from: u  reason: collision with root package name */
        public y1 f11118u;

        public a(y1 y1Var) {
            super(y1Var.z());
            this.f11118u = y1Var;
        }
    }

    public f0(Context context) {
        this.f11115d = context;
        this.f11116e = new t(context);
    }

    /* renamed from: K */
    public void w(a aVar, int i10) {
        PkgUid pkgUid = (PkgUid) this.f11117f.get(i10);
        aVar.f11118u.A.setText(this.f11116e.d(pkgUid));
        aVar.f11118u.f6291z.setImageDrawable(this.f11116e.f(pkgUid));
    }

    /* renamed from: L */
    public a y(ViewGroup viewGroup, int i10) {
        return new a(y1.N(LayoutInflater.from(this.f11115d), viewGroup, false));
    }

    public void M() {
        if (!this.f11117f.isEmpty()) {
            this.f11117f.remove(0);
            u(0);
        }
    }

    public void N(List list) {
        this.f11117f.clear();
        this.f11117f.addAll(list);
        o();
    }

    public int j() {
        return this.f11117f.size();
    }
}
