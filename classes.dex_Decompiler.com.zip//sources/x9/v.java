package x9;

import com.samsung.android.sm.score.data.DetailItem;
import java.util.function.Consumer;

public final /* synthetic */ class v implements Consumer {
    public final void accept(Object obj) {
        ((DetailItem) obj).f5331h = 0;
    }
}
