package x9;

import android.content.Context;
import android.view.View;
import com.samsung.android.sm.score.data.DetailItem;
import x6.h;

public abstract class e extends h {

    /* renamed from: v  reason: collision with root package name */
    public Context f11114v;

    public interface a {
        void a(DetailItem detailItem, int i10, boolean z10);
    }

    public e(View view) {
        super(view);
        this.f11114v = view.getContext();
    }

    public abstract void P(DetailItem detailItem);

    public void Q(DetailItem detailItem, DetailItem detailItem2) {
    }

    public void R(DetailItem detailItem, a aVar) {
    }
}
