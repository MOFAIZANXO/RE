package x9;

import com.samsung.android.sm.score.data.DetailItem;
import java.util.function.Predicate;

public final /* synthetic */ class t implements Predicate {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ a0 f11130a;

    public /* synthetic */ t(a0 a0Var) {
        this.f11130a = a0Var;
    }

    public final boolean test(Object obj) {
        return this.f11130a.n0((DetailItem) obj);
    }
}
