package x9;

import android.view.View;
import com.samsung.android.sm.score.data.DetailItem;
import x9.e;
import x9.g;

public final /* synthetic */ class i implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ g.c f11122a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ DetailItem f11123b;

    /* renamed from: f  reason: collision with root package name */
    public final /* synthetic */ e.a f11124f;

    public /* synthetic */ i(g.c cVar, DetailItem detailItem, e.a aVar) {
        this.f11122a = cVar;
        this.f11123b = detailItem;
        this.f11124f = aVar;
    }

    public final void onClick(View view) {
        this.f11122a.T(this.f11123b, this.f11124f, view);
    }
}
