package x9;

import a7.b;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.core.content.res.ResourcesCompat;
import androidx.fragment.app.h;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.g0;
import androidx.lifecycle.m;
import androidx.lifecycle.t;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.n;
import com.samsung.android.sm.score.data.DetailItem;
import com.samsung.android.util.SemLog;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;
import o9.e;
import o9.f;

public class d extends RecyclerView.t {

    /* renamed from: n  reason: collision with root package name */
    public static long f11099n;

    /* renamed from: d  reason: collision with root package name */
    public final Context f11100d;

    /* renamed from: e  reason: collision with root package name */
    public RecyclerView f11101e;

    /* renamed from: f  reason: collision with root package name */
    public final z9.a f11102f;

    /* renamed from: g  reason: collision with root package name */
    public final l f11103g = new l();

    /* renamed from: h  reason: collision with root package name */
    public final ArrayList f11104h;

    /* renamed from: i  reason: collision with root package name */
    public final List f11105i;

    /* renamed from: j  reason: collision with root package name */
    public final a f11106j;

    /* renamed from: k  reason: collision with root package name */
    public boolean f11107k;

    /* renamed from: l  reason: collision with root package name */
    public boolean f11108l;

    /* renamed from: m  reason: collision with root package name */
    public final t f11109m;

    public class a implements Runnable {

        /* renamed from: a  reason: collision with root package name */
        public int f11110a = 0;

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ Handler f11111b;

        public a(Handler handler) {
            this.f11111b = handler;
        }

        public void run() {
            if (d.this.f11107k) {
                DetailItem detailItem = null;
                while (this.f11110a < d.this.f11104h.size() && detailItem == null) {
                    detailItem = d.this.W(((Integer) d.this.f11104h.get(this.f11110a)).intValue(), true);
                    this.f11110a++;
                }
                if (detailItem != null) {
                    d.this.f11105i.add(detailItem);
                    d dVar = d.this;
                    dVar.r(dVar.f11105i.size() - 1);
                    if (d.this.f11106j != null) {
                        d.this.f11106j.j(d.this.f11105i.size() - 1);
                    }
                    this.f11111b.postDelayed(this, 583);
                } else if (d.this.f11106j != null) {
                    Handler handler = this.f11111b;
                    a L = d.this.f11106j;
                    Objects.requireNonNull(L);
                    handler.postDelayed(new c(L), 583);
                }
            }
        }
    }

    public d(h hVar, a aVar) {
        ArrayList arrayList = new ArrayList();
        this.f11104h = arrayList;
        this.f11105i = new ArrayList();
        this.f11107k = false;
        this.f11108l = false;
        this.f11109m = new b(this);
        this.f11100d = hVar;
        this.f11106j = aVar;
        this.f11102f = (z9.a) new g0(hVar).a(z9.a.class);
        arrayList.addAll(e.f8663a);
        Collections.sort(arrayList);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void Y(f fVar) {
        Log.i("DashBoard.AutoFixAdapter", "ItemObserver : " + fVar + ", VIStatus : " + this.f11107k);
        if (fVar != null) {
            int a10 = fVar.a();
            if (fVar.e()) {
                Z(a10);
            }
        }
    }

    public final void Q() {
        Iterator it = this.f11104h.iterator();
        while (it.hasNext()) {
            DetailItem W = W(((Integer) it.next()).intValue(), false);
            if (W != null) {
                X(W);
            }
        }
    }

    public void R() {
        this.f11107k = false;
        this.f11101e.clearAnimation();
    }

    public final void S() {
        this.f11105i.clear();
    }

    public final DetailItem T(int i10, String str, Drawable drawable, int i11) {
        long j10 = f11099n;
        f11099n = 1 + j10;
        return new DetailItem.b(j10, i10, str).b(drawable).e(i11).a();
    }

    public void U() {
        if (this.f11108l) {
            SemLog.d("DashBoard.AutoFixAdapter", "avoid second insert animation until all animation clear");
            return;
        }
        SemLog.d("DashBoard.AutoFixAdapter", "finishAnimation()");
        this.f11108l = true;
        c0();
        e0();
        this.f11107k = false;
    }

    public final f V(Integer num) {
        LiveData s10;
        if (num == null || (s10 = this.f11102f.s(this.f11103g.c(num))) == null) {
            return null;
        }
        return (f) s10.j();
    }

    public final DetailItem W(int i10, boolean z10) {
        f V = V(Integer.valueOf(i10));
        Drawable drawable = null;
        if (V == null || !V.e()) {
            return null;
        }
        int a10 = this.f11103g.a(Integer.valueOf(i10));
        String c10 = V.c();
        try {
            drawable = ResourcesCompat.getDrawable(this.f11100d.getResources(), V.b(), this.f11100d.getTheme());
        } catch (Resources.NotFoundException e10) {
            Log.w("DashBoard.AutoFixAdapter", "fail to load[" + V + "]", e10);
        }
        return T(i10, c10, drawable, (!this.f11103g.e(Integer.valueOf(a10)) || !V.d()) ? (!z10 || this.f11103g.e(Integer.valueOf(a10))) ? 2 : 0 : 3);
    }

    public final void X(DetailItem detailItem) {
        if (detailItem != null) {
            this.f11105i.add(detailItem);
            Collections.sort(this.f11105i);
        }
    }

    public final void Z(int i10) {
        for (int i11 = 0; i11 < this.f11105i.size(); i11++) {
            if (i10 == ((DetailItem) this.f11105i.get(i11)).f5328b) {
                if (((DetailItem) this.f11105i.get(i11)).f5331h == 0) {
                    ((DetailItem) this.f11105i.get(i11)).f5331h = 1;
                }
                p(i11);
                return;
            }
        }
    }

    /* renamed from: a0 */
    public void w(e eVar, int i10) {
        DetailItem detailItem = (DetailItem) this.f11105i.get(i10);
        eVar.P(detailItem);
        int i11 = detailItem.f5328b;
        eVar.O(0);
        if (b.e("user.developer")) {
            SemLog.d("DashBoard.AutoFixAdapter", "onBindViewHolder : " + i11 + ", icon status : " + detailItem.f5331h + " holder pos : " + eVar.k() + ", pos :" + i10 + ", total : " + j());
        }
    }

    /* renamed from: b0 */
    public e y(ViewGroup viewGroup, int i10) {
        return g.a(viewGroup, LayoutInflater.from(this.f11100d), i10);
    }

    public final void c0() {
        Collections.sort(this.f11105i);
        o();
    }

    public void d0(m mVar, int i10) {
        LiveData s10 = this.f11102f.s(i10);
        if (s10 != null) {
            s10.n(mVar, this.f11109m);
        }
    }

    public final void e0() {
        a aVar = this.f11106j;
        if (aVar != null) {
            aVar.b();
        }
    }

    public void f0(boolean z10) {
        Log.i("DashBoard.AutoFixAdapter", "startChecking withAnimate? " + z10);
        S();
        if (z10) {
            this.f11108l = false;
            g0();
            return;
        }
        Q();
        o();
        this.f11108l = true;
    }

    public final void g0() {
        this.f11107k = true;
        Handler handler = new Handler();
        handler.post(new a(handler));
    }

    public int j() {
        return this.f11105i.size();
    }

    public long k(int i10) {
        if (i10 < this.f11105i.size()) {
            return ((DetailItem) this.f11105i.get(i10)).f5327a;
        }
        SemLog.w("DashBoard.AutoFixAdapter", "getItemId pos : " + i10 + ", " + this.f11105i.size());
        return 0;
    }

    public int l(int i10) {
        if (i10 < this.f11105i.size()) {
            return ((DetailItem) this.f11105i.get(i10)).f5328b;
        }
        SemLog.w("DashBoard.AutoFixAdapter", "getItemViewType pos : " + i10 + ", " + this.f11105i.size());
        return 0;
    }

    public void v(RecyclerView recyclerView) {
        super.v(recyclerView);
        SemLog.i("DashBoard.AutoFixAdapter", "onAttachedToRecyclerView");
        this.f11101e = recyclerView;
        n nVar = (n) recyclerView.getItemAnimator();
        if (nVar != null) {
            nVar.O(false);
        }
        S();
    }
}
