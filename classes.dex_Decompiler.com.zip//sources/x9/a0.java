package x9;

import a7.b;
import android.content.Context;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.SparseIntArray;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.fragment.app.h;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.g0;
import androidx.lifecycle.m;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.n;
import com.samsung.android.sm.core.data.AppData;
import com.samsung.android.sm.core.data.PkgUid;
import com.samsung.android.sm.score.data.DetailItem;
import com.samsung.android.sm.score.data.OptData;
import com.samsung.android.util.SemLog;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import p5.x;
import w6.t;
import x9.e;
import z9.d;

public class a0 extends RecyclerView.t {

    /* renamed from: p  reason: collision with root package name */
    public static long f11084p;

    /* renamed from: d  reason: collision with root package name */
    public SparseIntArray f11085d = new SparseIntArray();

    /* renamed from: e  reason: collision with root package name */
    public final Context f11086e;

    /* renamed from: f  reason: collision with root package name */
    public RecyclerView f11087f;

    /* renamed from: g  reason: collision with root package name */
    public final t f11088g;

    /* renamed from: h  reason: collision with root package name */
    public final d f11089h;

    /* renamed from: i  reason: collision with root package name */
    public final l f11090i = new l();

    /* renamed from: j  reason: collision with root package name */
    public final List f11091j = new ArrayList();

    /* renamed from: k  reason: collision with root package name */
    public final List f11092k = new ArrayList();

    /* renamed from: l  reason: collision with root package name */
    public final List f11093l = new ArrayList();

    /* renamed from: m  reason: collision with root package name */
    public final b0 f11094m;

    /* renamed from: n  reason: collision with root package name */
    public final androidx.lifecycle.t f11095n = new m(this);

    /* renamed from: o  reason: collision with root package name */
    public final e.a f11096o = new r(this);

    public a0(h hVar, b0 b0Var) {
        this.f11086e = hVar;
        this.f11094m = b0Var;
        this.f11089h = (d) new g0(hVar).a(d.class);
        this.f11088g = new t(hVar);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ boolean l0(DetailItem detailItem) {
        return this.f11093l.contains(detailItem.f5332i);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ boolean n0(DetailItem detailItem) {
        return this.f11090i.e(Integer.valueOf(detailItem.f5328b)) && detailItem.f5331h == 1;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ boolean o0(DetailItem detailItem) {
        return this.f11090i.e(Integer.valueOf(detailItem.f5328b));
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void p0(OptData optData) {
        SemLog.i("DashBoard.ManualFixAdapter", "ItemObserver : " + optData);
        if (optData != null && !e0().isEmpty()) {
            G0(optData);
        }
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void q0(DetailItem detailItem, int i10, boolean z10) {
        if (z10) {
            this.f11093l.remove(detailItem.f5332i);
        } else {
            this.f11093l.add(detailItem.f5332i);
        }
        d0();
    }

    public static /* synthetic */ boolean r0(int i10, ArrayList arrayList, DetailItem detailItem) {
        return detailItem.f5328b == i10 && !arrayList.contains(detailItem.f5332i);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ boolean s0(List list, DetailItem detailItem) {
        return this.f11090i.e(Integer.valueOf(detailItem.f5328b)) && !list.contains(detailItem);
    }

    public static /* synthetic */ boolean t0(int i10, DetailItem detailItem) {
        return detailItem.f5328b == i10;
    }

    public static /* synthetic */ boolean u0(int i10, DetailItem detailItem) {
        return detailItem.f5328b == i10;
    }

    /* access modifiers changed from: private */
    public /* synthetic */ boolean w0(DetailItem detailItem) {
        return this.f11090i.e(Integer.valueOf(detailItem.f5328b));
    }

    public void A0(Bundle bundle) {
        bundle.putParcelableArrayList("key_saved_instance_unchecked_items", j0());
    }

    public final void B0() {
        Collections.sort(this.f11092k);
        o();
    }

    public void C0(m mVar, int i10) {
        LiveData w10 = this.f11089h.w(i10);
        if (w10 != null) {
            w10.n(mVar, this.f11095n);
        }
    }

    public void D0() {
        SemLog.d("DashBoard.ManualFixAdapter", "setIssueItemList");
        Z();
        X();
        d0();
        B0();
    }

    public void E0(List list, SparseIntArray sparseIntArray) {
        this.f11091j.clear();
        this.f11091j.addAll(list);
        this.f11085d.clear();
        this.f11085d = sparseIntArray.clone();
    }

    public final void F0(ArrayList arrayList) {
        this.f11093l.clear();
        this.f11093l.addAll(arrayList);
    }

    /* JADX WARNING: Code restructure failed: missing block: B:22:0x018d, code lost:
        return;
     */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final synchronized void G0(com.samsung.android.sm.score.data.OptData r12) {
        /*
            r11 = this;
            monitor-enter(r11)
            java.util.ArrayList r0 = r11.e0()     // Catch:{ all -> 0x018e }
            java.lang.String r1 = "DashBoard.ManualFixAdapter"
            java.lang.StringBuilder r2 = new java.lang.StringBuilder     // Catch:{ all -> 0x018e }
            r2.<init>()     // Catch:{ all -> 0x018e }
            java.lang.String r3 = "updateListByScannedData. "
            r2.append(r3)     // Catch:{ all -> 0x018e }
            r2.append(r12)     // Catch:{ all -> 0x018e }
            java.lang.String r3 = ", size : "
            r2.append(r3)     // Catch:{ all -> 0x018e }
            int r3 = r0.size()     // Catch:{ all -> 0x018e }
            r2.append(r3)     // Catch:{ all -> 0x018e }
            java.lang.String r2 = r2.toString()     // Catch:{ all -> 0x018e }
            com.samsung.android.util.SemLog.d(r1, r2)     // Catch:{ all -> 0x018e }
            if (r12 != 0) goto L_0x002b
            monitor-exit(r11)
            return
        L_0x002b:
            int r1 = r12.j()     // Catch:{ all -> 0x018e }
            x9.l r2 = r11.f11090i     // Catch:{ all -> 0x018e }
            java.lang.Integer r1 = java.lang.Integer.valueOf(r1)     // Catch:{ all -> 0x018e }
            int r1 = r2.a(r1)     // Catch:{ all -> 0x018e }
            r2 = -1
            if (r1 != r2) goto L_0x0045
            java.lang.String r12 = "DashBoard.ManualFixAdapter"
            java.lang.String r0 = "There is no remove logic of optimization"
            com.samsung.android.util.SemLog.d(r12, r0)     // Catch:{ all -> 0x018e }
            monitor-exit(r11)
            return
        L_0x0045:
            java.util.ArrayList r3 = r12.d()     // Catch:{ all -> 0x018e }
            java.util.stream.Stream r3 = r3.stream()     // Catch:{ all -> 0x018e }
            x9.w r4 = new x9.w     // Catch:{ all -> 0x018e }
            r4.<init>()     // Catch:{ all -> 0x018e }
            java.util.stream.Stream r3 = r3.map(r4)     // Catch:{ all -> 0x018e }
            p5.x r4 = new p5.x     // Catch:{ all -> 0x018e }
            r4.<init>()     // Catch:{ all -> 0x018e }
            java.util.stream.Collector r4 = java.util.stream.Collectors.toCollection(r4)     // Catch:{ all -> 0x018e }
            java.lang.Object r3 = r3.collect(r4)     // Catch:{ all -> 0x018e }
            java.util.ArrayList r3 = (java.util.ArrayList) r3     // Catch:{ all -> 0x018e }
            java.util.stream.Stream r4 = r0.stream()     // Catch:{ all -> 0x018e }
            x9.x r5 = new x9.x     // Catch:{ all -> 0x018e }
            r5.<init>(r1, r3)     // Catch:{ all -> 0x018e }
            java.util.stream.Stream r3 = r4.filter(r5)     // Catch:{ all -> 0x018e }
            java.util.stream.Collector r4 = java.util.stream.Collectors.toList()     // Catch:{ all -> 0x018e }
            java.lang.Object r3 = r3.collect(r4)     // Catch:{ all -> 0x018e }
            java.util.List r3 = (java.util.List) r3     // Catch:{ all -> 0x018e }
            x9.l r4 = r11.f11090i     // Catch:{ all -> 0x018e }
            java.lang.Integer r5 = java.lang.Integer.valueOf(r1)     // Catch:{ all -> 0x018e }
            int r4 = r4.b(r5)     // Catch:{ all -> 0x018e }
            java.util.List r5 = r11.f11092k     // Catch:{ all -> 0x018e }
            java.util.stream.Stream r5 = r5.stream()     // Catch:{ all -> 0x018e }
            x9.y r6 = new x9.y     // Catch:{ all -> 0x018e }
            r6.<init>(r11, r3)     // Catch:{ all -> 0x018e }
            java.util.stream.Stream r5 = r5.filter(r6)     // Catch:{ all -> 0x018e }
            java.util.stream.Collector r6 = java.util.stream.Collectors.toList()     // Catch:{ all -> 0x018e }
            java.lang.Object r5 = r5.collect(r6)     // Catch:{ all -> 0x018e }
            java.util.List r5 = (java.util.List) r5     // Catch:{ all -> 0x018e }
            java.util.stream.Stream r6 = r5.stream()     // Catch:{ all -> 0x018e }
            x9.z r7 = new x9.z     // Catch:{ all -> 0x018e }
            r7.<init>(r1)     // Catch:{ all -> 0x018e }
            java.util.stream.Stream r6 = r6.filter(r7)     // Catch:{ all -> 0x018e }
            long r6 = r6.count()     // Catch:{ all -> 0x018e }
            int r6 = (int) r6     // Catch:{ all -> 0x018e }
            java.util.List r7 = r11.f11092k     // Catch:{ all -> 0x018e }
            java.util.stream.Stream r7 = r7.stream()     // Catch:{ all -> 0x018e }
            x9.n r8 = new x9.n     // Catch:{ all -> 0x018e }
            r8.<init>(r4)     // Catch:{ all -> 0x018e }
            java.util.stream.Stream r7 = r7.filter(r8)     // Catch:{ all -> 0x018e }
            java.util.Optional r7 = r7.findFirst()     // Catch:{ all -> 0x018e }
            r8 = 0
            java.lang.Object r7 = r7.orElse(r8)     // Catch:{ all -> 0x018e }
            com.samsung.android.sm.score.data.DetailItem r7 = (com.samsung.android.sm.score.data.DetailItem) r7     // Catch:{ all -> 0x018e }
            java.util.List r8 = r11.f11092k     // Catch:{ all -> 0x018e }
            int r8 = r8.indexOf(r7)     // Catch:{ all -> 0x018e }
            java.lang.String r9 = "DashBoard.ManualFixAdapter"
            java.lang.StringBuilder r10 = new java.lang.StringBuilder     // Catch:{ all -> 0x018e }
            r10.<init>()     // Catch:{ all -> 0x018e }
            r10.append(r1)     // Catch:{ all -> 0x018e }
            java.lang.String r1 = ":: manual count : "
            r10.append(r1)     // Catch:{ all -> 0x018e }
            r10.append(r6)     // Catch:{ all -> 0x018e }
            java.lang.String r1 = ", all remained app count : "
            r10.append(r1)     // Catch:{ all -> 0x018e }
            int r1 = r5.size()     // Catch:{ all -> 0x018e }
            r10.append(r1)     // Catch:{ all -> 0x018e }
            java.lang.String r1 = r10.toString()     // Catch:{ all -> 0x018e }
            com.samsung.android.util.SemLog.i(r9, r1)     // Catch:{ all -> 0x018e }
            if (r8 == r2) goto L_0x0107
            if (r6 > 0) goto L_0x00fe
            r3.add(r7)     // Catch:{ all -> 0x018e }
            goto L_0x0107
        L_0x00fe:
            java.util.List r1 = r11.f11092k     // Catch:{ all -> 0x018e }
            com.samsung.android.sm.score.data.DetailItem r2 = r11.g0(r4)     // Catch:{ all -> 0x018e }
            r1.set(r8, r2)     // Catch:{ all -> 0x018e }
        L_0x0107:
            java.util.stream.Stream r1 = r3.stream()     // Catch:{ all -> 0x018e }
            java.util.stream.Stream r1 = r1.distinct()     // Catch:{ all -> 0x018e }
            x9.o r2 = new x9.o     // Catch:{ all -> 0x018e }
            r2.<init>()     // Catch:{ all -> 0x018e }
            java.util.stream.Stream r1 = r1.filter(r2)     // Catch:{ all -> 0x018e }
            java.util.stream.Stream r1 = r1.sorted()     // Catch:{ all -> 0x018e }
            java.util.stream.Collector r2 = java.util.stream.Collectors.toList()     // Catch:{ all -> 0x018e }
            java.lang.Object r1 = r1.collect(r2)     // Catch:{ all -> 0x018e }
            java.util.List r1 = (java.util.List) r1     // Catch:{ all -> 0x018e }
            java.util.List r2 = r11.f11092k     // Catch:{ all -> 0x018e }
            r2.removeAll(r1)     // Catch:{ all -> 0x018e }
            java.util.List r2 = r11.f11093l     // Catch:{ all -> 0x018e }
            java.util.stream.Stream r3 = r1.stream()     // Catch:{ all -> 0x018e }
            x9.p r4 = new x9.p     // Catch:{ all -> 0x018e }
            r4.<init>()     // Catch:{ all -> 0x018e }
            java.util.stream.Stream r3 = r3.map(r4)     // Catch:{ all -> 0x018e }
            java.util.stream.Collector r4 = java.util.stream.Collectors.toList()     // Catch:{ all -> 0x018e }
            java.lang.Object r3 = r3.collect(r4)     // Catch:{ all -> 0x018e }
            java.util.Collection r3 = (java.util.Collection) r3     // Catch:{ all -> 0x018e }
            r2.removeAll(r3)     // Catch:{ all -> 0x018e }
            java.lang.String r2 = "DashBoard.ManualFixAdapter"
            java.lang.StringBuilder r3 = new java.lang.StringBuilder     // Catch:{ all -> 0x018e }
            r3.<init>()     // Catch:{ all -> 0x018e }
            java.lang.String r4 = "EndCheckList. "
            r3.append(r4)     // Catch:{ all -> 0x018e }
            r3.append(r12)     // Catch:{ all -> 0x018e }
            java.lang.String r12 = ", removeItems: "
            r3.append(r12)     // Catch:{ all -> 0x018e }
            int r12 = r1.size()     // Catch:{ all -> 0x018e }
            r3.append(r12)     // Catch:{ all -> 0x018e }
            java.lang.String r12 = " and remained "
            r3.append(r12)     // Catch:{ all -> 0x018e }
            int r12 = r0.size()     // Catch:{ all -> 0x018e }
            r3.append(r12)     // Catch:{ all -> 0x018e }
            java.lang.String r12 = r3.toString()     // Catch:{ all -> 0x018e }
            com.samsung.android.util.SemLog.i(r2, r12)     // Catch:{ all -> 0x018e }
            java.util.List r12 = r11.f11092k     // Catch:{ all -> 0x018e }
            java.util.stream.Stream r12 = r12.stream()     // Catch:{ all -> 0x018e }
            x9.q r0 = new x9.q     // Catch:{ all -> 0x018e }
            r0.<init>(r11)     // Catch:{ all -> 0x018e }
            boolean r12 = r12.anyMatch(r0)     // Catch:{ all -> 0x018e }
            if (r12 == 0) goto L_0x018c
            r11.d0()     // Catch:{ all -> 0x018e }
            r11.o()     // Catch:{ all -> 0x018e }
        L_0x018c:
            monitor-exit(r11)
            return
        L_0x018e:
            r12 = move-exception
            monitor-exit(r11)
            throw r12
        */
        throw new UnsupportedOperationException("Method not decompiled: x9.a0.G0(com.samsung.android.sm.score.data.OptData):void");
    }

    public final void W(List list, int i10) {
        DetailItem g02;
        if (!list.isEmpty()) {
            for (int i11 = 0; i11 < list.size(); i11++) {
                k0((DetailItem) list.get(i11));
            }
            if (i10 != -1 && (g02 = g0(i10)) != null) {
                k0(g02);
            }
        }
    }

    public final void X() {
        for (Integer intValue : this.f11091j) {
            int a10 = this.f11090i.a(Integer.valueOf(intValue.intValue()));
            W(b0(a10), this.f11090i.b(Integer.valueOf(a10)));
        }
    }

    public void Y() {
        this.f11087f.clearAnimation();
    }

    public final void Z() {
        this.f11092k.clear();
    }

    public final DetailItem a0(int i10, String str) {
        long j10 = f11084p;
        f11084p = 1 + j10;
        return new DetailItem.b(j10, i10, str).a();
    }

    public final List b0(int i10) {
        ArrayList arrayList = new ArrayList();
        OptData f02 = f0(Integer.valueOf(i10));
        if (f02 == null) {
            return arrayList;
        }
        ArrayList arrayList2 = new ArrayList(f02.d());
        if (!arrayList2.isEmpty()) {
            Iterator it = arrayList2.iterator();
            while (it.hasNext()) {
                AppData appData = (AppData) it.next();
                String d10 = this.f11088g.d(appData.C());
                Drawable f10 = this.f11088g.f(appData.C());
                if (!(d10 == null || f10 == null)) {
                    arrayList.add(c0(i10, d10, f10, appData.C(), appData.m()));
                }
            }
            if (!this.f11093l.isEmpty()) {
                arrayList.stream().filter(new u(this)).forEach(new v());
            }
        } else {
            SemLog.w("DashBoard.ManualFixAdapter", i10 + " 's app list is empty");
        }
        return arrayList;
    }

    public final DetailItem c0(int i10, String str, Drawable drawable, PkgUid pkgUid, int i11) {
        long j10 = f11084p;
        f11084p = 1 + j10;
        return new DetailItem.b(j10, i10, str).d(pkgUid).b(drawable).e(1).c(i11).a();
    }

    public final void d0() {
        this.f11094m.o(!e0().isEmpty());
    }

    public ArrayList e0() {
        return (ArrayList) this.f11092k.stream().filter(new t(this)).collect(Collectors.toCollection(new x()));
    }

    public final OptData f0(Integer num) {
        LiveData w10;
        if (num == null || (w10 = this.f11089h.w(this.f11090i.c(num))) == null) {
            return null;
        }
        return (OptData) w10.j();
    }

    public final DetailItem g0(int i10) {
        OptData f02;
        if (!this.f11090i.d(Integer.valueOf(i10)) || (f02 = f0(Integer.valueOf(this.f11090i.c(Integer.valueOf(i10))))) == null) {
            return null;
        }
        int i11 = this.f11085d.get(f02.j());
        int size = f02.d().size();
        return a0(i10, this.f11086e.getResources().getQuantityString(i11, size, new Object[]{Integer.valueOf(size)}));
    }

    public int h0() {
        return (int) this.f11092k.stream().filter(new s(this)).count();
    }

    public final int i0(int i10, int i11) {
        try {
            if (!this.f11090i.e(Integer.valueOf(i10))) {
                return 0;
            }
            int i12 = this.f11090i.d(Integer.valueOf(((DetailItem) this.f11092k.get(i11 + -1)).f5328b)) ? 3 : 0;
            return (i11 != this.f11092k.size() + -1 && !this.f11090i.d(Integer.valueOf(((DetailItem) this.f11092k.get(i11 + 1)).f5328b))) ? i12 : i12 | 12;
        } catch (IndexOutOfBoundsException unused) {
            SemLog.w("DashBoard.ManualFixAdapter", "index out of bounds. cur index : " + i11);
            return 0;
        }
    }

    public int j() {
        return this.f11092k.size();
    }

    public final ArrayList j0() {
        return new ArrayList(this.f11093l);
    }

    public long k(int i10) {
        if (i10 < this.f11092k.size()) {
            return ((DetailItem) this.f11092k.get(i10)).f5327a;
        }
        SemLog.w("DashBoard.ManualFixAdapter", "getItemId pos : " + i10 + ", " + this.f11092k.size());
        return 0;
    }

    public final void k0(DetailItem detailItem) {
        if (detailItem != null) {
            this.f11092k.add(detailItem);
        }
    }

    public int l(int i10) {
        if (i10 < this.f11092k.size()) {
            return ((DetailItem) this.f11092k.get(i10)).f5328b;
        }
        SemLog.w("DashBoard.ManualFixAdapter", "getItemViewType pos : " + i10 + ", " + this.f11092k.size());
        return 0;
    }

    public void v(RecyclerView recyclerView) {
        super.v(recyclerView);
        SemLog.i("DashBoard.ManualFixAdapter", "onAttachedToRecyclerView");
        this.f11087f = recyclerView;
        n nVar = (n) recyclerView.getItemAnimator();
        if (nVar != null) {
            nVar.O(false);
        }
        Z();
    }

    /* renamed from: x0 */
    public void w(e eVar, int i10) {
        DetailItem detailItem = (DetailItem) this.f11092k.get(i10);
        eVar.P(detailItem);
        eVar.R(detailItem, this.f11096o);
        int i11 = i10 + 1;
        if (i11 < this.f11092k.size()) {
            eVar.Q(detailItem, (DetailItem) this.f11092k.get(i11));
        } else {
            eVar.Q(detailItem, (DetailItem) null);
        }
        int i12 = detailItem.f5328b;
        eVar.O(i0(i12, i10));
        if (b.e("user.developer")) {
            SemLog.d("DashBoard.ManualFixAdapter", "onBindViewHolder : " + i12 + " holder pos : " + eVar.k() + ", pos :" + i10 + ", total : " + j());
        }
    }

    /* renamed from: y0 */
    public e y(ViewGroup viewGroup, int i10) {
        return g.a(viewGroup, LayoutInflater.from(this.f11086e), i10);
    }

    public void z0(Bundle bundle) {
        if (bundle != null) {
            F0(bundle.getParcelableArrayList("key_saved_instance_unchecked_items"));
        }
    }
}
