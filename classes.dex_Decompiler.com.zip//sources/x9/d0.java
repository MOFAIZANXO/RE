package x9;

import android.animation.ValueAnimator;
import com.samsung.android.sm.score.ui.fixlist.ManualFixAnimActivity;

public final /* synthetic */ class d0 implements ValueAnimator.AnimatorUpdateListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ ManualFixAnimActivity f11113a;

    public /* synthetic */ d0(ManualFixAnimActivity manualFixAnimActivity) {
        this.f11113a = manualFixAnimActivity;
    }

    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        this.f11113a.g0(valueAnimator);
    }
}
