package x9;

import com.samsung.android.sm.core.data.AppData;
import java.util.function.Function;

public final /* synthetic */ class w implements Function {
    public final Object apply(Object obj) {
        return ((AppData) obj).C();
    }
}
