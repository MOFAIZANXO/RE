package x9;

public final /* synthetic */ class c implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ a f11098a;

    public /* synthetic */ c(a aVar) {
        this.f11098a = aVar;
    }

    public final void run() {
        this.f11098a.p();
    }
}
