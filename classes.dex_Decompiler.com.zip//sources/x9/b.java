package x9;

import androidx.lifecycle.t;
import o9.f;

public final /* synthetic */ class b implements t {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ d f11097a;

    public /* synthetic */ b(d dVar) {
        this.f11097a = dVar;
    }

    public final void a(Object obj) {
        this.f11097a.Y((f) obj);
    }
}
