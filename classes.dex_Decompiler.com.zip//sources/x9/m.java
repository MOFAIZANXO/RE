package x9;

import androidx.lifecycle.t;
import com.samsung.android.sm.score.data.OptData;

public final /* synthetic */ class m implements t {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ a0 f11125a;

    public /* synthetic */ m(a0 a0Var) {
        this.f11125a = a0Var;
    }

    public final void a(Object obj) {
        this.f11125a.p0((OptData) obj);
    }
}
