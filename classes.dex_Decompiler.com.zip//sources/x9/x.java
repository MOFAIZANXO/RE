package x9;

import com.samsung.android.sm.score.data.DetailItem;
import java.util.ArrayList;
import java.util.function.Predicate;

public final /* synthetic */ class x implements Predicate {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ int f11132a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ ArrayList f11133b;

    public /* synthetic */ x(int i10, ArrayList arrayList) {
        this.f11132a = i10;
        this.f11133b = arrayList;
    }

    public final boolean test(Object obj) {
        return a0.r0(this.f11132a, this.f11133b, (DetailItem) obj);
    }
}
