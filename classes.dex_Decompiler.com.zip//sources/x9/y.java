package x9;

import com.samsung.android.sm.score.data.DetailItem;
import java.util.List;
import java.util.function.Predicate;

public final /* synthetic */ class y implements Predicate {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ a0 f11134a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ List f11135b;

    public /* synthetic */ y(a0 a0Var, List list) {
        this.f11134a = a0Var;
        this.f11135b = list;
    }

    public final boolean test(Object obj) {
        return this.f11134a.s0(this.f11135b, (DetailItem) obj);
    }
}
