package d4;

import android.net.Uri;

public abstract class a {

    /* renamed from: a  reason: collision with root package name */
    public static final Uri f5597a = Uri.parse("content://com.samsung.android.rubin.persona.searchrecommendation");
}
