package q1;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import androidx.core.app.NotificationCompat;
import androidx.work.impl.WorkDatabase;
import n1.l;
import o1.i;
import w1.g;
import w1.h;
import x1.c;

public abstract class a {

    /* renamed from: a  reason: collision with root package name */
    public static final String f9103a = l.f("Alarms");

    public static void a(Context context, i iVar, String str) {
        h y10 = iVar.q().y();
        g b10 = y10.b(str);
        if (b10 != null) {
            b(context, str, b10.f10338b);
            l.c().a(f9103a, String.format("Removing SystemIdInfo for workSpecId (%s)", new Object[]{str}), new Throwable[0]);
            y10.c(str);
        }
    }

    public static void b(Context context, String str, int i10) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(NotificationCompat.CATEGORY_ALARM);
        PendingIntent service = PendingIntent.getService(context, i10, androidx.work.impl.background.systemalarm.a.c(context, str), 603979776);
        if (service != null && alarmManager != null) {
            l.c().a(f9103a, String.format("Cancelling existing alarm with (workSpecId, systemId) (%s, %s)", new Object[]{str, Integer.valueOf(i10)}), new Throwable[0]);
            alarmManager.cancel(service);
        }
    }

    public static void c(Context context, i iVar, String str, long j10) {
        WorkDatabase q10 = iVar.q();
        h y10 = q10.y();
        g b10 = y10.b(str);
        if (b10 != null) {
            b(context, str, b10.f10338b);
            d(context, str, b10.f10338b, j10);
            return;
        }
        int b11 = new c(q10).b();
        y10.d(new g(str, b11));
        d(context, str, b11, j10);
    }

    public static void d(Context context, String str, int i10, long j10) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(NotificationCompat.CATEGORY_ALARM);
        PendingIntent service = PendingIntent.getService(context, i10, androidx.work.impl.background.systemalarm.a.c(context, str), 201326592);
        if (alarmManager != null) {
            alarmManager.setExact(0, j10, service);
        }
    }
}
