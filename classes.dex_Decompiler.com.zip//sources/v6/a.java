package v6;

import android.content.Context;
import androidx.fragment.app.Fragment;

public abstract class a extends Fragment {

    /* renamed from: a  reason: collision with root package name */
    public b f10245a;

    /* renamed from: b  reason: collision with root package name */
    public Context f10246b;

    public void onAttach(Context context) {
        super.onAttach(context);
        this.f10246b = context;
    }

    public abstract boolean y(boolean z10);
}
