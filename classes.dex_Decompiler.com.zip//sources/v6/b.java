package v6;

import android.os.Bundle;

public interface b {
    void h(String str, Bundle bundle);

    void s(String str) {
        h(str, (Bundle) null);
    }
}
