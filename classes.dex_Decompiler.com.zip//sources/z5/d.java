package z5;

import ac.l;
import android.app.Application;
import android.database.ContentObserver;
import android.os.Handler;
import android.os.Looper;
import androidx.core.view.PointerIconCompat;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.q;
import b7.e;
import com.samsung.android.rubin.sdk.module.odm.OdmProviderContract;
import com.samsung.android.sm.history.data.AppIssueHistoryData;
import com.samsung.android.util.SemLog;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import kotlin.jvm.internal.g;
import kotlin.jvm.internal.m;
import qb.r;
import rb.u;

public final class d extends androidx.lifecycle.a {

    /* renamed from: n  reason: collision with root package name */
    public static final b f11428n = new b((g) null);

    /* renamed from: h  reason: collision with root package name */
    public final q f11429h;

    /* renamed from: i  reason: collision with root package name */
    public Map f11430i = new HashMap();

    /* renamed from: j  reason: collision with root package name */
    public b8.b f11431j;

    /* renamed from: k  reason: collision with root package name */
    public boolean f11432k;

    /* renamed from: l  reason: collision with root package name */
    public int f11433l;

    /* renamed from: m  reason: collision with root package name */
    public ContentObserver f11434m = new c(this, new Handler(Looper.getMainLooper()));

    public static final class a extends m implements l {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ d f11435a;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(d dVar) {
            super(1);
            this.f11435a = dVar;
        }

        public final void a(ArrayList arrayList) {
            kotlin.jvm.internal.l.e(arrayList, "dataList");
            this.f11435a.A(arrayList);
        }

        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            a((ArrayList) obj);
            return r.f9409a;
        }
    }

    public static final class b {
        public b() {
        }

        public /* synthetic */ b(g gVar) {
            this();
        }
    }

    public static final class c extends ContentObserver {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ d f11436a;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public c(d dVar, Handler handler) {
            super(handler);
            this.f11436a = dVar;
        }

        public void onChange(boolean z10) {
            super.onChange(z10);
            this.f11436a.E();
        }
    }

    /* renamed from: z5.d$d  reason: collision with other inner class name */
    public static final class C0155d extends m implements l {

        /* renamed from: a  reason: collision with root package name */
        public static final C0155d f11437a = new C0155d();

        public C0155d() {
            super(1);
        }

        /* renamed from: a */
        public final Boolean invoke(AppIssueHistoryData appIssueHistoryData) {
            return Boolean.valueOf(appIssueHistoryData.q() == 0);
        }
    }

    public static final class e extends m implements l {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ d f11438a;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public e(d dVar) {
            super(1);
            this.f11438a = dVar;
        }

        /* renamed from: a */
        public final Integer invoke(AppIssueHistoryData appIssueHistoryData) {
            kotlin.jvm.internal.l.e(appIssueHistoryData, "obj");
            return Integer.valueOf(this.f11438a.z(appIssueHistoryData));
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public d(Application application) {
        super(application);
        kotlin.jvm.internal.l.e(application, "application");
        q qVar = new q();
        this.f11429h = qVar;
        b8.b bVar = new b8.b(application.getApplicationContext());
        this.f11431j = bVar;
        qVar.v(bVar.f(PointerIconCompat.TYPE_TEXT), new a(new a(this)));
        r().getContentResolver().registerContentObserver(e.c.f2840a, true, this.f11434m);
    }

    public static final boolean B(l lVar, Object obj) {
        kotlin.jvm.internal.l.e(lVar, "$tmp0");
        return ((Boolean) lVar.invoke(obj)).booleanValue();
    }

    public static final Integer C(l lVar, Object obj) {
        kotlin.jvm.internal.l.e(lVar, "$tmp0");
        return (Integer) lVar.invoke(obj);
    }

    public static final void v(l lVar, Object obj) {
        kotlin.jvm.internal.l.e(lVar, "$tmp0");
        lVar.invoke(obj);
    }

    public final void A(ArrayList arrayList) {
        kotlin.jvm.internal.l.e(arrayList, "dataList");
        this.f11432k = arrayList.stream().anyMatch(new b(C0155d.f11437a));
        Object collect = arrayList.stream().collect(Collectors.groupingBy(new c(new e(this))));
        kotlin.jvm.internal.l.d(collect, "fun makeAppData(dataList…ist.distinct().size\n    }");
        this.f11430i = (Map) collect;
        this.f11433l = arrayList.size();
        this.f11429h.u(Integer.valueOf(u.o(arrayList).size()));
    }

    public final boolean D() {
        return this.f11432k;
    }

    public final void E() {
        this.f11431j.m(PointerIconCompat.TYPE_TEXT);
        SemLog.i("DC.AppOptimizeCategoryCardViewModel", "reloadData");
    }

    public void p() {
        r().getContentResolver().unregisterContentObserver(this.f11434m);
        super.p();
    }

    public final List w(int i10) {
        return this.f11430i.containsKey(Integer.valueOf(i10)) ? u.o((Iterable) this.f11430i.getOrDefault(Integer.valueOf(i10), new ArrayList())) : new ArrayList();
    }

    public final LiveData x() {
        return this.f11429h;
    }

    public final int y() {
        return this.f11433l;
    }

    public final int z(AppIssueHistoryData appIssueHistoryData) {
        kotlin.jvm.internal.l.e(appIssueHistoryData, OdmProviderContract.OdmResult.COLUMN_DATA);
        int e10 = appIssueHistoryData.e();
        if (e10 != 32) {
            return e10 != 1030 ? PointerIconCompat.TYPE_CELL : PointerIconCompat.TYPE_CROSSHAIR;
        }
        return 1005;
    }
}
