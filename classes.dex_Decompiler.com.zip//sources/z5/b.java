package z5;

import ac.l;
import java.util.function.Predicate;

public final /* synthetic */ class b implements Predicate {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ l f11426a;

    public /* synthetic */ b(l lVar) {
        this.f11426a = lVar;
    }

    public final boolean test(Object obj) {
        return d.B(this.f11426a, obj);
    }
}
