package z5;

import ac.l;
import androidx.lifecycle.t;

public final /* synthetic */ class a implements t {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ l f11425a;

    public /* synthetic */ a(l lVar) {
        this.f11425a = lVar;
    }

    public final void a(Object obj) {
        d.v(this.f11425a, obj);
    }
}
