package z5;

import ac.l;
import androidx.lifecycle.t;

public final /* synthetic */ class e implements t {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ l f11439a;

    public /* synthetic */ e(l lVar) {
        this.f11439a = lVar;
    }

    public final void a(Object obj) {
        f.t(this.f11439a, obj);
    }
}
