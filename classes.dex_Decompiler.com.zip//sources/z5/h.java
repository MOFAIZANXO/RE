package z5;

import android.app.Application;
import android.database.ContentObserver;
import android.os.Handler;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.q;
import b7.e;
import b8.b;
import com.samsung.android.sm.history.data.AppIssueHistoryData;
import com.samsung.android.util.SemLog;
import java.util.ArrayList;

public class h extends androidx.lifecycle.a {

    /* renamed from: h  reason: collision with root package name */
    public final q f11448h;

    /* renamed from: i  reason: collision with root package name */
    public final LiveData f11449i;

    /* renamed from: j  reason: collision with root package name */
    public final AppIssueHistoryData f11450j;

    /* renamed from: k  reason: collision with root package name */
    public final b f11451k;

    /* renamed from: l  reason: collision with root package name */
    public int f11452l;

    /* renamed from: m  reason: collision with root package name */
    public final ContentObserver f11453m = new a(new Handler());

    public class a extends ContentObserver {
        public a(Handler handler) {
            super(handler);
        }

        public void onChange(boolean z10) {
            h.this.x();
        }
    }

    public h(Application application, AppIssueHistoryData appIssueHistoryData, int i10) {
        super(application);
        this.f11450j = appIssueHistoryData;
        q qVar = new q();
        this.f11448h = qVar;
        qVar.u((Object) null);
        this.f11452l = i10;
        b bVar = new b(application.getApplicationContext());
        this.f11451k = bVar;
        this.f11449i = bVar.i(appIssueHistoryData, i10);
        w();
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void v(ArrayList arrayList) {
        SemLog.i("DC.IssueHistoryViewModel", "appHistoryData : " + arrayList.size());
        this.f11448h.u(arrayList);
    }

    public void p() {
        q qVar = this.f11448h;
        if (qVar != null) {
            qVar.w(this.f11449i);
        }
        r().getContentResolver().unregisterContentObserver(this.f11453m);
        super.p();
    }

    public LiveData u() {
        return this.f11448h;
    }

    public final void w() {
        this.f11448h.v(this.f11449i, new g(this));
        r().getContentResolver().registerContentObserver(e.c.f2840a, true, this.f11453m);
    }

    public final void x() {
        if (this.f11450j != null) {
            SemLog.i("DC.IssueHistoryViewModel", "reloadData : " + this.f11450j.m());
            this.f11451k.n(this.f11450j, this.f11452l);
            return;
        }
        SemLog.i("DC.IssueHistoryViewModel", "reloadData, mAppHistoryData is null");
    }
}
