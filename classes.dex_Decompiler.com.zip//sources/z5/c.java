package z5;

import ac.l;
import java.util.function.Function;

public final /* synthetic */ class c implements Function {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ l f11427a;

    public /* synthetic */ c(l lVar) {
        this.f11427a = lVar;
    }

    public final Object apply(Object obj) {
        return d.C(this.f11427a, obj);
    }
}
