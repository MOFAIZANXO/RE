package z5;

import ac.l;
import android.app.Application;
import android.database.ContentObserver;
import android.os.Handler;
import android.os.Looper;
import androidx.core.view.PointerIconCompat;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.q;
import b7.e;
import com.samsung.android.util.SemLog;
import java.util.ArrayList;
import kotlin.jvm.internal.g;
import kotlin.jvm.internal.m;
import qb.r;

public final class f extends androidx.lifecycle.a {

    /* renamed from: l  reason: collision with root package name */
    public static final b f11440l = new b((g) null);

    /* renamed from: h  reason: collision with root package name */
    public b8.b f11441h;

    /* renamed from: i  reason: collision with root package name */
    public int f11442i = PointerIconCompat.TYPE_TEXT;

    /* renamed from: j  reason: collision with root package name */
    public final q f11443j;

    /* renamed from: k  reason: collision with root package name */
    public ContentObserver f11444k;

    public static final class a extends m implements l {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ f f11445a;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public a(f fVar) {
            super(1);
            this.f11445a = fVar;
        }

        public final void a(ArrayList arrayList) {
            this.f11445a.f11443j.r(arrayList);
        }

        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            a((ArrayList) obj);
            return r.f9409a;
        }
    }

    public static final class b {
        public b() {
        }

        public /* synthetic */ b(g gVar) {
            this();
        }
    }

    public static final class c extends ContentObserver {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ f f11446a;

        /* JADX INFO: super call moved to the top of the method (can break code semantics) */
        public c(f fVar, Handler handler) {
            super(handler);
            this.f11446a = fVar;
        }

        public void onChange(boolean z10) {
            super.onChange(z10);
            this.f11446a.x();
        }
    }

    /* JADX INFO: super call moved to the top of the method (can break code semantics) */
    public f(Application application) {
        super(application);
        kotlin.jvm.internal.l.e(application, "application");
        q qVar = new q();
        this.f11443j = qVar;
        this.f11444k = new c(this, new Handler(Looper.getMainLooper()));
        this.f11441h = new b8.b(application.getApplicationContext());
        r().getContentResolver().registerContentObserver(e.c.f2840a, true, this.f11444k);
        qVar.v(w(this.f11442i), new e(new a(this)));
    }

    public static final void t(l lVar, Object obj) {
        kotlin.jvm.internal.l.e(lVar, "$tmp0");
        lVar.invoke(obj);
    }

    public void p() {
        r().getContentResolver().unregisterContentObserver(this.f11444k);
        super.p();
    }

    public final LiveData v() {
        return this.f11443j;
    }

    public final LiveData w(int i10) {
        LiveData f10 = this.f11441h.f(i10);
        kotlin.jvm.internal.l.d(f10, "mRepository.getAppIssueHistoryDataType(type)");
        return f10;
    }

    public final void x() {
        w(this.f11442i);
        int i10 = this.f11442i;
        SemLog.i("DC.AppOptimizeViewModel", "reloadData " + i10);
    }

    public final void y(int i10) {
        this.f11441h.o(i10);
    }

    public final void z(int i10) {
        if (this.f11442i != i10) {
            this.f11442i = i10;
            w(i10);
        }
    }
}
