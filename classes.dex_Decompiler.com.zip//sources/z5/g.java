package z5;

import androidx.lifecycle.t;
import java.util.ArrayList;

public final /* synthetic */ class g implements t {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ h f11447a;

    public /* synthetic */ g(h hVar) {
        this.f11447a = hVar;
    }

    public final void a(Object obj) {
        this.f11447a.v((ArrayList) obj);
    }
}
