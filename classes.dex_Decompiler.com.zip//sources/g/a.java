package g;

public interface a {
    Object apply(Object obj);
}
