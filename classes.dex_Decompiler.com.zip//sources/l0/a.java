package l0;

import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import java.lang.reflect.Method;

public abstract class a {

    /* renamed from: a  reason: collision with root package name */
    public static final Class f7759a = StateListDrawable.class;

    public static int a(StateListDrawable stateListDrawable) {
        Method e10 = h0.a.e(f7759a, "hidden_getStateCount", new Class[0]);
        if (e10 != null) {
            Object k10 = h0.a.k(stateListDrawable, e10, new Object[0]);
            if (k10 instanceof Integer) {
                return ((Integer) k10).intValue();
            }
        }
        return 0;
    }

    public static Drawable b(StateListDrawable stateListDrawable, int i10) {
        Method e10 = h0.a.e(f7759a, "hidden_getStateDrawable", Integer.TYPE);
        if (e10 == null) {
            return null;
        }
        Object k10 = h0.a.k(stateListDrawable, e10, Integer.valueOf(i10));
        if (k10 instanceof Drawable) {
            return (Drawable) k10;
        }
        return null;
    }

    public static int[] c(StateListDrawable stateListDrawable, int i10) {
        Method e10 = h0.a.e(f7759a, "hidden_getStateSet", Integer.TYPE);
        if (e10 != null) {
            Object k10 = h0.a.k(stateListDrawable, e10, Integer.valueOf(i10));
            if (k10 instanceof int[]) {
                return (int[]) k10;
            }
        }
        return new int[0];
    }
}
