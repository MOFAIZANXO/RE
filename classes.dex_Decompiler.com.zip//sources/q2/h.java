package q2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.RelativeLayout;
import com.github.mikephil.charting.data.Entry;
import java.lang.ref.WeakReference;
import p2.b;
import z2.d;

public abstract class h extends RelativeLayout implements d {

    /* renamed from: a  reason: collision with root package name */
    public d f9193a = new d();

    /* renamed from: b  reason: collision with root package name */
    public d f9194b = new d();

    /* renamed from: f  reason: collision with root package name */
    public WeakReference f9195f;

    public h(Context context, int i10) {
        super(context);
        setupLayoutResource(i10);
    }

    private void setupLayoutResource(int i10) {
        View inflate = LayoutInflater.from(getContext()).inflate(i10, this);
        inflate.setLayoutParams(new RelativeLayout.LayoutParams(-2, -2));
        inflate.measure(View.MeasureSpec.makeMeasureSpec(0, 0), View.MeasureSpec.makeMeasureSpec(0, 0));
        inflate.layout(0, 0, inflate.getMeasuredWidth(), inflate.getMeasuredHeight());
    }

    public void b(Entry entry, t2.d dVar) {
        measure(View.MeasureSpec.makeMeasureSpec(0, 0), View.MeasureSpec.makeMeasureSpec(0, 0));
        layout(0, 0, getMeasuredWidth(), getMeasuredHeight());
    }

    public d c(float f10, float f11) {
        d offset = getOffset();
        d dVar = this.f9194b;
        dVar.f11371c = offset.f11371c;
        dVar.f11372d = offset.f11372d;
        b chartView = getChartView();
        float width = (float) getWidth();
        float height = (float) getHeight();
        d dVar2 = this.f9194b;
        float f12 = dVar2.f11371c;
        if (f10 + f12 < 0.0f) {
            dVar2.f11371c = -f10;
        } else if (chartView != null && f10 + width + f12 > ((float) chartView.getWidth())) {
            this.f9194b.f11371c = (((float) chartView.getWidth()) - f10) - width;
        }
        d dVar3 = this.f9194b;
        float f13 = dVar3.f11372d;
        if (f11 + f13 < 0.0f) {
            dVar3.f11372d = -f11;
        } else if (chartView != null && f11 + height + f13 > ((float) chartView.getHeight())) {
            this.f9194b.f11372d = (((float) chartView.getHeight()) - f11) - height;
        }
        return this.f9194b;
    }

    public b getChartView() {
        WeakReference weakReference = this.f9195f;
        if (weakReference == null) {
            return null;
        }
        return (b) weakReference.get();
    }

    public d getOffset() {
        return this.f9193a;
    }

    public void setChartView(b bVar) {
        this.f9195f = new WeakReference(bVar);
    }

    public void setOffset(d dVar) {
        this.f9193a = dVar;
        if (dVar == null) {
            this.f9193a = new d();
        }
    }
}
