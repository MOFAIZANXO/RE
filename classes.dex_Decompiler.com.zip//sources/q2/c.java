package q2;

import android.graphics.Paint;
import z2.d;
import z2.g;

public class c extends b {

    /* renamed from: g  reason: collision with root package name */
    public String f9130g = "Description Label";

    /* renamed from: h  reason: collision with root package name */
    public d f9131h;

    /* renamed from: i  reason: collision with root package name */
    public Paint.Align f9132i = Paint.Align.RIGHT;

    public c() {
        this.f9128e = g.e(8.0f);
    }

    public d l() {
        return this.f9131h;
    }

    public String m() {
        return this.f9130g;
    }

    public Paint.Align n() {
        return this.f9132i;
    }
}
