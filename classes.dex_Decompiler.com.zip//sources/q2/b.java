package q2;

import android.graphics.Typeface;
import androidx.core.view.ViewCompat;
import z2.g;

public abstract class b {

    /* renamed from: a  reason: collision with root package name */
    public boolean f9124a = true;

    /* renamed from: b  reason: collision with root package name */
    public float f9125b = 5.0f;

    /* renamed from: c  reason: collision with root package name */
    public float f9126c = 5.0f;

    /* renamed from: d  reason: collision with root package name */
    public Typeface f9127d = null;

    /* renamed from: e  reason: collision with root package name */
    public float f9128e = g.e(10.0f);

    /* renamed from: f  reason: collision with root package name */
    public int f9129f = ViewCompat.MEASURED_STATE_MASK;

    public int a() {
        return this.f9129f;
    }

    public float b() {
        return this.f9128e;
    }

    public Typeface c() {
        return this.f9127d;
    }

    public float d() {
        return this.f9125b;
    }

    public float e() {
        return this.f9126c;
    }

    public boolean f() {
        return this.f9124a;
    }

    public void g(boolean z10) {
        this.f9124a = z10;
    }

    public void h(int i10) {
        this.f9129f = i10;
    }

    public void i(float f10) {
        if (f10 > 24.0f) {
            f10 = 24.0f;
        }
        if (f10 < 6.0f) {
            f10 = 6.0f;
        }
        this.f9128e = g.e(f10);
    }

    public void j(float f10) {
        this.f9125b = g.e(f10);
    }

    public void k(float f10) {
        this.f9126c = g.e(f10);
    }
}
