package q2;

import android.graphics.DashPathEffect;
import android.graphics.Paint;
import java.util.ArrayList;
import java.util.List;
import z2.g;
import z2.h;

public class e extends b {
    public float A = 0.0f;
    public boolean B = false;
    public List C = new ArrayList(16);
    public List D = new ArrayList(16);
    public List E = new ArrayList(16);

    /* renamed from: g  reason: collision with root package name */
    public f[] f9133g = new f[0];

    /* renamed from: h  reason: collision with root package name */
    public f[] f9134h;

    /* renamed from: i  reason: collision with root package name */
    public boolean f9135i = false;

    /* renamed from: j  reason: collision with root package name */
    public d f9136j = d.LEFT;

    /* renamed from: k  reason: collision with root package name */
    public f f9137k = f.BOTTOM;

    /* renamed from: l  reason: collision with root package name */
    public C0125e f9138l = C0125e.HORIZONTAL;

    /* renamed from: m  reason: collision with root package name */
    public boolean f9139m = false;

    /* renamed from: n  reason: collision with root package name */
    public b f9140n = b.LEFT_TO_RIGHT;

    /* renamed from: o  reason: collision with root package name */
    public c f9141o = c.SQUARE;

    /* renamed from: p  reason: collision with root package name */
    public float f9142p = 8.0f;

    /* renamed from: q  reason: collision with root package name */
    public float f9143q = 3.0f;

    /* renamed from: r  reason: collision with root package name */
    public DashPathEffect f9144r = null;

    /* renamed from: s  reason: collision with root package name */
    public float f9145s = 6.0f;

    /* renamed from: t  reason: collision with root package name */
    public float f9146t = 0.0f;

    /* renamed from: u  reason: collision with root package name */
    public float f9147u = 5.0f;

    /* renamed from: v  reason: collision with root package name */
    public float f9148v = 3.0f;

    /* renamed from: w  reason: collision with root package name */
    public float f9149w = 0.95f;

    /* renamed from: x  reason: collision with root package name */
    public float f9150x = 0.0f;

    /* renamed from: y  reason: collision with root package name */
    public float f9151y = 0.0f;

    /* renamed from: z  reason: collision with root package name */
    public float f9152z = 0.0f;

    public static /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        public static final /* synthetic */ int[] f9153a;

        /* JADX WARNING: Can't wrap try/catch for region: R(6:0|1|2|3|4|6) */
        /* JADX WARNING: Code restructure failed: missing block: B:7:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        static {
            /*
                q2.e$e[] r0 = q2.e.C0125e.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f9153a = r0
                q2.e$e r1 = q2.e.C0125e.VERTICAL     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = f9153a     // Catch:{ NoSuchFieldError -> 0x001d }
                q2.e$e r1 = q2.e.C0125e.HORIZONTAL     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: q2.e.a.<clinit>():void");
        }
    }

    public enum b {
        LEFT_TO_RIGHT,
        RIGHT_TO_LEFT
    }

    public enum c {
        NONE,
        EMPTY,
        DEFAULT,
        SQUARE,
        CIRCLE,
        LINE
    }

    public enum d {
        LEFT,
        CENTER,
        RIGHT
    }

    /* renamed from: q2.e$e  reason: collision with other inner class name */
    public enum C0125e {
        HORIZONTAL,
        VERTICAL
    }

    public enum f {
        TOP,
        CENTER,
        BOTTOM
    }

    public e() {
        this.f9128e = g.e(10.0f);
        this.f9125b = g.e(5.0f);
        this.f9126c = g.e(3.0f);
    }

    public float A(Paint paint) {
        float e10 = g.e(this.f9147u);
        float f10 = 0.0f;
        float f11 = 0.0f;
        for (f fVar : this.f9133g) {
            float e11 = g.e(Float.isNaN(fVar.f9177c) ? this.f9142p : fVar.f9177c);
            if (e11 > f11) {
                f11 = e11;
            }
            String str = fVar.f9175a;
            if (str != null) {
                float d10 = (float) g.d(paint, str);
                if (d10 > f10) {
                    f10 = d10;
                }
            }
        }
        return f10 + f11 + e10;
    }

    public C0125e B() {
        return this.f9138l;
    }

    public float C() {
        return this.f9148v;
    }

    public f D() {
        return this.f9137k;
    }

    public float E() {
        return this.f9145s;
    }

    public float F() {
        return this.f9146t;
    }

    public boolean G() {
        return this.f9139m;
    }

    public boolean H() {
        return this.f9135i;
    }

    public void I(List list) {
        this.f9133g = (f[]) list.toArray(new f[list.size()]);
    }

    public void l(Paint paint, h hVar) {
        float f10;
        float f11;
        float f12;
        Paint paint2 = paint;
        float e10 = g.e(this.f9142p);
        float e11 = g.e(this.f9148v);
        float e12 = g.e(this.f9147u);
        float e13 = g.e(this.f9145s);
        float e14 = g.e(this.f9146t);
        boolean z10 = this.B;
        f[] fVarArr = this.f9133g;
        int length = fVarArr.length;
        this.A = A(paint);
        this.f9152z = z(paint);
        int i10 = a.f9153a[this.f9138l.ordinal()];
        if (i10 == 1) {
            float f13 = e10;
            float f14 = e11;
            f[] fVarArr2 = fVarArr;
            float k10 = g.k(paint);
            float f15 = 0.0f;
            float f16 = 0.0f;
            float f17 = 0.0f;
            boolean z11 = false;
            for (int i11 = 0; i11 < length; i11++) {
                f fVar = fVarArr2[i11];
                boolean z12 = fVar.f9176b != c.NONE;
                float e15 = Float.isNaN(fVar.f9177c) ? f13 : g.e(fVar.f9177c);
                String str = fVar.f9175a;
                if (!z11) {
                    f17 = 0.0f;
                }
                if (z12) {
                    if (z11) {
                        f17 += f14;
                    }
                    f17 += e15;
                }
                if (str != null) {
                    if (z12 && !z11) {
                        f17 += e12;
                    } else if (z11) {
                        f15 = Math.max(f15, f17);
                        f16 += k10 + e14;
                        f17 = 0.0f;
                        z11 = false;
                    }
                    f17 += (float) g.d(paint2, str);
                    if (i11 < length - 1) {
                        f16 += k10 + e14;
                    }
                } else {
                    f17 += e15;
                    if (i11 < length - 1) {
                        f17 += f14;
                    }
                    z11 = true;
                }
                f15 = Math.max(f15, f17);
            }
            this.f9150x = f15;
            this.f9151y = f16;
        } else if (i10 == 2) {
            float k11 = g.k(paint);
            float m10 = g.m(paint) + e14;
            float k12 = hVar.k() * this.f9149w;
            this.D.clear();
            this.C.clear();
            this.E.clear();
            int i12 = 0;
            float f18 = 0.0f;
            int i13 = -1;
            float f19 = 0.0f;
            float f20 = 0.0f;
            while (i12 < length) {
                f fVar2 = fVarArr[i12];
                float f21 = e10;
                float f22 = e13;
                boolean z13 = fVar2.f9176b != c.NONE;
                float e16 = Float.isNaN(fVar2.f9177c) ? f21 : g.e(fVar2.f9177c);
                String str2 = fVar2.f9175a;
                f[] fVarArr3 = fVarArr;
                float f23 = m10;
                this.D.add(Boolean.FALSE);
                float f24 = i13 == -1 ? 0.0f : f19 + e11;
                if (str2 != null) {
                    f10 = e11;
                    this.C.add(g.b(paint2, str2));
                    f11 = f24 + (z13 ? e12 + e16 : 0.0f) + ((z2.b) this.C.get(i12)).f11364c;
                } else {
                    f10 = e11;
                    float f25 = e16;
                    this.C.add(z2.b.b(0.0f, 0.0f));
                    f11 = f24 + (z13 ? f25 : 0.0f);
                    if (i13 == -1) {
                        i13 = i12;
                    }
                }
                if (str2 != null || i12 == length - 1) {
                    float f26 = f20;
                    int i14 = (f26 > 0.0f ? 1 : (f26 == 0.0f ? 0 : -1));
                    float f27 = i14 == 0 ? 0.0f : f22;
                    if (!z10 || i14 == 0 || k12 - f26 >= f27 + f11) {
                        f12 = f26 + f27 + f11;
                    } else {
                        this.E.add(z2.b.b(f26, k11));
                        float max = Math.max(f18, f26);
                        this.D.set(i13 > -1 ? i13 : i12, Boolean.TRUE);
                        f18 = max;
                        f12 = f11;
                    }
                    if (i12 == length - 1) {
                        this.E.add(z2.b.b(f12, k11));
                        f18 = Math.max(f18, f12);
                    }
                    f20 = f12;
                }
                if (str2 != null) {
                    i13 = -1;
                }
                i12++;
                e11 = f10;
                e10 = f21;
                e13 = f22;
                m10 = f23;
                f19 = f11;
                fVarArr = fVarArr3;
            }
            float f28 = m10;
            this.f9150x = f18;
            this.f9151y = (k11 * ((float) this.E.size())) + (f28 * ((float) (this.E.size() == 0 ? 0 : this.E.size() - 1)));
        }
        this.f9151y += this.f9126c;
        this.f9150x += this.f9125b;
    }

    public List m() {
        return this.D;
    }

    public List n() {
        return this.C;
    }

    public List o() {
        return this.E;
    }

    public b p() {
        return this.f9140n;
    }

    public f[] q() {
        return this.f9133g;
    }

    public f[] r() {
        return this.f9134h;
    }

    public c s() {
        return this.f9141o;
    }

    public DashPathEffect t() {
        return this.f9144r;
    }

    public float u() {
        return this.f9143q;
    }

    public float v() {
        return this.f9142p;
    }

    public float w() {
        return this.f9147u;
    }

    public d x() {
        return this.f9136j;
    }

    public float y() {
        return this.f9149w;
    }

    public float z(Paint paint) {
        float f10 = 0.0f;
        for (f fVar : this.f9133g) {
            String str = fVar.f9175a;
            if (str != null) {
                float a10 = (float) g.a(paint, str);
                if (a10 > f10) {
                    f10 = a10;
                }
            }
        }
        return f10;
    }
}
