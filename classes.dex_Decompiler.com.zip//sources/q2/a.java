package q2;

import android.graphics.DashPathEffect;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;
import s2.e;
import z2.g;

public abstract class a extends b {
    public boolean A = false;
    public boolean B = true;
    public float C = 0.0f;
    public float D = 0.0f;
    public boolean E = false;
    public boolean F = false;
    public float G = 0.0f;
    public float H = 0.0f;
    public float I = 0.0f;

    /* renamed from: g  reason: collision with root package name */
    public e f9104g;

    /* renamed from: h  reason: collision with root package name */
    public int f9105h = -7829368;

    /* renamed from: i  reason: collision with root package name */
    public float f9106i = 1.0f;

    /* renamed from: j  reason: collision with root package name */
    public int f9107j = -7829368;

    /* renamed from: k  reason: collision with root package name */
    public float f9108k = 1.0f;

    /* renamed from: l  reason: collision with root package name */
    public float[] f9109l = new float[0];

    /* renamed from: m  reason: collision with root package name */
    public float[] f9110m = new float[0];

    /* renamed from: n  reason: collision with root package name */
    public int f9111n;

    /* renamed from: o  reason: collision with root package name */
    public int f9112o;

    /* renamed from: p  reason: collision with root package name */
    public int f9113p = 6;

    /* renamed from: q  reason: collision with root package name */
    public float f9114q = 1.0f;

    /* renamed from: r  reason: collision with root package name */
    public boolean f9115r = false;

    /* renamed from: s  reason: collision with root package name */
    public boolean f9116s = false;

    /* renamed from: t  reason: collision with root package name */
    public boolean f9117t = true;

    /* renamed from: u  reason: collision with root package name */
    public boolean f9118u = true;

    /* renamed from: v  reason: collision with root package name */
    public boolean f9119v = true;

    /* renamed from: w  reason: collision with root package name */
    public boolean f9120w = false;

    /* renamed from: x  reason: collision with root package name */
    public DashPathEffect f9121x = null;

    /* renamed from: y  reason: collision with root package name */
    public DashPathEffect f9122y = null;

    /* renamed from: z  reason: collision with root package name */
    public List f9123z;

    public a() {
        this.f9128e = g.e(10.0f);
        this.f9125b = g.e(5.0f);
        this.f9126c = g.e(5.0f);
        this.f9123z = new ArrayList();
    }

    public boolean A() {
        return this.f9118u;
    }

    public boolean B() {
        return this.B;
    }

    public boolean C() {
        return this.f9117t;
    }

    public boolean D() {
        return this.f9119v;
    }

    public boolean E() {
        return this.A;
    }

    public boolean F() {
        return this.f9116s;
    }

    public boolean G() {
        return this.f9115r;
    }

    public void H() {
        this.f9123z.clear();
    }

    public void I(int i10) {
        this.f9107j = i10;
    }

    public void J(float f10) {
        this.f9108k = g.e(f10);
    }

    public void K(float f10) {
        this.F = true;
        this.G = f10;
        this.I = Math.abs(f10 - this.H);
    }

    public void L(float f10) {
        this.E = true;
        this.H = f10;
        this.I = Math.abs(this.G - f10);
    }

    public void M(boolean z10) {
        this.f9118u = z10;
    }

    public void N(boolean z10) {
        this.f9117t = z10;
    }

    public void O(boolean z10) {
        this.f9119v = z10;
    }

    public void P(boolean z10) {
        this.A = z10;
    }

    public void Q(int i10) {
        this.f9105h = i10;
    }

    public void R(float f10) {
        this.f9106i = g.e(f10);
    }

    public void S(int i10) {
        if (i10 > 25) {
            i10 = 25;
        }
        if (i10 < 2) {
            i10 = 2;
        }
        this.f9113p = i10;
        this.f9116s = false;
    }

    public void T(int i10, boolean z10) {
        S(i10);
        this.f9116s = z10;
    }

    public void U(float f10) {
        this.D = f10;
    }

    public void V(float f10) {
        this.C = f10;
    }

    public void W(e eVar) {
        if (eVar == null) {
            this.f9104g = new s2.a(this.f9112o);
        } else {
            this.f9104g = eVar;
        }
    }

    public void l(g gVar) {
        this.f9123z.add(gVar);
        if (this.f9123z.size() > 6) {
            Log.e("MPAndroiChart", "Warning! You have more than 6 LimitLines on your axis, do you really want that?");
        }
    }

    public void m(float f10, float f11) {
        float f12 = this.E ? this.H : f10 - this.C;
        float f13 = this.F ? this.G : f11 + this.D;
        if (Math.abs(f13 - f12) == 0.0f) {
            f13 += 1.0f;
            f12 -= 1.0f;
        }
        this.H = f12;
        this.G = f13;
        this.I = Math.abs(f13 - f12);
    }

    public int n() {
        return this.f9107j;
    }

    public DashPathEffect o() {
        return this.f9121x;
    }

    public float p() {
        return this.f9108k;
    }

    public String q(int i10) {
        return (i10 < 0 || i10 >= this.f9109l.length) ? "" : y().a(this.f9109l[i10], this);
    }

    public float r() {
        return this.f9114q;
    }

    public int s() {
        return this.f9105h;
    }

    public DashPathEffect t() {
        return this.f9122y;
    }

    public float u() {
        return this.f9106i;
    }

    public int v() {
        return this.f9113p;
    }

    public List w() {
        return this.f9123z;
    }

    public String x() {
        String str = "";
        for (int i10 = 0; i10 < this.f9109l.length; i10++) {
            String q10 = q(i10);
            if (q10 != null && str.length() < q10.length()) {
                str = q10;
            }
        }
        return str;
    }

    public e y() {
        e eVar = this.f9104g;
        if (eVar == null || ((eVar instanceof s2.a) && ((s2.a) eVar).f() != this.f9112o)) {
            this.f9104g = new s2.a(this.f9112o);
        }
        return this.f9104g;
    }

    public boolean z() {
        return this.f9120w && this.f9111n > 0;
    }
}
