package q2;

import android.graphics.DashPathEffect;
import q2.e;

public class f {

    /* renamed from: a  reason: collision with root package name */
    public String f9175a;

    /* renamed from: b  reason: collision with root package name */
    public e.c f9176b;

    /* renamed from: c  reason: collision with root package name */
    public float f9177c;

    /* renamed from: d  reason: collision with root package name */
    public float f9178d;

    /* renamed from: e  reason: collision with root package name */
    public DashPathEffect f9179e;

    /* renamed from: f  reason: collision with root package name */
    public int f9180f;

    public f(String str, e.c cVar, float f10, float f11, DashPathEffect dashPathEffect, int i10) {
        e.c cVar2 = e.c.NONE;
        this.f9175a = str;
        this.f9176b = cVar;
        this.f9177c = f10;
        this.f9178d = f11;
        this.f9179e = dashPathEffect;
        this.f9180f = i10;
    }
}
