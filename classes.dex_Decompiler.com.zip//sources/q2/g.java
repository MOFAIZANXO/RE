package q2;

import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;

public class g extends b {

    /* renamed from: g  reason: collision with root package name */
    public float f9181g = 0.0f;

    /* renamed from: h  reason: collision with root package name */
    public float f9182h = 2.0f;

    /* renamed from: i  reason: collision with root package name */
    public int f9183i = Color.rgb(237, 91, 91);

    /* renamed from: j  reason: collision with root package name */
    public Paint.Style f9184j = Paint.Style.FILL_AND_STROKE;

    /* renamed from: k  reason: collision with root package name */
    public String f9185k = "";

    /* renamed from: l  reason: collision with root package name */
    public DashPathEffect f9186l = null;

    /* renamed from: m  reason: collision with root package name */
    public a f9187m = a.RIGHT_TOP;

    public enum a {
        LEFT_TOP,
        LEFT_BOTTOM,
        RIGHT_TOP,
        RIGHT_BOTTOM
    }

    public g(float f10, String str) {
        this.f9181g = f10;
        this.f9185k = str;
    }

    public void l(float f10, float f11, float f12) {
        this.f9186l = new DashPathEffect(new float[]{f10, f11}, f12);
    }

    public DashPathEffect m() {
        return this.f9186l;
    }

    public String n() {
        return this.f9185k;
    }

    public a o() {
        return this.f9187m;
    }

    public float p() {
        return this.f9181g;
    }

    public int q() {
        return this.f9183i;
    }

    public float r() {
        return this.f9182h;
    }

    public Paint.Style s() {
        return this.f9184j;
    }

    public void t(int i10) {
        this.f9183i = i10;
    }

    public void u(float f10) {
        if (f10 < 0.2f) {
            f10 = 0.2f;
        }
        if (f10 > 12.0f) {
            f10 = 12.0f;
        }
        this.f9182h = z2.g.e(f10);
    }
}
