package q2;

import android.graphics.Paint;
import z2.g;

public class j extends a {
    public boolean J = true;
    public boolean K = true;
    public boolean L = false;
    public boolean M = false;
    public boolean N = false;
    public boolean O = false;
    public int P = -7829368;
    public float Q = 1.0f;
    public float R = 10.0f;
    public float S = 10.0f;
    public b T = b.OUTSIDE_CHART;
    public a U;
    public float V = 0.0f;
    public float W = Float.POSITIVE_INFINITY;

    public enum a {
        LEFT,
        RIGHT
    }

    public enum b {
        OUTSIDE_CHART,
        INSIDE_CHART
    }

    public j(a aVar) {
        this.U = aVar;
        this.f9126c = 0.0f;
    }

    public a X() {
        return this.U;
    }

    public b Y() {
        return this.T;
    }

    public float Z() {
        return this.W;
    }

    public float a0() {
        return this.V;
    }

    public float b0(Paint paint) {
        paint.setTextSize(this.f9128e);
        float d10 = ((float) g.d(paint, x())) + (d() * 2.0f);
        float a02 = a0();
        float Z = Z();
        if (a02 > 0.0f) {
            a02 = g.e(a02);
        }
        if (Z > 0.0f && Z != Float.POSITIVE_INFINITY) {
            Z = g.e(Z);
        }
        if (((double) Z) <= 0.0d) {
            Z = d10;
        }
        return Math.max(a02, Math.min(d10, Z));
    }

    public float c0() {
        return this.S;
    }

    public float d0() {
        return this.R;
    }

    public int e0() {
        return this.P;
    }

    public float f0() {
        return this.Q;
    }

    public boolean g0() {
        return this.J;
    }

    public boolean h0() {
        return this.K;
    }

    public boolean i0() {
        return this.M;
    }

    public boolean j0() {
        return this.L;
    }

    public boolean k0() {
        return f() && D() && Y() == b.OUTSIDE_CHART;
    }

    public void m(float f10, float f11) {
        if (Math.abs(f11 - f10) == 0.0f) {
            f11 += 1.0f;
            f10 -= 1.0f;
        }
        float abs = Math.abs(f11 - f10);
        this.H = this.E ? this.H : f10 - ((abs / 100.0f) * c0());
        float d02 = this.F ? this.G : f11 + ((abs / 100.0f) * d0());
        this.G = d02;
        this.I = Math.abs(this.H - d02);
    }
}
