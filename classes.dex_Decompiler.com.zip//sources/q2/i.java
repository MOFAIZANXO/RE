package q2;

import z2.g;

public class i extends a {
    public int J = 1;
    public int K = 1;
    public int L = 1;
    public int M = 1;
    public float N = 0.0f;
    public boolean O = false;
    public a P = a.TOP;

    public enum a {
        TOP,
        BOTTOM,
        BOTH_SIDED,
        TOP_INSIDE,
        BOTTOM_INSIDE
    }

    public i() {
        this.f9126c = g.e(4.0f);
    }

    public float X() {
        return this.N;
    }

    public a Y() {
        return this.P;
    }

    public boolean Z() {
        return this.O;
    }

    public void a0(a aVar) {
        this.P = aVar;
    }
}
