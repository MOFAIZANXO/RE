package q2;

import android.graphics.Canvas;
import com.github.mikephil.charting.data.Entry;

public interface d {
    void a(Canvas canvas, float f10, float f11);

    void b(Entry entry, t2.d dVar);
}
