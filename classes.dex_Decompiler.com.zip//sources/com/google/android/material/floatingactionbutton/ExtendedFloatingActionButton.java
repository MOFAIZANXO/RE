package com.google.android.material.floatingactionbutton;

import a3.k;
import a3.l;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Property;
import android.view.View;
import android.view.ViewGroup;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.ViewCompat;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.button.MaterialButton;
import java.util.List;
import m.f;

public abstract class ExtendedFloatingActionButton extends MaterialButton implements CoordinatorLayout.b {

    /* renamed from: t  reason: collision with root package name */
    public static final int f4099t = k.Widget_MaterialComponents_ExtendedFloatingActionButton_Icon;

    /* renamed from: u  reason: collision with root package name */
    public static final Property f4100u;

    /* renamed from: v  reason: collision with root package name */
    public static final Property f4101v;

    /* renamed from: w  reason: collision with root package name */
    public static final Property f4102w;

    /* renamed from: x  reason: collision with root package name */
    public static final Property f4103x;

    public class a extends Property {
        public a(Class cls, String str) {
            super(cls, str);
        }

        /* renamed from: a */
        public Float get(View view) {
            return Float.valueOf((float) view.getLayoutParams().width);
        }

        /* renamed from: b */
        public void set(View view, Float f10) {
            view.getLayoutParams().width = f10.intValue();
            view.requestLayout();
        }
    }

    public class b extends Property {
        public b(Class cls, String str) {
            super(cls, str);
        }

        /* renamed from: a */
        public Float get(View view) {
            return Float.valueOf((float) view.getLayoutParams().height);
        }

        /* renamed from: b */
        public void set(View view, Float f10) {
            view.getLayoutParams().height = f10.intValue();
            view.requestLayout();
        }
    }

    public class c extends Property {
        public c(Class cls, String str) {
            super(cls, str);
        }

        /* renamed from: a */
        public Float get(View view) {
            return Float.valueOf((float) ViewCompat.getPaddingStart(view));
        }

        /* renamed from: b */
        public void set(View view, Float f10) {
            ViewCompat.setPaddingRelative(view, f10.intValue(), view.getPaddingTop(), ViewCompat.getPaddingEnd(view), view.getPaddingBottom());
        }
    }

    public class d extends Property {
        public d(Class cls, String str) {
            super(cls, str);
        }

        /* renamed from: a */
        public Float get(View view) {
            return Float.valueOf((float) ViewCompat.getPaddingEnd(view));
        }

        /* renamed from: b */
        public void set(View view, Float f10) {
            ViewCompat.setPaddingRelative(view, ViewCompat.getPaddingStart(view), view.getPaddingTop(), f10.intValue(), view.getPaddingBottom());
        }
    }

    public static abstract class e {
    }

    static {
        Class<Float> cls = Float.class;
        f4100u = new a(cls, "width");
        f4101v = new b(cls, "height");
        f4102w = new c(cls, "paddingStart");
        f4103x = new d(cls, "paddingEnd");
    }

    public static /* synthetic */ a l(ExtendedFloatingActionButton extendedFloatingActionButton) {
        throw null;
    }

    public static /* synthetic */ a m(ExtendedFloatingActionButton extendedFloatingActionButton) {
        throw null;
    }

    public static /* synthetic */ void n(ExtendedFloatingActionButton extendedFloatingActionButton, a aVar, e eVar) {
        throw null;
    }

    public static /* synthetic */ a o(ExtendedFloatingActionButton extendedFloatingActionButton) {
        throw null;
    }

    public static /* synthetic */ a p(ExtendedFloatingActionButton extendedFloatingActionButton) {
        throw null;
    }

    public static class ExtendedFloatingActionButtonBehavior<T extends ExtendedFloatingActionButton> extends CoordinatorLayout.c {

        /* renamed from: a  reason: collision with root package name */
        public Rect f4104a;

        /* renamed from: b  reason: collision with root package name */
        public boolean f4105b;

        /* renamed from: c  reason: collision with root package name */
        public boolean f4106c;

        public ExtendedFloatingActionButtonBehavior() {
            this.f4105b = false;
            this.f4106c = true;
        }

        public static boolean H(View view) {
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            if (layoutParams instanceof CoordinatorLayout.f) {
                return ((CoordinatorLayout.f) layoutParams).e() instanceof BottomSheetBehavior;
            }
            return false;
        }

        public void F(ExtendedFloatingActionButton extendedFloatingActionButton) {
            if (this.f4106c) {
                ExtendedFloatingActionButton.o(extendedFloatingActionButton);
            } else {
                ExtendedFloatingActionButton.p(extendedFloatingActionButton);
            }
            ExtendedFloatingActionButton.n(extendedFloatingActionButton, (a) null, (e) null);
        }

        public boolean G(CoordinatorLayout coordinatorLayout, ExtendedFloatingActionButton extendedFloatingActionButton, Rect rect) {
            return super.c(coordinatorLayout, extendedFloatingActionButton, rect);
        }

        public boolean I(CoordinatorLayout coordinatorLayout, ExtendedFloatingActionButton extendedFloatingActionButton, View view) {
            if (view instanceof AppBarLayout) {
                M(coordinatorLayout, (AppBarLayout) view, extendedFloatingActionButton);
                return false;
            } else if (!H(view)) {
                return false;
            } else {
                N(view, extendedFloatingActionButton);
                return false;
            }
        }

        public boolean J(CoordinatorLayout coordinatorLayout, ExtendedFloatingActionButton extendedFloatingActionButton, int i10) {
            List m10 = coordinatorLayout.m(extendedFloatingActionButton);
            int size = m10.size();
            for (int i11 = 0; i11 < size; i11++) {
                View view = (View) m10.get(i11);
                if (!(view instanceof AppBarLayout)) {
                    if (H(view) && N(view, extendedFloatingActionButton)) {
                        break;
                    }
                } else if (M(coordinatorLayout, (AppBarLayout) view, extendedFloatingActionButton)) {
                    break;
                }
            }
            coordinatorLayout.F(extendedFloatingActionButton, i10);
            return true;
        }

        public final boolean K(View view, ExtendedFloatingActionButton extendedFloatingActionButton) {
            throw null;
        }

        public void L(ExtendedFloatingActionButton extendedFloatingActionButton) {
            if (this.f4106c) {
                ExtendedFloatingActionButton.l(extendedFloatingActionButton);
            } else {
                ExtendedFloatingActionButton.m(extendedFloatingActionButton);
            }
            ExtendedFloatingActionButton.n(extendedFloatingActionButton, (a) null, (e) null);
        }

        public final boolean M(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, ExtendedFloatingActionButton extendedFloatingActionButton) {
            if (!K(appBarLayout, extendedFloatingActionButton)) {
                return false;
            }
            if (this.f4104a == null) {
                this.f4104a = new Rect();
            }
            Rect rect = this.f4104a;
            com.google.android.material.internal.c.a(coordinatorLayout, appBarLayout, rect);
            if (rect.bottom <= appBarLayout.getMinimumHeightForVisibleOverlappingContent()) {
                L(extendedFloatingActionButton);
                return true;
            }
            F(extendedFloatingActionButton);
            return true;
        }

        public final boolean N(View view, ExtendedFloatingActionButton extendedFloatingActionButton) {
            if (!K(view, extendedFloatingActionButton)) {
                return false;
            }
            throw null;
        }

        public /* bridge */ /* synthetic */ boolean c(CoordinatorLayout coordinatorLayout, View view, Rect rect) {
            f.a(view);
            return G(coordinatorLayout, (ExtendedFloatingActionButton) null, rect);
        }

        public void h(CoordinatorLayout.f fVar) {
            if (fVar.f556h == 0) {
                fVar.f556h = 80;
            }
        }

        public /* bridge */ /* synthetic */ boolean i(CoordinatorLayout coordinatorLayout, View view, View view2) {
            f.a(view);
            return I(coordinatorLayout, (ExtendedFloatingActionButton) null, view2);
        }

        public /* bridge */ /* synthetic */ boolean m(CoordinatorLayout coordinatorLayout, View view, int i10) {
            f.a(view);
            return J(coordinatorLayout, (ExtendedFloatingActionButton) null, i10);
        }

        public ExtendedFloatingActionButtonBehavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l.ExtendedFloatingActionButton_Behavior_Layout);
            this.f4105b = obtainStyledAttributes.getBoolean(l.ExtendedFloatingActionButton_Behavior_Layout_behavior_autoHide, false);
            this.f4106c = obtainStyledAttributes.getBoolean(l.ExtendedFloatingActionButton_Behavior_Layout_behavior_autoShrink, true);
            obtainStyledAttributes.recycle();
        }
    }
}
