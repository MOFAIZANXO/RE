package com.google.android.material.floatingactionbutton;

import a3.l;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.TintableBackgroundView;
import androidx.core.widget.TintableImageSourceView;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.internal.c;
import com.google.android.material.internal.r;
import java.util.List;
import k3.a;
import m.f;
import q3.o;

public abstract class FloatingActionButton extends r implements TintableBackgroundView, TintableImageSourceView, a, o, CoordinatorLayout.b {

    public static class Behavior extends BaseBehavior<FloatingActionButton> {
        public Behavior() {
        }

        public /* bridge */ /* synthetic */ boolean F(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, Rect rect) {
            return super.F(coordinatorLayout, floatingActionButton, rect);
        }

        public /* bridge */ /* synthetic */ boolean I(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, View view) {
            return super.I(coordinatorLayout, floatingActionButton, view);
        }

        public /* bridge */ /* synthetic */ boolean J(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, int i10) {
            return super.J(coordinatorLayout, floatingActionButton, i10);
        }

        public /* bridge */ /* synthetic */ void h(CoordinatorLayout.f fVar) {
            super.h(fVar);
        }

        public Behavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
        }
    }

    public static class BaseBehavior<T extends FloatingActionButton> extends CoordinatorLayout.c {

        /* renamed from: a  reason: collision with root package name */
        public Rect f4107a;

        /* renamed from: b  reason: collision with root package name */
        public boolean f4108b;

        public BaseBehavior() {
            this.f4108b = true;
        }

        public static boolean G(View view) {
            ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
            if (layoutParams instanceof CoordinatorLayout.f) {
                return ((CoordinatorLayout.f) layoutParams).e() instanceof BottomSheetBehavior;
            }
            return false;
        }

        public boolean F(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, Rect rect) {
            throw null;
        }

        public final void H(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton) {
            throw null;
        }

        public boolean I(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, View view) {
            if (view instanceof AppBarLayout) {
                L(coordinatorLayout, (AppBarLayout) view, floatingActionButton);
                return false;
            } else if (!G(view)) {
                return false;
            } else {
                M(view, floatingActionButton);
                return false;
            }
        }

        public boolean J(CoordinatorLayout coordinatorLayout, FloatingActionButton floatingActionButton, int i10) {
            List m10 = coordinatorLayout.m(floatingActionButton);
            int size = m10.size();
            for (int i11 = 0; i11 < size; i11++) {
                View view = (View) m10.get(i11);
                if (!(view instanceof AppBarLayout)) {
                    if (G(view) && M(view, floatingActionButton)) {
                        break;
                    }
                } else if (L(coordinatorLayout, (AppBarLayout) view, floatingActionButton)) {
                    break;
                }
            }
            coordinatorLayout.F(floatingActionButton, i10);
            H(coordinatorLayout, floatingActionButton);
            return true;
        }

        public final boolean K(View view, FloatingActionButton floatingActionButton) {
            throw null;
        }

        public final boolean L(CoordinatorLayout coordinatorLayout, AppBarLayout appBarLayout, FloatingActionButton floatingActionButton) {
            if (!K(appBarLayout, floatingActionButton)) {
                return false;
            }
            if (this.f4107a == null) {
                this.f4107a = new Rect();
            }
            Rect rect = this.f4107a;
            c.a(coordinatorLayout, appBarLayout, rect);
            if (rect.bottom <= appBarLayout.getMinimumHeightForVisibleOverlappingContent()) {
                throw null;
            }
            throw null;
        }

        public final boolean M(View view, FloatingActionButton floatingActionButton) {
            if (!K(view, floatingActionButton)) {
                return false;
            }
            throw null;
        }

        public /* bridge */ /* synthetic */ boolean c(CoordinatorLayout coordinatorLayout, View view, Rect rect) {
            f.a(view);
            return F(coordinatorLayout, (FloatingActionButton) null, rect);
        }

        public void h(CoordinatorLayout.f fVar) {
            if (fVar.f556h == 0) {
                fVar.f556h = 80;
            }
        }

        public /* bridge */ /* synthetic */ boolean i(CoordinatorLayout coordinatorLayout, View view, View view2) {
            f.a(view);
            return I(coordinatorLayout, (FloatingActionButton) null, view2);
        }

        public /* bridge */ /* synthetic */ boolean m(CoordinatorLayout coordinatorLayout, View view, int i10) {
            f.a(view);
            return J(coordinatorLayout, (FloatingActionButton) null, i10);
        }

        public BaseBehavior(Context context, AttributeSet attributeSet) {
            super(context, attributeSet);
            TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l.FloatingActionButton_Behavior_Layout);
            this.f4108b = obtainStyledAttributes.getBoolean(l.FloatingActionButton_Behavior_Layout_behavior_autoHide, true);
            obtainStyledAttributes.recycle();
        }
    }
}
