package com.airbnb.lottie;

import com.airbnb.lottie.d0;

public final /* synthetic */ class w implements d0.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ d0 f3475a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ int f3476b;

    public /* synthetic */ w(d0 d0Var, int i10) {
        this.f3475a = d0Var;
        this.f3476b = i10;
    }

    public final void a(h hVar) {
        this.f3475a.P(this.f3476b, hVar);
    }
}
