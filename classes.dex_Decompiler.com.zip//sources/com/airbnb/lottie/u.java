package com.airbnb.lottie;

import com.airbnb.lottie.d0;

public final /* synthetic */ class u implements d0.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ d0 f3471a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ int f3472b;

    public /* synthetic */ u(d0 d0Var, int i10) {
        this.f3471a = d0Var;
        this.f3472b = i10;
    }

    public final void a(h hVar) {
        this.f3471a.U(this.f3472b, hVar);
    }
}
