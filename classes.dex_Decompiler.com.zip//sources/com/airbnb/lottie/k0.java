package com.airbnb.lottie;

import android.os.Handler;
import android.os.Looper;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;
import m2.d;

public class k0 {

    /* renamed from: e  reason: collision with root package name */
    public static Executor f3433e = Executors.newCachedThreadPool();

    /* renamed from: a  reason: collision with root package name */
    public final Set f3434a;

    /* renamed from: b  reason: collision with root package name */
    public final Set f3435b;

    /* renamed from: c  reason: collision with root package name */
    public final Handler f3436c;

    /* renamed from: d  reason: collision with root package name */
    public volatile i0 f3437d;

    public class a extends FutureTask {
        public a(Callable callable) {
            super(callable);
        }

        public void done() {
            if (!isCancelled()) {
                try {
                    k0.this.k((i0) get());
                } catch (InterruptedException | ExecutionException e10) {
                    k0.this.k(new i0(e10));
                }
            }
        }
    }

    public k0(Callable callable) {
        this(callable, false);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void e() {
        i0 i0Var = this.f3437d;
        if (i0Var != null) {
            if (i0Var.b() != null) {
                h(i0Var.b());
            } else {
                f(i0Var.a());
            }
        }
    }

    public synchronized k0 c(f0 f0Var) {
        i0 i0Var = this.f3437d;
        if (!(i0Var == null || i0Var.a() == null)) {
            f0Var.onResult(i0Var.a());
        }
        this.f3435b.add(f0Var);
        return this;
    }

    public synchronized k0 d(f0 f0Var) {
        i0 i0Var = this.f3437d;
        if (!(i0Var == null || i0Var.b() == null)) {
            f0Var.onResult(i0Var.b());
        }
        this.f3434a.add(f0Var);
        return this;
    }

    public final synchronized void f(Throwable th) {
        ArrayList<f0> arrayList = new ArrayList<>(this.f3435b);
        if (arrayList.isEmpty()) {
            d.d("Lottie encountered an error but no failure listener was added:", th);
            return;
        }
        for (f0 onResult : arrayList) {
            onResult.onResult(th);
        }
    }

    public final void g() {
        this.f3436c.post(new j0(this));
    }

    public final synchronized void h(Object obj) {
        for (f0 onResult : new ArrayList(this.f3434a)) {
            onResult.onResult(obj);
        }
    }

    public synchronized k0 i(f0 f0Var) {
        this.f3435b.remove(f0Var);
        return this;
    }

    public synchronized k0 j(f0 f0Var) {
        this.f3434a.remove(f0Var);
        return this;
    }

    public final void k(i0 i0Var) {
        if (this.f3437d == null) {
            this.f3437d = i0Var;
            g();
            return;
        }
        throw new IllegalStateException("A task may only be set once.");
    }

    public k0(Callable callable, boolean z10) {
        this.f3434a = new LinkedHashSet(1);
        this.f3435b = new LinkedHashSet(1);
        this.f3436c = new Handler(Looper.getMainLooper());
        this.f3437d = null;
        if (z10) {
            try {
                k((i0) callable.call());
            } catch (Throwable th) {
                k(new i0(th));
            }
        } else {
            f3433e.execute(new a(callable));
        }
    }
}
