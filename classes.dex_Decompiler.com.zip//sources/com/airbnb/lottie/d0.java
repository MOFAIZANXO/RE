package com.airbnb.lottie;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.ImageView;
import f2.h;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import k2.v;
import m2.d;
import m2.e;
import m2.g;

public class d0 extends Drawable implements Drawable.Callback, Animatable {
    public Canvas A;
    public Rect B;
    public RectF C;
    public Paint D;
    public Rect E;
    public Rect F;
    public RectF G;
    public RectF H;
    public Matrix I;
    public Matrix J;
    public boolean K;

    /* renamed from: a  reason: collision with root package name */
    public h f3346a;

    /* renamed from: b  reason: collision with root package name */
    public final e f3347b;

    /* renamed from: f  reason: collision with root package name */
    public boolean f3348f = true;

    /* renamed from: g  reason: collision with root package name */
    public boolean f3349g = false;

    /* renamed from: h  reason: collision with root package name */
    public boolean f3350h = false;

    /* renamed from: i  reason: collision with root package name */
    public c f3351i = c.NONE;

    /* renamed from: j  reason: collision with root package name */
    public final ArrayList f3352j = new ArrayList();

    /* renamed from: k  reason: collision with root package name */
    public final ValueAnimator.AnimatorUpdateListener f3353k;

    /* renamed from: l  reason: collision with root package name */
    public e2.b f3354l;

    /* renamed from: m  reason: collision with root package name */
    public String f3355m;

    /* renamed from: n  reason: collision with root package name */
    public e2.a f3356n;

    /* renamed from: o  reason: collision with root package name */
    public boolean f3357o;

    /* renamed from: p  reason: collision with root package name */
    public boolean f3358p;

    /* renamed from: q  reason: collision with root package name */
    public boolean f3359q;

    /* renamed from: r  reason: collision with root package name */
    public i2.c f3360r;

    /* renamed from: s  reason: collision with root package name */
    public int f3361s;

    /* renamed from: t  reason: collision with root package name */
    public boolean f3362t;

    /* renamed from: u  reason: collision with root package name */
    public boolean f3363u;

    /* renamed from: v  reason: collision with root package name */
    public boolean f3364v;

    /* renamed from: w  reason: collision with root package name */
    public o0 f3365w;

    /* renamed from: x  reason: collision with root package name */
    public boolean f3366x;

    /* renamed from: y  reason: collision with root package name */
    public final Matrix f3367y;

    /* renamed from: z  reason: collision with root package name */
    public Bitmap f3368z;

    public class a implements ValueAnimator.AnimatorUpdateListener {
        public a() {
        }

        public void onAnimationUpdate(ValueAnimator valueAnimator) {
            if (d0.this.f3360r != null) {
                d0.this.f3360r.N(d0.this.f3347b.h());
            }
        }
    }

    public interface b {
        void a(h hVar);
    }

    public enum c {
        NONE,
        PLAY,
        RESUME
    }

    public d0() {
        e eVar = new e();
        this.f3347b = eVar;
        a aVar = new a();
        this.f3353k = aVar;
        this.f3358p = false;
        this.f3359q = true;
        this.f3361s = 255;
        this.f3365w = o0.AUTOMATIC;
        this.f3366x = false;
        this.f3367y = new Matrix();
        this.K = false;
        eVar.addUpdateListener(aVar);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void L(f2.e eVar, Object obj, n2.c cVar, h hVar) {
        q(eVar, obj, cVar);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void M(h hVar) {
        Z();
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void N(h hVar) {
        c0();
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void O(int i10, h hVar) {
        setFrame(i10);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void P(int i10, h hVar) {
        setMaxFrame(i10);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void Q(String str, h hVar) {
        setMaxFrame(str);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void R(float f10, h hVar) {
        setMaxProgress(f10);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void S(int i10, int i11, h hVar) {
        f0(i10, i11);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void T(String str, h hVar) {
        setMinAndMaxFrame(str);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void U(int i10, h hVar) {
        setMinFrame(i10);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void V(String str, h hVar) {
        setMinFrame(str);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void W(float f10, h hVar) {
        setMinProgress(f10);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void X(float f10, h hVar) {
        setProgress(f10);
    }

    private Context getContext() {
        Drawable.Callback callback = getCallback();
        if (callback != null && (callback instanceof View)) {
            return ((View) callback).getContext();
        }
        return null;
    }

    private e2.a getFontAssetManager() {
        if (getCallback() == null) {
            return null;
        }
        if (this.f3356n == null) {
            this.f3356n = new e2.a(getCallback(), (a) null);
        }
        return this.f3356n;
    }

    private e2.b getImageAssetManager() {
        if (getCallback() == null) {
            return null;
        }
        e2.b bVar = this.f3354l;
        if (bVar != null && !bVar.b(getContext())) {
            this.f3354l = null;
        }
        if (this.f3354l == null) {
            this.f3354l = new e2.b(getCallback(), this.f3355m, (b) null, this.f3346a.j());
        }
        return this.f3354l;
    }

    public boolean A() {
        return this.f3357o;
    }

    public void B() {
        this.f3352j.clear();
        this.f3347b.g();
        if (!isVisible()) {
            this.f3351i = c.NONE;
        }
    }

    public final void C(int i10, int i11) {
        Bitmap bitmap = this.f3368z;
        if (bitmap == null || bitmap.getWidth() < i10 || this.f3368z.getHeight() < i11) {
            Bitmap createBitmap = Bitmap.createBitmap(i10, i11, Bitmap.Config.ARGB_8888);
            this.f3368z = createBitmap;
            this.A.setBitmap(createBitmap);
            this.K = true;
        } else if (this.f3368z.getWidth() > i10 || this.f3368z.getHeight() > i11) {
            Bitmap createBitmap2 = Bitmap.createBitmap(this.f3368z, 0, 0, i10, i11);
            this.f3368z = createBitmap2;
            this.A.setBitmap(createBitmap2);
            this.K = true;
        }
    }

    public final void D() {
        if (this.A == null) {
            this.A = new Canvas();
            this.H = new RectF();
            this.I = new Matrix();
            this.J = new Matrix();
            this.B = new Rect();
            this.C = new RectF();
            this.D = new b2.a();
            this.E = new Rect();
            this.F = new Rect();
            this.G = new RectF();
        }
    }

    public Bitmap E(String str) {
        e2.b imageAssetManager = getImageAssetManager();
        if (imageAssetManager != null) {
            return imageAssetManager.a(str);
        }
        return null;
    }

    public e0 F(String str) {
        h hVar = this.f3346a;
        if (hVar == null) {
            return null;
        }
        return (e0) hVar.j().get(str);
    }

    public Typeface G(String str, String str2) {
        e2.a fontAssetManager = getFontAssetManager();
        if (fontAssetManager != null) {
            return fontAssetManager.b(str, str2);
        }
        return null;
    }

    public final boolean H() {
        Drawable.Callback callback = getCallback();
        if (!(callback instanceof View)) {
            return false;
        }
        ViewParent parent = ((View) callback).getParent();
        if (parent instanceof ViewGroup) {
            return !((ViewGroup) parent).getClipChildren();
        }
        return false;
    }

    public boolean I() {
        e eVar = this.f3347b;
        if (eVar == null) {
            return false;
        }
        return eVar.isRunning();
    }

    public boolean J() {
        if (isVisible()) {
            return this.f3347b.isRunning();
        }
        c cVar = this.f3351i;
        return cVar == c.PLAY || cVar == c.RESUME;
    }

    public boolean K() {
        return this.f3364v;
    }

    public void Y() {
        this.f3352j.clear();
        this.f3347b.o();
        if (!isVisible()) {
            this.f3351i = c.NONE;
        }
    }

    public void Z() {
        if (this.f3360r == null) {
            this.f3352j.add(new c0(this));
            return;
        }
        v();
        if (r() || getRepeatCount() == 0) {
            if (isVisible()) {
                this.f3347b.p();
                this.f3351i = c.NONE;
            } else {
                this.f3351i = c.PLAY;
            }
        }
        if (!r()) {
            setFrame((int) (getSpeed() < 0.0f ? getMinFrame() : getMaxFrame()));
            this.f3347b.g();
            if (!isVisible()) {
                this.f3351i = c.NONE;
            }
        }
    }

    public final void a0(Canvas canvas, i2.c cVar) {
        if (this.f3346a != null && cVar != null) {
            D();
            canvas.getMatrix(this.I);
            canvas.getClipBounds(this.B);
            w(this.B, this.C);
            this.I.mapRect(this.C);
            x(this.C, this.B);
            if (this.f3359q) {
                this.H.set(0.0f, 0.0f, (float) getIntrinsicWidth(), (float) getIntrinsicHeight());
            } else {
                cVar.a(this.H, (Matrix) null, false);
            }
            this.I.mapRect(this.H);
            Rect bounds = getBounds();
            float width = ((float) bounds.width()) / ((float) getIntrinsicWidth());
            float height = ((float) bounds.height()) / ((float) getIntrinsicHeight());
            d0(this.H, width, height);
            if (!H()) {
                RectF rectF = this.H;
                Rect rect = this.B;
                rectF.intersect((float) rect.left, (float) rect.top, (float) rect.right, (float) rect.bottom);
            }
            int ceil = (int) Math.ceil((double) this.H.width());
            int ceil2 = (int) Math.ceil((double) this.H.height());
            if (ceil != 0 && ceil2 != 0) {
                C(ceil, ceil2);
                if (this.K) {
                    this.f3367y.set(this.I);
                    this.f3367y.preScale(width, height);
                    Matrix matrix = this.f3367y;
                    RectF rectF2 = this.H;
                    matrix.postTranslate(-rectF2.left, -rectF2.top);
                    this.f3368z.eraseColor(0);
                    cVar.f(this.A, this.f3367y, this.f3361s);
                    this.I.invert(this.J);
                    this.J.mapRect(this.G, this.H);
                    x(this.G, this.F);
                }
                this.E.set(0, 0, ceil, ceil2);
                canvas.drawBitmap(this.f3368z, this.E, this.F, this.D);
            }
        }
    }

    public List b0(f2.e eVar) {
        if (this.f3360r == null) {
            d.c("Cannot resolve KeyPath. Composition is not set yet.");
            return Collections.emptyList();
        }
        ArrayList arrayList = new ArrayList();
        this.f3360r.i(eVar, 0, arrayList, new f2.e(new String[0]));
        return arrayList;
    }

    public void c0() {
        if (this.f3360r == null) {
            this.f3352j.add(new x(this));
            return;
        }
        v();
        if (r() || getRepeatCount() == 0) {
            if (isVisible()) {
                this.f3347b.t();
                this.f3351i = c.NONE;
            } else {
                this.f3351i = c.RESUME;
            }
        }
        if (!r()) {
            setFrame((int) (getSpeed() < 0.0f ? getMinFrame() : getMaxFrame()));
            this.f3347b.g();
            if (!isVisible()) {
                this.f3351i = c.NONE;
            }
        }
    }

    public final void d0(RectF rectF, float f10, float f11) {
        rectF.set(rectF.left * f10, rectF.top * f11, rectF.right * f10, rectF.bottom * f11);
    }

    public void draw(Canvas canvas) {
        c.a("Drawable#draw");
        if (this.f3350h) {
            try {
                if (this.f3366x) {
                    a0(canvas, this.f3360r);
                } else {
                    y(canvas);
                }
            } catch (Throwable th) {
                d.b("Lottie crashed in draw!", th);
            }
        } else if (this.f3366x) {
            a0(canvas, this.f3360r);
        } else {
            y(canvas);
        }
        this.K = false;
        c.b("Drawable#draw");
    }

    public boolean e0(h hVar) {
        if (this.f3346a == hVar) {
            return false;
        }
        this.K = true;
        u();
        this.f3346a = hVar;
        s();
        this.f3347b.v(hVar);
        setProgress(this.f3347b.getAnimatedFraction());
        Iterator it = new ArrayList(this.f3352j).iterator();
        while (it.hasNext()) {
            b bVar = (b) it.next();
            if (bVar != null) {
                bVar.a(hVar);
            }
            it.remove();
        }
        this.f3352j.clear();
        hVar.v(this.f3362t);
        v();
        Drawable.Callback callback = getCallback();
        if (callback instanceof ImageView) {
            ImageView imageView = (ImageView) callback;
            imageView.setImageDrawable((Drawable) null);
            imageView.setImageDrawable(this);
        }
        return true;
    }

    public void f0(int i10, int i11) {
        if (this.f3346a == null) {
            this.f3352j.add(new t(this, i10, i11));
        } else {
            this.f3347b.y((float) i10, ((float) i11) + 0.99f);
        }
    }

    public boolean g0() {
        return this.f3346a.c().j() > 0;
    }

    public int getAlpha() {
        return this.f3361s;
    }

    public boolean getClipToCompositionBounds() {
        return this.f3359q;
    }

    public h getComposition() {
        return this.f3346a;
    }

    public int getFrame() {
        return (int) this.f3347b.i();
    }

    public String getImageAssetsFolder() {
        return this.f3355m;
    }

    public int getIntrinsicHeight() {
        h hVar = this.f3346a;
        if (hVar == null) {
            return -1;
        }
        return hVar.b().height();
    }

    public int getIntrinsicWidth() {
        h hVar = this.f3346a;
        if (hVar == null) {
            return -1;
        }
        return hVar.b().width();
    }

    public boolean getMaintainOriginalImageBounds() {
        return this.f3358p;
    }

    public float getMaxFrame() {
        return this.f3347b.k();
    }

    public float getMinFrame() {
        return this.f3347b.l();
    }

    public int getOpacity() {
        return -3;
    }

    public l0 getPerformanceTracker() {
        h hVar = this.f3346a;
        if (hVar != null) {
            return hVar.n();
        }
        return null;
    }

    public float getProgress() {
        return this.f3347b.h();
    }

    public o0 getRenderMode() {
        return this.f3366x ? o0.SOFTWARE : o0.HARDWARE;
    }

    public int getRepeatCount() {
        return this.f3347b.getRepeatCount();
    }

    @SuppressLint({"WrongConstant"})
    public int getRepeatMode() {
        return this.f3347b.getRepeatMode();
    }

    public float getSpeed() {
        return this.f3347b.m();
    }

    public q0 getTextDelegate() {
        return null;
    }

    public void invalidateDrawable(Drawable drawable) {
        Drawable.Callback callback = getCallback();
        if (callback != null) {
            callback.invalidateDrawable(this);
        }
    }

    public void invalidateSelf() {
        if (!this.K) {
            this.K = true;
            Drawable.Callback callback = getCallback();
            if (callback != null) {
                callback.invalidateDrawable(this);
            }
        }
    }

    public boolean isRunning() {
        return I();
    }

    public void p(Animator.AnimatorListener animatorListener) {
        this.f3347b.addListener(animatorListener);
    }

    public void q(f2.e eVar, Object obj, n2.c cVar) {
        i2.c cVar2 = this.f3360r;
        if (cVar2 == null) {
            this.f3352j.add(new a0(this, eVar, obj, cVar));
            return;
        }
        boolean z10 = true;
        if (eVar == f2.e.f6109c) {
            cVar2.h(obj, cVar);
        } else if (eVar.d() != null) {
            eVar.d().h(obj, cVar);
        } else {
            List b02 = b0(eVar);
            for (int i10 = 0; i10 < b02.size(); i10++) {
                ((f2.e) b02.get(i10)).d().h(obj, cVar);
            }
            z10 = true ^ b02.isEmpty();
        }
        if (z10) {
            invalidateSelf();
            if (obj == h0.E) {
                setProgress(getProgress());
            }
        }
    }

    public final boolean r() {
        return this.f3348f || this.f3349g;
    }

    public final void s() {
        h hVar = this.f3346a;
        if (hVar != null) {
            i2.c cVar = new i2.c(this, v.a(hVar), hVar.k(), hVar);
            this.f3360r = cVar;
            if (this.f3363u) {
                cVar.L(true);
            }
            this.f3360r.Q(this.f3359q);
        }
    }

    public void scheduleDrawable(Drawable drawable, Runnable runnable, long j10) {
        Drawable.Callback callback = getCallback();
        if (callback != null) {
            callback.scheduleDrawable(this, runnable, j10);
        }
    }

    public void setAlpha(int i10) {
        this.f3361s = i10;
        invalidateSelf();
    }

    public void setApplyingOpacityToLayersEnabled(boolean z10) {
        this.f3364v = z10;
    }

    public void setClipToCompositionBounds(boolean z10) {
        if (z10 != this.f3359q) {
            this.f3359q = z10;
            i2.c cVar = this.f3360r;
            if (cVar != null) {
                cVar.Q(z10);
            }
            invalidateSelf();
        }
    }

    public void setColorFilter(ColorFilter colorFilter) {
        d.c("Use addColorFilter instead.");
    }

    public void setFontAssetDelegate(a aVar) {
        e2.a aVar2 = this.f3356n;
        if (aVar2 != null) {
            aVar2.c(aVar);
        }
    }

    public void setFrame(int i10) {
        if (this.f3346a == null) {
            this.f3352j.add(new r(this, i10));
        } else {
            this.f3347b.w((float) i10);
        }
    }

    public void setIgnoreDisabledSystemAnimations(boolean z10) {
        this.f3349g = z10;
    }

    public void setImageAssetDelegate(b bVar) {
        e2.b bVar2 = this.f3354l;
        if (bVar2 != null) {
            bVar2.d(bVar);
        }
    }

    public void setImagesAssetsFolder(String str) {
        this.f3355m = str;
    }

    public void setMaintainOriginalImageBounds(boolean z10) {
        this.f3358p = z10;
    }

    public void setMaxFrame(int i10) {
        if (this.f3346a == null) {
            this.f3352j.add(new w(this, i10));
        } else {
            this.f3347b.x(((float) i10) + 0.99f);
        }
    }

    public void setMaxProgress(float f10) {
        h hVar = this.f3346a;
        if (hVar == null) {
            this.f3352j.add(new b0(this, f10));
        } else {
            this.f3347b.x(g.i(hVar.p(), this.f3346a.f(), f10));
        }
    }

    public void setMinAndMaxFrame(String str) {
        h hVar = this.f3346a;
        if (hVar == null) {
            this.f3352j.add(new s(this, str));
            return;
        }
        h l10 = hVar.l(str);
        if (l10 != null) {
            int i10 = (int) l10.f6115b;
            f0(i10, ((int) l10.f6116c) + i10);
            return;
        }
        throw new IllegalArgumentException("Cannot find marker with name " + str + ".");
    }

    public void setMinFrame(int i10) {
        if (this.f3346a == null) {
            this.f3352j.add(new u(this, i10));
        } else {
            this.f3347b.z(i10);
        }
    }

    public void setMinProgress(float f10) {
        h hVar = this.f3346a;
        if (hVar == null) {
            this.f3352j.add(new v(this, f10));
        } else {
            setMinFrame((int) g.i(hVar.p(), this.f3346a.f(), f10));
        }
    }

    public void setOutlineMasksAndMattes(boolean z10) {
        if (this.f3363u != z10) {
            this.f3363u = z10;
            i2.c cVar = this.f3360r;
            if (cVar != null) {
                cVar.L(z10);
            }
        }
    }

    public void setPerformanceTrackingEnabled(boolean z10) {
        this.f3362t = z10;
        h hVar = this.f3346a;
        if (hVar != null) {
            hVar.v(z10);
        }
    }

    public void setProgress(float f10) {
        if (this.f3346a == null) {
            this.f3352j.add(new q(this, f10));
            return;
        }
        c.a("Drawable#setProgress");
        this.f3347b.w(this.f3346a.h(f10));
        c.b("Drawable#setProgress");
    }

    public void setRenderMode(o0 o0Var) {
        this.f3365w = o0Var;
        v();
    }

    public void setRepeatCount(int i10) {
        this.f3347b.setRepeatCount(i10);
    }

    public void setRepeatMode(int i10) {
        this.f3347b.setRepeatMode(i10);
    }

    public void setSafeMode(boolean z10) {
        this.f3350h = z10;
    }

    public void setSpeed(float f10) {
        this.f3347b.A(f10);
    }

    public void setSystemAnimationsAreEnabled(Boolean bool) {
        this.f3348f = bool.booleanValue();
    }

    public void setTextDelegate(q0 q0Var) {
    }

    public boolean setVisible(boolean z10, boolean z11) {
        boolean z12 = !isVisible();
        boolean visible = super.setVisible(z10, z11);
        if (z10) {
            c cVar = this.f3351i;
            if (cVar == c.PLAY) {
                Z();
            } else if (cVar == c.RESUME) {
                c0();
            }
        } else if (this.f3347b.isRunning()) {
            Y();
            this.f3351i = c.RESUME;
        } else if (!z12) {
            this.f3351i = c.NONE;
        }
        return visible;
    }

    public void start() {
        Drawable.Callback callback = getCallback();
        if (!(callback instanceof View) || !((View) callback).isInEditMode()) {
            Z();
        }
    }

    public void stop() {
        B();
    }

    public void t() {
        this.f3352j.clear();
        this.f3347b.cancel();
        if (!isVisible()) {
            this.f3351i = c.NONE;
        }
    }

    public void u() {
        if (this.f3347b.isRunning()) {
            this.f3347b.cancel();
            if (!isVisible()) {
                this.f3351i = c.NONE;
            }
        }
        this.f3346a = null;
        this.f3360r = null;
        this.f3354l = null;
        this.f3347b.f();
        invalidateSelf();
    }

    public void unscheduleDrawable(Drawable drawable, Runnable runnable) {
        Drawable.Callback callback = getCallback();
        if (callback != null) {
            callback.unscheduleDrawable(this, runnable);
        }
    }

    public final void v() {
        h hVar = this.f3346a;
        if (hVar != null) {
            this.f3366x = this.f3365w.a(Build.VERSION.SDK_INT, hVar.q(), hVar.m());
        }
    }

    public final void w(Rect rect, RectF rectF) {
        rectF.set((float) rect.left, (float) rect.top, (float) rect.right, (float) rect.bottom);
    }

    public final void x(RectF rectF, Rect rect) {
        rect.set((int) Math.floor((double) rectF.left), (int) Math.floor((double) rectF.top), (int) Math.ceil((double) rectF.right), (int) Math.ceil((double) rectF.bottom));
    }

    public final void y(Canvas canvas) {
        i2.c cVar = this.f3360r;
        h hVar = this.f3346a;
        if (cVar != null && hVar != null) {
            this.f3367y.reset();
            Rect bounds = getBounds();
            if (!bounds.isEmpty()) {
                float height = ((float) bounds.height()) / ((float) hVar.b().height());
                this.f3367y.preScale(((float) bounds.width()) / ((float) hVar.b().width()), height);
            }
            cVar.f(canvas, this.f3367y, this.f3361s);
        }
    }

    public void z(boolean z10) {
        if (this.f3357o != z10) {
            this.f3357o = z10;
            if (this.f3346a != null) {
                s();
            }
        }
    }

    public void setMaxFrame(String str) {
        h hVar = this.f3346a;
        if (hVar == null) {
            this.f3352j.add(new y(this, str));
            return;
        }
        h l10 = hVar.l(str);
        if (l10 != null) {
            setMaxFrame((int) (l10.f6115b + l10.f6116c));
            return;
        }
        throw new IllegalArgumentException("Cannot find marker with name " + str + ".");
    }

    public void setMinFrame(String str) {
        h hVar = this.f3346a;
        if (hVar == null) {
            this.f3352j.add(new z(this, str));
            return;
        }
        h l10 = hVar.l(str);
        if (l10 != null) {
            setMinFrame((int) l10.f6115b);
            return;
        }
        throw new IllegalArgumentException("Cannot find marker with name " + str + ".");
    }
}
