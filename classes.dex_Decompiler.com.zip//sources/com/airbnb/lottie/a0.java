package com.airbnb.lottie;

import com.airbnb.lottie.d0;
import f2.e;
import n2.c;

public final /* synthetic */ class a0 implements d0.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ d0 f3326a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ e f3327b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ Object f3328c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ c f3329d;

    public /* synthetic */ a0(d0 d0Var, e eVar, Object obj, c cVar) {
        this.f3326a = d0Var;
        this.f3327b = eVar;
        this.f3328c = obj;
        this.f3329d = cVar;
    }

    public final void a(h hVar) {
        this.f3326a.L(this.f3327b, this.f3328c, this.f3329d, hVar);
    }
}
