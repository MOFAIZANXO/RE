package com.airbnb.lottie;

import android.content.Context;
import java.util.concurrent.Callable;

public final /* synthetic */ class n implements Callable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ Context f3448a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ String f3449b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ String f3450c;

    public /* synthetic */ n(Context context, String str, String str2) {
        this.f3448a = context;
        this.f3449b = str;
        this.f3450c = str2;
    }

    public final Object call() {
        return p.m(this.f3448a, this.f3449b, this.f3450c);
    }
}
