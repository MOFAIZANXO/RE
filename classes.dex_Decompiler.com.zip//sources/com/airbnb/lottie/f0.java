package com.airbnb.lottie;

public interface f0 {
    void onResult(Object obj);
}
