package com.airbnb.lottie;

import java.util.concurrent.Callable;

public final /* synthetic */ class g implements Callable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ LottieAnimationView f3381a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ String f3382b;

    public /* synthetic */ g(LottieAnimationView lottieAnimationView, String str) {
        this.f3381a = lottieAnimationView;
        this.f3382b = str;
    }

    public final Object call() {
        return this.f3381a.r(this.f3382b);
    }
}
