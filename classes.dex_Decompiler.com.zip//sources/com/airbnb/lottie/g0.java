package com.airbnb.lottie;

public interface g0 {
    void a(String str, Throwable th);

    void b(String str);

    void c(String str, Throwable th);

    void d(String str);
}
