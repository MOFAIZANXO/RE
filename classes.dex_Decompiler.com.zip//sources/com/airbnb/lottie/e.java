package com.airbnb.lottie;

public final /* synthetic */ class e implements f0 {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ LottieAnimationView f3374a;

    public /* synthetic */ e(LottieAnimationView lottieAnimationView) {
        this.f3374a = lottieAnimationView;
    }

    public final void onResult(Object obj) {
        this.f3374a.setComposition((h) obj);
    }
}
