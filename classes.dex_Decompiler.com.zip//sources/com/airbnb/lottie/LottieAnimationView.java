package com.airbnb.lottie;

import android.animation.Animator;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.appcompat.widget.AppCompatImageView;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import m.f;
import m2.d;
import m2.h;
import n2.e;

public class LottieAnimationView extends AppCompatImageView {

    /* renamed from: r  reason: collision with root package name */
    public static final String f3293r = "LottieAnimationView";

    /* renamed from: s  reason: collision with root package name */
    public static final f0 f3294s = new f();

    /* renamed from: a  reason: collision with root package name */
    public final f0 f3295a = new e(this);

    /* renamed from: b  reason: collision with root package name */
    public final f0 f3296b = new a();

    /* renamed from: f  reason: collision with root package name */
    public f0 f3297f;

    /* renamed from: g  reason: collision with root package name */
    public int f3298g = 0;

    /* renamed from: h  reason: collision with root package name */
    public final d0 f3299h = new d0();

    /* renamed from: i  reason: collision with root package name */
    public String f3300i;

    /* renamed from: j  reason: collision with root package name */
    public int f3301j;

    /* renamed from: k  reason: collision with root package name */
    public boolean f3302k = false;

    /* renamed from: l  reason: collision with root package name */
    public boolean f3303l = false;

    /* renamed from: m  reason: collision with root package name */
    public boolean f3304m = true;

    /* renamed from: n  reason: collision with root package name */
    public final Set f3305n = new HashSet();

    /* renamed from: o  reason: collision with root package name */
    public final Set f3306o = new HashSet();

    /* renamed from: p  reason: collision with root package name */
    public k0 f3307p;

    /* renamed from: q  reason: collision with root package name */
    public h f3308q;

    public static class SavedState extends View.BaseSavedState {
        public static final Parcelable.Creator<SavedState> CREATOR = new a();

        /* renamed from: a  reason: collision with root package name */
        public String f3309a;

        /* renamed from: b  reason: collision with root package name */
        public int f3310b;

        /* renamed from: f  reason: collision with root package name */
        public float f3311f;

        /* renamed from: g  reason: collision with root package name */
        public boolean f3312g;

        /* renamed from: h  reason: collision with root package name */
        public String f3313h;

        /* renamed from: i  reason: collision with root package name */
        public int f3314i;

        /* renamed from: j  reason: collision with root package name */
        public int f3315j;

        public class a implements Parcelable.Creator {
            /* renamed from: a */
            public SavedState createFromParcel(Parcel parcel) {
                return new SavedState(parcel, (a) null);
            }

            /* renamed from: b */
            public SavedState[] newArray(int i10) {
                return new SavedState[i10];
            }
        }

        public /* synthetic */ SavedState(Parcel parcel, a aVar) {
            this(parcel);
        }

        public void writeToParcel(Parcel parcel, int i10) {
            super.writeToParcel(parcel, i10);
            parcel.writeString(this.f3309a);
            parcel.writeFloat(this.f3311f);
            parcel.writeInt(this.f3312g ? 1 : 0);
            parcel.writeString(this.f3313h);
            parcel.writeInt(this.f3314i);
            parcel.writeInt(this.f3315j);
        }

        public SavedState(Parcelable parcelable) {
            super(parcelable);
        }

        public SavedState(Parcel parcel) {
            super(parcel);
            this.f3309a = parcel.readString();
            this.f3311f = parcel.readFloat();
            this.f3312g = parcel.readInt() != 1 ? false : true;
            this.f3313h = parcel.readString();
            this.f3314i = parcel.readInt();
            this.f3315j = parcel.readInt();
        }
    }

    public class a implements f0 {
        public a() {
        }

        /* renamed from: a */
        public void onResult(Throwable th) {
            if (LottieAnimationView.this.f3298g != 0) {
                LottieAnimationView lottieAnimationView = LottieAnimationView.this;
                lottieAnimationView.setImageResource(lottieAnimationView.f3298g);
            }
            (LottieAnimationView.this.f3297f == null ? LottieAnimationView.f3294s : LottieAnimationView.this.f3297f).onResult(th);
        }
    }

    public class b extends n2.c {

        /* renamed from: d  reason: collision with root package name */
        public final /* synthetic */ e f3317d;

        public b(e eVar) {
            this.f3317d = eVar;
        }

        public Object a(n2.b bVar) {
            return this.f3317d.a(bVar);
        }
    }

    public enum c {
        SET_ANIMATION,
        SET_PROGRESS,
        SET_REPEAT_MODE,
        SET_REPEAT_COUNT,
        SET_IMAGE_ASSETS,
        PLAY_OPTION
    }

    public LottieAnimationView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        p(attributeSet, m0.lottieAnimationViewStyle);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ i0 r(String str) {
        return this.f3304m ? p.l(getContext(), str) : p.m(getContext(), str, (String) null);
    }

    /* access modifiers changed from: private */
    public /* synthetic */ i0 s(int i10) {
        return this.f3304m ? p.u(getContext(), i10) : p.v(getContext(), i10, (String) null);
    }

    private void setCompositionTask(k0 k0Var) {
        this.f3305n.add(c.SET_ANIMATION);
        l();
        k();
        this.f3307p = k0Var.d(this.f3295a).c(this.f3296b);
    }

    public static /* synthetic */ void t(Throwable th) {
        if (h.k(th)) {
            d.d("Unable to load composition.", th);
            return;
        }
        throw new IllegalStateException("Unable to parse composition", th);
    }

    public void g(Animator.AnimatorListener animatorListener) {
        this.f3299h.p(animatorListener);
    }

    public boolean getClipToCompositionBounds() {
        return this.f3299h.getClipToCompositionBounds();
    }

    public h getComposition() {
        return this.f3308q;
    }

    public long getDuration() {
        h hVar = this.f3308q;
        if (hVar != null) {
            return (long) hVar.d();
        }
        return 0;
    }

    public int getFrame() {
        return this.f3299h.getFrame();
    }

    public String getImageAssetsFolder() {
        return this.f3299h.getImageAssetsFolder();
    }

    public boolean getMaintainOriginalImageBounds() {
        return this.f3299h.getMaintainOriginalImageBounds();
    }

    public float getMaxFrame() {
        return this.f3299h.getMaxFrame();
    }

    public float getMinFrame() {
        return this.f3299h.getMinFrame();
    }

    public l0 getPerformanceTracker() {
        return this.f3299h.getPerformanceTracker();
    }

    public float getProgress() {
        return this.f3299h.getProgress();
    }

    public o0 getRenderMode() {
        return this.f3299h.getRenderMode();
    }

    public int getRepeatCount() {
        return this.f3299h.getRepeatCount();
    }

    public int getRepeatMode() {
        return this.f3299h.getRepeatMode();
    }

    public float getSpeed() {
        return this.f3299h.getSpeed();
    }

    public void h(f2.e eVar, Object obj, n2.c cVar) {
        this.f3299h.q(eVar, obj, cVar);
    }

    public void i(f2.e eVar, Object obj, e eVar2) {
        this.f3299h.q(eVar, obj, new b(eVar2));
    }

    public void invalidate() {
        super.invalidate();
        Drawable drawable = getDrawable();
        if ((drawable instanceof d0) && ((d0) drawable).getRenderMode() == o0.SOFTWARE) {
            this.f3299h.invalidateSelf();
        }
    }

    public void invalidateDrawable(Drawable drawable) {
        Drawable drawable2 = getDrawable();
        d0 d0Var = this.f3299h;
        if (drawable2 == d0Var) {
            super.invalidateDrawable(d0Var);
        } else {
            super.invalidateDrawable(drawable);
        }
    }

    public void j() {
        this.f3305n.add(c.PLAY_OPTION);
        this.f3299h.t();
    }

    public final void k() {
        k0 k0Var = this.f3307p;
        if (k0Var != null) {
            k0Var.j(this.f3295a);
            this.f3307p.i(this.f3296b);
        }
    }

    public final void l() {
        this.f3308q = null;
        this.f3299h.u();
    }

    public void m(boolean z10) {
        this.f3299h.z(z10);
    }

    public final k0 n(String str) {
        return isInEditMode() ? new k0(new g(this, str), true) : this.f3304m ? p.j(getContext(), str) : p.k(getContext(), str, (String) null);
    }

    public final k0 o(int i10) {
        return isInEditMode() ? new k0(new d(this, i10), true) : this.f3304m ? p.s(getContext(), i10) : p.t(getContext(), i10, (String) null);
    }

    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (!isInEditMode() && this.f3303l) {
            this.f3299h.Z();
        }
    }

    public void onRestoreInstanceState(Parcelable parcelable) {
        int i10;
        if (!(parcelable instanceof SavedState)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        SavedState savedState = (SavedState) parcelable;
        super.onRestoreInstanceState(savedState.getSuperState());
        this.f3300i = savedState.f3309a;
        Set set = this.f3305n;
        c cVar = c.SET_ANIMATION;
        if (!set.contains(cVar) && !TextUtils.isEmpty(this.f3300i)) {
            setAnimation(this.f3300i);
        }
        this.f3301j = savedState.f3310b;
        if (!this.f3305n.contains(cVar) && (i10 = this.f3301j) != 0) {
            setAnimation(i10);
        }
        if (!this.f3305n.contains(c.SET_PROGRESS)) {
            setProgress(savedState.f3311f);
        }
        if (!this.f3305n.contains(c.PLAY_OPTION) && savedState.f3312g) {
            v();
        }
        if (!this.f3305n.contains(c.SET_IMAGE_ASSETS)) {
            setImageAssetsFolder(savedState.f3313h);
        }
        if (!this.f3305n.contains(c.SET_REPEAT_MODE)) {
            setRepeatMode(savedState.f3314i);
        }
        if (!this.f3305n.contains(c.SET_REPEAT_COUNT)) {
            setRepeatCount(savedState.f3315j);
        }
    }

    public Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        savedState.f3309a = this.f3300i;
        savedState.f3310b = this.f3301j;
        savedState.f3311f = this.f3299h.getProgress();
        savedState.f3312g = this.f3299h.J();
        savedState.f3313h = this.f3299h.getImageAssetsFolder();
        savedState.f3314i = this.f3299h.getRepeatMode();
        savedState.f3315j = this.f3299h.getRepeatCount();
        return savedState;
    }

    public final void p(AttributeSet attributeSet, int i10) {
        String string;
        boolean z10 = false;
        TypedArray obtainStyledAttributes = getContext().obtainStyledAttributes(attributeSet, n0.LottieAnimationView, i10, 0);
        this.f3304m = obtainStyledAttributes.getBoolean(n0.LottieAnimationView_lottie_cacheComposition, true);
        int i11 = n0.LottieAnimationView_lottie_rawRes;
        boolean hasValue = obtainStyledAttributes.hasValue(i11);
        int i12 = n0.LottieAnimationView_lottie_fileName;
        boolean hasValue2 = obtainStyledAttributes.hasValue(i12);
        int i13 = n0.LottieAnimationView_lottie_url;
        boolean hasValue3 = obtainStyledAttributes.hasValue(i13);
        if (!hasValue || !hasValue2) {
            if (hasValue) {
                int resourceId = obtainStyledAttributes.getResourceId(i11, 0);
                if (resourceId != 0) {
                    setAnimation(resourceId);
                }
            } else if (hasValue2) {
                String string2 = obtainStyledAttributes.getString(i12);
                if (string2 != null) {
                    setAnimation(string2);
                }
            } else if (hasValue3 && (string = obtainStyledAttributes.getString(i13)) != null) {
                setAnimationFromUrl(string);
            }
            setFallbackResource(obtainStyledAttributes.getResourceId(n0.LottieAnimationView_lottie_fallbackRes, 0));
            if (obtainStyledAttributes.getBoolean(n0.LottieAnimationView_lottie_autoPlay, false)) {
                this.f3303l = true;
            }
            if (obtainStyledAttributes.getBoolean(n0.LottieAnimationView_lottie_loop, false)) {
                this.f3299h.setRepeatCount(-1);
            }
            int i14 = n0.LottieAnimationView_lottie_repeatMode;
            if (obtainStyledAttributes.hasValue(i14)) {
                setRepeatMode(obtainStyledAttributes.getInt(i14, 1));
            }
            int i15 = n0.LottieAnimationView_lottie_repeatCount;
            if (obtainStyledAttributes.hasValue(i15)) {
                setRepeatCount(obtainStyledAttributes.getInt(i15, -1));
            }
            int i16 = n0.LottieAnimationView_lottie_speed;
            if (obtainStyledAttributes.hasValue(i16)) {
                setSpeed(obtainStyledAttributes.getFloat(i16, 1.0f));
            }
            int i17 = n0.LottieAnimationView_lottie_clipToCompositionBounds;
            if (obtainStyledAttributes.hasValue(i17)) {
                setClipToCompositionBounds(obtainStyledAttributes.getBoolean(i17, true));
            }
            setImageAssetsFolder(obtainStyledAttributes.getString(n0.LottieAnimationView_lottie_imageAssetsFolder));
            setProgress(obtainStyledAttributes.getFloat(n0.LottieAnimationView_lottie_progress, 0.0f));
            m(obtainStyledAttributes.getBoolean(n0.LottieAnimationView_lottie_enableMergePathsForKitKatAndAbove, false));
            int i18 = n0.LottieAnimationView_lottie_colorFilter;
            if (obtainStyledAttributes.hasValue(i18)) {
                h(new f2.e("**"), h0.K, new n2.c(new p0(AppCompatResources.getColorStateList(getContext(), obtainStyledAttributes.getResourceId(i18, -1)).getDefaultColor())));
            }
            int i19 = n0.LottieAnimationView_lottie_renderMode;
            if (obtainStyledAttributes.hasValue(i19)) {
                o0 o0Var = o0.AUTOMATIC;
                int i20 = obtainStyledAttributes.getInt(i19, o0Var.ordinal());
                if (i20 >= o0.values().length) {
                    i20 = o0Var.ordinal();
                }
                setRenderMode(o0.values()[i20]);
            }
            setIgnoreDisabledSystemAnimations(obtainStyledAttributes.getBoolean(n0.LottieAnimationView_lottie_ignoreDisabledSystemAnimations, false));
            obtainStyledAttributes.recycle();
            d0 d0Var = this.f3299h;
            if (h.f(getContext()) != 0.0f) {
                z10 = true;
            }
            d0Var.setSystemAnimationsAreEnabled(Boolean.valueOf(z10));
            return;
        }
        throw new IllegalArgumentException("lottie_rawRes and lottie_fileName cannot be used at the same time. Please use only one at once.");
    }

    public boolean q() {
        return this.f3299h.I();
    }

    public void setAnimation(int i10) {
        this.f3301j = i10;
        this.f3300i = null;
        setCompositionTask(o(i10));
    }

    @Deprecated
    public void setAnimationFromJson(String str) {
        x(str, (String) null);
    }

    public void setAnimationFromUrl(String str) {
        setCompositionTask(this.f3304m ? p.w(getContext(), str) : p.x(getContext(), str, (String) null));
    }

    public void setApplyingOpacityToLayersEnabled(boolean z10) {
        this.f3299h.setApplyingOpacityToLayersEnabled(z10);
    }

    public void setCacheComposition(boolean z10) {
        this.f3304m = z10;
    }

    public void setClipToCompositionBounds(boolean z10) {
        this.f3299h.setClipToCompositionBounds(z10);
    }

    public void setComposition(h hVar) {
        if (c.f3332a) {
            String str = f3293r;
            Log.v(str, "Set Composition \n" + hVar);
        }
        this.f3299h.setCallback(this);
        this.f3308q = hVar;
        this.f3302k = true;
        boolean e02 = this.f3299h.e0(hVar);
        this.f3302k = false;
        if (getDrawable() != this.f3299h || e02) {
            if (!e02) {
                y();
            }
            onVisibilityChanged(this, getVisibility());
            requestLayout();
            Iterator it = this.f3306o.iterator();
            if (it.hasNext()) {
                f.a(it.next());
                throw null;
            }
        }
    }

    public void setFailureListener(f0 f0Var) {
        this.f3297f = f0Var;
    }

    public void setFallbackResource(int i10) {
        this.f3298g = i10;
    }

    public void setFontAssetDelegate(a aVar) {
        this.f3299h.setFontAssetDelegate(aVar);
    }

    public void setFrame(int i10) {
        this.f3299h.setFrame(i10);
    }

    public void setIgnoreDisabledSystemAnimations(boolean z10) {
        this.f3299h.setIgnoreDisabledSystemAnimations(z10);
    }

    public void setImageAssetDelegate(b bVar) {
        this.f3299h.setImageAssetDelegate(bVar);
    }

    public void setImageAssetsFolder(String str) {
        this.f3299h.setImagesAssetsFolder(str);
    }

    public void setImageBitmap(Bitmap bitmap) {
        k();
        super.setImageBitmap(bitmap);
    }

    public void setImageDrawable(Drawable drawable) {
        k();
        super.setImageDrawable(drawable);
    }

    public void setImageResource(int i10) {
        k();
        super.setImageResource(i10);
    }

    public void setMaintainOriginalImageBounds(boolean z10) {
        this.f3299h.setMaintainOriginalImageBounds(z10);
    }

    public void setMaxFrame(int i10) {
        this.f3299h.setMaxFrame(i10);
    }

    public void setMaxProgress(float f10) {
        this.f3299h.setMaxProgress(f10);
    }

    public void setMinAndMaxFrame(String str) {
        this.f3299h.setMinAndMaxFrame(str);
    }

    public void setMinFrame(int i10) {
        this.f3299h.setMinFrame(i10);
    }

    public void setMinProgress(float f10) {
        this.f3299h.setMinProgress(f10);
    }

    public void setOutlineMasksAndMattes(boolean z10) {
        this.f3299h.setOutlineMasksAndMattes(z10);
    }

    public void setPerformanceTrackingEnabled(boolean z10) {
        this.f3299h.setPerformanceTrackingEnabled(z10);
    }

    public void setProgress(float f10) {
        this.f3305n.add(c.SET_PROGRESS);
        this.f3299h.setProgress(f10);
    }

    public void setRenderMode(o0 o0Var) {
        this.f3299h.setRenderMode(o0Var);
    }

    public void setRepeatCount(int i10) {
        this.f3305n.add(c.SET_REPEAT_COUNT);
        this.f3299h.setRepeatCount(i10);
    }

    public void setRepeatMode(int i10) {
        this.f3305n.add(c.SET_REPEAT_MODE);
        this.f3299h.setRepeatMode(i10);
    }

    public void setSafeMode(boolean z10) {
        this.f3299h.setSafeMode(z10);
    }

    public void setSpeed(float f10) {
        this.f3299h.setSpeed(f10);
    }

    public void setTextDelegate(q0 q0Var) {
        this.f3299h.setTextDelegate(q0Var);
    }

    public void u() {
        this.f3303l = false;
        this.f3299h.Y();
    }

    public void unscheduleDrawable(Drawable drawable) {
        d0 d0Var;
        if (!this.f3302k && drawable == (d0Var = this.f3299h) && d0Var.I()) {
            u();
        } else if (!this.f3302k && (drawable instanceof d0)) {
            d0 d0Var2 = (d0) drawable;
            if (d0Var2.I()) {
                d0Var2.Y();
            }
        }
        super.unscheduleDrawable(drawable);
    }

    public void v() {
        this.f3305n.add(c.PLAY_OPTION);
        this.f3299h.Z();
    }

    public void w(InputStream inputStream, String str) {
        setCompositionTask(p.n(inputStream, str));
    }

    public void x(String str, String str2) {
        w(new ByteArrayInputStream(str.getBytes()), str2);
    }

    public final void y() {
        boolean q10 = q();
        setImageDrawable((Drawable) null);
        setImageDrawable(this.f3299h);
        if (q10) {
            this.f3299h.c0();
        }
    }

    public void setMaxFrame(String str) {
        this.f3299h.setMaxFrame(str);
    }

    public void setMinFrame(String str) {
        this.f3299h.setMinFrame(str);
    }

    public void setAnimation(String str) {
        this.f3300i = str;
        this.f3301j = 0;
        setCompositionTask(n(str));
    }
}
