package com.airbnb.lottie;

import com.airbnb.lottie.d0;

public final /* synthetic */ class x implements d0.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ d0 f3477a;

    public /* synthetic */ x(d0 d0Var) {
        this.f3477a = d0Var;
    }

    public final void a(h hVar) {
        this.f3477a.N(hVar);
    }
}
