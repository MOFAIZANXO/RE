package com.airbnb.lottie;

import com.airbnb.lottie.d0;

public final /* synthetic */ class t implements d0.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ d0 f3468a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ int f3469b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ int f3470c;

    public /* synthetic */ t(d0 d0Var, int i10, int i11) {
        this.f3468a = d0Var;
        this.f3469b = i10;
        this.f3470c = i11;
    }

    public final void a(h hVar) {
        this.f3468a.S(this.f3469b, this.f3470c, hVar);
    }
}
