package com.airbnb.lottie;

import java.util.concurrent.Callable;

public final /* synthetic */ class k implements Callable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ h f3432a;

    public /* synthetic */ k(h hVar) {
        this.f3432a = hVar;
    }

    public final Object call() {
        return p.D(this.f3432a);
    }
}
