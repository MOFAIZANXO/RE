package com.airbnb.lottie;

import java.util.concurrent.atomic.AtomicBoolean;

public final /* synthetic */ class l implements f0 {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ String f3439a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ AtomicBoolean f3440b;

    public /* synthetic */ l(String str, AtomicBoolean atomicBoolean) {
        this.f3439a = str;
        this.f3440b = atomicBoolean;
    }

    public final void onResult(Object obj) {
        p.E(this.f3439a, this.f3440b, (h) obj);
    }
}
