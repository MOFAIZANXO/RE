package com.airbnb.lottie;

import android.content.Context;
import androidx.core.os.TraceCompat;
import j2.b;
import j2.e;
import j2.f;
import j2.g;
import j2.h;
import java.io.File;

public abstract class c {

    /* renamed from: a  reason: collision with root package name */
    public static boolean f3332a = false;

    /* renamed from: b  reason: collision with root package name */
    public static boolean f3333b = false;

    /* renamed from: c  reason: collision with root package name */
    public static String[] f3334c;

    /* renamed from: d  reason: collision with root package name */
    public static long[] f3335d;

    /* renamed from: e  reason: collision with root package name */
    public static int f3336e;

    /* renamed from: f  reason: collision with root package name */
    public static int f3337f;

    /* renamed from: g  reason: collision with root package name */
    public static f f3338g;

    /* renamed from: h  reason: collision with root package name */
    public static e f3339h;

    /* renamed from: i  reason: collision with root package name */
    public static volatile h f3340i;

    /* renamed from: j  reason: collision with root package name */
    public static volatile g f3341j;

    public class a implements e {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ Context f3342a;

        public a(Context context) {
            this.f3342a = context;
        }

        public File a() {
            return new File(this.f3342a.getCacheDir(), "lottie_network_cache");
        }
    }

    public static void a(String str) {
        if (f3333b) {
            int i10 = f3336e;
            if (i10 == 20) {
                f3337f++;
                return;
            }
            f3334c[i10] = str;
            f3335d[i10] = System.nanoTime();
            TraceCompat.beginSection(str);
            f3336e++;
        }
    }

    public static float b(String str) {
        int i10 = f3337f;
        if (i10 > 0) {
            f3337f = i10 - 1;
            return 0.0f;
        } else if (!f3333b) {
            return 0.0f;
        } else {
            int i11 = f3336e - 1;
            f3336e = i11;
            if (i11 == -1) {
                throw new IllegalStateException("Can't end trace section. There are none.");
            } else if (str.equals(f3334c[i11])) {
                TraceCompat.endSection();
                return ((float) (System.nanoTime() - f3335d[f3336e])) / 1000000.0f;
            } else {
                throw new IllegalStateException("Unbalanced trace call " + str + ". Expected " + f3334c[f3336e] + ".");
            }
        }
    }

    public static g c(Context context) {
        Context applicationContext = context.getApplicationContext();
        g gVar = f3341j;
        if (gVar == null) {
            synchronized (g.class) {
                gVar = f3341j;
                if (gVar == null) {
                    e eVar = f3339h;
                    if (eVar == null) {
                        eVar = new a(applicationContext);
                    }
                    gVar = new g(eVar);
                    f3341j = gVar;
                }
            }
        }
        return gVar;
    }

    public static h d(Context context) {
        h hVar = f3340i;
        if (hVar == null) {
            synchronized (h.class) {
                hVar = f3340i;
                if (hVar == null) {
                    g c10 = c(context);
                    f fVar = f3338g;
                    if (fVar == null) {
                        fVar = new b();
                    }
                    hVar = new h(c10, fVar);
                    f3340i = hVar;
                }
            }
        }
        return hVar;
    }
}
