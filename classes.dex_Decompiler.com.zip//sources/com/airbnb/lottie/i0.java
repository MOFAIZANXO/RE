package com.airbnb.lottie;

import java.util.Arrays;

public final class i0 {

    /* renamed from: a  reason: collision with root package name */
    public final Object f3427a;

    /* renamed from: b  reason: collision with root package name */
    public final Throwable f3428b;

    public i0(Object obj) {
        this.f3427a = obj;
        this.f3428b = null;
    }

    public Throwable a() {
        return this.f3428b;
    }

    public Object b() {
        return this.f3427a;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof i0)) {
            return false;
        }
        i0 i0Var = (i0) obj;
        if (b() != null && b().equals(i0Var.b())) {
            return true;
        }
        if (a() == null || i0Var.a() == null) {
            return false;
        }
        return a().toString().equals(a().toString());
    }

    public int hashCode() {
        return Arrays.hashCode(new Object[]{b(), a()});
    }

    public i0(Throwable th) {
        this.f3428b = th;
        this.f3427a = null;
    }
}
