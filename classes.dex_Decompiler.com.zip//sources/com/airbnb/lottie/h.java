package com.airbnb.lottie;

import android.graphics.Rect;
import h.e;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import m2.d;
import m2.g;

public class h {

    /* renamed from: a  reason: collision with root package name */
    public final l0 f3383a = new l0();

    /* renamed from: b  reason: collision with root package name */
    public final HashSet f3384b = new HashSet();

    /* renamed from: c  reason: collision with root package name */
    public Map f3385c;

    /* renamed from: d  reason: collision with root package name */
    public Map f3386d;

    /* renamed from: e  reason: collision with root package name */
    public Map f3387e;

    /* renamed from: f  reason: collision with root package name */
    public List f3388f;

    /* renamed from: g  reason: collision with root package name */
    public h.h f3389g;

    /* renamed from: h  reason: collision with root package name */
    public e f3390h;

    /* renamed from: i  reason: collision with root package name */
    public List f3391i;

    /* renamed from: j  reason: collision with root package name */
    public Rect f3392j;

    /* renamed from: k  reason: collision with root package name */
    public float f3393k;

    /* renamed from: l  reason: collision with root package name */
    public float f3394l;

    /* renamed from: m  reason: collision with root package name */
    public float f3395m;

    /* renamed from: n  reason: collision with root package name */
    public boolean f3396n;

    /* renamed from: o  reason: collision with root package name */
    public int f3397o = 0;

    public void a(String str) {
        d.c(str);
        this.f3384b.add(str);
    }

    public Rect b() {
        return this.f3392j;
    }

    public h.h c() {
        return this.f3389g;
    }

    public float d() {
        return (float) ((long) ((e() / this.f3395m) * 1000.0f));
    }

    public float e() {
        return this.f3394l - this.f3393k;
    }

    public float f() {
        return this.f3394l;
    }

    public Map g() {
        return this.f3387e;
    }

    public float h(float f10) {
        return g.i(this.f3393k, this.f3394l, f10);
    }

    public float i() {
        return this.f3395m;
    }

    public Map j() {
        return this.f3386d;
    }

    public List k() {
        return this.f3391i;
    }

    public f2.h l(String str) {
        int size = this.f3388f.size();
        for (int i10 = 0; i10 < size; i10++) {
            f2.h hVar = (f2.h) this.f3388f.get(i10);
            if (hVar.a(str)) {
                return hVar;
            }
        }
        return null;
    }

    public int m() {
        return this.f3397o;
    }

    public l0 n() {
        return this.f3383a;
    }

    public List o(String str) {
        return (List) this.f3385c.get(str);
    }

    public float p() {
        return this.f3393k;
    }

    public boolean q() {
        return this.f3396n;
    }

    public void r(int i10) {
        this.f3397o += i10;
    }

    public void s(Rect rect, float f10, float f11, float f12, List list, e eVar, Map map, Map map2, h.h hVar, Map map3, List list2) {
        this.f3392j = rect;
        this.f3393k = f10;
        this.f3394l = f11;
        this.f3395m = f12;
        this.f3391i = list;
        this.f3390h = eVar;
        this.f3385c = map;
        this.f3386d = map2;
        this.f3389g = hVar;
        this.f3387e = map3;
        this.f3388f = list2;
    }

    public i2.e t(long j10) {
        return (i2.e) this.f3390h.f(j10);
    }

    public String toString() {
        StringBuilder sb2 = new StringBuilder("LottieComposition:\n");
        for (i2.e y10 : this.f3391i) {
            sb2.append(y10.y("\t"));
        }
        return sb2.toString();
    }

    public void u(boolean z10) {
        this.f3396n = z10;
    }

    public void v(boolean z10) {
        this.f3383a.b(z10);
    }
}
