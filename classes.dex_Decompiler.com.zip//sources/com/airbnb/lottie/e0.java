package com.airbnb.lottie;

import android.graphics.Bitmap;

public class e0 {

    /* renamed from: a  reason: collision with root package name */
    public final int f3375a;

    /* renamed from: b  reason: collision with root package name */
    public final int f3376b;

    /* renamed from: c  reason: collision with root package name */
    public final String f3377c;

    /* renamed from: d  reason: collision with root package name */
    public final String f3378d;

    /* renamed from: e  reason: collision with root package name */
    public final String f3379e;

    /* renamed from: f  reason: collision with root package name */
    public Bitmap f3380f;

    public e0(int i10, int i11, String str, String str2, String str3) {
        this.f3375a = i10;
        this.f3376b = i11;
        this.f3377c = str;
        this.f3378d = str2;
        this.f3379e = str3;
    }

    public Bitmap a() {
        return this.f3380f;
    }

    public String b() {
        return this.f3378d;
    }

    public int c() {
        return this.f3376b;
    }

    public String d() {
        return this.f3377c;
    }

    public int e() {
        return this.f3375a;
    }

    public void f(Bitmap bitmap) {
        this.f3380f = bitmap;
    }
}
