package com.airbnb.lottie;

import java.util.concurrent.atomic.AtomicBoolean;

public final /* synthetic */ class m implements f0 {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ String f3446a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ AtomicBoolean f3447b;

    public /* synthetic */ m(String str, AtomicBoolean atomicBoolean) {
        this.f3446a = str;
        this.f3447b = atomicBoolean;
    }

    public final void onResult(Object obj) {
        p.C(this.f3446a, this.f3447b, (Throwable) obj);
    }
}
