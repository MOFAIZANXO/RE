package com.airbnb.lottie;

import java.util.concurrent.Callable;

public final /* synthetic */ class d implements Callable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ LottieAnimationView f3344a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ int f3345b;

    public /* synthetic */ d(LottieAnimationView lottieAnimationView, int i10) {
        this.f3344a = lottieAnimationView;
        this.f3345b = i10;
    }

    public final Object call() {
        return this.f3344a.s(this.f3345b);
    }
}
