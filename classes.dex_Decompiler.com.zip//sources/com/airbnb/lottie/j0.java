package com.airbnb.lottie;

public final /* synthetic */ class j0 implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ k0 f3431a;

    public /* synthetic */ j0(k0 k0Var) {
        this.f3431a = k0Var;
    }

    public final void run() {
        this.f3431a.e();
    }
}
