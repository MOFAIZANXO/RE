package com.airbnb.lottie;

import android.content.Context;
import android.content.res.Resources;
import f2.g;
import java.io.IOException;
import java.io.InputStream;
import java.lang.ref.WeakReference;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.zip.ZipInputStream;
import k2.w;
import m2.d;
import m2.h;
import oc.c;
import oc.e;

public abstract class p {

    /* renamed from: a  reason: collision with root package name */
    public static final Map f3460a = new HashMap();

    /* renamed from: b  reason: collision with root package name */
    public static final byte[] f3461b = {80, 75, 3, 4};

    public static boolean A(Context context) {
        return (context.getResources().getConfiguration().uiMode & 48) == 32;
    }

    public static Boolean B(c cVar) {
        try {
            c R = cVar.R();
            for (byte b10 : f3461b) {
                if (R.b0() != b10) {
                    return Boolean.FALSE;
                }
            }
            R.close();
            return Boolean.TRUE;
        } catch (NoSuchMethodError unused) {
            return Boolean.FALSE;
        } catch (Exception e10) {
            d.b("Failed to check zip file header", e10);
            return Boolean.FALSE;
        }
    }

    public static /* synthetic */ void C(String str, AtomicBoolean atomicBoolean, Throwable th) {
        f3460a.remove(str);
        atomicBoolean.set(true);
    }

    public static /* synthetic */ i0 D(h hVar) {
        return new i0((Object) hVar);
    }

    public static /* synthetic */ void E(String str, AtomicBoolean atomicBoolean, h hVar) {
        f3460a.remove(str);
        atomicBoolean.set(true);
    }

    public static /* synthetic */ i0 H(WeakReference weakReference, Context context, int i10, String str) {
        Context context2 = (Context) weakReference.get();
        if (context2 != null) {
            context = context2;
        }
        return v(context, i10, str);
    }

    public static /* synthetic */ i0 I(Context context, String str, String str2) {
        i0 c10 = c.d(context).c(str, str2);
        if (!(str2 == null || c10.b() == null)) {
            g.b().c(str2, (h) c10.b());
        }
        return c10;
    }

    public static String J(Context context, int i10) {
        StringBuilder sb2 = new StringBuilder();
        sb2.append("rawRes");
        sb2.append(A(context) ? "_night_" : "_day_");
        sb2.append(i10);
        return sb2.toString();
    }

    public static k0 h(String str, Callable callable) {
        h a10 = str == null ? null : g.b().a(str);
        if (a10 != null) {
            return new k0(new k(a10));
        }
        if (str != null) {
            Map map = f3460a;
            if (map.containsKey(str)) {
                return (k0) map.get(str);
            }
        }
        k0 k0Var = new k0(callable);
        if (str != null) {
            AtomicBoolean atomicBoolean = new AtomicBoolean(false);
            k0Var.d(new l(str, atomicBoolean));
            k0Var.c(new m(str, atomicBoolean));
            if (!atomicBoolean.get()) {
                f3460a.put(str, k0Var);
            }
        }
        return k0Var;
    }

    public static e0 i(h hVar, String str) {
        for (e0 e0Var : hVar.j().values()) {
            if (e0Var.b().equals(str)) {
                return e0Var;
            }
        }
        return null;
    }

    public static k0 j(Context context, String str) {
        return k(context, str, "asset_" + str);
    }

    public static k0 k(Context context, String str, String str2) {
        return h(str2, new n(context.getApplicationContext(), str, str2));
    }

    public static i0 l(Context context, String str) {
        return m(context, str, "asset_" + str);
    }

    public static i0 m(Context context, String str, String str2) {
        try {
            if (!str.endsWith(".zip")) {
                if (!str.endsWith(".lottie")) {
                    return o(context.getAssets().open(str), str2);
                }
            }
            return y(new ZipInputStream(context.getAssets().open(str)), str2);
        } catch (IOException e10) {
            return new i0((Throwable) e10);
        }
    }

    public static k0 n(InputStream inputStream, String str) {
        return h(str, new j(inputStream, str));
    }

    public static i0 o(InputStream inputStream, String str) {
        return p(inputStream, str, true);
    }

    public static i0 p(InputStream inputStream, String str, boolean z10) {
        try {
            return q(l2.c.C(e.a(e.c(inputStream))), str);
        } finally {
            if (z10) {
                h.c(inputStream);
            }
        }
    }

    public static i0 q(l2.c cVar, String str) {
        return r(cVar, str, true);
    }

    public static i0 r(l2.c cVar, String str, boolean z10) {
        try {
            h a10 = w.a(cVar);
            if (str != null) {
                g.b().c(str, a10);
            }
            i0 i0Var = new i0((Object) a10);
            if (z10) {
                h.c(cVar);
            }
            return i0Var;
        } catch (Exception e10) {
            i0 i0Var2 = new i0((Throwable) e10);
            if (z10) {
                h.c(cVar);
            }
            return i0Var2;
        } catch (Throwable th) {
            if (z10) {
                h.c(cVar);
            }
            throw th;
        }
    }

    public static k0 s(Context context, int i10) {
        return t(context, i10, J(context, i10));
    }

    public static k0 t(Context context, int i10, String str) {
        return h(str, new o(new WeakReference(context), context.getApplicationContext(), i10, str));
    }

    public static i0 u(Context context, int i10) {
        return v(context, i10, J(context, i10));
    }

    public static i0 v(Context context, int i10, String str) {
        try {
            c a10 = e.a(e.c(context.getResources().openRawResource(i10)));
            return B(a10).booleanValue() ? y(new ZipInputStream(a10.a0()), str) : o(a10.a0(), str);
        } catch (Resources.NotFoundException e10) {
            return new i0((Throwable) e10);
        }
    }

    public static k0 w(Context context, String str) {
        return x(context, str, "url_" + str);
    }

    public static k0 x(Context context, String str, String str2) {
        return h(str2, new i(context, str, str2));
    }

    public static i0 y(ZipInputStream zipInputStream, String str) {
        try {
            return z(zipInputStream, str);
        } finally {
            h.c(zipInputStream);
        }
    }

    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r1v27, resolved type: java.lang.Object} */
    /* JADX DEBUG: Multi-variable search result rejected for TypeSearchVarInfo{r3v4, resolved type: com.airbnb.lottie.h} */
    /* JADX WARNING: Multi-variable type inference failed */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static com.airbnb.lottie.i0 z(java.util.zip.ZipInputStream r7, java.lang.String r8) {
        /*
            java.util.HashMap r0 = new java.util.HashMap
            r0.<init>()
            java.util.zip.ZipEntry r1 = r7.getNextEntry()     // Catch:{ IOException -> 0x012d }
            r2 = 0
            r3 = r2
        L_0x000b:
            if (r1 == 0) goto L_0x008f
            java.lang.String r4 = r1.getName()     // Catch:{ IOException -> 0x012d }
            java.lang.String r5 = "__MACOSX"
            boolean r5 = r4.contains(r5)     // Catch:{ IOException -> 0x012d }
            if (r5 == 0) goto L_0x001d
            r7.closeEntry()     // Catch:{ IOException -> 0x012d }
            goto L_0x0089
        L_0x001d:
            java.lang.String r5 = r1.getName()     // Catch:{ IOException -> 0x012d }
            java.lang.String r6 = "manifest.json"
            boolean r5 = r5.equalsIgnoreCase(r6)     // Catch:{ IOException -> 0x012d }
            if (r5 == 0) goto L_0x002d
            r7.closeEntry()     // Catch:{ IOException -> 0x012d }
            goto L_0x0089
        L_0x002d:
            java.lang.String r1 = r1.getName()     // Catch:{ IOException -> 0x012d }
            java.lang.String r5 = ".json"
            boolean r1 = r1.contains(r5)     // Catch:{ IOException -> 0x012d }
            if (r1 == 0) goto L_0x0052
            oc.l r1 = oc.e.c(r7)     // Catch:{ IOException -> 0x012d }
            oc.c r1 = oc.e.a(r1)     // Catch:{ IOException -> 0x012d }
            l2.c r1 = l2.c.C(r1)     // Catch:{ IOException -> 0x012d }
            r3 = 0
            com.airbnb.lottie.i0 r1 = r(r1, r2, r3)     // Catch:{ IOException -> 0x012d }
            java.lang.Object r1 = r1.b()     // Catch:{ IOException -> 0x012d }
            r3 = r1
            com.airbnb.lottie.h r3 = (com.airbnb.lottie.h) r3     // Catch:{ IOException -> 0x012d }
            goto L_0x0089
        L_0x0052:
            java.lang.String r1 = ".png"
            boolean r1 = r4.contains(r1)     // Catch:{ IOException -> 0x012d }
            if (r1 != 0) goto L_0x0077
            java.lang.String r1 = ".webp"
            boolean r1 = r4.contains(r1)     // Catch:{ IOException -> 0x012d }
            if (r1 != 0) goto L_0x0077
            java.lang.String r1 = ".jpg"
            boolean r1 = r4.contains(r1)     // Catch:{ IOException -> 0x012d }
            if (r1 != 0) goto L_0x0077
            java.lang.String r1 = ".jpeg"
            boolean r1 = r4.contains(r1)     // Catch:{ IOException -> 0x012d }
            if (r1 == 0) goto L_0x0073
            goto L_0x0077
        L_0x0073:
            r7.closeEntry()     // Catch:{ IOException -> 0x012d }
            goto L_0x0089
        L_0x0077:
            java.lang.String r1 = "/"
            java.lang.String[] r1 = r4.split(r1)     // Catch:{ IOException -> 0x012d }
            int r4 = r1.length     // Catch:{ IOException -> 0x012d }
            int r4 = r4 + -1
            r1 = r1[r4]     // Catch:{ IOException -> 0x012d }
            android.graphics.Bitmap r4 = android.graphics.BitmapFactory.decodeStream(r7)     // Catch:{ IOException -> 0x012d }
            r0.put(r1, r4)     // Catch:{ IOException -> 0x012d }
        L_0x0089:
            java.util.zip.ZipEntry r1 = r7.getNextEntry()     // Catch:{ IOException -> 0x012d }
            goto L_0x000b
        L_0x008f:
            if (r3 != 0) goto L_0x009e
            com.airbnb.lottie.i0 r7 = new com.airbnb.lottie.i0
            java.lang.IllegalArgumentException r8 = new java.lang.IllegalArgumentException
            java.lang.String r0 = "Unable to parse composition"
            r8.<init>(r0)
            r7.<init>((java.lang.Throwable) r8)
            return r7
        L_0x009e:
            java.util.Set r7 = r0.entrySet()
            java.util.Iterator r7 = r7.iterator()
        L_0x00a6:
            boolean r0 = r7.hasNext()
            if (r0 == 0) goto L_0x00d4
            java.lang.Object r0 = r7.next()
            java.util.Map$Entry r0 = (java.util.Map.Entry) r0
            java.lang.Object r1 = r0.getKey()
            java.lang.String r1 = (java.lang.String) r1
            com.airbnb.lottie.e0 r1 = i(r3, r1)
            if (r1 == 0) goto L_0x00a6
            java.lang.Object r0 = r0.getValue()
            android.graphics.Bitmap r0 = (android.graphics.Bitmap) r0
            int r2 = r1.e()
            int r4 = r1.c()
            android.graphics.Bitmap r0 = m2.h.l(r0, r2, r4)
            r1.f(r0)
            goto L_0x00a6
        L_0x00d4:
            java.util.Map r7 = r3.j()
            java.util.Set r7 = r7.entrySet()
            java.util.Iterator r7 = r7.iterator()
        L_0x00e0:
            boolean r0 = r7.hasNext()
            if (r0 == 0) goto L_0x011e
            java.lang.Object r0 = r7.next()
            java.util.Map$Entry r0 = (java.util.Map.Entry) r0
            java.lang.Object r1 = r0.getValue()
            com.airbnb.lottie.e0 r1 = (com.airbnb.lottie.e0) r1
            android.graphics.Bitmap r1 = r1.a()
            if (r1 != 0) goto L_0x00e0
            com.airbnb.lottie.i0 r7 = new com.airbnb.lottie.i0
            java.lang.IllegalStateException r8 = new java.lang.IllegalStateException
            java.lang.StringBuilder r1 = new java.lang.StringBuilder
            r1.<init>()
            java.lang.String r2 = "There is no image for "
            r1.append(r2)
            java.lang.Object r0 = r0.getValue()
            com.airbnb.lottie.e0 r0 = (com.airbnb.lottie.e0) r0
            java.lang.String r0 = r0.b()
            r1.append(r0)
            java.lang.String r0 = r1.toString()
            r8.<init>(r0)
            r7.<init>((java.lang.Throwable) r8)
            return r7
        L_0x011e:
            if (r8 == 0) goto L_0x0127
            f2.g r7 = f2.g.b()
            r7.c(r8, r3)
        L_0x0127:
            com.airbnb.lottie.i0 r7 = new com.airbnb.lottie.i0
            r7.<init>((java.lang.Object) r3)
            return r7
        L_0x012d:
            r7 = move-exception
            com.airbnb.lottie.i0 r8 = new com.airbnb.lottie.i0
            r8.<init>((java.lang.Throwable) r7)
            return r8
        */
        throw new UnsupportedOperationException("Method not decompiled: com.airbnb.lottie.p.z(java.util.zip.ZipInputStream, java.lang.String):com.airbnb.lottie.i0");
    }
}
