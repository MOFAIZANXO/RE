package com.airbnb.lottie;

import android.content.Context;
import java.util.concurrent.Callable;

public final /* synthetic */ class i implements Callable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ Context f3424a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ String f3425b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ String f3426c;

    public /* synthetic */ i(Context context, String str, String str2) {
        this.f3424a = context;
        this.f3425b = str;
        this.f3426c = str2;
    }

    public final Object call() {
        return p.I(this.f3424a, this.f3425b, this.f3426c);
    }
}
