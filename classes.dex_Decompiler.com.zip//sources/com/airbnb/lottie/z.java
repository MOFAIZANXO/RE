package com.airbnb.lottie;

import com.airbnb.lottie.d0;

public final /* synthetic */ class z implements d0.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ d0 f3480a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ String f3481b;

    public /* synthetic */ z(d0 d0Var, String str) {
        this.f3480a = d0Var;
        this.f3481b = str;
    }

    public final void a(h hVar) {
        this.f3480a.V(this.f3481b, hVar);
    }
}
