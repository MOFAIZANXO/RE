package com.airbnb.lottie;

import android.content.Context;
import java.lang.ref.WeakReference;
import java.util.concurrent.Callable;

public final /* synthetic */ class o implements Callable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ WeakReference f3451a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ Context f3452b;

    /* renamed from: c  reason: collision with root package name */
    public final /* synthetic */ int f3453c;

    /* renamed from: d  reason: collision with root package name */
    public final /* synthetic */ String f3454d;

    public /* synthetic */ o(WeakReference weakReference, Context context, int i10, String str) {
        this.f3451a = weakReference;
        this.f3452b = context;
        this.f3453c = i10;
        this.f3454d = str;
    }

    public final Object call() {
        return p.H(this.f3451a, this.f3452b, this.f3453c, this.f3454d);
    }
}
