package com.airbnb.lottie;

import androidx.core.util.Pair;
import h.b;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import m2.f;

public class l0 {

    /* renamed from: a  reason: collision with root package name */
    public boolean f3441a = false;

    /* renamed from: b  reason: collision with root package name */
    public final Set f3442b = new b();

    /* renamed from: c  reason: collision with root package name */
    public final Map f3443c = new HashMap();

    /* renamed from: d  reason: collision with root package name */
    public final Comparator f3444d = new a();

    public class a implements Comparator {
        public a() {
        }

        /* renamed from: a */
        public int compare(Pair pair, Pair pair2) {
            float floatValue = ((Float) pair.second).floatValue();
            float floatValue2 = ((Float) pair2.second).floatValue();
            if (floatValue2 > floatValue) {
                return 1;
            }
            return floatValue > floatValue2 ? -1 : 0;
        }
    }

    public void a(String str, float f10) {
        if (this.f3441a) {
            f fVar = (f) this.f3443c.get(str);
            if (fVar == null) {
                fVar = new f();
                this.f3443c.put(str, fVar);
            }
            fVar.a(f10);
            if (str.equals("__container")) {
                Iterator it = this.f3442b.iterator();
                if (it.hasNext()) {
                    m.f.a(it.next());
                    throw null;
                }
            }
        }
    }

    public void b(boolean z10) {
        this.f3441a = z10;
    }
}
