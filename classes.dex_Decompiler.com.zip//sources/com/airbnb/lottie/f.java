package com.airbnb.lottie;

public final /* synthetic */ class f implements f0 {
    public final void onResult(Object obj) {
        LottieAnimationView.t((Throwable) obj);
    }
}
