package com.airbnb.lottie;

import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;

public class p0 extends PorterDuffColorFilter {
    public p0(int i10) {
        super(i10, PorterDuff.Mode.SRC_ATOP);
    }
}
