package com.airbnb.lottie;

import java.io.InputStream;
import java.util.concurrent.Callable;

public final /* synthetic */ class j implements Callable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ InputStream f3429a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ String f3430b;

    public /* synthetic */ j(InputStream inputStream, String str) {
        this.f3429a = inputStream;
        this.f3430b = str;
    }

    public final Object call() {
        return p.o(this.f3429a, this.f3430b);
    }
}
