package com.airbnb.lottie;

import com.airbnb.lottie.d0;

public final /* synthetic */ class r implements d0.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ d0 f3464a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ int f3465b;

    public /* synthetic */ r(d0 d0Var, int i10) {
        this.f3464a = d0Var;
        this.f3465b = i10;
    }

    public final void a(h hVar) {
        this.f3464a.O(this.f3465b, hVar);
    }
}
