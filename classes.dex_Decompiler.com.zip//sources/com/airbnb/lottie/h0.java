package com.airbnb.lottie;

import android.graphics.Bitmap;
import android.graphics.ColorFilter;
import android.graphics.PointF;
import android.graphics.Typeface;
import n2.d;

public interface h0 {
    public static final Float A = Float.valueOf(10.0f);
    public static final Float B = Float.valueOf(11.0f);
    public static final Float C = Float.valueOf(12.0f);
    public static final Float D = Float.valueOf(12.1f);
    public static final Float E = Float.valueOf(13.0f);
    public static final Float F = Float.valueOf(14.0f);
    public static final Float G;
    public static final Float H;
    public static final Float I;
    public static final Float J = Float.valueOf(18.0f);
    public static final ColorFilter K = new ColorFilter();
    public static final Integer[] L = new Integer[0];
    public static final Typeface M = Typeface.DEFAULT;
    public static final Bitmap N = Bitmap.createBitmap(1, 1, Bitmap.Config.ALPHA_8);
    public static final CharSequence O = "dynamic_text";

    /* renamed from: a  reason: collision with root package name */
    public static final Integer f3398a = 1;

    /* renamed from: b  reason: collision with root package name */
    public static final Integer f3399b = 2;

    /* renamed from: c  reason: collision with root package name */
    public static final Integer f3400c = 3;

    /* renamed from: d  reason: collision with root package name */
    public static final Integer f3401d = 4;

    /* renamed from: e  reason: collision with root package name */
    public static final Integer f3402e = 5;

    /* renamed from: f  reason: collision with root package name */
    public static final PointF f3403f = new PointF();

    /* renamed from: g  reason: collision with root package name */
    public static final PointF f3404g = new PointF();

    /* renamed from: h  reason: collision with root package name */
    public static final Float f3405h;

    /* renamed from: i  reason: collision with root package name */
    public static final Float f3406i;

    /* renamed from: j  reason: collision with root package name */
    public static final Float f3407j;

    /* renamed from: k  reason: collision with root package name */
    public static final PointF f3408k = new PointF();

    /* renamed from: l  reason: collision with root package name */
    public static final PointF f3409l = new PointF();

    /* renamed from: m  reason: collision with root package name */
    public static final Float f3410m;

    /* renamed from: n  reason: collision with root package name */
    public static final PointF f3411n = new PointF();

    /* renamed from: o  reason: collision with root package name */
    public static final d f3412o = new d();

    /* renamed from: p  reason: collision with root package name */
    public static final Float f3413p = Float.valueOf(1.0f);

    /* renamed from: q  reason: collision with root package name */
    public static final Float f3414q;

    /* renamed from: r  reason: collision with root package name */
    public static final Float f3415r;

    /* renamed from: s  reason: collision with root package name */
    public static final Float f3416s = Float.valueOf(2.0f);

    /* renamed from: t  reason: collision with root package name */
    public static final Float f3417t = Float.valueOf(3.0f);

    /* renamed from: u  reason: collision with root package name */
    public static final Float f3418u = Float.valueOf(4.0f);

    /* renamed from: v  reason: collision with root package name */
    public static final Float f3419v = Float.valueOf(5.0f);

    /* renamed from: w  reason: collision with root package name */
    public static final Float f3420w = Float.valueOf(6.0f);

    /* renamed from: x  reason: collision with root package name */
    public static final Float f3421x = Float.valueOf(7.0f);

    /* renamed from: y  reason: collision with root package name */
    public static final Float f3422y = Float.valueOf(8.0f);

    /* renamed from: z  reason: collision with root package name */
    public static final Float f3423z = Float.valueOf(9.0f);

    static {
        Float valueOf = Float.valueOf(15.0f);
        f3405h = valueOf;
        Float valueOf2 = Float.valueOf(16.0f);
        f3406i = valueOf2;
        Float valueOf3 = Float.valueOf(17.0f);
        f3407j = valueOf3;
        Float valueOf4 = Float.valueOf(0.0f);
        f3410m = valueOf4;
        f3414q = valueOf4;
        f3415r = valueOf4;
        G = valueOf;
        H = valueOf2;
        I = valueOf3;
    }
}
