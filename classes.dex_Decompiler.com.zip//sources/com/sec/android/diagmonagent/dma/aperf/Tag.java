package com.sec.android.diagmonagent.dma.aperf;

import android.os.Parcel;
import android.os.Parcelable;

public class Tag implements Parcelable {
    public static final Parcelable.Creator<Tag> CREATOR = new a();

    /* renamed from: a  reason: collision with root package name */
    public String f5517a;

    /* renamed from: b  reason: collision with root package name */
    public String f5518b;

    public class a implements Parcelable.Creator {
        /* renamed from: a */
        public Tag createFromParcel(Parcel parcel) {
            return new Tag(parcel);
        }

        /* renamed from: b */
        public Tag[] newArray(int i10) {
            return new Tag[i10];
        }
    }

    public Tag(Parcel parcel) {
        this.f5517a = parcel.readString();
        this.f5518b = parcel.readString();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i10) {
        parcel.writeString(this.f5517a);
        parcel.writeString(this.f5518b);
    }
}
