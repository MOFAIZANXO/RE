package com.sec.android.diagmonagent.dma.aperf;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

public class Operation implements Parcelable {
    public static final Parcelable.Creator<Operation> CREATOR = new a();

    /* renamed from: a  reason: collision with root package name */
    public String f5497a;

    /* renamed from: b  reason: collision with root package name */
    public String f5498b;

    /* renamed from: f  reason: collision with root package name */
    public long f5499f;

    /* renamed from: g  reason: collision with root package name */
    public String f5500g;

    /* renamed from: h  reason: collision with root package name */
    public long f5501h;

    /* renamed from: i  reason: collision with root package name */
    public String f5502i;

    /* renamed from: j  reason: collision with root package name */
    public long f5503j;

    /* renamed from: k  reason: collision with root package name */
    public long f5504k;

    /* renamed from: l  reason: collision with root package name */
    public long f5505l;

    /* renamed from: m  reason: collision with root package name */
    public long f5506m;

    /* renamed from: n  reason: collision with root package name */
    public long f5507n;

    /* renamed from: o  reason: collision with root package name */
    public ArrayList f5508o = null;

    /* renamed from: p  reason: collision with root package name */
    public ArrayList f5509p = null;

    public class a implements Parcelable.Creator {
        /* renamed from: a */
        public Operation createFromParcel(Parcel parcel) {
            return new Operation(parcel);
        }

        /* renamed from: b */
        public Operation[] newArray(int i10) {
            return new Operation[i10];
        }
    }

    public Operation(Parcel parcel) {
        Bundle readBundle = parcel.readBundle();
        readBundle.setClassLoader(Operation.class.getClassLoader());
        this.f5497a = readBundle.getString("opId");
        this.f5498b = readBundle.getString("opName");
        this.f5499f = readBundle.getLong("startOpTimeMills");
        this.f5500g = readBundle.getString("startOpTimestamp");
        this.f5501h = readBundle.getLong("stopOpTimeMills");
        this.f5502i = readBundle.getString("stopOpTimestamp");
        this.f5503j = readBundle.getLong("opElapsedTime");
        this.f5504k = readBundle.getLong("opItemCount");
        this.f5505l = readBundle.getLong("opDataSize");
        this.f5508o = readBundle.getParcelableArrayList("subOpList");
        this.f5509p = readBundle.getParcelableArrayList("tagList");
        this.f5506m = readBundle.getLong("subOpTotalElapsedTime");
        this.f5507n = readBundle.getLong("subOpTotalCount");
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i10) {
        Bundle bundle = new Bundle();
        bundle.putString("opId", this.f5497a);
        bundle.putString("opName", this.f5498b);
        bundle.putLong("startOpTimeMills", this.f5499f);
        bundle.putString("startOpTimestamp", this.f5500g);
        bundle.putLong("stopOpTimeMills", this.f5501h);
        bundle.putString("stopOpTimestamp", this.f5502i);
        bundle.putLong("opElapsedTime", this.f5503j);
        bundle.putLong("opItemCount", this.f5504k);
        bundle.putLong("opDataSize", this.f5505l);
        bundle.putParcelableArrayList("subOpList", this.f5508o);
        bundle.putParcelableArrayList("tagList", this.f5509p);
        bundle.putLong("subOpTotalElapsedTime", this.f5506m);
        bundle.putLong("subOpTotalCount", this.f5507n);
        parcel.writeBundle(bundle);
    }
}
