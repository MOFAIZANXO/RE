package com.sec.android.diagmonagent.dma.aperf;

import android.os.Parcel;
import android.os.Parcelable;

public class SubOperation implements Parcelable {
    public static final Parcelable.Creator<SubOperation> CREATOR = new a();

    /* renamed from: a  reason: collision with root package name */
    public String f5510a;

    /* renamed from: b  reason: collision with root package name */
    public String f5511b;

    /* renamed from: f  reason: collision with root package name */
    public long f5512f;

    /* renamed from: g  reason: collision with root package name */
    public String f5513g;

    /* renamed from: h  reason: collision with root package name */
    public long f5514h;

    /* renamed from: i  reason: collision with root package name */
    public long f5515i = 0;

    /* renamed from: j  reason: collision with root package name */
    public long f5516j = 0;

    public class a implements Parcelable.Creator {
        /* renamed from: a */
        public SubOperation createFromParcel(Parcel parcel) {
            return new SubOperation(parcel);
        }

        /* renamed from: b */
        public SubOperation[] newArray(int i10) {
            return new SubOperation[i10];
        }
    }

    public SubOperation(Parcel parcel) {
        this.f5510a = parcel.readString();
        this.f5511b = parcel.readString();
        this.f5512f = parcel.readLong();
        this.f5513g = parcel.readString();
        this.f5514h = parcel.readLong();
        this.f5515i = parcel.readLong();
        this.f5516j = parcel.readLong();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel parcel, int i10) {
        parcel.writeString(this.f5510a);
        parcel.writeString(this.f5511b);
        parcel.writeLong(this.f5512f);
        parcel.writeString(this.f5513g);
        parcel.writeLong(this.f5514h);
        parcel.writeLong(this.f5515i);
        parcel.writeLong(this.f5516j);
    }
}
