package com.sec.android.diagmonagent.log.provider;

import kb.f;

public class DiagMonProvider extends f {
    public boolean onCreate() {
        return super.onCreate();
    }
}
