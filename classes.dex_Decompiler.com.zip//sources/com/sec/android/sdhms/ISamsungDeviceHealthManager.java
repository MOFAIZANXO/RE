package com.sec.android.sdhms;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import java.util.List;

public interface ISamsungDeviceHealthManager extends IInterface {

    public static class Default implements ISamsungDeviceHealthManager {
        public IBinder asBinder() {
            return null;
        }

        public int getRUT(int i10, String str) throws RemoteException {
            return 0;
        }

        public int getRemainingUsageTime(int i10) throws RemoteException {
            return 0;
        }

        public int getRemainingUsageTimeWithSettings(int i10, String str, String str2, String str3, int i11, int i12, String str4) throws RemoteException {
            return 0;
        }

        public int getSsrmStatus(int i10) throws RemoteException {
            return 0;
        }

        public void logAction(String str, int i10, List<Bundle> list) throws RemoteException {
        }

        public void logActionWithPkg(String str, int i10, String str2, List<Bundle> list) throws RemoteException {
        }

        public void logActionWithSource(String str, int i10, int i11) throws RemoteException {
        }

        public void logAnomaly(Bundle bundle) throws RemoteException {
        }

        public void sendCommand(String str, String str2) throws RemoteException {
        }

        public float[] supportVRTemperaturesInformation(String str, int i10, int i11) throws RemoteException {
            return null;
        }
    }

    public static abstract class Stub extends Binder implements ISamsungDeviceHealthManager {

        public static class Proxy implements ISamsungDeviceHealthManager {

            /* renamed from: a  reason: collision with root package name */
            public IBinder f5519a;

            public Proxy(IBinder iBinder) {
                this.f5519a = iBinder;
            }

            public IBinder asBinder() {
                return this.f5519a;
            }

            public String getInterfaceDescriptor() {
                return "com.sec.android.sdhms.ISamsungDeviceHealthManager";
            }

            public int getRUT(int i10, String str) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.sec.android.sdhms.ISamsungDeviceHealthManager");
                    obtain.writeInt(i10);
                    obtain.writeString(str);
                    this.f5519a.transact(8, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public int getRemainingUsageTime(int i10) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.sec.android.sdhms.ISamsungDeviceHealthManager");
                    obtain.writeInt(i10);
                    this.f5519a.transact(6, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public int getRemainingUsageTimeWithSettings(int i10, String str, String str2, String str3, int i11, int i12, String str4) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.sec.android.sdhms.ISamsungDeviceHealthManager");
                    obtain.writeInt(i10);
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    obtain.writeString(str3);
                    obtain.writeInt(i11);
                    obtain.writeInt(i12);
                    obtain.writeString(str4);
                    this.f5519a.transact(7, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public int getSsrmStatus(int i10) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.sec.android.sdhms.ISamsungDeviceHealthManager");
                    obtain.writeInt(i10);
                    this.f5519a.transact(10, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.readInt();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void logAction(String str, int i10, List<Bundle> list) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.sec.android.sdhms.ISamsungDeviceHealthManager");
                    obtain.writeString(str);
                    obtain.writeInt(i10);
                    _Parcel.e(obtain, list, 0);
                    this.f5519a.transact(1, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void logActionWithPkg(String str, int i10, String str2, List<Bundle> list) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.sec.android.sdhms.ISamsungDeviceHealthManager");
                    obtain.writeString(str);
                    obtain.writeInt(i10);
                    obtain.writeString(str2);
                    _Parcel.e(obtain, list, 0);
                    this.f5519a.transact(2, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void logActionWithSource(String str, int i10, int i11) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.sec.android.sdhms.ISamsungDeviceHealthManager");
                    obtain.writeString(str);
                    obtain.writeInt(i10);
                    obtain.writeInt(i11);
                    this.f5519a.transact(3, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void logAnomaly(Bundle bundle) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.sec.android.sdhms.ISamsungDeviceHealthManager");
                    _Parcel.f(obtain, bundle, 0);
                    this.f5519a.transact(4, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public void sendCommand(String str, String str2) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.sec.android.sdhms.ISamsungDeviceHealthManager");
                    obtain.writeString(str);
                    obtain.writeString(str2);
                    this.f5519a.transact(5, obtain, obtain2, 0);
                    obtain2.readException();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }

            public float[] supportVRTemperaturesInformation(String str, int i10, int i11) throws RemoteException {
                Parcel obtain = Parcel.obtain();
                Parcel obtain2 = Parcel.obtain();
                try {
                    obtain.writeInterfaceToken("com.sec.android.sdhms.ISamsungDeviceHealthManager");
                    obtain.writeString(str);
                    obtain.writeInt(i10);
                    obtain.writeInt(i11);
                    this.f5519a.transact(9, obtain, obtain2, 0);
                    obtain2.readException();
                    return obtain2.createFloatArray();
                } finally {
                    obtain2.recycle();
                    obtain.recycle();
                }
            }
        }

        public Stub() {
            attachInterface(this, "com.sec.android.sdhms.ISamsungDeviceHealthManager");
        }

        public static ISamsungDeviceHealthManager asInterface(IBinder iBinder) {
            if (iBinder == null) {
                return null;
            }
            IInterface queryLocalInterface = iBinder.queryLocalInterface("com.sec.android.sdhms.ISamsungDeviceHealthManager");
            return (queryLocalInterface == null || !(queryLocalInterface instanceof ISamsungDeviceHealthManager)) ? new Proxy(iBinder) : (ISamsungDeviceHealthManager) queryLocalInterface;
        }

        public IBinder asBinder() {
            return this;
        }

        public abstract /* synthetic */ int getRUT(int i10, String str) throws RemoteException;

        public abstract /* synthetic */ int getRemainingUsageTime(int i10) throws RemoteException;

        public abstract /* synthetic */ int getRemainingUsageTimeWithSettings(int i10, String str, String str2, String str3, int i11, int i12, String str4) throws RemoteException;

        public abstract /* synthetic */ int getSsrmStatus(int i10) throws RemoteException;

        public abstract /* synthetic */ void logAction(String str, int i10, List list) throws RemoteException;

        public abstract /* synthetic */ void logActionWithPkg(String str, int i10, String str2, List list) throws RemoteException;

        public abstract /* synthetic */ void logActionWithSource(String str, int i10, int i11) throws RemoteException;

        public abstract /* synthetic */ void logAnomaly(Bundle bundle) throws RemoteException;

        public boolean onTransact(int i10, Parcel parcel, Parcel parcel2, int i11) throws RemoteException {
            if (i10 >= 1 && i10 <= 16777215) {
                parcel.enforceInterface("com.sec.android.sdhms.ISamsungDeviceHealthManager");
            }
            if (i10 != 1598968902) {
                switch (i10) {
                    case 1:
                        logAction(parcel.readString(), parcel.readInt(), parcel.createTypedArrayList(Bundle.CREATOR));
                        parcel2.writeNoException();
                        break;
                    case 2:
                        logActionWithPkg(parcel.readString(), parcel.readInt(), parcel.readString(), parcel.createTypedArrayList(Bundle.CREATOR));
                        parcel2.writeNoException();
                        break;
                    case 3:
                        logActionWithSource(parcel.readString(), parcel.readInt(), parcel.readInt());
                        parcel2.writeNoException();
                        break;
                    case 4:
                        logAnomaly((Bundle) _Parcel.d(parcel, Bundle.CREATOR));
                        parcel2.writeNoException();
                        break;
                    case 5:
                        sendCommand(parcel.readString(), parcel.readString());
                        parcel2.writeNoException();
                        break;
                    case 6:
                        int remainingUsageTime = getRemainingUsageTime(parcel.readInt());
                        parcel2.writeNoException();
                        parcel2.writeInt(remainingUsageTime);
                        break;
                    case 7:
                        int remainingUsageTimeWithSettings = getRemainingUsageTimeWithSettings(parcel.readInt(), parcel.readString(), parcel.readString(), parcel.readString(), parcel.readInt(), parcel.readInt(), parcel.readString());
                        parcel2.writeNoException();
                        parcel2.writeInt(remainingUsageTimeWithSettings);
                        break;
                    case 8:
                        int rut = getRUT(parcel.readInt(), parcel.readString());
                        parcel2.writeNoException();
                        parcel2.writeInt(rut);
                        break;
                    case 9:
                        float[] supportVRTemperaturesInformation = supportVRTemperaturesInformation(parcel.readString(), parcel.readInt(), parcel.readInt());
                        parcel2.writeNoException();
                        parcel2.writeFloatArray(supportVRTemperaturesInformation);
                        break;
                    case 10:
                        int ssrmStatus = getSsrmStatus(parcel.readInt());
                        parcel2.writeNoException();
                        parcel2.writeInt(ssrmStatus);
                        break;
                    default:
                        return super.onTransact(i10, parcel, parcel2, i11);
                }
                return true;
            }
            parcel2.writeString("com.sec.android.sdhms.ISamsungDeviceHealthManager");
            return true;
        }

        public abstract /* synthetic */ void sendCommand(String str, String str2) throws RemoteException;

        public abstract /* synthetic */ float[] supportVRTemperaturesInformation(String str, int i10, int i11) throws RemoteException;
    }

    public static class _Parcel {
        public static Object d(Parcel parcel, Parcelable.Creator creator) {
            if (parcel.readInt() != 0) {
                return creator.createFromParcel(parcel);
            }
            return null;
        }

        public static void e(Parcel parcel, List list, int i10) {
            if (list == null) {
                parcel.writeInt(-1);
                return;
            }
            int size = list.size();
            parcel.writeInt(size);
            for (int i11 = 0; i11 < size; i11++) {
                f(parcel, (Parcelable) list.get(i11), i10);
            }
        }

        public static void f(Parcel parcel, Parcelable parcelable, int i10) {
            if (parcelable != null) {
                parcel.writeInt(1);
                parcelable.writeToParcel(parcel, i10);
                return;
            }
            parcel.writeInt(0);
        }
    }

    int getRUT(int i10, String str);

    void logActionWithPkg(String str, int i10, String str2, List list);

    void logAnomaly(Bundle bundle);
}
