package i2;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import com.airbnb.lottie.d0;
import com.airbnb.lottie.h;
import com.airbnb.lottie.h0;
import d2.q;
import g2.b;
import h.e;
import java.util.ArrayList;
import java.util.List;

public class c extends b {
    public d2.a D;
    public final List E = new ArrayList();
    public final RectF F = new RectF();
    public final RectF G = new RectF();
    public final Paint H = new Paint();
    public boolean I = true;

    public static /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        public static final /* synthetic */ int[] f7166a;

        /* JADX WARNING: Can't wrap try/catch for region: R(6:0|1|2|3|4|6) */
        /* JADX WARNING: Code restructure failed: missing block: B:7:?, code lost:
            return;
         */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        static {
            /*
                i2.e$b[] r0 = i2.e.b.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f7166a = r0
                i2.e$b r1 = i2.e.b.ADD     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = f7166a     // Catch:{ NoSuchFieldError -> 0x001d }
                i2.e$b r1 = i2.e.b.INVERT     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: i2.c.a.<clinit>():void");
        }
    }

    public c(d0 d0Var, e eVar, List list, h hVar) {
        super(d0Var, eVar);
        int i10;
        b bVar;
        b u10 = eVar.u();
        if (u10 != null) {
            d2.a a10 = u10.a();
            this.D = a10;
            k(a10);
            this.D.a(this);
        } else {
            this.D = null;
        }
        e eVar2 = new e(hVar.k().size());
        int size = list.size() - 1;
        b bVar2 = null;
        while (true) {
            if (size < 0) {
                break;
            }
            e eVar3 = (e) list.get(size);
            b w10 = b.w(this, eVar3, d0Var, hVar);
            if (w10 != null) {
                eVar2.j(w10.A().d(), w10);
                if (bVar2 != null) {
                    bVar2.K(w10);
                    bVar2 = null;
                } else {
                    this.E.add(0, w10);
                    int i11 = a.f7166a[eVar3.h().ordinal()];
                    if (i11 == 1 || i11 == 2) {
                        bVar2 = w10;
                    }
                }
            }
            size--;
        }
        for (i10 = 0; i10 < eVar2.m(); i10++) {
            b bVar3 = (b) eVar2.f(eVar2.i(i10));
            if (!(bVar3 == null || (bVar = (b) eVar2.f(bVar3.A().j())) == null)) {
                bVar3.M(bVar);
            }
        }
    }

    public void J(f2.e eVar, int i10, List list, f2.e eVar2) {
        for (int i11 = 0; i11 < this.E.size(); i11++) {
            ((b) this.E.get(i11)).i(eVar, i10, list, eVar2);
        }
    }

    public void L(boolean z10) {
        super.L(z10);
        for (b L : this.E) {
            L.L(z10);
        }
    }

    public void N(float f10) {
        super.N(f10);
        if (this.D != null) {
            f10 = ((((Float) this.D.h()).floatValue() * this.f7154q.b().i()) - this.f7154q.b().p()) / (this.f7153p.getComposition().e() + 0.01f);
        }
        if (this.D == null) {
            f10 -= this.f7154q.r();
        }
        if (this.f7154q.v() != 0.0f && !"__container".equals(this.f7154q.i())) {
            f10 /= this.f7154q.v();
        }
        for (int size = this.E.size() - 1; size >= 0; size--) {
            ((b) this.E.get(size)).N(f10);
        }
    }

    public void Q(boolean z10) {
        this.I = z10;
    }

    public void a(RectF rectF, Matrix matrix, boolean z10) {
        super.a(rectF, matrix, z10);
        for (int size = this.E.size() - 1; size >= 0; size--) {
            this.F.set(0.0f, 0.0f, 0.0f, 0.0f);
            ((b) this.E.get(size)).a(this.F, this.f7152o, true);
            rectF.union(this.F);
        }
    }

    public void h(Object obj, n2.c cVar) {
        super.h(obj, cVar);
        if (obj != h0.E) {
            return;
        }
        if (cVar == null) {
            d2.a aVar = this.D;
            if (aVar != null) {
                aVar.n((n2.c) null);
                return;
            }
            return;
        }
        q qVar = new q(cVar);
        this.D = qVar;
        qVar.a(this);
        k(this.D);
    }

    public void v(Canvas canvas, Matrix matrix, int i10) {
        com.airbnb.lottie.c.a("CompositionLayer#draw");
        this.G.set(0.0f, 0.0f, (float) this.f7154q.l(), (float) this.f7154q.k());
        matrix.mapRect(this.G);
        boolean z10 = this.f7153p.K() && this.E.size() > 1 && i10 != 255;
        if (z10) {
            this.H.setAlpha(i10);
            m2.h.m(canvas, this.G, this.H);
        } else {
            canvas.save();
        }
        if (z10) {
            i10 = 255;
        }
        for (int size = this.E.size() - 1; size >= 0; size--) {
            if (((!this.I && "__container".equals(this.f7154q.i())) || this.G.isEmpty()) ? true : canvas.clipRect(this.G)) {
                ((b) this.E.get(size)).f(canvas, matrix, i10);
            }
        }
        canvas.restore();
        com.airbnb.lottie.c.b("CompositionLayer#draw");
    }
}
