package i2;

import com.airbnb.lottie.h;
import g2.j;
import g2.k;
import g2.l;
import java.util.List;
import java.util.Locale;

public class e {

    /* renamed from: a  reason: collision with root package name */
    public final List f7167a;

    /* renamed from: b  reason: collision with root package name */
    public final h f7168b;

    /* renamed from: c  reason: collision with root package name */
    public final String f7169c;

    /* renamed from: d  reason: collision with root package name */
    public final long f7170d;

    /* renamed from: e  reason: collision with root package name */
    public final a f7171e;

    /* renamed from: f  reason: collision with root package name */
    public final long f7172f;

    /* renamed from: g  reason: collision with root package name */
    public final String f7173g;

    /* renamed from: h  reason: collision with root package name */
    public final List f7174h;

    /* renamed from: i  reason: collision with root package name */
    public final l f7175i;

    /* renamed from: j  reason: collision with root package name */
    public final int f7176j;

    /* renamed from: k  reason: collision with root package name */
    public final int f7177k;

    /* renamed from: l  reason: collision with root package name */
    public final int f7178l;

    /* renamed from: m  reason: collision with root package name */
    public final float f7179m;

    /* renamed from: n  reason: collision with root package name */
    public final float f7180n;

    /* renamed from: o  reason: collision with root package name */
    public final int f7181o;

    /* renamed from: p  reason: collision with root package name */
    public final int f7182p;

    /* renamed from: q  reason: collision with root package name */
    public final j f7183q;

    /* renamed from: r  reason: collision with root package name */
    public final k f7184r;

    /* renamed from: s  reason: collision with root package name */
    public final g2.b f7185s;

    /* renamed from: t  reason: collision with root package name */
    public final List f7186t;

    /* renamed from: u  reason: collision with root package name */
    public final b f7187u;

    /* renamed from: v  reason: collision with root package name */
    public final boolean f7188v;

    /* renamed from: w  reason: collision with root package name */
    public final h2.a f7189w;

    /* renamed from: x  reason: collision with root package name */
    public final k2.j f7190x;

    public enum a {
        PRE_COMP,
        SOLID,
        IMAGE,
        NULL,
        SHAPE,
        TEXT,
        UNKNOWN
    }

    public enum b {
        NONE,
        ADD,
        INVERT,
        LUMA,
        LUMA_INVERTED,
        UNKNOWN
    }

    public e(List list, h hVar, String str, long j10, a aVar, long j11, String str2, List list2, l lVar, int i10, int i11, int i12, float f10, float f11, int i13, int i14, j jVar, k kVar, List list3, b bVar, g2.b bVar2, boolean z10, h2.a aVar2, k2.j jVar2) {
        this.f7167a = list;
        this.f7168b = hVar;
        this.f7169c = str;
        this.f7170d = j10;
        this.f7171e = aVar;
        this.f7172f = j11;
        this.f7173g = str2;
        this.f7174h = list2;
        this.f7175i = lVar;
        this.f7176j = i10;
        this.f7177k = i11;
        this.f7178l = i12;
        this.f7179m = f10;
        this.f7180n = f11;
        this.f7181o = i13;
        this.f7182p = i14;
        this.f7183q = jVar;
        this.f7184r = kVar;
        this.f7186t = list3;
        this.f7187u = bVar;
        this.f7185s = bVar2;
        this.f7188v = z10;
        this.f7189w = aVar2;
        this.f7190x = jVar2;
    }

    public h2.a a() {
        return this.f7189w;
    }

    public h b() {
        return this.f7168b;
    }

    public k2.j c() {
        return this.f7190x;
    }

    public long d() {
        return this.f7170d;
    }

    public List e() {
        return this.f7186t;
    }

    public a f() {
        return this.f7171e;
    }

    public List g() {
        return this.f7174h;
    }

    public b h() {
        return this.f7187u;
    }

    public String i() {
        return this.f7169c;
    }

    public long j() {
        return this.f7172f;
    }

    public int k() {
        return this.f7182p;
    }

    public int l() {
        return this.f7181o;
    }

    public String m() {
        return this.f7173g;
    }

    public List n() {
        return this.f7167a;
    }

    public int o() {
        return this.f7178l;
    }

    public int p() {
        return this.f7177k;
    }

    public int q() {
        return this.f7176j;
    }

    public float r() {
        return this.f7180n / this.f7168b.e();
    }

    public j s() {
        return this.f7183q;
    }

    public k t() {
        return this.f7184r;
    }

    public String toString() {
        return y("");
    }

    public g2.b u() {
        return this.f7185s;
    }

    public float v() {
        return this.f7179m;
    }

    public l w() {
        return this.f7175i;
    }

    public boolean x() {
        return this.f7188v;
    }

    public String y(String str) {
        StringBuilder sb2 = new StringBuilder();
        sb2.append(str);
        sb2.append(i());
        sb2.append("\n");
        e t10 = this.f7168b.t(j());
        if (t10 != null) {
            sb2.append("\t\tParents: ");
            sb2.append(t10.i());
            e t11 = this.f7168b.t(t10.j());
            while (t11 != null) {
                sb2.append("->");
                sb2.append(t11.i());
                t11 = this.f7168b.t(t11.j());
            }
            sb2.append(str);
            sb2.append("\n");
        }
        if (!g().isEmpty()) {
            sb2.append(str);
            sb2.append("\tMasks: ");
            sb2.append(g().size());
            sb2.append("\n");
        }
        if (!(q() == 0 || p() == 0)) {
            sb2.append(str);
            sb2.append("\tBackground: ");
            sb2.append(String.format(Locale.US, "%dx%d %X\n", new Object[]{Integer.valueOf(q()), Integer.valueOf(p()), Integer.valueOf(o())}));
        }
        if (!this.f7167a.isEmpty()) {
            sb2.append(str);
            sb2.append("\tShapes:\n");
            for (Object next : this.f7167a) {
                sb2.append(str);
                sb2.append("\t\t");
                sb2.append(next);
                sb2.append("\n");
            }
        }
        return sb2.toString();
    }
}
