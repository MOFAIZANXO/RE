package i2;

import android.graphics.BlurMaskFilter;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RectF;
import androidx.core.view.ViewCompat;
import c2.e;
import com.airbnb.lottie.c;
import com.airbnb.lottie.d0;
import d2.a;
import d2.d;
import d2.h;
import d2.p;
import f2.f;
import h2.h;
import i2.e;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import k2.j;

public abstract class b implements e, a.b, f {
    public Paint A;
    public float B;
    public BlurMaskFilter C;

    /* renamed from: a  reason: collision with root package name */
    public final Path f7138a = new Path();

    /* renamed from: b  reason: collision with root package name */
    public final Matrix f7139b = new Matrix();

    /* renamed from: c  reason: collision with root package name */
    public final Matrix f7140c = new Matrix();

    /* renamed from: d  reason: collision with root package name */
    public final Paint f7141d = new b2.a(1);

    /* renamed from: e  reason: collision with root package name */
    public final Paint f7142e = new b2.a(1, PorterDuff.Mode.DST_IN);

    /* renamed from: f  reason: collision with root package name */
    public final Paint f7143f = new b2.a(1, PorterDuff.Mode.DST_OUT);

    /* renamed from: g  reason: collision with root package name */
    public final Paint f7144g;

    /* renamed from: h  reason: collision with root package name */
    public final Paint f7145h;

    /* renamed from: i  reason: collision with root package name */
    public final RectF f7146i;

    /* renamed from: j  reason: collision with root package name */
    public final RectF f7147j;

    /* renamed from: k  reason: collision with root package name */
    public final RectF f7148k;

    /* renamed from: l  reason: collision with root package name */
    public final RectF f7149l;

    /* renamed from: m  reason: collision with root package name */
    public final RectF f7150m;

    /* renamed from: n  reason: collision with root package name */
    public final String f7151n;

    /* renamed from: o  reason: collision with root package name */
    public final Matrix f7152o;

    /* renamed from: p  reason: collision with root package name */
    public final d0 f7153p;

    /* renamed from: q  reason: collision with root package name */
    public final e f7154q;

    /* renamed from: r  reason: collision with root package name */
    public h f7155r;

    /* renamed from: s  reason: collision with root package name */
    public d f7156s;

    /* renamed from: t  reason: collision with root package name */
    public b f7157t;

    /* renamed from: u  reason: collision with root package name */
    public b f7158u;

    /* renamed from: v  reason: collision with root package name */
    public List f7159v;

    /* renamed from: w  reason: collision with root package name */
    public final List f7160w;

    /* renamed from: x  reason: collision with root package name */
    public final p f7161x;

    /* renamed from: y  reason: collision with root package name */
    public boolean f7162y;

    /* renamed from: z  reason: collision with root package name */
    public boolean f7163z;

    public static /* synthetic */ class a {

        /* renamed from: a  reason: collision with root package name */
        public static final /* synthetic */ int[] f7164a;

        /* renamed from: b  reason: collision with root package name */
        public static final /* synthetic */ int[] f7165b;

        /* JADX WARNING: Can't wrap try/catch for region: R(23:0|(2:1|2)|3|(2:5|6)|7|9|10|11|(2:13|14)|15|17|18|19|20|21|22|23|24|25|26|27|28|(3:29|30|32)) */
        /* JADX WARNING: Can't wrap try/catch for region: R(27:0|1|2|3|(2:5|6)|7|9|10|11|13|14|15|17|18|19|20|21|22|23|24|25|26|27|28|29|30|32) */
        /* JADX WARNING: Can't wrap try/catch for region: R(28:0|1|2|3|5|6|7|9|10|11|13|14|15|17|18|19|20|21|22|23|24|25|26|27|28|29|30|32) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:19:0x0044 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:21:0x004e */
        /* JADX WARNING: Missing exception handler attribute for start block: B:23:0x0058 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:25:0x0062 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:27:0x006d */
        /* JADX WARNING: Missing exception handler attribute for start block: B:29:0x0078 */
        static {
            /*
                h2.h$a[] r0 = h2.h.a.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f7165b = r0
                r1 = 1
                h2.h$a r2 = h2.h.a.MASK_MODE_NONE     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r2 = r2.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r0[r2] = r1     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                r0 = 2
                int[] r2 = f7165b     // Catch:{ NoSuchFieldError -> 0x001d }
                h2.h$a r3 = h2.h.a.MASK_MODE_SUBTRACT     // Catch:{ NoSuchFieldError -> 0x001d }
                int r3 = r3.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2[r3] = r0     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                r2 = 3
                int[] r3 = f7165b     // Catch:{ NoSuchFieldError -> 0x0028 }
                h2.h$a r4 = h2.h.a.MASK_MODE_INTERSECT     // Catch:{ NoSuchFieldError -> 0x0028 }
                int r4 = r4.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
                r3[r4] = r2     // Catch:{ NoSuchFieldError -> 0x0028 }
            L_0x0028:
                r3 = 4
                int[] r4 = f7165b     // Catch:{ NoSuchFieldError -> 0x0033 }
                h2.h$a r5 = h2.h.a.MASK_MODE_ADD     // Catch:{ NoSuchFieldError -> 0x0033 }
                int r5 = r5.ordinal()     // Catch:{ NoSuchFieldError -> 0x0033 }
                r4[r5] = r3     // Catch:{ NoSuchFieldError -> 0x0033 }
            L_0x0033:
                i2.e$a[] r4 = i2.e.a.values()
                int r4 = r4.length
                int[] r4 = new int[r4]
                f7164a = r4
                i2.e$a r5 = i2.e.a.SHAPE     // Catch:{ NoSuchFieldError -> 0x0044 }
                int r5 = r5.ordinal()     // Catch:{ NoSuchFieldError -> 0x0044 }
                r4[r5] = r1     // Catch:{ NoSuchFieldError -> 0x0044 }
            L_0x0044:
                int[] r1 = f7164a     // Catch:{ NoSuchFieldError -> 0x004e }
                i2.e$a r4 = i2.e.a.PRE_COMP     // Catch:{ NoSuchFieldError -> 0x004e }
                int r4 = r4.ordinal()     // Catch:{ NoSuchFieldError -> 0x004e }
                r1[r4] = r0     // Catch:{ NoSuchFieldError -> 0x004e }
            L_0x004e:
                int[] r0 = f7164a     // Catch:{ NoSuchFieldError -> 0x0058 }
                i2.e$a r1 = i2.e.a.SOLID     // Catch:{ NoSuchFieldError -> 0x0058 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0058 }
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0058 }
            L_0x0058:
                int[] r0 = f7164a     // Catch:{ NoSuchFieldError -> 0x0062 }
                i2.e$a r1 = i2.e.a.IMAGE     // Catch:{ NoSuchFieldError -> 0x0062 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0062 }
                r0[r1] = r3     // Catch:{ NoSuchFieldError -> 0x0062 }
            L_0x0062:
                int[] r0 = f7164a     // Catch:{ NoSuchFieldError -> 0x006d }
                i2.e$a r1 = i2.e.a.NULL     // Catch:{ NoSuchFieldError -> 0x006d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x006d }
                r2 = 5
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x006d }
            L_0x006d:
                int[] r0 = f7164a     // Catch:{ NoSuchFieldError -> 0x0078 }
                i2.e$a r1 = i2.e.a.TEXT     // Catch:{ NoSuchFieldError -> 0x0078 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0078 }
                r2 = 6
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0078 }
            L_0x0078:
                int[] r0 = f7164a     // Catch:{ NoSuchFieldError -> 0x0083 }
                i2.e$a r1 = i2.e.a.UNKNOWN     // Catch:{ NoSuchFieldError -> 0x0083 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0083 }
                r2 = 7
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0083 }
            L_0x0083:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: i2.b.a.<clinit>():void");
        }
    }

    public b(d0 d0Var, e eVar) {
        b2.a aVar = new b2.a(1);
        this.f7144g = aVar;
        this.f7145h = new b2.a(PorterDuff.Mode.CLEAR);
        this.f7146i = new RectF();
        this.f7147j = new RectF();
        this.f7148k = new RectF();
        this.f7149l = new RectF();
        this.f7150m = new RectF();
        this.f7152o = new Matrix();
        this.f7160w = new ArrayList();
        this.f7162y = true;
        this.B = 0.0f;
        this.f7153p = d0Var;
        this.f7154q = eVar;
        this.f7151n = eVar.i() + "#draw";
        if (eVar.h() == e.b.INVERT) {
            aVar.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
        } else {
            aVar.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        }
        p b10 = eVar.w().b();
        this.f7161x = b10;
        b10.b(this);
        if (eVar.g() != null && !eVar.g().isEmpty()) {
            h hVar = new h(eVar.g());
            this.f7155r = hVar;
            for (d2.a a10 : hVar.a()) {
                a10.a(this);
            }
            for (d2.a aVar2 : this.f7155r.c()) {
                k(aVar2);
                aVar2.a(this);
            }
        }
        P();
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void G() {
        O(this.f7156s.p() == 1.0f);
    }

    public static b w(c cVar, e eVar, d0 d0Var, com.airbnb.lottie.h hVar) {
        switch (a.f7164a[eVar.f().ordinal()]) {
            case 1:
                return new g(d0Var, eVar, cVar);
            case 2:
                return new c(d0Var, eVar, hVar.o(eVar.m()), hVar);
            case 3:
                return new h(d0Var, eVar);
            case 4:
                return new d(d0Var, eVar);
            case 5:
                return new f(d0Var, eVar);
            case 6:
                return new i(d0Var, eVar);
            default:
                m2.d.c("Unknown layer type " + eVar.f());
                return null;
        }
    }

    public e A() {
        return this.f7154q;
    }

    public boolean B() {
        h hVar = this.f7155r;
        return hVar != null && !hVar.a().isEmpty();
    }

    public boolean C() {
        return this.f7157t != null;
    }

    public final void D(RectF rectF, Matrix matrix) {
        this.f7148k.set(0.0f, 0.0f, 0.0f, 0.0f);
        if (B()) {
            int size = this.f7155r.b().size();
            for (int i10 = 0; i10 < size; i10++) {
                h2.h hVar = (h2.h) this.f7155r.b().get(i10);
                Path path = (Path) ((d2.a) this.f7155r.a().get(i10)).h();
                if (path != null) {
                    this.f7138a.set(path);
                    this.f7138a.transform(matrix);
                    int i11 = a.f7165b[hVar.a().ordinal()];
                    if (i11 != 1 && i11 != 2) {
                        if ((i11 != 3 && i11 != 4) || !hVar.d()) {
                            this.f7138a.computeBounds(this.f7150m, false);
                            if (i10 == 0) {
                                this.f7148k.set(this.f7150m);
                            } else {
                                RectF rectF2 = this.f7148k;
                                rectF2.set(Math.min(rectF2.left, this.f7150m.left), Math.min(this.f7148k.top, this.f7150m.top), Math.max(this.f7148k.right, this.f7150m.right), Math.max(this.f7148k.bottom, this.f7150m.bottom));
                            }
                        } else {
                            return;
                        }
                    } else {
                        return;
                    }
                }
            }
            if (!rectF.intersect(this.f7148k)) {
                rectF.set(0.0f, 0.0f, 0.0f, 0.0f);
            }
        }
    }

    public final void E(RectF rectF, Matrix matrix) {
        if (C() && this.f7154q.h() != e.b.INVERT) {
            this.f7149l.set(0.0f, 0.0f, 0.0f, 0.0f);
            this.f7157t.a(this.f7149l, matrix, true);
            if (!rectF.intersect(this.f7149l)) {
                rectF.set(0.0f, 0.0f, 0.0f, 0.0f);
            }
        }
    }

    public final void F() {
        this.f7153p.invalidateSelf();
    }

    public final void H(float f10) {
        this.f7153p.getComposition().n().a(this.f7154q.i(), f10);
    }

    public void I(d2.a aVar) {
        this.f7160w.remove(aVar);
    }

    public void J(f2.e eVar, int i10, List list, f2.e eVar2) {
    }

    public void K(b bVar) {
        this.f7157t = bVar;
    }

    public void L(boolean z10) {
        if (z10 && this.A == null) {
            this.A = new b2.a();
        }
        this.f7163z = z10;
    }

    public void M(b bVar) {
        this.f7158u = bVar;
    }

    public void N(float f10) {
        this.f7161x.j(f10);
        if (this.f7155r != null) {
            for (int i10 = 0; i10 < this.f7155r.a().size(); i10++) {
                ((d2.a) this.f7155r.a().get(i10)).m(f10);
            }
        }
        d dVar = this.f7156s;
        if (dVar != null) {
            dVar.m(f10);
        }
        b bVar = this.f7157t;
        if (bVar != null) {
            bVar.N(f10);
        }
        for (int i11 = 0; i11 < this.f7160w.size(); i11++) {
            ((d2.a) this.f7160w.get(i11)).m(f10);
        }
    }

    public final void O(boolean z10) {
        if (z10 != this.f7162y) {
            this.f7162y = z10;
            F();
        }
    }

    public final void P() {
        boolean z10 = true;
        if (!this.f7154q.e().isEmpty()) {
            d dVar = new d(this.f7154q.e());
            this.f7156s = dVar;
            dVar.l();
            this.f7156s.a(new a(this));
            if (((Float) this.f7156s.h()).floatValue() != 1.0f) {
                z10 = false;
            }
            O(z10);
            k(this.f7156s);
            return;
        }
        O(true);
    }

    public void a(RectF rectF, Matrix matrix, boolean z10) {
        this.f7146i.set(0.0f, 0.0f, 0.0f, 0.0f);
        t();
        this.f7152o.set(matrix);
        if (z10) {
            List list = this.f7159v;
            if (list != null) {
                for (int size = list.size() - 1; size >= 0; size--) {
                    this.f7152o.preConcat(((b) this.f7159v.get(size)).f7161x.f());
                }
            } else {
                b bVar = this.f7158u;
                if (bVar != null) {
                    this.f7152o.preConcat(bVar.f7161x.f());
                }
            }
        }
        this.f7152o.preConcat(this.f7161x.f());
    }

    public void c() {
        F();
    }

    public void d(List list, List list2) {
    }

    public void f(Canvas canvas, Matrix matrix, int i10) {
        Paint paint;
        c.a(this.f7151n);
        if (!this.f7162y || this.f7154q.x()) {
            c.b(this.f7151n);
            return;
        }
        t();
        c.a("Layer#parentMatrix");
        this.f7139b.reset();
        this.f7139b.set(matrix);
        for (int size = this.f7159v.size() - 1; size >= 0; size--) {
            this.f7139b.preConcat(((b) this.f7159v.get(size)).f7161x.f());
        }
        c.b("Layer#parentMatrix");
        int intValue = (int) ((((((float) i10) / 255.0f) * ((float) (this.f7161x.h() == null ? 100 : ((Integer) this.f7161x.h().h()).intValue()))) / 100.0f) * 255.0f);
        if (C() || B()) {
            c.a("Layer#computeBounds");
            a(this.f7146i, this.f7139b, false);
            E(this.f7146i, matrix);
            this.f7139b.preConcat(this.f7161x.f());
            D(this.f7146i, this.f7139b);
            this.f7147j.set(0.0f, 0.0f, (float) canvas.getWidth(), (float) canvas.getHeight());
            canvas.getMatrix(this.f7140c);
            if (!this.f7140c.isIdentity()) {
                Matrix matrix2 = this.f7140c;
                matrix2.invert(matrix2);
                this.f7140c.mapRect(this.f7147j);
            }
            if (!this.f7146i.intersect(this.f7147j)) {
                this.f7146i.set(0.0f, 0.0f, 0.0f, 0.0f);
            }
            c.b("Layer#computeBounds");
            if (this.f7146i.width() >= 1.0f && this.f7146i.height() >= 1.0f) {
                c.a("Layer#saveLayer");
                this.f7141d.setAlpha(255);
                m2.h.m(canvas, this.f7146i, this.f7141d);
                c.b("Layer#saveLayer");
                u(canvas);
                c.a("Layer#drawLayer");
                v(canvas, this.f7139b, intValue);
                c.b("Layer#drawLayer");
                if (B()) {
                    q(canvas, this.f7139b);
                }
                if (C()) {
                    c.a("Layer#drawMatte");
                    c.a("Layer#saveLayer");
                    m2.h.n(canvas, this.f7146i, this.f7144g, 19);
                    c.b("Layer#saveLayer");
                    u(canvas);
                    this.f7157t.f(canvas, matrix, intValue);
                    c.a("Layer#restoreLayer");
                    canvas.restore();
                    c.b("Layer#restoreLayer");
                    c.b("Layer#drawMatte");
                }
                c.a("Layer#restoreLayer");
                canvas.restore();
                c.b("Layer#restoreLayer");
            }
            if (this.f7163z && (paint = this.A) != null) {
                paint.setStyle(Paint.Style.STROKE);
                this.A.setColor(-251901);
                this.A.setStrokeWidth(4.0f);
                canvas.drawRect(this.f7146i, this.A);
                this.A.setStyle(Paint.Style.FILL);
                this.A.setColor(1357638635);
                canvas.drawRect(this.f7146i, this.A);
            }
            H(c.b(this.f7151n));
            return;
        }
        this.f7139b.preConcat(this.f7161x.f());
        c.a("Layer#drawLayer");
        v(canvas, this.f7139b, intValue);
        c.b("Layer#drawLayer");
        H(c.b(this.f7151n));
    }

    public String g() {
        return this.f7154q.i();
    }

    public void h(Object obj, n2.c cVar) {
        this.f7161x.c(obj, cVar);
    }

    public void i(f2.e eVar, int i10, List list, f2.e eVar2) {
        b bVar = this.f7157t;
        if (bVar != null) {
            f2.e a10 = eVar2.a(bVar.g());
            if (eVar.c(this.f7157t.g(), i10)) {
                list.add(a10.i(this.f7157t));
            }
            if (eVar.h(g(), i10)) {
                this.f7157t.J(eVar, eVar.e(this.f7157t.g(), i10) + i10, list, a10);
            }
        }
        if (eVar.g(g(), i10)) {
            if (!"__container".equals(g())) {
                eVar2 = eVar2.a(g());
                if (eVar.c(g(), i10)) {
                    list.add(eVar2.i(this));
                }
            }
            if (eVar.h(g(), i10)) {
                J(eVar, i10 + eVar.e(g(), i10), list, eVar2);
            }
        }
    }

    public void k(d2.a aVar) {
        if (aVar != null) {
            this.f7160w.add(aVar);
        }
    }

    public final void l(Canvas canvas, Matrix matrix, d2.a aVar, d2.a aVar2) {
        this.f7138a.set((Path) aVar.h());
        this.f7138a.transform(matrix);
        this.f7141d.setAlpha((int) (((float) ((Integer) aVar2.h()).intValue()) * 2.55f));
        canvas.drawPath(this.f7138a, this.f7141d);
    }

    public final void m(Canvas canvas, Matrix matrix, d2.a aVar, d2.a aVar2) {
        m2.h.m(canvas, this.f7146i, this.f7142e);
        this.f7138a.set((Path) aVar.h());
        this.f7138a.transform(matrix);
        this.f7141d.setAlpha((int) (((float) ((Integer) aVar2.h()).intValue()) * 2.55f));
        canvas.drawPath(this.f7138a, this.f7141d);
        canvas.restore();
    }

    public final void n(Canvas canvas, Matrix matrix, d2.a aVar, d2.a aVar2) {
        m2.h.m(canvas, this.f7146i, this.f7141d);
        canvas.drawRect(this.f7146i, this.f7141d);
        this.f7138a.set((Path) aVar.h());
        this.f7138a.transform(matrix);
        this.f7141d.setAlpha((int) (((float) ((Integer) aVar2.h()).intValue()) * 2.55f));
        canvas.drawPath(this.f7138a, this.f7143f);
        canvas.restore();
    }

    public final void o(Canvas canvas, Matrix matrix, d2.a aVar, d2.a aVar2) {
        m2.h.m(canvas, this.f7146i, this.f7142e);
        canvas.drawRect(this.f7146i, this.f7141d);
        this.f7143f.setAlpha((int) (((float) ((Integer) aVar2.h()).intValue()) * 2.55f));
        this.f7138a.set((Path) aVar.h());
        this.f7138a.transform(matrix);
        canvas.drawPath(this.f7138a, this.f7143f);
        canvas.restore();
    }

    public final void p(Canvas canvas, Matrix matrix, d2.a aVar, d2.a aVar2) {
        m2.h.m(canvas, this.f7146i, this.f7143f);
        canvas.drawRect(this.f7146i, this.f7141d);
        this.f7143f.setAlpha((int) (((float) ((Integer) aVar2.h()).intValue()) * 2.55f));
        this.f7138a.set((Path) aVar.h());
        this.f7138a.transform(matrix);
        canvas.drawPath(this.f7138a, this.f7143f);
        canvas.restore();
    }

    public final void q(Canvas canvas, Matrix matrix) {
        c.a("Layer#saveLayer");
        m2.h.n(canvas, this.f7146i, this.f7142e, 19);
        c.b("Layer#saveLayer");
        for (int i10 = 0; i10 < this.f7155r.b().size(); i10++) {
            h2.h hVar = (h2.h) this.f7155r.b().get(i10);
            d2.a aVar = (d2.a) this.f7155r.a().get(i10);
            d2.a aVar2 = (d2.a) this.f7155r.c().get(i10);
            int i11 = a.f7165b[hVar.a().ordinal()];
            if (i11 != 1) {
                if (i11 == 2) {
                    if (i10 == 0) {
                        this.f7141d.setColor(ViewCompat.MEASURED_STATE_MASK);
                        this.f7141d.setAlpha(255);
                        canvas.drawRect(this.f7146i, this.f7141d);
                    }
                    if (hVar.d()) {
                        p(canvas, matrix, aVar, aVar2);
                    } else {
                        r(canvas, matrix, aVar);
                    }
                } else if (i11 != 3) {
                    if (i11 == 4) {
                        if (hVar.d()) {
                            n(canvas, matrix, aVar, aVar2);
                        } else {
                            l(canvas, matrix, aVar, aVar2);
                        }
                    }
                } else if (hVar.d()) {
                    o(canvas, matrix, aVar, aVar2);
                } else {
                    m(canvas, matrix, aVar, aVar2);
                }
            } else if (s()) {
                this.f7141d.setAlpha(255);
                canvas.drawRect(this.f7146i, this.f7141d);
            }
        }
        c.a("Layer#restoreLayer");
        canvas.restore();
        c.b("Layer#restoreLayer");
    }

    public final void r(Canvas canvas, Matrix matrix, d2.a aVar) {
        this.f7138a.set((Path) aVar.h());
        this.f7138a.transform(matrix);
        canvas.drawPath(this.f7138a, this.f7143f);
    }

    public final boolean s() {
        if (this.f7155r.a().isEmpty()) {
            return false;
        }
        for (int i10 = 0; i10 < this.f7155r.b().size(); i10++) {
            if (((h2.h) this.f7155r.b().get(i10)).a() != h.a.MASK_MODE_NONE) {
                return false;
            }
        }
        return true;
    }

    public final void t() {
        if (this.f7159v == null) {
            if (this.f7158u == null) {
                this.f7159v = Collections.emptyList();
                return;
            }
            this.f7159v = new ArrayList();
            for (b bVar = this.f7158u; bVar != null; bVar = bVar.f7158u) {
                this.f7159v.add(bVar);
            }
        }
    }

    public final void u(Canvas canvas) {
        c.a("Layer#clearLayer");
        RectF rectF = this.f7146i;
        canvas.drawRect(rectF.left - 1.0f, rectF.top - 1.0f, rectF.right + 1.0f, rectF.bottom + 1.0f, this.f7145h);
        c.b("Layer#clearLayer");
    }

    public abstract void v(Canvas canvas, Matrix matrix, int i10);

    public h2.a x() {
        return this.f7154q.a();
    }

    public BlurMaskFilter y(float f10) {
        if (this.B == f10) {
            return this.C;
        }
        BlurMaskFilter blurMaskFilter = new BlurMaskFilter(f10 / 2.0f, BlurMaskFilter.Blur.NORMAL);
        this.C = blurMaskFilter;
        this.B = f10;
        return blurMaskFilter;
    }

    public j z() {
        return this.f7154q.c();
    }
}
