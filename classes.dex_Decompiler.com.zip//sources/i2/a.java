package i2;

import d2.a;

public final /* synthetic */ class a implements a.b {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ b f7137a;

    public /* synthetic */ a(b bVar) {
        this.f7137a = bVar;
    }

    public final void c() {
        this.f7137a.G();
    }
}
