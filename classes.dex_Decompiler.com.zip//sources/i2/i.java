package i2;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import com.airbnb.lottie.d0;
import com.airbnb.lottie.h;
import com.airbnb.lottie.h0;
import d2.o;
import d2.q;
import f2.b;
import f2.d;
import g2.k;
import h.e;
import h2.p;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class i extends b {
    public final StringBuilder D = new StringBuilder(2);
    public final RectF E = new RectF();
    public final Matrix F = new Matrix();
    public final Paint G = new a(1);
    public final Paint H = new b(1);
    public final Map I = new HashMap();
    public final e J = new e();
    public final o K;
    public final d0 L;
    public final h M;
    public d2.a N;
    public d2.a O;
    public d2.a P;
    public d2.a Q;
    public d2.a R;
    public d2.a S;
    public d2.a T;
    public d2.a U;
    public d2.a V;
    public d2.a W;

    public class a extends Paint {
        public a(int i10) {
            super(i10);
            setStyle(Paint.Style.FILL);
        }
    }

    public class b extends Paint {
        public b(int i10) {
            super(i10);
            setStyle(Paint.Style.STROKE);
        }
    }

    public static /* synthetic */ class c {

        /* renamed from: a  reason: collision with root package name */
        public static final /* synthetic */ int[] f7208a;

        /* JADX WARNING: Can't wrap try/catch for region: R(6:0|1|2|3|4|(3:5|6|8)) */
        /* JADX WARNING: Failed to process nested try/catch */
        /* JADX WARNING: Missing exception handler attribute for start block: B:3:0x0012 */
        /* JADX WARNING: Missing exception handler attribute for start block: B:5:0x001d */
        static {
            /*
                f2.b$a[] r0 = f2.b.a.values()
                int r0 = r0.length
                int[] r0 = new int[r0]
                f7208a = r0
                f2.b$a r1 = f2.b.a.LEFT_ALIGN     // Catch:{ NoSuchFieldError -> 0x0012 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0012 }
                r2 = 1
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0012 }
            L_0x0012:
                int[] r0 = f7208a     // Catch:{ NoSuchFieldError -> 0x001d }
                f2.b$a r1 = f2.b.a.RIGHT_ALIGN     // Catch:{ NoSuchFieldError -> 0x001d }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x001d }
                r2 = 2
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x001d }
            L_0x001d:
                int[] r0 = f7208a     // Catch:{ NoSuchFieldError -> 0x0028 }
                f2.b$a r1 = f2.b.a.CENTER     // Catch:{ NoSuchFieldError -> 0x0028 }
                int r1 = r1.ordinal()     // Catch:{ NoSuchFieldError -> 0x0028 }
                r2 = 3
                r0[r1] = r2     // Catch:{ NoSuchFieldError -> 0x0028 }
            L_0x0028:
                return
            */
            throw new UnsupportedOperationException("Method not decompiled: i2.i.c.<clinit>():void");
        }
    }

    public i(d0 d0Var, e eVar) {
        super(d0Var, eVar);
        g2.b bVar;
        g2.b bVar2;
        g2.a aVar;
        g2.a aVar2;
        this.L = d0Var;
        this.M = eVar.b();
        o d10 = eVar.s().a();
        this.K = d10;
        d10.a(this);
        k(d10);
        k t10 = eVar.t();
        if (!(t10 == null || (aVar2 = t10.f6438a) == null)) {
            d2.a a10 = aVar2.a();
            this.N = a10;
            a10.a(this);
            k(this.N);
        }
        if (!(t10 == null || (aVar = t10.f6439b) == null)) {
            d2.a a11 = aVar.a();
            this.P = a11;
            a11.a(this);
            k(this.P);
        }
        if (!(t10 == null || (bVar2 = t10.f6440c) == null)) {
            d2.a a12 = bVar2.a();
            this.R = a12;
            a12.a(this);
            k(this.R);
        }
        if (t10 != null && (bVar = t10.f6441d) != null) {
            d2.a a13 = bVar.a();
            this.T = a13;
            a13.a(this);
            k(this.T);
        }
    }

    public final void Q(b.a aVar, Canvas canvas, float f10) {
        int i10 = c.f7208a[aVar.ordinal()];
        if (i10 == 2) {
            canvas.translate(-f10, 0.0f);
        } else if (i10 == 3) {
            canvas.translate((-f10) / 2.0f, 0.0f);
        }
    }

    public final String R(String str, int i10) {
        int codePointAt = str.codePointAt(i10);
        int charCount = Character.charCount(codePointAt) + i10;
        while (charCount < str.length()) {
            int codePointAt2 = str.codePointAt(charCount);
            if (!e0(codePointAt2)) {
                break;
            }
            charCount += Character.charCount(codePointAt2);
            codePointAt = (codePointAt * 31) + codePointAt2;
        }
        long j10 = (long) codePointAt;
        if (this.J.d(j10)) {
            return (String) this.J.f(j10);
        }
        this.D.setLength(0);
        while (i10 < charCount) {
            int codePointAt3 = str.codePointAt(i10);
            this.D.appendCodePoint(codePointAt3);
            i10 += Character.charCount(codePointAt3);
        }
        String sb2 = this.D.toString();
        this.J.j(j10, sb2);
        return sb2;
    }

    public final void S(String str, Paint paint, Canvas canvas) {
        if (paint.getColor() != 0) {
            if (paint.getStyle() != Paint.Style.STROKE || paint.getStrokeWidth() != 0.0f) {
                canvas.drawText(str, 0, str.length(), 0.0f, 0.0f, paint);
            }
        }
    }

    public final void T(d dVar, Matrix matrix, float f10, f2.b bVar, Canvas canvas) {
        List a02 = a0(dVar);
        for (int i10 = 0; i10 < a02.size(); i10++) {
            Path b10 = ((c2.d) a02.get(i10)).b();
            b10.computeBounds(this.E, false);
            this.F.set(matrix);
            this.F.preTranslate(0.0f, (-bVar.f6089g) * m2.h.e());
            this.F.preScale(f10, f10);
            b10.transform(this.F);
            if (bVar.f6093k) {
                W(b10, this.G, canvas);
                W(b10, this.H, canvas);
            } else {
                W(b10, this.H, canvas);
                W(b10, this.G, canvas);
            }
        }
    }

    public final void U(String str, f2.b bVar, Canvas canvas) {
        if (bVar.f6093k) {
            S(str, this.G, canvas);
            S(str, this.H, canvas);
            return;
        }
        S(str, this.H, canvas);
        S(str, this.G, canvas);
    }

    public final void V(String str, f2.b bVar, Canvas canvas, float f10) {
        int i10 = 0;
        while (i10 < str.length()) {
            String R2 = R(str, i10);
            i10 += R2.length();
            U(R2, bVar, canvas);
            canvas.translate(this.G.measureText(R2) + f10, 0.0f);
        }
    }

    public final void W(Path path, Paint paint, Canvas canvas) {
        if (paint.getColor() != 0) {
            if (paint.getStyle() != Paint.Style.STROKE || paint.getStrokeWidth() != 0.0f) {
                canvas.drawPath(path, paint);
            }
        }
    }

    public final void X(String str, f2.b bVar, Matrix matrix, f2.c cVar, Canvas canvas, float f10, float f11) {
        float floatValue;
        for (int i10 = 0; i10 < str.length(); i10++) {
            d dVar = (d) this.M.c().e(d.c(str.charAt(i10), cVar.a(), cVar.c()));
            if (dVar != null) {
                T(dVar, matrix, f11, bVar, canvas);
                float b10 = ((float) dVar.b()) * f11 * m2.h.e() * f10;
                float f12 = ((float) bVar.f6087e) / 10.0f;
                d2.a aVar = this.U;
                if (aVar != null) {
                    floatValue = ((Float) aVar.h()).floatValue();
                } else {
                    d2.a aVar2 = this.T;
                    if (aVar2 != null) {
                        floatValue = ((Float) aVar2.h()).floatValue();
                    }
                    canvas.translate(b10 + (f12 * f10), 0.0f);
                }
                f12 += floatValue;
                canvas.translate(b10 + (f12 * f10), 0.0f);
            }
        }
    }

    public final void Y(f2.b bVar, Matrix matrix, f2.c cVar, Canvas canvas) {
        f2.b bVar2 = bVar;
        Canvas canvas2 = canvas;
        d2.a aVar = this.V;
        float floatValue = (aVar != null ? ((Float) aVar.h()).floatValue() : bVar2.f6085c) / 100.0f;
        float g10 = m2.h.g(matrix);
        String str = bVar2.f6083a;
        float e10 = bVar2.f6088f * m2.h.e();
        List c02 = c0(str);
        int size = c02.size();
        for (int i10 = 0; i10 < size; i10++) {
            String str2 = (String) c02.get(i10);
            float b02 = b0(str2, cVar, floatValue, g10);
            canvas.save();
            Q(bVar2.f6086d, canvas2, b02);
            canvas2.translate(0.0f, (((float) i10) * e10) - ((((float) (size - 1)) * e10) / 2.0f));
            X(str2, bVar, matrix, cVar, canvas, g10, floatValue);
            canvas.restore();
        }
    }

    /* JADX WARNING: Removed duplicated region for block: B:16:0x0084 A[LOOP:0: B:15:0x0082->B:16:0x0084, LOOP_END] */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void Z(f2.b r8, f2.c r9, android.graphics.Canvas r10) {
        /*
            r7 = this;
            android.graphics.Typeface r9 = r7.d0(r9)
            if (r9 != 0) goto L_0x0007
            return
        L_0x0007:
            java.lang.String r0 = r8.f6083a
            com.airbnb.lottie.d0 r1 = r7.L
            r1.getTextDelegate()
            android.graphics.Paint r1 = r7.G
            r1.setTypeface(r9)
            d2.a r9 = r7.V
            if (r9 == 0) goto L_0x0022
            java.lang.Object r9 = r9.h()
            java.lang.Float r9 = (java.lang.Float) r9
            float r9 = r9.floatValue()
            goto L_0x0024
        L_0x0022:
            float r9 = r8.f6085c
        L_0x0024:
            android.graphics.Paint r1 = r7.G
            float r2 = m2.h.e()
            float r2 = r2 * r9
            r1.setTextSize(r2)
            android.graphics.Paint r1 = r7.H
            android.graphics.Paint r2 = r7.G
            android.graphics.Typeface r2 = r2.getTypeface()
            r1.setTypeface(r2)
            android.graphics.Paint r1 = r7.H
            android.graphics.Paint r2 = r7.G
            float r2 = r2.getTextSize()
            r1.setTextSize(r2)
            float r1 = r8.f6088f
            float r2 = m2.h.e()
            float r1 = r1 * r2
            int r2 = r8.f6087e
            float r2 = (float) r2
            r3 = 1092616192(0x41200000, float:10.0)
            float r2 = r2 / r3
            d2.a r3 = r7.U
            if (r3 == 0) goto L_0x0061
            java.lang.Object r3 = r3.h()
            java.lang.Float r3 = (java.lang.Float) r3
            float r3 = r3.floatValue()
        L_0x005f:
            float r2 = r2 + r3
            goto L_0x0070
        L_0x0061:
            d2.a r3 = r7.T
            if (r3 == 0) goto L_0x0070
            java.lang.Object r3 = r3.h()
            java.lang.Float r3 = (java.lang.Float) r3
            float r3 = r3.floatValue()
            goto L_0x005f
        L_0x0070:
            float r3 = m2.h.e()
            float r2 = r2 * r3
            float r2 = r2 * r9
            r9 = 1120403456(0x42c80000, float:100.0)
            float r2 = r2 / r9
            java.util.List r9 = r7.c0(r0)
            int r0 = r9.size()
            r3 = 0
        L_0x0082:
            if (r3 >= r0) goto L_0x00b8
            java.lang.Object r4 = r9.get(r3)
            java.lang.String r4 = (java.lang.String) r4
            android.graphics.Paint r5 = r7.H
            float r5 = r5.measureText(r4)
            int r6 = r4.length()
            int r6 = r6 + -1
            float r6 = (float) r6
            float r6 = r6 * r2
            float r5 = r5 + r6
            r10.save()
            f2.b$a r6 = r8.f6086d
            r7.Q(r6, r10, r5)
            int r5 = r0 + -1
            float r5 = (float) r5
            float r5 = r5 * r1
            r6 = 1073741824(0x40000000, float:2.0)
            float r5 = r5 / r6
            float r6 = (float) r3
            float r6 = r6 * r1
            float r6 = r6 - r5
            r5 = 0
            r10.translate(r5, r6)
            r7.V(r4, r8, r10, r2)
            r10.restore()
            int r3 = r3 + 1
            goto L_0x0082
        L_0x00b8:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: i2.i.Z(f2.b, f2.c, android.graphics.Canvas):void");
    }

    public void a(RectF rectF, Matrix matrix, boolean z10) {
        super.a(rectF, matrix, z10);
        rectF.set(0.0f, 0.0f, (float) this.M.b().width(), (float) this.M.b().height());
    }

    public final List a0(d dVar) {
        if (this.I.containsKey(dVar)) {
            return (List) this.I.get(dVar);
        }
        List a10 = dVar.a();
        int size = a10.size();
        ArrayList arrayList = new ArrayList(size);
        for (int i10 = 0; i10 < size; i10++) {
            arrayList.add(new c2.d(this.L, this, (p) a10.get(i10)));
        }
        this.I.put(dVar, arrayList);
        return arrayList;
    }

    public final float b0(String str, f2.c cVar, float f10, float f11) {
        float f12 = 0.0f;
        for (int i10 = 0; i10 < str.length(); i10++) {
            d dVar = (d) this.M.c().e(d.c(str.charAt(i10), cVar.a(), cVar.c()));
            if (dVar != null) {
                f12 = (float) (((double) f12) + (dVar.b() * ((double) f10) * ((double) m2.h.e()) * ((double) f11)));
            }
        }
        return f12;
    }

    public final List c0(String str) {
        return Arrays.asList(str.replaceAll("\r\n", "\r").replaceAll("\n", "\r").split("\r"));
    }

    public final Typeface d0(f2.c cVar) {
        Typeface typeface;
        d2.a aVar = this.W;
        if (aVar != null && (typeface = (Typeface) aVar.h()) != null) {
            return typeface;
        }
        Typeface G2 = this.L.G(cVar.a(), cVar.c());
        return G2 != null ? G2 : cVar.d();
    }

    public final boolean e0(int i10) {
        return Character.getType(i10) == 16 || Character.getType(i10) == 27 || Character.getType(i10) == 6 || Character.getType(i10) == 28 || Character.getType(i10) == 8 || Character.getType(i10) == 19;
    }

    public void h(Object obj, n2.c cVar) {
        super.h(obj, cVar);
        if (obj == h0.f3398a) {
            d2.a aVar = this.O;
            if (aVar != null) {
                I(aVar);
            }
            if (cVar == null) {
                this.O = null;
                return;
            }
            q qVar = new q(cVar);
            this.O = qVar;
            qVar.a(this);
            k(this.O);
        } else if (obj == h0.f3399b) {
            d2.a aVar2 = this.Q;
            if (aVar2 != null) {
                I(aVar2);
            }
            if (cVar == null) {
                this.Q = null;
                return;
            }
            q qVar2 = new q(cVar);
            this.Q = qVar2;
            qVar2.a(this);
            k(this.Q);
        } else if (obj == h0.f3416s) {
            d2.a aVar3 = this.S;
            if (aVar3 != null) {
                I(aVar3);
            }
            if (cVar == null) {
                this.S = null;
                return;
            }
            q qVar3 = new q(cVar);
            this.S = qVar3;
            qVar3.a(this);
            k(this.S);
        } else if (obj == h0.f3417t) {
            d2.a aVar4 = this.U;
            if (aVar4 != null) {
                I(aVar4);
            }
            if (cVar == null) {
                this.U = null;
                return;
            }
            q qVar4 = new q(cVar);
            this.U = qVar4;
            qVar4.a(this);
            k(this.U);
        } else if (obj == h0.F) {
            d2.a aVar5 = this.V;
            if (aVar5 != null) {
                I(aVar5);
            }
            if (cVar == null) {
                this.V = null;
                return;
            }
            q qVar5 = new q(cVar);
            this.V = qVar5;
            qVar5.a(this);
            k(this.V);
        } else if (obj == h0.M) {
            d2.a aVar6 = this.W;
            if (aVar6 != null) {
                I(aVar6);
            }
            if (cVar == null) {
                this.W = null;
                return;
            }
            q qVar6 = new q(cVar);
            this.W = qVar6;
            qVar6.a(this);
            k(this.W);
        } else if (obj == h0.O) {
            this.K.q(cVar);
        }
    }

    public void v(Canvas canvas, Matrix matrix, int i10) {
        canvas.save();
        if (!this.L.g0()) {
            canvas.concat(matrix);
        }
        f2.b bVar = (f2.b) this.K.h();
        f2.c cVar = (f2.c) this.M.g().get(bVar.f6084b);
        if (cVar == null) {
            canvas.restore();
            return;
        }
        d2.a aVar = this.O;
        if (aVar != null) {
            this.G.setColor(((Integer) aVar.h()).intValue());
        } else {
            d2.a aVar2 = this.N;
            if (aVar2 != null) {
                this.G.setColor(((Integer) aVar2.h()).intValue());
            } else {
                this.G.setColor(bVar.f6090h);
            }
        }
        d2.a aVar3 = this.Q;
        if (aVar3 != null) {
            this.H.setColor(((Integer) aVar3.h()).intValue());
        } else {
            d2.a aVar4 = this.P;
            if (aVar4 != null) {
                this.H.setColor(((Integer) aVar4.h()).intValue());
            } else {
                this.H.setColor(bVar.f6091i);
            }
        }
        int intValue = ((this.f7161x.h() == null ? 100 : ((Integer) this.f7161x.h().h()).intValue()) * 255) / 100;
        this.G.setAlpha(intValue);
        this.H.setAlpha(intValue);
        d2.a aVar5 = this.S;
        if (aVar5 != null) {
            this.H.setStrokeWidth(((Float) aVar5.h()).floatValue());
        } else {
            d2.a aVar6 = this.R;
            if (aVar6 != null) {
                this.H.setStrokeWidth(((Float) aVar6.h()).floatValue());
            } else {
                this.H.setStrokeWidth(bVar.f6092j * m2.h.e() * m2.h.g(matrix));
            }
        }
        if (this.L.g0()) {
            Y(bVar, matrix, cVar, canvas);
        } else {
            Z(bVar, cVar, canvas);
        }
        canvas.restore();
    }
}
