package i2;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.RectF;
import com.airbnb.lottie.d0;

public class f extends b {
    public f(d0 d0Var, e eVar) {
        super(d0Var, eVar);
    }

    public void a(RectF rectF, Matrix matrix, boolean z10) {
        super.a(rectF, matrix, z10);
        rectF.set(0.0f, 0.0f, 0.0f, 0.0f);
    }

    public void v(Canvas canvas, Matrix matrix, int i10) {
    }
}
