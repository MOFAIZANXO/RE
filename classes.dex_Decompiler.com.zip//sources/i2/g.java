package i2;

import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.RectF;
import c2.d;
import com.airbnb.lottie.d0;
import f2.e;
import h2.a;
import h2.p;
import java.util.Collections;
import java.util.List;
import k2.j;

public class g extends b {
    public final d D;
    public final c E;

    public g(d0 d0Var, e eVar, c cVar) {
        super(d0Var, eVar);
        this.E = cVar;
        d dVar = new d(d0Var, this, new p("__container", eVar.n(), false));
        this.D = dVar;
        dVar.d(Collections.emptyList(), Collections.emptyList());
    }

    public void J(e eVar, int i10, List list, e eVar2) {
        this.D.i(eVar, i10, list, eVar2);
    }

    public void a(RectF rectF, Matrix matrix, boolean z10) {
        super.a(rectF, matrix, z10);
        this.D.a(rectF, this.f7152o, z10);
    }

    public void v(Canvas canvas, Matrix matrix, int i10) {
        this.D.f(canvas, matrix, i10);
    }

    public a x() {
        a x10 = super.x();
        return x10 != null ? x10 : this.E.x();
    }

    public j z() {
        j z10 = super.z();
        return z10 != null ? z10 : this.E.z();
    }
}
