package i2;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import b2.a;
import com.airbnb.lottie.d0;
import com.airbnb.lottie.e0;
import com.airbnb.lottie.h0;
import d2.q;
import m2.h;
import n2.c;

public class d extends b {
    public final Paint D = new a(3);
    public final Rect E = new Rect();
    public final Rect F = new Rect();
    public final e0 G;
    public d2.a H;
    public d2.a I;

    public d(d0 d0Var, e eVar) {
        super(d0Var, eVar);
        this.G = d0Var.F(eVar.m());
    }

    public final Bitmap Q() {
        Bitmap bitmap;
        d2.a aVar = this.I;
        if (aVar != null && (bitmap = (Bitmap) aVar.h()) != null) {
            return bitmap;
        }
        Bitmap E2 = this.f7153p.E(this.f7154q.m());
        if (E2 != null) {
            return E2;
        }
        e0 e0Var = this.G;
        if (e0Var != null) {
            return e0Var.a();
        }
        return null;
    }

    public void a(RectF rectF, Matrix matrix, boolean z10) {
        super.a(rectF, matrix, z10);
        if (this.G != null) {
            float e10 = h.e();
            rectF.set(0.0f, 0.0f, ((float) this.G.e()) * e10, ((float) this.G.c()) * e10);
            this.f7152o.mapRect(rectF);
        }
    }

    public void h(Object obj, c cVar) {
        super.h(obj, cVar);
        if (obj == h0.K) {
            if (cVar == null) {
                this.H = null;
            } else {
                this.H = new q(cVar);
            }
        } else if (obj != h0.N) {
        } else {
            if (cVar == null) {
                this.I = null;
            } else {
                this.I = new q(cVar);
            }
        }
    }

    public void v(Canvas canvas, Matrix matrix, int i10) {
        Bitmap Q = Q();
        if (Q != null && !Q.isRecycled() && this.G != null) {
            float e10 = h.e();
            this.D.setAlpha(i10);
            d2.a aVar = this.H;
            if (aVar != null) {
                this.D.setColorFilter((ColorFilter) aVar.h());
            }
            canvas.save();
            canvas.concat(matrix);
            this.E.set(0, 0, Q.getWidth(), Q.getHeight());
            if (this.f7153p.getMaintainOriginalImageBounds()) {
                this.F.set(0, 0, (int) (((float) this.G.e()) * e10), (int) (((float) this.G.c()) * e10));
            } else {
                this.F.set(0, 0, (int) (((float) Q.getWidth()) * e10), (int) (((float) Q.getHeight()) * e10));
            }
            canvas.drawBitmap(Q, this.E, this.F, this.D);
            canvas.restore();
        }
    }
}
