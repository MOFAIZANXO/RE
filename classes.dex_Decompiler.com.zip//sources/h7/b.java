package h7;

public class b {

    /* renamed from: a  reason: collision with root package name */
    public String f6990a;

    /* renamed from: b  reason: collision with root package name */
    public String f6991b;

    /* renamed from: c  reason: collision with root package name */
    public long f6992c;

    public b(String str, String str2, long j10) {
        this.f6990a = str;
        this.f6991b = str2;
        this.f6992c = j10;
    }

    public String a() {
        return this.f6990a;
    }

    public long b() {
        return this.f6992c;
    }

    public String c() {
        return this.f6991b;
    }
}
