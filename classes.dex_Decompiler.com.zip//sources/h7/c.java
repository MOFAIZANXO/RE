package h7;

import android.content.Context;
import java.util.ArrayList;

public interface c {
    ArrayList a(Context context);
}
