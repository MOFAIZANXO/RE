package h7;

import android.content.ContentValues;
import android.content.Context;
import android.util.Log;
import b7.e;

public class a {

    /* renamed from: b  reason: collision with root package name */
    public static final char[] f6988b = "0123456789abcdef".toCharArray();

    /* renamed from: a  reason: collision with root package name */
    public final Context f6989a;

    public a(Context context) {
        this.f6989a = context.getApplicationContext();
    }

    public static b a(String str, String str2) {
        return b(str, str2, -1);
    }

    public static b b(String str, String str2, long j10) {
        return new b(str, str2, j10);
    }

    public void c(String str, String str2, long j10) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("key", str);
        contentValues.put("value", str2);
        contentValues.put("timeStamp", Long.valueOf(j10));
        try {
            this.f6989a.getContentResolver().insert(e.j.f2852a, contentValues);
        } catch (Error | Exception e10) {
            Log.w("SmDump", "IllegalArgumentException" + e10.toString());
        }
    }
}
