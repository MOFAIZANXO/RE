package x6;

import com.samsung.android.sm.common.view.SmileLayout;
import n2.b;
import n2.e;

public final /* synthetic */ class k implements e {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ SmileLayout f10888a;

    public /* synthetic */ k(SmileLayout smileLayout) {
        this.f10888a = smileLayout;
    }

    public final Object a(b bVar) {
        return this.f10888a.m(bVar);
    }
}
