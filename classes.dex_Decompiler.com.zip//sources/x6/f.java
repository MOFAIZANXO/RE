package x6;

import android.content.Context;
import android.util.AttributeSet;

public interface f {
    a a(Context context, AttributeSet attributeSet) {
        return new a(context, attributeSet);
    }

    a getSeslInstance();

    void setRoundedCorners(int i10) {
        getSeslInstance().setRoundedCorners(i10);
    }
}
