package x6;

import android.content.Context;
import android.provider.Settings;
import android.util.TypedValue;
import java.util.Locale;

public abstract class n {
    public static int a(Context context, int i10) {
        TypedValue typedValue = new TypedValue();
        context.getTheme().resolveAttribute(i10, typedValue, true);
        return typedValue.data;
    }

    public static boolean b(Context context) {
        return Settings.Global.getFloat(context.getApplicationContext().getContentResolver(), "animator_duration_scale", 1.0f) > 0.0f;
    }

    public static boolean c() {
        return d(Locale.getDefault());
    }

    public static boolean d(Locale locale) {
        byte directionality = Character.getDirectionality(locale.getDisplayName().charAt(0));
        return directionality == 1 || directionality == 2;
    }
}
