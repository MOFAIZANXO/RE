package x6;

import android.content.res.Configuration;
import android.widget.TextView;

public class c {

    /* renamed from: a  reason: collision with root package name */
    public float f10872a;

    /* renamed from: b  reason: collision with root package name */
    public float f10873b = 1.0f;

    public void a(TextView textView, Configuration configuration) {
        if (configuration != null) {
            float f10 = configuration.fontScale;
            if (f10 != this.f10873b) {
                this.f10873b = f10;
                c(textView);
            }
        }
    }

    public void b(TextView textView) {
        if (textView != null) {
            this.f10873b = textView.getResources().getConfiguration().fontScale;
            this.f10872a = textView.getTextSize() / this.f10873b;
            c(textView);
        }
    }

    public final void c(TextView textView) {
        if (this.f10873b > 1.2f) {
            this.f10873b = 1.2f;
        }
        if (textView != null) {
            textView.setTextSize(0, this.f10872a * this.f10873b);
        }
    }
}
