package x6;

import com.airbnb.lottie.f0;
import com.airbnb.lottie.h;
import com.samsung.android.sm.common.view.SmileLayout;

public final /* synthetic */ class l implements f0 {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ SmileLayout f10889a;

    public /* synthetic */ l(SmileLayout smileLayout) {
        this.f10889a = smileLayout;
    }

    public final void onResult(Object obj) {
        this.f10889a.j((h) obj);
    }
}
