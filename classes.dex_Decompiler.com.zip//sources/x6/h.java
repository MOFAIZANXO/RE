package x6;

import android.view.View;
import androidx.recyclerview.widget.RecyclerView;

public abstract class h extends RecyclerView.t0 {

    /* renamed from: u  reason: collision with root package name */
    public int f10885u = 0;

    public h(View view) {
        super(view);
    }

    public int N() {
        return this.f10885u;
    }

    public void O(int i10) {
        this.f10885u = i10;
    }
}
