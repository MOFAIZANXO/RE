package x6;

import android.animation.ValueAnimator;

public final /* synthetic */ class d implements ValueAnimator.AnimatorUpdateListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ e f10874a;

    public /* synthetic */ d(e eVar) {
        this.f10874a = eVar;
    }

    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        this.f10874a.N(valueAnimator);
    }
}
