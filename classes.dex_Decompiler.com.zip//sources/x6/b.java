package x6;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.appcompat.widget.SwitchCompat;
import o4.a;

public abstract class b extends LinearLayout {

    /* renamed from: a  reason: collision with root package name */
    public ViewGroup f10865a;

    /* renamed from: b  reason: collision with root package name */
    public TextView f10866b;

    /* renamed from: f  reason: collision with root package name */
    public TextView f10867f;

    /* renamed from: g  reason: collision with root package name */
    public View f10868g;

    /* renamed from: h  reason: collision with root package name */
    public String f10869h;

    /* renamed from: i  reason: collision with root package name */
    public final Context f10870i;

    /* renamed from: j  reason: collision with root package name */
    public SwitchCompat f10871j;

    public b(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f10870i = context;
        a(attributeSet);
    }

    private void setStyleable(AttributeSet attributeSet) {
        TypedArray obtainStyledAttributes = this.f10870i.obtainStyledAttributes(attributeSet, a.DcSwitchView);
        this.f10869h = obtainStyledAttributes.getString(0);
        obtainStyledAttributes.recycle();
    }

    public final void a(AttributeSet attributeSet) {
        removeAllViews();
        setStyleable(attributeSet);
        LayoutInflater.from(this.f10870i).inflate(2131558471, this);
        this.f10865a = (ViewGroup) findViewById(2131362455);
        TextView textView = (TextView) findViewById(2131362972);
        this.f10866b = textView;
        textView.setText(this.f10869h);
        this.f10867f = (TextView) findViewById(2131362886);
        View findViewById = findViewById(2131362202);
        this.f10868g = findViewById;
        findViewById.setVisibility(8);
        this.f10871j = (SwitchCompat) findViewById(2131362057);
    }

    public boolean b() {
        SwitchCompat switchCompat = this.f10871j;
        return switchCompat != null && switchCompat.isChecked();
    }

    public void c() {
        this.f10871j.performClick();
    }

    public View getDivider() {
        return this.f10868g;
    }

    public TextView getSubTitle() {
        return this.f10867f;
    }

    public void setDivider(boolean z10) {
        if (z10) {
            this.f10868g.setVisibility(0);
        } else {
            this.f10868g.setVisibility(8);
        }
    }

    public void setSubTitle(String str) {
        this.f10867f.setText(str);
    }

    public void setSubTitleVisibility(boolean z10) {
        TextView textView = this.f10867f;
        if (textView != null) {
            textView.setVisibility(z10 ? 0 : 8);
        }
    }

    public void setSwitchBarVisible(boolean z10) {
        if (z10) {
            this.f10871j.setVisibility(0);
        } else {
            this.f10871j.setVisibility(8);
        }
    }

    public void setSwitchChecked(boolean z10) {
        this.f10871j.setChecked(z10);
    }

    public void setTitleText(String str) {
        this.f10866b.setText(str);
    }

    public void setVisibilityItem(boolean z10) {
        if (z10) {
            this.f10865a.setVisibility(0);
        } else {
            this.f10865a.setVisibility(8);
        }
    }
}
