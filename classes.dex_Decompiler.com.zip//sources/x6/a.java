package x6;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import androidx.appcompat.R;
import androidx.appcompat.util.SeslRoundedCorner;

public class a extends SeslRoundedCorner {
    public a(Context context, AttributeSet attributeSet) {
        super(context, false);
        a(context, attributeSet);
    }

    public final void a(Context context, AttributeSet attributeSet) {
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, o4.a.DcRoundedCorner);
        int integer = obtainStyledAttributes.getInteger(0, 0);
        obtainStyledAttributes.recycle();
        setRoundedCornerColor(15, n.a(context, R.attr.roundedCornerColor));
        setRoundedCorners(integer);
    }

    public void setRoundedCorners(int i10) {
        if (i10 <= 15) {
            super.setRoundedCorners(i10);
        }
    }
}
