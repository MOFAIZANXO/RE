package x6;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.view.animation.AlphaAnimation;
import android.view.animation.DecelerateInterpolator;
import android.widget.RelativeLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.c;
import java.util.ArrayList;

public abstract class e extends RecyclerView.t {

    /* renamed from: k  reason: collision with root package name */
    public static int f10875k = 3;

    /* renamed from: d  reason: collision with root package name */
    public int f10876d;

    /* renamed from: e  reason: collision with root package name */
    public int f10877e;

    /* renamed from: f  reason: collision with root package name */
    public int f10878f;

    /* renamed from: g  reason: collision with root package name */
    public RecyclerView f10879g;

    /* renamed from: h  reason: collision with root package name */
    public ArrayList f10880h = new ArrayList();

    /* renamed from: i  reason: collision with root package name */
    public ArrayList f10881i = new ArrayList();

    /* renamed from: j  reason: collision with root package name */
    public boolean f10882j = false;

    public class a extends c {
        public a() {
        }

        public boolean x(RecyclerView.t0 t0Var) {
            if (t0Var.m() != 3) {
                return true;
            }
            t0Var.f2105a.clearAnimation();
            t0Var.f2105a.animate().alpha(0.0f).setDuration(400).withLayer();
            return true;
        }
    }

    public class b extends AnimatorListenerAdapter {
        public b() {
        }

        public void onAnimationEnd(Animator animator) {
            e.this.f10882j = false;
        }
    }

    /* access modifiers changed from: private */
    public /* synthetic */ void N(ValueAnimator valueAnimator) {
        this.f10879g.getLayoutParams().height = ((Integer) valueAnimator.getAnimatedValue()).intValue();
        this.f10879g.requestLayout();
    }

    public void B(RecyclerView.t0 t0Var) {
        super.B(t0Var);
        if (t0Var.m() == 3) {
            t0Var.f2105a.clearAnimation();
            AlphaAnimation alphaAnimation = new AlphaAnimation(0.0f, 1.0f);
            alphaAnimation.setStartOffset(50);
            alphaAnimation.setDuration(400);
            t0Var.f2105a.startAnimation(alphaAnimation);
        }
    }

    public void L(boolean z10) {
        int i10;
        this.f10882j = true;
        this.f10879g.animate().cancel();
        if (z10) {
            i10 = this.f10877e + (this.f10876d * f10875k);
            this.f10878f = (this.f10881i.size() * this.f10876d) + i10;
        } else {
            i10 = this.f10879g.getMeasuredHeight();
            this.f10878f = (this.f10876d * f10875k) + this.f10877e;
        }
        ValueAnimator ofInt = ValueAnimator.ofInt(new int[]{i10, this.f10878f});
        ofInt.addUpdateListener(new d(this));
        ofInt.addListener(new b());
        ofInt.setInterpolator(new DecelerateInterpolator());
        ofInt.setDuration(400);
        ofInt.start();
    }

    public int M() {
        return this.f10878f;
    }

    public void O() {
        this.f10879g.setLayoutParams(new RelativeLayout.LayoutParams(-1, -2));
    }

    public int j() {
        if (this.f10880h.isEmpty()) {
            return 0;
        }
        return this.f10880h.size();
    }

    public void v(RecyclerView recyclerView) {
        super.v(recyclerView);
        recyclerView.setItemAnimator(new a());
    }
}
