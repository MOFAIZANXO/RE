package x6;

import com.samsung.android.sm.common.view.SmileLayout;

public final /* synthetic */ class m implements Runnable {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ SmileLayout f10890a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ int f10891b;

    public /* synthetic */ m(SmileLayout smileLayout, int i10) {
        this.f10890a = smileLayout;
        this.f10891b = i10;
    }

    public final void run() {
        this.f10890a.l(this.f10891b);
    }
}
