package x6;

import com.airbnb.lottie.f0;
import com.airbnb.lottie.h;
import com.samsung.android.sm.common.view.SmileLayout;

public final /* synthetic */ class j implements f0 {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ SmileLayout f10887a;

    public /* synthetic */ j(SmileLayout smileLayout) {
        this.f10887a = smileLayout;
    }

    public final void onResult(Object obj) {
        this.f10887a.n((h) obj);
    }
}
