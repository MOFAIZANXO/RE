package j6;

import a7.b;
import android.content.res.Resources;
import android.view.View;
import androidx.core.view.AccessibilityDelegateCompat;
import androidx.core.view.ViewCompat;
import androidx.core.view.accessibility.AccessibilityNodeInfoCompat;
import com.samsung.android.util.SemLog;

public class a {

    /* renamed from: j6.a$a  reason: collision with other inner class name */
    public class C0102a extends AccessibilityDelegateCompat {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ View f7443a;

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ Resources f7444b;

        /* renamed from: c  reason: collision with root package name */
        public final /* synthetic */ int f7445c;

        public C0102a(View view, Resources resources, int i10) {
            this.f7443a = view;
            this.f7444b = resources;
            this.f7445c = i10;
        }

        public void onInitializeAccessibilityNodeInfo(View view, AccessibilityNodeInfoCompat accessibilityNodeInfoCompat) {
            super.onInitializeAccessibilityNodeInfo(view, accessibilityNodeInfoCompat);
            if (view.getId() == this.f7443a.getId()) {
                try {
                    accessibilityNodeInfoCompat.getExtras().putString("viva", this.f7444b.getString(this.f7445c));
                } catch (Resources.NotFoundException e10) {
                    SemLog.w("PathLoggerViva", "error", e10);
                }
            }
        }
    }

    public void a(Resources resources, View view, int i10) {
        if (b.e("biXby") && resources != null && view != null && view.getId() != 0 && i10 >= 0) {
            ViewCompat.setAccessibilityDelegate(view, new C0102a(view, resources, i10));
        }
    }
}
