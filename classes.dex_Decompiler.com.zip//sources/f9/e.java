package f9;

import android.view.MenuItem;
import com.google.android.material.navigation.NavigationBarView;
import com.samsung.android.sm.routine.v3.actions.ui.RoutineProtectionBatteryActivity;

public final /* synthetic */ class e implements NavigationBarView.c {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ RoutineProtectionBatteryActivity f6305a;

    public /* synthetic */ e(RoutineProtectionBatteryActivity routineProtectionBatteryActivity) {
        this.f6305a = routineProtectionBatteryActivity;
    }

    public final boolean a(MenuItem menuItem) {
        return this.f6305a.L(menuItem);
    }
}
