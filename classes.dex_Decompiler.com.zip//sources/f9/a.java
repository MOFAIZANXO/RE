package f9;

import a7.b;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import androidx.fragment.app.Fragment;
import com.samsung.android.sm.common.ui.SelectableItemView;
import com.samsung.android.util.SemLog;
import v5.i;

public class a extends Fragment implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public Context f6293a;

    /* renamed from: b  reason: collision with root package name */
    public View f6294b;

    /* renamed from: f  reason: collision with root package name */
    public SelectableItemView f6295f;

    /* renamed from: g  reason: collision with root package name */
    public SelectableItemView f6296g;

    /* renamed from: h  reason: collision with root package name */
    public SelectableItemView f6297h;

    /* renamed from: i  reason: collision with root package name */
    public SelectableItemView f6298i;

    /* renamed from: j  reason: collision with root package name */
    public SelectableItemView f6299j;

    /* renamed from: k  reason: collision with root package name */
    public int f6300k;

    /* renamed from: l  reason: collision with root package name */
    public boolean f6301l;

    public final void A(ViewGroup viewGroup) {
        this.f6294b = LayoutInflater.from(this.f6293a).inflate(2131558516, viewGroup, false);
        B();
        H();
        I();
    }

    public final void B() {
        this.f6295f = (SelectableItemView) this.f6294b.findViewById(2131362619);
        this.f6296g = (SelectableItemView) this.f6294b.findViewById(2131362618);
        this.f6295f.setOnClickListener(this);
        this.f6296g.setOnClickListener(this);
        this.f6297h = (SelectableItemView) this.f6294b.findViewById(2131361993);
        this.f6298i = (SelectableItemView) this.f6294b.findViewById(2131361889);
        this.f6299j = (SelectableItemView) this.f6294b.findViewById(2131362446);
        this.f6297h.setOnClickListener(this);
        this.f6299j.setOnClickListener(this);
        if (i.q(this.f6293a)) {
            this.f6298i.setVisibility(0);
            this.f6298i.setOnClickListener(this);
            return;
        }
        this.f6298i.setVisibility(8);
    }

    public final void C() {
        this.f6297h.b(false);
        this.f6298i.b(true);
        this.f6299j.b(false);
    }

    public final void D() {
        this.f6297h.b(true);
        this.f6298i.b(false);
        this.f6299j.b(false);
    }

    public final void E() {
        this.f6297h.b(false);
        this.f6298i.b(false);
        this.f6299j.b(true);
    }

    public void F(boolean z10, int i10) {
        this.f6301l = z10;
        this.f6300k = i10;
    }

    public final void G(boolean z10) {
        this.f6297h.setEnabled(z10);
        this.f6297h.setClickable(z10);
        this.f6298i.setEnabled(z10);
        this.f6298i.setClickable(z10);
        this.f6299j.setEnabled(z10);
        this.f6299j.setClickable(z10);
    }

    public final void H() {
        this.f6295f.b(this.f6301l);
        this.f6296g.b(!this.f6301l);
        G(this.f6301l);
        int i10 = this.f6300k;
        if (i10 == 1) {
            E();
        } else if (i10 == 3) {
            D();
        } else if (i10 == 4) {
            C();
        }
    }

    public final void I() {
        this.f6295f.c("");
        this.f6296g.c("");
        boolean e10 = b.e("screen.res.tablet");
        int k10 = i.k(this.f6293a);
        SelectableItemView selectableItemView = this.f6297h;
        Context context = this.f6293a;
        selectableItemView.c(context.getString(2131951825, new Object[]{Integer.valueOf(i.e(context))}));
        this.f6298i.c(e10 ? this.f6293a.getString(2131951823) : this.f6293a.getString(2131951822));
        this.f6299j.c(this.f6293a.getString(2131951841, new Object[]{Integer.valueOf(k10)}));
    }

    public void onAttach(Context context) {
        super.onAttach(context);
        this.f6293a = context;
    }

    public void onClick(View view) {
        SemLog.d("RoutineBatteryProtectionFragment", "onClick");
        switch (view.getId()) {
            case 2131361889:
                this.f6300k = 4;
                break;
            case 2131361993:
                this.f6300k = 3;
                break;
            case 2131362446:
                this.f6300k = 1;
                break;
            case 2131362618:
                this.f6301l = false;
                break;
            case 2131362619:
                this.f6301l = true;
                break;
        }
        H();
    }

    public View onCreateView(LayoutInflater layoutInflater, ViewGroup viewGroup, Bundle bundle) {
        A(viewGroup);
        return this.f6294b;
    }

    public void onStart() {
        super.onStart();
        Log.i("RoutineBatteryProtectionFragment", "onStart");
    }

    public void onStop() {
        super.onStop();
        Log.i("RoutineBatteryProtectionFragment", "onStop");
    }

    public boolean y() {
        return this.f6301l;
    }

    public int z() {
        return this.f6300k;
    }
}
