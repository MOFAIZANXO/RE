package f9;

import android.view.View;
import com.samsung.android.sm.routine.v3.actions.ui.RoutineProtectionBatteryDialog;

public final /* synthetic */ class i implements View.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ RoutineProtectionBatteryDialog f6309a;

    /* renamed from: b  reason: collision with root package name */
    public final /* synthetic */ int f6310b;

    public /* synthetic */ i(RoutineProtectionBatteryDialog routineProtectionBatteryDialog, int i10) {
        this.f6309a = routineProtectionBatteryDialog;
        this.f6310b = i10;
    }

    public final void onClick(View view) {
        this.f6309a.Q(this.f6310b, view);
    }
}
