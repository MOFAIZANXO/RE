package f9;

import android.content.DialogInterface;
import com.samsung.android.sm.routine.v3.actions.ui.RoutineProtectionBatteryDialog;

public final /* synthetic */ class h implements DialogInterface.OnCancelListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ RoutineProtectionBatteryDialog f6308a;

    public /* synthetic */ h(RoutineProtectionBatteryDialog routineProtectionBatteryDialog) {
        this.f6308a = routineProtectionBatteryDialog;
    }

    public final void onCancel(DialogInterface dialogInterface) {
        this.f6308a.T(dialogInterface);
    }
}
