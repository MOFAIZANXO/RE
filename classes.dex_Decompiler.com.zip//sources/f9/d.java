package f9;

import android.content.DialogInterface;
import com.samsung.android.sm.routine.v3.actions.ui.RoutineProcessingSpeedActivity;

public final /* synthetic */ class d implements DialogInterface.OnCancelListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ RoutineProcessingSpeedActivity f6304a;

    public /* synthetic */ d(RoutineProcessingSpeedActivity routineProcessingSpeedActivity) {
        this.f6304a = routineProcessingSpeedActivity;
    }

    public final void onCancel(DialogInterface dialogInterface) {
        this.f6304a.Q(dialogInterface);
    }
}
