package f9;

import android.content.DialogInterface;
import com.samsung.android.sm.routine.v3.actions.ui.RoutineProcessingSpeedActivity;

public final /* synthetic */ class c implements DialogInterface.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ RoutineProcessingSpeedActivity f6303a;

    public /* synthetic */ c(RoutineProcessingSpeedActivity routineProcessingSpeedActivity) {
        this.f6303a = routineProcessingSpeedActivity;
    }

    public final void onClick(DialogInterface dialogInterface, int i10) {
        this.f6303a.P(dialogInterface, i10);
    }
}
