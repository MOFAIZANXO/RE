package f9;

import android.content.DialogInterface;
import com.samsung.android.sm.routine.v3.actions.ui.RoutineProtectionBatteryDialog;

public final /* synthetic */ class g implements DialogInterface.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ RoutineProtectionBatteryDialog f6307a;

    public /* synthetic */ g(RoutineProtectionBatteryDialog routineProtectionBatteryDialog) {
        this.f6307a = routineProtectionBatteryDialog;
    }

    public final void onClick(DialogInterface dialogInterface, int i10) {
        this.f6307a.S(dialogInterface, i10);
    }
}
