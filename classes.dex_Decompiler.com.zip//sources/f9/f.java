package f9;

import android.content.DialogInterface;
import com.samsung.android.sm.routine.v3.actions.ui.RoutineProtectionBatteryDialog;

public final /* synthetic */ class f implements DialogInterface.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ RoutineProtectionBatteryDialog f6306a;

    public /* synthetic */ f(RoutineProtectionBatteryDialog routineProtectionBatteryDialog) {
        this.f6306a = routineProtectionBatteryDialog;
    }

    public final void onClick(DialogInterface dialogInterface, int i10) {
        this.f6306a.R(dialogInterface, i10);
    }
}
