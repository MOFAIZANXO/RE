package f9;

import android.content.DialogInterface;
import com.samsung.android.sm.routine.v3.actions.ui.RoutineProcessingSpeedActivity;

public final /* synthetic */ class b implements DialogInterface.OnClickListener {

    /* renamed from: a  reason: collision with root package name */
    public final /* synthetic */ RoutineProcessingSpeedActivity f6302a;

    public /* synthetic */ b(RoutineProcessingSpeedActivity routineProcessingSpeedActivity) {
        this.f6302a = routineProcessingSpeedActivity;
    }

    public final void onClick(DialogInterface dialogInterface, int i10) {
        this.f6302a.O(dialogInterface, i10);
    }
}
