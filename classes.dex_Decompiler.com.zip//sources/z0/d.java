package z0;

import androidx.core.location.LocationRequestCompat;
import java.nio.channels.FileChannel;
import java.nio.channels.ReadableByteChannel;

public abstract class d {
    public static void a(ReadableByteChannel readableByteChannel, FileChannel fileChannel) {
        try {
            fileChannel.transferFrom(readableByteChannel, 0, LocationRequestCompat.PASSIVE_INTERVAL);
            fileChannel.force(false);
        } finally {
            readableByteChannel.close();
            fileChannel.close();
        }
    }
}
