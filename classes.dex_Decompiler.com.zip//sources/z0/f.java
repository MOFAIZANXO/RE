package z0;

import android.database.Cursor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class f {

    /* renamed from: a  reason: collision with root package name */
    public final String f11330a;

    /* renamed from: b  reason: collision with root package name */
    public final Map f11331b;

    /* renamed from: c  reason: collision with root package name */
    public final Set f11332c;

    /* renamed from: d  reason: collision with root package name */
    public final Set f11333d;

    public static class a {

        /* renamed from: a  reason: collision with root package name */
        public final String f11334a;

        /* renamed from: b  reason: collision with root package name */
        public final String f11335b;

        /* renamed from: c  reason: collision with root package name */
        public final int f11336c;

        /* renamed from: d  reason: collision with root package name */
        public final boolean f11337d;

        /* renamed from: e  reason: collision with root package name */
        public final int f11338e;

        /* renamed from: f  reason: collision with root package name */
        public final String f11339f;

        /* renamed from: g  reason: collision with root package name */
        public final int f11340g;

        public a(String str, String str2, boolean z10, int i10, String str3, int i11) {
            this.f11334a = str;
            this.f11335b = str2;
            this.f11337d = z10;
            this.f11338e = i10;
            this.f11336c = a(str2);
            this.f11339f = str3;
            this.f11340g = i11;
        }

        public static int a(String str) {
            if (str == null) {
                return 5;
            }
            String upperCase = str.toUpperCase(Locale.US);
            if (upperCase.contains("INT")) {
                return 3;
            }
            if (upperCase.contains("CHAR") || upperCase.contains("CLOB") || upperCase.contains("TEXT")) {
                return 2;
            }
            if (upperCase.contains("BLOB")) {
                return 5;
            }
            return (upperCase.contains("REAL") || upperCase.contains("FLOA") || upperCase.contains("DOUB")) ? 4 : 1;
        }

        public boolean equals(Object obj) {
            String str;
            String str2;
            String str3;
            if (this == obj) {
                return true;
            }
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            a aVar = (a) obj;
            if (this.f11338e != aVar.f11338e || !this.f11334a.equals(aVar.f11334a) || this.f11337d != aVar.f11337d) {
                return false;
            }
            if (this.f11340g == 1 && aVar.f11340g == 2 && (str3 = this.f11339f) != null && !str3.equals(aVar.f11339f)) {
                return false;
            }
            if (this.f11340g == 2 && aVar.f11340g == 1 && (str2 = aVar.f11339f) != null && !str2.equals(this.f11339f)) {
                return false;
            }
            int i10 = this.f11340g;
            if (i10 == 0 || i10 != aVar.f11340g || ((str = this.f11339f) == null ? aVar.f11339f == null : str.equals(aVar.f11339f))) {
                return this.f11336c == aVar.f11336c;
            }
            return false;
        }

        public int hashCode() {
            return (((((this.f11334a.hashCode() * 31) + this.f11336c) * 31) + (this.f11337d ? 1231 : 1237)) * 31) + this.f11338e;
        }

        public String toString() {
            return "Column{name='" + this.f11334a + '\'' + ", type='" + this.f11335b + '\'' + ", affinity='" + this.f11336c + '\'' + ", notNull=" + this.f11337d + ", primaryKeyPosition=" + this.f11338e + ", defaultValue='" + this.f11339f + '\'' + '}';
        }
    }

    public static class b {

        /* renamed from: a  reason: collision with root package name */
        public final String f11341a;

        /* renamed from: b  reason: collision with root package name */
        public final String f11342b;

        /* renamed from: c  reason: collision with root package name */
        public final String f11343c;

        /* renamed from: d  reason: collision with root package name */
        public final List f11344d;

        /* renamed from: e  reason: collision with root package name */
        public final List f11345e;

        public b(String str, String str2, String str3, List list, List list2) {
            this.f11341a = str;
            this.f11342b = str2;
            this.f11343c = str3;
            this.f11344d = Collections.unmodifiableList(list);
            this.f11345e = Collections.unmodifiableList(list2);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            b bVar = (b) obj;
            if (this.f11341a.equals(bVar.f11341a) && this.f11342b.equals(bVar.f11342b) && this.f11343c.equals(bVar.f11343c) && this.f11344d.equals(bVar.f11344d)) {
                return this.f11345e.equals(bVar.f11345e);
            }
            return false;
        }

        public int hashCode() {
            return (((((((this.f11341a.hashCode() * 31) + this.f11342b.hashCode()) * 31) + this.f11343c.hashCode()) * 31) + this.f11344d.hashCode()) * 31) + this.f11345e.hashCode();
        }

        public String toString() {
            return "ForeignKey{referenceTable='" + this.f11341a + '\'' + ", onDelete='" + this.f11342b + '\'' + ", onUpdate='" + this.f11343c + '\'' + ", columnNames=" + this.f11344d + ", referenceColumnNames=" + this.f11345e + '}';
        }
    }

    public static class c implements Comparable {

        /* renamed from: a  reason: collision with root package name */
        public final int f11346a;

        /* renamed from: b  reason: collision with root package name */
        public final int f11347b;

        /* renamed from: f  reason: collision with root package name */
        public final String f11348f;

        /* renamed from: g  reason: collision with root package name */
        public final String f11349g;

        public c(int i10, int i11, String str, String str2) {
            this.f11346a = i10;
            this.f11347b = i11;
            this.f11348f = str;
            this.f11349g = str2;
        }

        /* renamed from: a */
        public int compareTo(c cVar) {
            int i10 = this.f11346a - cVar.f11346a;
            return i10 == 0 ? this.f11347b - cVar.f11347b : i10;
        }
    }

    public static class d {

        /* renamed from: a  reason: collision with root package name */
        public final String f11350a;

        /* renamed from: b  reason: collision with root package name */
        public final boolean f11351b;

        /* renamed from: c  reason: collision with root package name */
        public final List f11352c;

        public d(String str, boolean z10, List list) {
            this.f11350a = str;
            this.f11351b = z10;
            this.f11352c = list;
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null || getClass() != obj.getClass()) {
                return false;
            }
            d dVar = (d) obj;
            if (this.f11351b == dVar.f11351b && this.f11352c.equals(dVar.f11352c)) {
                return this.f11350a.startsWith("index_") ? dVar.f11350a.startsWith("index_") : this.f11350a.equals(dVar.f11350a);
            }
            return false;
        }

        public int hashCode() {
            return ((((this.f11350a.startsWith("index_") ? -1184239155 : this.f11350a.hashCode()) * 31) + (this.f11351b ? 1 : 0)) * 31) + this.f11352c.hashCode();
        }

        public String toString() {
            return "Index{name='" + this.f11350a + '\'' + ", unique=" + this.f11351b + ", columns=" + this.f11352c + '}';
        }
    }

    public f(String str, Map map, Set set, Set set2) {
        this.f11330a = str;
        this.f11331b = Collections.unmodifiableMap(map);
        this.f11332c = Collections.unmodifiableSet(set);
        this.f11333d = set2 == null ? null : Collections.unmodifiableSet(set2);
    }

    public static f a(b1.b bVar, String str) {
        return new f(str, b(bVar, str), d(bVar, str), f(bVar, str));
    }

    public static Map b(b1.b bVar, String str) {
        Cursor Y = bVar.Y("PRAGMA table_info(`" + str + "`)");
        HashMap hashMap = new HashMap();
        try {
            if (Y.getColumnCount() > 0) {
                int columnIndex = Y.getColumnIndex("name");
                int columnIndex2 = Y.getColumnIndex("type");
                int columnIndex3 = Y.getColumnIndex("notnull");
                int columnIndex4 = Y.getColumnIndex("pk");
                int columnIndex5 = Y.getColumnIndex("dflt_value");
                while (Y.moveToNext()) {
                    String string = Y.getString(columnIndex);
                    hashMap.put(string, new a(string, Y.getString(columnIndex2), Y.getInt(columnIndex3) != 0, Y.getInt(columnIndex4), Y.getString(columnIndex5), 2));
                }
            }
            return hashMap;
        } finally {
            Y.close();
        }
    }

    public static List c(Cursor cursor) {
        int columnIndex = cursor.getColumnIndex("id");
        int columnIndex2 = cursor.getColumnIndex("seq");
        int columnIndex3 = cursor.getColumnIndex("from");
        int columnIndex4 = cursor.getColumnIndex("to");
        int count = cursor.getCount();
        ArrayList arrayList = new ArrayList();
        for (int i10 = 0; i10 < count; i10++) {
            cursor.moveToPosition(i10);
            arrayList.add(new c(cursor.getInt(columnIndex), cursor.getInt(columnIndex2), cursor.getString(columnIndex3), cursor.getString(columnIndex4)));
        }
        Collections.sort(arrayList);
        return arrayList;
    }

    public static Set d(b1.b bVar, String str) {
        HashSet hashSet = new HashSet();
        Cursor Y = bVar.Y("PRAGMA foreign_key_list(`" + str + "`)");
        try {
            int columnIndex = Y.getColumnIndex("id");
            int columnIndex2 = Y.getColumnIndex("seq");
            int columnIndex3 = Y.getColumnIndex("table");
            int columnIndex4 = Y.getColumnIndex("on_delete");
            int columnIndex5 = Y.getColumnIndex("on_update");
            List<c> c10 = c(Y);
            int count = Y.getCount();
            for (int i10 = 0; i10 < count; i10++) {
                Y.moveToPosition(i10);
                if (Y.getInt(columnIndex2) == 0) {
                    int i11 = Y.getInt(columnIndex);
                    ArrayList arrayList = new ArrayList();
                    ArrayList arrayList2 = new ArrayList();
                    for (c cVar : c10) {
                        if (cVar.f11346a == i11) {
                            arrayList.add(cVar.f11348f);
                            arrayList2.add(cVar.f11349g);
                        }
                    }
                    hashSet.add(new b(Y.getString(columnIndex3), Y.getString(columnIndex4), Y.getString(columnIndex5), arrayList, arrayList2));
                }
            }
            return hashSet;
        } finally {
            Y.close();
        }
    }

    /* JADX INFO: finally extract failed */
    public static d e(b1.b bVar, String str, boolean z10) {
        Cursor Y = bVar.Y("PRAGMA index_xinfo(`" + str + "`)");
        try {
            int columnIndex = Y.getColumnIndex("seqno");
            int columnIndex2 = Y.getColumnIndex("cid");
            int columnIndex3 = Y.getColumnIndex("name");
            if (!(columnIndex == -1 || columnIndex2 == -1)) {
                if (columnIndex3 != -1) {
                    TreeMap treeMap = new TreeMap();
                    while (Y.moveToNext()) {
                        if (Y.getInt(columnIndex2) >= 0) {
                            int i10 = Y.getInt(columnIndex);
                            treeMap.put(Integer.valueOf(i10), Y.getString(columnIndex3));
                        }
                    }
                    ArrayList arrayList = new ArrayList(treeMap.size());
                    arrayList.addAll(treeMap.values());
                    d dVar = new d(str, z10, arrayList);
                    Y.close();
                    return dVar;
                }
            }
            Y.close();
            return null;
        } catch (Throwable th) {
            Y.close();
            throw th;
        }
    }

    public static Set f(b1.b bVar, String str) {
        Cursor Y = bVar.Y("PRAGMA index_list(`" + str + "`)");
        try {
            int columnIndex = Y.getColumnIndex("name");
            int columnIndex2 = Y.getColumnIndex("origin");
            int columnIndex3 = Y.getColumnIndex("unique");
            if (!(columnIndex == -1 || columnIndex2 == -1)) {
                if (columnIndex3 != -1) {
                    HashSet hashSet = new HashSet();
                    while (Y.moveToNext()) {
                        if (com.google.android.material.navigation.c.W.equals(Y.getString(columnIndex2))) {
                            String string = Y.getString(columnIndex);
                            boolean z10 = true;
                            if (Y.getInt(columnIndex3) != 1) {
                                z10 = false;
                            }
                            d e10 = e(bVar, string, z10);
                            if (e10 == null) {
                                Y.close();
                                return null;
                            }
                            hashSet.add(e10);
                        }
                    }
                    Y.close();
                    return hashSet;
                }
            }
            return null;
        } finally {
            Y.close();
        }
    }

    public boolean equals(Object obj) {
        Set set;
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        f fVar = (f) obj;
        String str = this.f11330a;
        if (str == null ? fVar.f11330a != null : !str.equals(fVar.f11330a)) {
            return false;
        }
        Map map = this.f11331b;
        if (map == null ? fVar.f11331b != null : !map.equals(fVar.f11331b)) {
            return false;
        }
        Set set2 = this.f11332c;
        if (set2 == null ? fVar.f11332c != null : !set2.equals(fVar.f11332c)) {
            return false;
        }
        Set set3 = this.f11333d;
        if (set3 == null || (set = fVar.f11333d) == null) {
            return true;
        }
        return set3.equals(set);
    }

    public int hashCode() {
        String str = this.f11330a;
        int i10 = 0;
        int hashCode = (str != null ? str.hashCode() : 0) * 31;
        Map map = this.f11331b;
        int hashCode2 = (hashCode + (map != null ? map.hashCode() : 0)) * 31;
        Set set = this.f11332c;
        if (set != null) {
            i10 = set.hashCode();
        }
        return hashCode2 + i10;
    }

    public String toString() {
        return "TableInfo{name='" + this.f11330a + '\'' + ", columns=" + this.f11331b + ", foreignKeys=" + this.f11332c + ", indices=" + this.f11333d + '}';
    }
}
