package z0;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class a {

    /* renamed from: e  reason: collision with root package name */
    public static final Map f11324e = new HashMap();

    /* renamed from: a  reason: collision with root package name */
    public final File f11325a;

    /* renamed from: b  reason: collision with root package name */
    public final Lock f11326b;

    /* renamed from: c  reason: collision with root package name */
    public final boolean f11327c;

    /* renamed from: d  reason: collision with root package name */
    public FileChannel f11328d;

    public a(String str, File file, boolean z10) {
        File file2 = new File(file, str + ".lck");
        this.f11325a = file2;
        this.f11326b = a(file2.getAbsolutePath());
        this.f11327c = z10;
    }

    public static Lock a(String str) {
        Lock lock;
        Map map = f11324e;
        synchronized (map) {
            lock = (Lock) map.get(str);
            if (lock == null) {
                lock = new ReentrantLock();
                map.put(str, lock);
            }
        }
        return lock;
    }

    public void b() {
        this.f11326b.lock();
        if (this.f11327c) {
            try {
                FileChannel channel = new FileOutputStream(this.f11325a).getChannel();
                this.f11328d = channel;
                channel.lock();
            } catch (IOException e10) {
                throw new IllegalStateException("Unable to grab copy lock.", e10);
            }
        }
    }

    public void c() {
        FileChannel fileChannel = this.f11328d;
        if (fileChannel != null) {
            try {
                fileChannel.close();
            } catch (IOException unused) {
            }
        }
        this.f11326b.unlock();
    }
}
