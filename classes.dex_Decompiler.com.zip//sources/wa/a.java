package wa;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import gb.e;
import java.util.Map;

public class a {

    /* renamed from: a  reason: collision with root package name */
    public final Context f10650a;

    public a(Context context) {
        this.f10650a = context;
    }

    public void a(Map map) {
        map.remove("t");
        SharedPreferences b10 = e.b(this.f10650a);
        for (Map.Entry entry : map.entrySet()) {
            if (TextUtils.isEmpty((CharSequence) entry.getValue())) {
                b10.edit().remove((String) entry.getKey()).apply();
            } else {
                b10.edit().putString((String) entry.getKey(), (String) entry.getValue()).apply();
            }
        }
    }
}
