package wa;

import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import gb.a;
import gb.e;
import gb.f;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import ra.c;
import ya.d;

public class b {

    /* renamed from: a  reason: collision with root package name */
    public final Context f10651a;

    /* renamed from: b  reason: collision with root package name */
    public final c f10652b;

    public b(Context context, c cVar) {
        this.f10651a = context;
        this.f10652b = cVar;
    }

    public final boolean a(Context context, String str) {
        String string = e.a(context).getString("property_data", "");
        long j10 = e.a(context).getLong("property_sent_date", 0);
        if (!string.equals(str) || f.b(1, Long.valueOf(j10))) {
            e.a(context).edit().putString("property_data", str).apply();
            e.a(context).edit().putLong("property_sent_date", System.currentTimeMillis()).apply();
            gb.c.f("update property, send it");
            return true;
        }
        gb.c.a("do not send property < 1day");
        return false;
    }

    public void b() {
        int i10;
        Uri uri;
        boolean a10 = this.f10652b.g().a();
        if (f.l(this.f10651a) || a10) {
            Map<String, ?> all = e.b(this.f10651a).getAll();
            if (all == null || all.isEmpty()) {
                gb.c.b("PropertyLogBuildClient", "No Property log");
                return;
            }
            if (this.f10652b.i()) {
                f.r(this.f10651a, this.f10652b);
            }
            String o10 = f.o(va.c.a(all), f.b.TWO_DEPTH);
            if (a(this.f10651a, a.a(o10))) {
                gb.c.f("Send Property Log");
                HashMap hashMap = new HashMap();
                String valueOf = String.valueOf(System.currentTimeMillis());
                hashMap.put("ts", valueOf);
                hashMap.put("t", "pp");
                hashMap.put("cp", o10);
                if (va.b.e() >= 3) {
                    hashMap.put("v", ra.b.f9596b);
                    hashMap.put("tz", String.valueOf(TimeUnit.MILLISECONDS.toMinutes((long) TimeZone.getDefault().getRawOffset())));
                    ContentValues contentValues = new ContentValues();
                    contentValues.put("tcType", Integer.valueOf(this.f10652b.k() ? 1 : 0));
                    contentValues.put("tid", this.f10652b.f());
                    contentValues.put("logType", ya.c.UIX.a());
                    contentValues.put("timeStamp", valueOf);
                    contentValues.put("agree", Integer.valueOf(a10 ? 1 : 0));
                    contentValues.put("body", f.o(hashMap, f.b.ONE_DEPTH));
                    if (!f.m(this.f10651a)) {
                        f.a(this.f10651a, contentValues, this.f10652b);
                    }
                    if (f.f(this.f10651a)) {
                        contentValues.put("networkType", Integer.valueOf(this.f10652b.e()));
                    }
                    try {
                        uri = this.f10651a.getContentResolver().insert(Uri.parse("content://com.sec.android.log.diagmonagent.sa/log"), contentValues);
                    } catch (IllegalArgumentException e10) {
                        gb.c.h("failed to send properties" + e10.getMessage());
                        uri = null;
                    }
                    if (uri == null) {
                        gb.c.a("Property send fail");
                        return;
                    }
                    i10 = Integer.parseInt(uri.getLastPathSegment());
                } else {
                    i10 = d.a(this.f10651a, va.b.e(), this.f10652b).a(hashMap);
                }
                gb.c.f("Send Property Log Result = " + i10);
                return;
            }
            return;
        }
        gb.c.a("user do not agree Property");
    }
}
