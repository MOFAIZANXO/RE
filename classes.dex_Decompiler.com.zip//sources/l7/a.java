package l7;

import a7.b;
import android.content.Context;
import android.os.StatFs;
import android.util.Log;
import com.samsung.android.util.SemLog;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;
import n7.g;

public class a {

    /* renamed from: a  reason: collision with root package name */
    public C0110a f7897a = C0110a.SUCCESS;

    /* renamed from: l7.a$a  reason: collision with other inner class name */
    public enum C0110a {
        SUCCESS(0),
        UNKNOWN_ERROR(1),
        STORAGE_FULL(2),
        INVALID_DATA(3),
        PERMISSION_FAIL(4),
        DB_COMP_ERROR(5);
        

        /* renamed from: a  reason: collision with root package name */
        public int f7905a;

        /* access modifiers changed from: public */
        C0110a(int i10) {
            this.f7905a = i10;
        }

        public int b() {
            return this.f7905a;
        }
    }

    public boolean a() {
        boolean e10 = b.e("user.owner");
        SemLog.d("BnrHelper", "canBackupAndRestore() : " + e10);
        this.f7897a = e10 ? this.f7897a : C0110a.DB_COMP_ERROR;
        return e10;
    }

    public boolean b(String str, int i10, String str2, String str3, String str4) {
        FileOutputStream fileOutputStream;
        this.f7897a = C0110a.SUCCESS;
        long e10 = e(str2);
        if (e10 < 10485760) {
            SemLog.d("BnrHelper", "freeSpaceInBytes = " + e10);
            this.f7897a = C0110a.STORAGE_FULL;
            return false;
        }
        SemLog.d("BnrHelper", "ENCRYPTED_FILE_PATH = " + str4);
        try {
            FileInputStream fileInputStream = new FileInputStream(str4);
            try {
                InputStream a10 = new b().a(fileInputStream, str, i10);
                try {
                    fileOutputStream = new FileOutputStream(new File(str3));
                    byte[] bArr = new byte[1024];
                    if (a10 != null) {
                        while (true) {
                            int read = a10.read(bArr);
                            if (read > 0) {
                                fileOutputStream.write(bArr, 0, read);
                            } else {
                                fileOutputStream.close();
                                a10.close();
                                fileInputStream.close();
                                return true;
                            }
                        }
                    } else {
                        fileOutputStream.close();
                        if (a10 != null) {
                            a10.close();
                        }
                        fileInputStream.close();
                        return false;
                    }
                } catch (Throwable th) {
                    if (a10 != null) {
                        a10.close();
                    }
                    throw th;
                }
            } catch (Throwable th2) {
                fileInputStream.close();
                throw th2;
            }
        } catch (Exception e11) {
            Log.w("BnrHelper", "decryptBackUpFile err", e11);
            this.f7897a = C0110a.INVALID_DATA;
            return false;
        } catch (Throwable th3) {
            th2.addSuppressed(th3);
        }
        throw th;
    }

    /* JADX WARNING: Removed duplicated region for block: B:34:0x008b A[SYNTHETIC, Splitter:B:34:0x008b] */
    /* JADX WARNING: Removed duplicated region for block: B:40:0x0097  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean c(java.lang.String r10, int r11, java.lang.String r12, java.lang.String r13) {
        /*
            r9 = this;
            java.lang.String r0 = "Failed to delete backup file : "
            java.io.File r1 = new java.io.File
            r1.<init>(r12)
            java.io.File r12 = new java.io.File
            r12.<init>(r13)
            java.io.File r13 = r12.getParentFile()
            r2 = 0
            java.lang.String r3 = "BnrHelper"
            r4 = 1
            if (r13 == 0) goto L_0x005a
            java.io.File r13 = r12.getParentFile()
            boolean r13 = r13.exists()
            if (r13 != 0) goto L_0x0029
            java.io.File r13 = r12.getParentFile()
            boolean r13 = r13.mkdirs()
            goto L_0x002a
        L_0x0029:
            r13 = r4
        L_0x002a:
            if (r13 != 0) goto L_0x0036
            java.lang.String r10 = "It couldn't make encryptBackUpFile"
            android.util.Log.w(r3, r10)
            l7.a$a r10 = l7.a.C0110a.UNKNOWN_ERROR
            r9.f7897a = r10
            return r2
        L_0x0036:
            boolean r13 = r12.exists()
            if (r13 == 0) goto L_0x005a
            boolean r13 = r12.delete()
            if (r13 != 0) goto L_0x005a
            java.lang.StringBuilder r13 = new java.lang.StringBuilder
            r13.<init>()
            java.lang.String r5 = "Encrypt file already exists. But failed to delete it : "
            r13.append(r5)
            java.lang.String r5 = r12.getPath()
            r13.append(r5)
            java.lang.String r13 = r13.toString()
            android.util.Log.w(r3, r13)
        L_0x005a:
            java.io.FileOutputStream r13 = new java.io.FileOutputStream     // Catch:{ Exception -> 0x00da }
            r13.<init>(r12)     // Catch:{ Exception -> 0x00da }
            l7.b r12 = new l7.b     // Catch:{ all -> 0x00ce }
            r12.<init>()     // Catch:{ all -> 0x00ce }
            java.io.OutputStream r10 = r12.b(r13, r10, r11)     // Catch:{ all -> 0x00ce }
            java.io.FileInputStream r11 = new java.io.FileInputStream     // Catch:{ all -> 0x00c2 }
            r11.<init>(r1)     // Catch:{ all -> 0x00c2 }
            java.io.BufferedInputStream r12 = new java.io.BufferedInputStream     // Catch:{ all -> 0x00b8 }
            r12.<init>(r11)     // Catch:{ all -> 0x00b8 }
            r5 = 1024(0x400, float:1.435E-42)
            byte[] r6 = new byte[r5]     // Catch:{ all -> 0x00ae }
            if (r10 == 0) goto L_0x0083
        L_0x0078:
            int r7 = r12.read(r6, r2, r5)     // Catch:{ all -> 0x00ae }
            r8 = -1
            if (r7 == r8) goto L_0x0083
            r10.write(r6, r2, r7)     // Catch:{ all -> 0x00ae }
            goto L_0x0078
        L_0x0083:
            r12.close()     // Catch:{ all -> 0x00b8 }
            r11.close()     // Catch:{ all -> 0x00c2 }
            if (r10 == 0) goto L_0x008e
            r10.close()     // Catch:{ all -> 0x00ce }
        L_0x008e:
            r13.close()     // Catch:{ Exception -> 0x00da }
            boolean r9 = r1.delete()
            if (r9 != 0) goto L_0x00ad
            java.lang.StringBuilder r9 = new java.lang.StringBuilder
            r9.<init>()
            r9.append(r0)
            java.lang.String r10 = r1.getPath()
            r9.append(r10)
            java.lang.String r9 = r9.toString()
            android.util.Log.w(r3, r9)
        L_0x00ad:
            return r4
        L_0x00ae:
            r4 = move-exception
            r12.close()     // Catch:{ all -> 0x00b3 }
            goto L_0x00b7
        L_0x00b3:
            r12 = move-exception
            r4.addSuppressed(r12)     // Catch:{ all -> 0x00b8 }
        L_0x00b7:
            throw r4     // Catch:{ all -> 0x00b8 }
        L_0x00b8:
            r12 = move-exception
            r11.close()     // Catch:{ all -> 0x00bd }
            goto L_0x00c1
        L_0x00bd:
            r11 = move-exception
            r12.addSuppressed(r11)     // Catch:{ all -> 0x00c2 }
        L_0x00c1:
            throw r12     // Catch:{ all -> 0x00c2 }
        L_0x00c2:
            r11 = move-exception
            if (r10 == 0) goto L_0x00cd
            r10.close()     // Catch:{ all -> 0x00c9 }
            goto L_0x00cd
        L_0x00c9:
            r10 = move-exception
            r11.addSuppressed(r10)     // Catch:{ all -> 0x00ce }
        L_0x00cd:
            throw r11     // Catch:{ all -> 0x00ce }
        L_0x00ce:
            r10 = move-exception
            r13.close()     // Catch:{ all -> 0x00d3 }
            goto L_0x00d7
        L_0x00d3:
            r11 = move-exception
            r10.addSuppressed(r11)     // Catch:{ Exception -> 0x00da }
        L_0x00d7:
            throw r10     // Catch:{ Exception -> 0x00da }
        L_0x00d8:
            r9 = move-exception
            goto L_0x0101
        L_0x00da:
            r10 = move-exception
            java.lang.String r11 = "encryptBackUpFile err"
            android.util.Log.w(r3, r11, r10)     // Catch:{ all -> 0x00d8 }
            l7.a$a r10 = l7.a.C0110a.UNKNOWN_ERROR     // Catch:{ all -> 0x00d8 }
            r9.f7897a = r10     // Catch:{ all -> 0x00d8 }
            boolean r9 = r1.delete()
            if (r9 != 0) goto L_0x0100
            java.lang.StringBuilder r9 = new java.lang.StringBuilder
            r9.<init>()
            r9.append(r0)
            java.lang.String r10 = r1.getPath()
            r9.append(r10)
            java.lang.String r9 = r9.toString()
            android.util.Log.w(r3, r9)
        L_0x0100:
            return r2
        L_0x0101:
            boolean r10 = r1.delete()
            if (r10 != 0) goto L_0x011d
            java.lang.StringBuilder r10 = new java.lang.StringBuilder
            r10.<init>()
            r10.append(r0)
            java.lang.String r11 = r1.getPath()
            r10.append(r11)
            java.lang.String r10 = r10.toString()
            android.util.Log.w(r3, r10)
        L_0x011d:
            throw r9
        */
        throw new UnsupportedOperationException("Method not decompiled: l7.a.c(java.lang.String, int, java.lang.String, java.lang.String):boolean");
    }

    /* JADX WARNING: Removed duplicated region for block: B:25:0x0053  */
    /* JADX WARNING: Removed duplicated region for block: B:26:0x0056  */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean d(android.content.Context r7, java.lang.String r8) {
        /*
            r6 = this;
            n7.g r0 = new n7.g
            r0.<init>()
            java.util.List r0 = r0.a()
            r1 = 0
            p7.b r2 = new p7.b     // Catch:{ IOException | IllegalArgumentException | IllegalStateException -> 0x0049 }
            java.io.FileWriter r3 = new java.io.FileWriter     // Catch:{ IOException | IllegalArgumentException | IllegalStateException -> 0x0049 }
            java.io.File r4 = new java.io.File     // Catch:{ IOException | IllegalArgumentException | IllegalStateException -> 0x0049 }
            r4.<init>(r8)     // Catch:{ IOException | IllegalArgumentException | IllegalStateException -> 0x0049 }
            r3.<init>(r4)     // Catch:{ IOException | IllegalArgumentException | IllegalStateException -> 0x0049 }
            r2.<init>(r3)     // Catch:{ IOException | IllegalArgumentException | IllegalStateException -> 0x0049 }
            java.util.Iterator r8 = r0.iterator()     // Catch:{ all -> 0x003f }
            r0 = 1
        L_0x001e:
            r3 = r0
        L_0x001f:
            boolean r4 = r8.hasNext()     // Catch:{ all -> 0x003f }
            if (r4 == 0) goto L_0x003a
            java.lang.Object r4 = r8.next()     // Catch:{ all -> 0x003f }
            n7.a r4 = (n7.a) r4     // Catch:{ all -> 0x003f }
            java.lang.Object r5 = r4.d(r7)     // Catch:{ all -> 0x003f }
            boolean r4 = r4.a(r2, r5)     // Catch:{ all -> 0x003f }
            if (r4 == 0) goto L_0x0038
            if (r3 == 0) goto L_0x0038
            goto L_0x001e
        L_0x0038:
            r3 = r1
            goto L_0x001f
        L_0x003a:
            r2.close()     // Catch:{ IOException | IllegalArgumentException | IllegalStateException -> 0x0049 }
            r1 = r3
            goto L_0x0051
        L_0x003f:
            r7 = move-exception
            r2.close()     // Catch:{ all -> 0x0044 }
            goto L_0x0048
        L_0x0044:
            r8 = move-exception
            r7.addSuppressed(r8)     // Catch:{ IOException | IllegalArgumentException | IllegalStateException -> 0x0049 }
        L_0x0048:
            throw r7     // Catch:{ IOException | IllegalArgumentException | IllegalStateException -> 0x0049 }
        L_0x0049:
            r7 = move-exception
            java.lang.String r8 = "BnrHelper"
            java.lang.String r0 = "backup err"
            android.util.Log.w(r8, r0, r7)
        L_0x0051:
            if (r1 == 0) goto L_0x0056
            l7.a$a r7 = r6.f7897a
            goto L_0x0058
        L_0x0056:
            l7.a$a r7 = l7.a.C0110a.INVALID_DATA
        L_0x0058:
            r6.f7897a = r7
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: l7.a.d(android.content.Context, java.lang.String):boolean");
    }

    public final long e(String str) {
        try {
            StatFs statFs = new StatFs(str);
            return statFs.getAvailableBlocksLong() * statFs.getBlockSizeLong();
        } catch (IllegalArgumentException e10) {
            Log.w("BnrHelper", "getFreeSpace err", e10);
            return 0;
        }
    }

    public o7.a f(boolean z10, int i10, String str, String str2) {
        o7.a aVar = new o7.a();
        if (i10 == 0) {
            aVar.f8633a = "com.samsung.android.intent.action.RESPONSE_BACKUP_SMARTMANAGER";
        } else if (i10 == 2) {
            aVar.f8633a = "com.samsung.android.intent.action.RESPONSE_RESTORE_SMARTMANAGER";
        }
        if (z10) {
            aVar.f8634b = 0;
        } else {
            aVar.f8634b = 1;
        }
        aVar.f8637e = this.f7897a.b();
        aVar.f8638f = 524288000;
        aVar.f8635c = str;
        aVar.f8636d = str2;
        return aVar;
    }

    public boolean g(String str, String str2) {
        SemLog.d("BnrHelper", "hasEnoughSpaceToBackup()");
        File file = new File(str2);
        File parentFile = file.getParentFile();
        if (parentFile != null) {
            if (!(!parentFile.exists() ? parentFile.mkdirs() : true)) {
                SemLog.w("BnrHelper", "It fails to create parent folder : " + str2);
                this.f7897a = C0110a.UNKNOWN_ERROR;
                return false;
            } else if (file.exists()) {
                boolean delete = file.delete();
                SemLog.d("BnrHelper", "delete file : " + delete);
            }
        }
        long e10 = e(str);
        if (e10 >= 524288000) {
            return true;
        }
        SemLog.d("BnrHelper", "freeSpaceInBytes = " + e10);
        this.f7897a = C0110a.STORAGE_FULL;
        return false;
    }

    public boolean h(Context context, String str) {
        boolean z10;
        List a10 = new g().a();
        p7.a aVar = new p7.a(str);
        try {
            Iterator it = a10.iterator();
            loop0:
            while (true) {
                z10 = true;
                while (true) {
                    if (!it.hasNext()) {
                        break loop0;
                    }
                    n7.a aVar2 = (n7.a) it.next();
                    if (!aVar2.c(context, aVar2.b(aVar)) || !z10) {
                        z10 = false;
                    }
                }
            }
            aVar.close();
            this.f7897a = z10 ? this.f7897a : C0110a.INVALID_DATA;
            return z10;
        } catch (Throwable th) {
            th.addSuppressed(th);
        }
        throw th;
    }
}
