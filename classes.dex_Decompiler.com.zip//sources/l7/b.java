package l7;

import android.util.Log;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

public class b {

    /* renamed from: a  reason: collision with root package name */
    public final SecureRandom f7906a = new SecureRandom();

    /* renamed from: b  reason: collision with root package name */
    public final SecureRandom f7907b = new SecureRandom();

    public InputStream a(InputStream inputStream, String str, int i10) {
        CipherInputStream cipherInputStream;
        try {
            Cipher instance = Cipher.getInstance("AES/CBC/PKCS5Padding");
            byte[] bArr = new byte[instance.getBlockSize()];
            if (inputStream.read(bArr) != -1) {
                IvParameterSpec ivParameterSpec = new IvParameterSpec(bArr);
                if (i10 == 1) {
                    byte[] bArr2 = new byte[16];
                    if (inputStream.read(bArr2) != -1) {
                        instance.init(2, d(bArr2, str), ivParameterSpec);
                        cipherInputStream = new CipherInputStream(inputStream, instance);
                    } else {
                        Log.w("EncryptionStream", "no in data");
                        return null;
                    }
                } else {
                    instance.init(2, e(str), ivParameterSpec);
                    cipherInputStream = new CipherInputStream(inputStream, instance);
                }
                return cipherInputStream;
            }
            Log.w("EncryptionStream", "no iv data");
            return null;
        } catch (Exception e10) {
            Log.w("EncryptionStream", "decryptStream err", e10);
            return null;
        }
    }

    public OutputStream b(OutputStream outputStream, String str, int i10) {
        SecretKeySpec secretKeySpec;
        try {
            Cipher instance = Cipher.getInstance("AES/CBC/PKCS5Padding");
            byte[] bArr = new byte[instance.getBlockSize()];
            this.f7906a.nextBytes(bArr);
            IvParameterSpec ivParameterSpec = new IvParameterSpec(bArr);
            if (i10 == 1) {
                byte[] c10 = c();
                outputStream.write(bArr);
                outputStream.write(c10);
                secretKeySpec = d(c10, str);
            } else {
                outputStream.write(bArr);
                secretKeySpec = e(str);
            }
            instance.init(1, secretKeySpec, ivParameterSpec);
            return new CipherOutputStream(outputStream, instance);
        } catch (Exception e10) {
            Log.w("EncryptionStream", "encryptStream err", e10);
            return null;
        }
    }

    public final byte[] c() {
        byte[] bArr = new byte[16];
        this.f7907b.nextBytes(bArr);
        return bArr;
    }

    public final SecretKeySpec d(byte[] bArr, String str) {
        try {
            return new SecretKeySpec(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(new PBEKeySpec(str.toCharArray(), bArr, 1000, 256)).getEncoded(), "AES");
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e10) {
            Log.w("EncryptionStream", "generatePBKDF2SecretKey err", e10);
            return null;
        }
    }

    public final SecretKeySpec e(String str) {
        MessageDigest instance = MessageDigest.getInstance("SHA-256");
        instance.update(str.getBytes(StandardCharsets.UTF_8));
        byte[] bArr = new byte[16];
        System.arraycopy(instance.digest(), 0, bArr, 0, 16);
        return new SecretKeySpec(bArr, "AES");
    }
}
